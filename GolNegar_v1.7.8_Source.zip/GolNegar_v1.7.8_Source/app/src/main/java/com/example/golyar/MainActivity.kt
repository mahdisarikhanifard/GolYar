package com.example.golyar

import android.app.AlertDialog
import android.app.Dialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Context
import android.util.Base64
import android.net.ConnectivityManager
import android.net.Network
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.widget.FrameLayout
import android.widget.*
import androidx.core.view.WindowCompat
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestore
import androidx.activity.OnBackPressedCallback
import java.text.NumberFormat
import java.text.Collator
import kotlin.math.abs
import java.util.Calendar
import java.util.Date
import java.util.ArrayDeque
import java.util.Locale
import java.util.UUID
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.SecretKey
import org.json.JSONObject
import org.json.JSONArray
import android.net.Uri
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.File

private class SecureCredentialStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("golnegar_secure_credentials", Context.MODE_PRIVATE)
    private val alias = "GolNegarCredentialKey"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(alias, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
            alias,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return generator.generateKey()
    }

    fun put(name: String, value: String) {
        if (value.isEmpty()) return
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val data = Base64.encodeToString(cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        prefs.edit().putString(name + "_iv", iv).putString(name + "_data", data).apply()
    }

    fun remove(name: String) {
        prefs.edit().remove(name + "_iv").remove(name + "_data").apply()
    }

    fun removeByPrefixes(prefixes: List<String>) {
        val editor = prefs.edit()
        prefs.all.keys.forEach { storedKey ->
            val logicalKey = storedKey.removeSuffix("_iv").removeSuffix("_data")
            if (prefixes.any { logicalKey.startsWith(it) }) editor.remove(storedKey)
        }
        editor.apply()
    }

    fun get(name: String): String? {
        return try {
            val iv = prefs.getString(name + "_iv", null) ?: return null
            val data = prefs.getString(name + "_data", null) ?: return null
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(data, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }
}

class MainActivity : AppCompatActivity() {
    private data class UiPalette(
        val id: String, val name: String, val background: Int, val surface: Int,
        val primary: Int, val accent: Int, val text: Int, val muted: Int, val border: Int
    )

    // Theme preferences are deliberately scoped by account edition: greenhouse/admin,
    // seller, and greenhouse staff each retain their own appearance on this device.
    private fun themeScope(): String = when {
        db.isSellerMode() -> "seller"
        db.isStaffMode() -> "staff"
        else -> "admin"
    }

    private val themePrefs by lazy { getSharedPreferences("golnegar_ui_themes", Context.MODE_PRIVATE) }

    private val builtInThemes = listOf(
        UiPalette("rose", "باغ رز", Color.parseColor("#FFF0F5"), Color.parseColor("#FFFFFE"), Color.parseColor("#C2185B"), Color.parseColor("#FF4081"), Color.parseColor("#3D1028"), Color.parseColor("#81536B"), Color.parseColor("#F3A9C8")),
        UiPalette("emerald", "سبز گلخانه", Color.parseColor("#EAF7ED"), Color.parseColor("#FCFFFC"), Color.parseColor("#08783E"), Color.parseColor("#42C477"), Color.parseColor("#103D25"), Color.parseColor("#4E735C"), Color.parseColor("#9BD9AE")),
        UiPalette("ocean", "آبی اقیانوسی", Color.parseColor("#EAF5FF"), Color.parseColor("#FCFEFF"), Color.parseColor("#075AA8"), Color.parseColor("#22A6F2"), Color.parseColor("#102F4D"), Color.parseColor("#4D6C88"), Color.parseColor("#9CCFF2")),
        UiPalette("lavender", "بنفش اسطوخودوسی", Color.parseColor("#F2ECFF"), Color.parseColor("#FFFDFF"), Color.parseColor("#673AB7"), Color.parseColor("#B388FF"), Color.parseColor("#2E174A"), Color.parseColor("#716087"), Color.parseColor("#C6B0F3")),
        UiPalette("sunset", "غروب گرم", Color.parseColor("#FFF0E4"), Color.parseColor("#FFFEFB"), Color.parseColor("#C64B0C"), Color.parseColor("#FF9D28"), Color.parseColor("#4C2412"), Color.parseColor("#86604A"), Color.parseColor("#F3B88B")),
        UiPalette("teal", "فیروزه‌ای", Color.parseColor("#E4F8F6"), Color.parseColor("#FBFFFF"), Color.parseColor("#00796B"), Color.parseColor("#26C6B8"), Color.parseColor("#103B39"), Color.parseColor("#4D7773"), Color.parseColor("#8DDDD5"))
    )

    private fun mixColor(from: Int, to: Int, amount: Float): Int {
        val a = amount.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(from) * (1 - a) + Color.red(to) * a).toInt(),
            (Color.green(from) * (1 - a) + Color.green(to) * a).toInt(),
            (Color.blue(from) * (1 - a) + Color.blue(to) * a).toInt()
        )
    }

    private fun palette(): UiPalette {
        val id = themePrefs.getString("theme_${themeScope()}", "rose") ?: "rose"
        val base = builtInThemes.firstOrNull { it.id == id } ?: builtInThemes.first()
        val custom = themePrefs.getInt("accent_${themeScope()}", 0)
        // A custom color now drives the primary controls, card borders, highlights,
        // and the page tint instead of changing only a few text labels.
        return if (custom == 0) base else base.copy(
            primary = custom,
            accent = mixColor(custom, Color.WHITE, 0.27f),
            border = mixColor(custom, base.background, 0.48f)
        )
    }

    private fun themeGradient(): GradientDrawable {
        val p = palette()
        val tint = mixColor(p.primary, p.background, 0.90f)
        val direction = when (p.id) {
            "emerald" -> GradientDrawable.Orientation.TL_BR
            "ocean" -> GradientDrawable.Orientation.LEFT_RIGHT
            "lavender" -> GradientDrawable.Orientation.TR_BL
            "sunset" -> GradientDrawable.Orientation.BOTTOM_TOP
            "teal" -> GradientDrawable.Orientation.BR_TL
            else -> GradientDrawable.Orientation.TOP_BOTTOM
        }
        return GradientDrawable(direction, intArrayOf(p.background, tint, p.background)).apply {
            cornerRadius = dp(18).toFloat()
        }
    }

    private fun themeCardBackground(): GradientDrawable {
        val p = palette()
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(mixColor(p.accent, p.surface, 0.82f), p.surface, p.surface)
        ).apply {
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), mixColor(p.primary, p.surface, 0.48f))
        }
    }

    private fun showThemeSettings() {
        val scopeLabel = when (themeScope()) { "seller" -> "فروشنده"; "staff" -> "کاربر گلخانه"; else -> "مدیر گلخانه" }
        val root = base("تم و رنگ‌ها", "رنگ‌ها، گرادیان‌ها و کارت‌های برنامه را مطابق سلیقه‌تان انتخاب کنید")
        root.addView(sectionTitle("🎨 تم‌های آماده"))
        root.addView(cardText("تنظیمات ظاهر برای نسخهٔ «$scopeLabel» جداگانه ذخیره می‌شود و روی ظاهر نسخه‌های دیگر اثر نمی‌گذارد."))
        builtInThemes.forEach { item ->
            val active = palette().id == item.id && themePrefs.getInt("accent_${themeScope()}", 0) == 0
            val button = actionButton("${if (active) "✓  " else ""}${item.name}   ●") { 
                themePrefs.edit().putString("theme_${themeScope()}", item.id).remove("accent_${themeScope()}").apply()
                info("تم «${item.name}» برای نسخهٔ $scopeLabel ذخیره شد.") { showHome() }
            }
            button.setTextColor(Color.WHITE)
            button.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(item.primary, item.accent)).apply {
                cornerRadius = dp(16).toFloat(); setStroke(dp(if (active) 3 else 1), if (active) Color.WHITE else item.border)
            }
            root.addView(button)
        }
        root.addView(sectionTitle("🖌️ رنگ اصلی دلخواه"))
        root.addView(actionButton("🌈 انتخاب رنگ اصلی سفارشی") { showAccentColorDialog() })
        root.addView(actionButton("↩️ بازگشت به تنظیمات") { showSettings() })
        setScreen(root)
    }

    private fun showAccentColorDialog() {
        val colors = listOf(
            "رز سرخابی" to "#C2185B", "قرمز یاقوتی" to "#B71C1C", "بنفش" to "#6A1B9A",
            "آبی" to "#1565C0", "فیروزه‌ای" to "#008577", "سبز زمردی" to "#2E7D32",
            "نارنجی" to "#E65100", "طلایی" to "#9A6700", "آبی نفتی" to "#006064",
            "صورتی" to "#AD1457", "نیلی" to "#3949AB", "قهوه‌ای گرم" to "#795548"
        )
        val labels = colors.map { "●  ${it.first}   ${it.second}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("انتخاب رنگ اصلی")
            .setItems(labels) { _, which ->
                val color = Color.parseColor(colors[which].second)
                themePrefs.edit().putInt("accent_${themeScope()}", color).apply()
                info("رنگ ${colors[which].first} ذخیره شد؛ دکمه‌ها، حاشیهٔ کارت‌ها و رنگ زمینه با آن هماهنگ شدند.") { showHome() }
            }
            .setNeutralButton("حذف رنگ سفارشی") { _, _ ->
                themePrefs.edit().remove("accent_${themeScope()}").apply()
                info("رنگ اصلی به حالت پیش‌فرض تم برگشت.") { showHome() }
            }
            .setNegativeButton("انصراف", null).show()
    }
    private lateinit var db: GolYarDb
    private lateinit var secureCredentials: SecureCredentialStore
    private var isHomeScreen = false
    private val nf = NumberFormat.getNumberInstance(Locale.US)
    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var syncInProgress = false
    @Volatile private var destructiveDeleteInProgress = false
    private val syncWatchdogHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val syncWatchdog = Runnable {
        if (syncInProgress) {
            syncInProgress = false
            db.setSettingText("last_sync_error", "همگام‌سازی بیش از حد طول کشید و متوقف شد. اتصال اینترنت و دسترسی Firebase را بررسی کنید.")
            refreshHomeSyncStatus()
            val waiting = synchronized(syncWaiters) { val copy = syncWaiters.toList(); syncWaiters.clear(); copy }
            waiting.forEach { waiter -> runCatching { waiter(false) } }
        }
    }
    private val syncWaiters = mutableListOf<(Boolean) -> Unit>()
    private data class ScreenState(val root: LinearLayout, val home: Boolean)
    private val screenBackStack = ArrayDeque<ScreenState>()
    private val screenBottomNav = java.util.IdentityHashMap<LinearLayout, View>()
    private var currentScreenRoot: LinearLayout? = null
    private var currentScreenIsHome = false
    private var restoringScreen = false

    private var syncStatusTapCount = 0
    private val syncStatusTapHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val resetSyncStatusTapCount = Runnable { syncStatusTapCount = 0 }
    private val autoSyncHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val autoSyncRunnable = object : Runnable {
        override fun run() {
            if (!isFinishing && FirebaseApp.getApps(this@MainActivity).isNotEmpty() && firebaseSignedIn() && isNetworkAvailable()) {
                syncWithFirebaseIfOnline(false)
            }
            autoSyncHandler.postDelayed(this, 60_000L)
        }
    }

    private val firebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    private fun firebaseEmail(username: String, role: String): String {
        if (role == "ADMIN") return db.adminFirebaseEmail()
        val clean = username.trim().lowercase(Locale.US).replace(Regex("[^a-z0-9._-]"), "_")
        return if (role == "STAFF") "$clean@staff.golyar.app" else "$clean@golyar.app"
    }

    private fun firebaseSignInOrCreate(username: String, password: String, role: String, sellerId: Long?, onDone: (Boolean) -> Unit) {
        if (username.isBlank() || password.length < 6) { onDone(false); return }
        val email = firebaseEmail(username, role)
        firebaseAuth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                if (role == "SELLER" && sellerId != null) secureCredentials.put("seller_firebase_$sellerId", password)
                ensureFirebaseUserDoc(result.user, role, sellerId, onDone)
            }
            .addOnFailureListener { onDone(false) }
    }

    private fun firebaseAdminLogin(onDone: (Boolean) -> Unit) {
        val email = db.adminFirebaseEmail()
        if (email.isBlank()) { onDone(false); return }

        val current = firebaseAuth.currentUser
        if (current?.email?.equals(email, ignoreCase = true) == true) {
            ensureFirebaseUserDoc(current, "ADMIN", null, onDone)
            return
        }

        // First try the encrypted credential saved after a successful Firebase login.
        // If it is not available, try the greenhouse login password once. This keeps
        // the common case completely silent without hard-coding a password in the APK.
        val candidates = linkedSetOf<String>()
        secureCredentials.get("admin_firebase_password")?.takeIf { it.length >= 6 }?.let { candidates.add(it) }
        db.adminLocalPassword()?.takeIf { it.length >= 6 }?.let { candidates.add(it) }

        fun tryCandidate(index: Int) {
            if (index >= candidates.size) {
                showFirebaseAdminPasswordDialog(email, onDone)
                return
            }
            val password = candidates.elementAt(index)
            firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    secureCredentials.put("admin_firebase_password", password)
                    ensureFirebaseUserDoc(result.user, "ADMIN", null, onDone)
                }
                .addOnFailureListener { error ->
                    // IMPORTANT: Never create a new Firebase user just because
                    // sign-in failed. A wrong password, disabled account, network
                    // error, etc. must NOT trigger account creation.
                    // Creation is allowed only when Firebase explicitly says that
                    // this email/user does not exist.
                    val authError = error as? FirebaseAuthException
                    val code = authError?.errorCode.orEmpty()
                    if (code == "ERROR_USER_NOT_FOUND") {
                        firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnSuccessListener { result ->
                                secureCredentials.put("admin_firebase_password", password)
                                ensureFirebaseUserDoc(result.user, "ADMIN", null, onDone)
                            }
                            .addOnFailureListener { createError ->
                                val createCode = (createError as? FirebaseAuthException)?.errorCode.orEmpty()
                                if (createCode == "ERROR_EMAIL_ALREADY_IN_USE") {
                                    // The account appeared between the lookup and
                                    // create request. Ask for the existing Firebase
                                    // password instead of trying to create another user.
                                    showFirebaseAdminPasswordDialog(email, onDone)
                                } else {
                                    tryCandidate(index + 1)
                                }
                            }
                    } else {
                        // Existing account / wrong credentials: try the next saved
                        // credential, then ask explicitly. Never auto-create here.
                        tryCandidate(index + 1)
                    }
                }
        }
        tryCandidate(0)
    }

    private fun showFirebaseAdminPasswordDialog(email: String, onDone: (Boolean) -> Unit) {
        val box = formBox()
        val emailField = field("ایمیل Firebase", email)
        emailField.isEnabled = false
        val passwordField = field("رمز عبور Firebase", "")
        passwordField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(emailField)
        box.addView(passwordField)

        AlertDialog.Builder(this)
            .setTitle("اتصال حساب گلخانه به Firebase")
            .setMessage("این رمز پس از ورود موفق، به‌صورت رمزگذاری‌شده در همین گوشی ذخیره می‌شود و در ورودهای بعدی دوباره پرسیده نمی‌شود.")
            .setView(box)
            .setPositiveButton("اتصال") { _, _ ->
                val firebasePassword = passwordField.text.toString()
                if (firebasePassword.length < 6) {
                    info("رمز عبور Firebase باید حداقل ۶ کاراکتر باشد.")
                    onDone(false)
                    return@setPositiveButton
                }
                firebaseAuth.signInWithEmailAndPassword(email, firebasePassword)
                    .addOnSuccessListener { result ->
                        secureCredentials.put("admin_firebase_password", firebasePassword)
                        ensureFirebaseUserDoc(result.user, "ADMIN", null, onDone)
                    }
                    .addOnFailureListener { error ->
                        info("ورود به حساب Firebase انجام نشد: ${error.localizedMessage ?: "ایمیل یا رمز عبور Firebase صحیح نیست."}")
                        onDone(false)
                    }
            }
            .setNegativeButton("انصراف") { _, _ -> onDone(false) }
            .show()
    }

    private fun provisionSellerFirebaseAccounts(onDone: (Boolean, String?) -> Unit) {
        val sellers = db.sellers()
        if (sellers.isEmpty()) { onDone(true, null); return }
        val primaryApp = FirebaseApp.getInstance()
        val secondaryName = "golyarSellerProvision"
        val secondaryApp = try {
            FirebaseApp.getInstance(secondaryName)
        } catch (_: Exception) {
            FirebaseApp.initializeApp(this, primaryApp.options, secondaryName)
        }
        if (secondaryApp == null) { onDone(false, "راه‌اندازی اتصال Firebase برای ساخت حساب فروشندگان انجام نشد."); return }
        val secondaryAuth = FirebaseAuth.getInstance(secondaryApp)
        val fs = FirebaseFirestore.getInstance()

        fun next(index: Int) {
            if (index >= sellers.size) {
                runCatching { secondaryAuth.signOut() }
                onDone(true, null)
                return
            }
            val seller = sellers[index]
            val username = seller.username.trim()
            val password = db.sellerPassword(seller.id)
            if (username.isBlank()) { onDone(false, "فروشنده «${seller.name}» نام کاربری ندارد."); return }
            if (password.length < 6) { onDone(false, "رمز عبور فروشنده «${seller.name}» باید حداقل ۶ کاراکتر باشد."); return }
            val clean = username.lowercase(Locale.US).replace(Regex("[^a-z0-9._-]"), "_")
            val email = "$clean@golyar.app"

            secondaryAuth.signOut()
            secondaryAuth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid
                    if (uid == null) { onDone(false, "حساب Firebase فروشنده «${seller.name}» ساخته نشد."); return@addOnSuccessListener }
                    val data = hashMapOf<String, Any>("role" to "SELLER", "username" to username, "firebase_email" to email, "seller_id" to seller.id, "seller_remote_id" to db.sellerRemoteId(seller.id), "updated_at" to System.currentTimeMillis())
                    fs.collection("users").document(uid).set(data)
                        .addOnSuccessListener { next(index + 1) }
                        .addOnFailureListener { e -> onDone(false, "ثبت پروفایل Firebase فروشنده «${seller.name}» انجام نشد: ${e.localizedMessage ?: e.message}") }
                }
                .addOnFailureListener { createError ->
                    // If the account already exists, verify the local seller password against it.
                    secondaryAuth.signInWithEmailAndPassword(email, password)
                        .addOnSuccessListener { result ->
                            val uid = result.user?.uid
                            if (uid == null) { onDone(false, "حساب Firebase فروشنده «${seller.name}» قابل شناسایی نیست."); return@addOnSuccessListener }
                            val data = hashMapOf<String, Any>("role" to "SELLER", "username" to username, "firebase_email" to email, "seller_id" to seller.id, "seller_remote_id" to db.sellerRemoteId(seller.id), "updated_at" to System.currentTimeMillis())
                            fs.collection("users").document(uid).set(data)
                                .addOnSuccessListener { next(index + 1) }
                                .addOnFailureListener { e -> onDone(false, "ثبت پروفایل Firebase فروشنده «${seller.name}» انجام نشد: ${e.localizedMessage ?: e.message}") }
                        }
                        .addOnFailureListener { signInError ->
                            onDone(false, "حساب Firebase فروشنده «${seller.name}» وجود دارد ولی رمز ثبت‌شده با Firebase مطابقت ندارد. از Authentication برای Reset password استفاده کنید.")
                        }
                }
        }
        next(0)
    }

    private fun ensureFirebaseUserDoc(user: FirebaseUser?, role: String, sellerId: Long?, onDone: (Boolean) -> Unit) {
        if (user == null) { onDone(false); return }

        // The admin account has already been authenticated by Firebase and its
        // users/{uid} profile is provisioned in Firestore. Do not perform a
        // second Firestore read/write during login; this avoids a false login
        // failure caused by Firestore rules while the authenticated session is valid.
        if (role == "ADMIN" &&
            user.email?.equals(db.adminFirebaseEmail(), ignoreCase = true) == true) {
            onDone(true)
            return
        }

        val data = hashMapOf<String, Any>(
            "role" to role,
            "username" to db.sellerUsername(sellerId ?: -1L),
            "firebase_email" to user.email.orEmpty(),
            "updated_at" to System.currentTimeMillis()
        )
        if (sellerId != null) { data["seller_id"] = sellerId; data["seller_remote_id"] = db.sellerRemoteId(sellerId) }
        val userRef = FirebaseFirestore.getInstance().collection("users").document(user.uid)
        userRef.get()
            .addOnSuccessListener { snap ->
                if (snap.exists()) {
                    onDone(true)
                } else {
                    userRef.set(data)
                        .addOnSuccessListener { onDone(true) }
                        .addOnFailureListener { error ->
                            info("ثبت پروفایل Firebase انجام نشد: ${error.localizedMessage ?: error.message ?: "خطای نامشخص"}")
                            onDone(false)
                        }
                }
            }
            .addOnFailureListener { error ->
                info("بررسی پروفایل Firebase انجام نشد: ${error.localizedMessage ?: error.message ?: "خطای نامشخص"}")
                onDone(false)
            }
    }

    private fun restoreFirebaseSessionIfNeeded() {
        if (FirebaseApp.getApps(this).isEmpty() || firebaseAuth.currentUser != null) return
        if (!isNetworkAvailable()) return
        if (db.isSellerMode()) {
            val sid = db.currentSellerId() ?: return
            val username = db.sellerUsername(sid)
            val password = secureCredentials.get("seller_firebase_$sid") ?: db.sellerPassword(sid)
            if (username.isBlank() || password.length < 6) return
            firebaseAuth.signInWithEmailAndPassword(firebaseEmail(username, "SELLER"), password)
                .addOnSuccessListener { secureCredentials.put("seller_firebase_$sid", password); syncWithFirebaseIfOnline(false) }
        } else if (db.getMode()?.startsWith("GREENHOUSE:STAFF:") == true) {
            val uid = db.getMode()!!.substringAfter("GREENHOUSE:STAFF:")
            val password = secureCredentials.get("staff_firebase_$uid") ?: return
            val email = secureCredentials.get("staff_email_$uid") ?: return
            firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { syncWithFirebaseIfOnline(false) }
        } else if (db.isAdminSetupDone()) {
            val password = secureCredentials.get("admin_firebase_password") ?: return
            val email = db.adminFirebaseEmail()
            if (email.isBlank() || password.length < 6) return
            firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { secureCredentials.put("admin_firebase_password", password); syncWithFirebaseIfOnline(false) }
        }
    }

    private fun firebaseSignedIn(): Boolean {
        val user = firebaseAuth.currentUser ?: return false
        return if (db.isSellerMode()) {
            val sid = db.currentSellerId() ?: return false
            val username = db.sellerUsername(sid)
            user.email?.equals(firebaseEmail(username, "SELLER"), ignoreCase = true) == true
        } else if (db.getMode()?.startsWith("GREENHOUSE:STAFF:") == true) {
            val uid = db.getMode()!!.substringAfter("GREENHOUSE:STAFF:")
            user.uid == uid
        } else if (db.isAdminSetupDone()) {
            user.email?.equals(db.adminFirebaseEmail(), ignoreCase = true) == true
        } else false
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        when (requestCode) {
            8101 -> {
                try {
                    val uri = data.data!!
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(db.exportBackupJson().toByteArray(Charsets.UTF_8))
                    }
                    info("نسخه پشتیبان با موفقیت ذخیره شد.")
                } catch (e: Exception) {
                    info("ذخیره نسخه پشتیبان انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}")
                }
            }
            8102 -> {
                try {
                    val uri = data.data!!
                    val text = contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    } ?: throw IllegalStateException("فایل قابل خواندن نیست")
                    AlertDialog.Builder(this)
                        .setTitle("بازنشانی از نسخه پشتیبان")
                        .setMessage("اطلاعات فعلی برنامه با اطلاعات داخل این فایل جایگزین می‌شود. این کار قابل بازگشت نیست. ادامه می‌دهید؟")
                        .setNegativeButton("انصراف", null)
                        .setPositiveButton("بازنشانی") { _, _ ->
                            try {
                                db.restoreBackupJson(text)
                                info("اطلاعات با موفقیت از نسخه پشتیبان بازنشانی شد.") {
                                    showHome()
                                }
                            } catch (e: Exception) {
                                info("بازنشانی انجام نشد: ${e.localizedMessage ?: e.message ?: "فایل پشتیبان نامعتبر است."}")
                            }
                        }.show()
                } catch (e: Exception) {
                    info("خواندن فایل پشتیبان انجام نشد: ${e.localizedMessage ?: e.message ?: "فایل نامعتبر است."}")
                }
            }
            8103 -> {
                try {
                    val uri = data.data!!
                    val source = File(noBackupFilesDir, "GolNegar_AutoBackup.json")
                    if (!source.exists()) throw IllegalStateException("نسخه پشتیبان خودکار پیدا نشد.")
                    contentResolver.openOutputStream(uri)?.use { out ->
                        source.inputStream().use { input -> input.copyTo(out) }
                    } ?: throw IllegalStateException("فایل مقصد قابل نوشتن نیست")
                    info("آخرین پشتیبان خودکار با موفقیت ذخیره شد.")
                } catch (e: Exception) {
                    info("ذخیره پشتیبان خودکار انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        db = GolYarDb(this)
        db.repairSellerActiveState()
        secureCredentials = SecureCredentialStore(this)
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (FirebaseApp.initializeApp(this) != null) {
            FirebaseAnalytics.getInstance(this).logEvent("app_open", null)
            registerNetworkSync()
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isHomeScreen && screenBackStack.isEmpty()) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("خروج از گل نگار")
                        .setMessage("آیا قصد خروج از برنامه را دارید؟")
                        .setNegativeButton("خیر", null)
                        .setPositiveButton("بله") { _, _ -> finish() }
                        .show()
                } else {
                    goBack()
                }
            }
        })
        // Every launch starts with Firebase-ready authentication flow.
        // A saved local mode never bypasses login; existing users get the
        // normal username/password screen, while a fresh installation can
        // explicitly create an account only after Firebase reports that the
        // account does not exist.
        db.closeCompletedFinancialMonths()
        startEntryFlow()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun base(title: String, subtitle: String? = null): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(18), dp(12), dp(8))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            background = themeGradient()
            tag = "SCREEN:$title"
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = themeCardBackground()
            val hp = LinearLayout.LayoutParams(-1, -2)
            hp.setMargins(0, 0, 0, dp(10))
            layoutParams = hp
            elevation = dp(2).toFloat()
        }
        header.addView(TextView(this).apply {
            text = title
            textSize = if (title == "گل نگار") 25f else 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(palette().primary)
            includeFontPadding = false
            minHeight = dp(38)
        })
        if (title == "گل نگار") {
            // Keep the version immediately under the app title; show the active account name below it.
            header.addView(TextView(this).apply {
                text = "نسخه ${BuildConfig.VERSION_NAME}"
                textSize = 12f
                typeface = Typeface.DEFAULT
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(105, 117, 109))
                includeFontPadding = true
                setPadding(0, dp(2), 0, dp(1))
            })
            if (!subtitle.isNullOrBlank()) {
                header.addView(TextView(this).apply {
                    text = subtitle
                    textSize = 15f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setTextColor(palette().primary)
                    includeFontPadding = true
                    setPadding(0, dp(1), 0, dp(4))
                })
            }
        }
        root.addView(header)
        return root
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 16f
        isAllCaps = false
        gravity = Gravity.CENTER
        minHeight = dp(48)
        minimumHeight = dp(48)
        setPadding(dp(10), dp(4), dp(10), dp(4))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        val p = palette()
        val orientation = when (p.id) {
            "emerald" -> GradientDrawable.Orientation.LEFT_RIGHT
            "ocean" -> GradientDrawable.Orientation.TL_BR
            "lavender" -> GradientDrawable.Orientation.TOP_BOTTOM
            "sunset" -> GradientDrawable.Orientation.BL_TR
            "teal" -> GradientDrawable.Orientation.RIGHT_LEFT
            else -> GradientDrawable.Orientation.TL_BR
        }
        background = GradientDrawable(orientation, intArrayOf(p.primary, p.accent)).apply {
            cornerRadius = dp(16).toFloat()
            setStroke(dp(1), mixColor(p.primary, Color.WHITE, 0.20f))
        }
        stateListAnimator = null
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, dp(50))
        lp.setMargins(0, dp(4), 0, dp(4))
        layoutParams = lp
    }

    private fun metricCard(title:String, value:String, icon:String):LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; layoutDirection=View.LAYOUT_DIRECTION_RTL
        setPadding(dp(10),dp(12),dp(10),dp(12))
        background=themeCardBackground()
        addView(TextView(this@MainActivity).apply{text=icon;textSize=20f;gravity=Gravity.CENTER})
        addView(TextView(this@MainActivity).apply{text=value;textSize=18f;typeface=Typeface.DEFAULT_BOLD;setTextColor(palette().text);gravity=Gravity.CENTER;setPadding(0,dp(5),0,dp(2))})
        addView(TextView(this@MainActivity).apply{text=title;textSize=12f;setTextColor(palette().muted);gravity=Gravity.CENTER})
    }

    private fun goBack() {
        if (screenBackStack.isNotEmpty()) {
            val previous = screenBackStack.removeLast()
            restoringScreen = true
            setScreen(previous.root, previous.home)
            restoringScreen = false
        } else {
            showHome()
        }
    }

    private fun detachFromParent(view: View) {
        val parent = view.parent
        if (parent is ViewGroup) parent.removeView(view)
    }

    private fun setScreen(root: LinearLayout, home: Boolean = false) {
        if (!restoringScreen && currentScreenRoot != null) {
            val current = currentScreenRoot!!
            val sameLogicalScreen = current.tag != null && current.tag == root.tag
            if (current !== root && !sameLogicalScreen) {
                // Keep the actual page the user came from, but never stack a duplicate
                // when Firebase refreshes/re-renders the same logical screen.
                if (screenBackStack.size >= 40) screenBackStack.removeFirst()
                screenBackStack.addLast(ScreenState(current, currentScreenIsHome))
            }
        }
        // A previous screen root can be reused by Back navigation. Detach it
        // before attaching it to a new ScrollView so a View never has two parents.
        detachFromParent(root)
        isHomeScreen = home
        currentScreenRoot = root
        currentScreenIsHome = home
        // Keep navigation fixed at the bottom of the app content instead of
        // placing it inside the scrolling page. With decorFitsSystemWindows=true,
        // Android reserves the system status/navigation-bar insets for us.
        var bottomNav: View? = screenBottomNav[root]
        for (i in root.childCount - 1 downTo 0) {
            val child = root.getChildAt(i)
            if (child.tag == "APP_BOTTOM_NAV") {
                bottomNav = child
                screenBottomNav[root] = child
                root.removeViewAt(i)
                break
            }
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = themeGradient()
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        // Apply system-bar insets to the outer frame, not the scrolling page.
        // This keeps the bottom navigation above Android's gesture/button area,
        // including on Android versions that enforce edge-to-edge by default.
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(page) { view, insets ->
            val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.TRANSPARENT)
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        scroll.addView(root, ViewGroup.LayoutParams(-1, -2))
        page.addView(scroll)
        bottomNav?.let { nav ->
            (nav.parent as? ViewGroup)?.removeView(nav)
            page.addView(nav, LinearLayout.LayoutParams(-1, dp(56)))
        }
        setContentView(page)
        page.post { androidx.core.view.ViewCompat.requestApplyInsets(page) }
    }

    private fun resumeLastStaffSessionOrChooseMode() {
        // If the last staff mode was not restored from the local database for any
        // reason, try the previously authenticated staff account silently. The
        // password is held only by SecureCredentialStore (Android Keystore AES-GCM).
        val username = secureCredentials.get("last_staff_username").orEmpty()
        val password = secureCredentials.get("last_staff_password").orEmpty()
        if (username.isBlank() || password.length < 6 ||
            FirebaseApp.getApps(this).isEmpty() || !isNetworkAvailable()) {
            showModeChooser()
            return
        }
        firebaseAuth.signInWithEmailAndPassword(firebaseEmail(username, "STAFF"), password)
            .addOnSuccessListener { result ->
                val user = result.user
                val uid = user?.uid
                if (uid == null) {
                    showModeChooser()
                    return@addOnSuccessListener
                }
                FirebaseFirestore.getInstance().collection("users").document(uid).get()
                    .addOnSuccessListener { snap ->
                        if (snap.getString("role") != "STAFF") {
                            firebaseAuth.signOut()
                            showModeChooser()
                            return@addOnSuccessListener
                        }
                        db.setMode("GREENHOUSE:STAFF:$uid")
                        db.setSettingText("staff_display_name", snap.getString("name")?.trim().takeUnless { it.isNullOrBlank() } ?: username)
                        val granted = (snap.get("permissions") as? List<*>)?.filterIsInstance<String>()?.toSet()
                        getSharedPreferences("golnegar_staff_permissions", Context.MODE_PRIVATE)
                            .edit().clear().putStringSet(uid, granted ?: setOf("delivery", "returns", "payments", "warnings")).apply()
                        secureCredentials.put("staff_firebase_$uid", password)
                        secureCredentials.put("staff_email_$uid", firebaseEmail(username, "STAFF"))
                        syncWithFirebaseIfOnline(false) { showHome() }
                    }
                    .addOnFailureListener {
                        // Do not discard the saved credentials on a temporary
                        // Firestore/network failure; let the user choose another mode.
                        showModeChooser()
                    }
            }
            .addOnFailureListener { showModeChooser() }
    }

    private fun startEntryFlow() {
        val savedMode = db.getMode()
        // One-time setup only. After setup there is deliberately no login screen.
        // Firebase Auth persists its authenticated session across app restarts; if
        // Android/Firebase needs a new session, the encrypted credential is used
        // silently. Offline use never blocks access to local data.
        if (savedMode?.startsWith("SELLER:") == true && db.currentSellerId() != null) {
            showHome()
            restoreFirebaseSessionIfNeeded()
            return
        }
        if (savedMode?.startsWith("GREENHOUSE:STAFF:") == true) {
            showHome()
            restoreFirebaseSessionIfNeeded()
            return
        }
        if (savedMode == "GREENHOUSE" && db.isAdminSetupDone()) {
            showHome()
            restoreFirebaseSessionIfNeeded()
            return
        }
        if (savedMode == null && !secureCredentials.get("last_staff_username").isNullOrBlank() &&
            (secureCredentials.get("last_staff_password")?.length ?: 0) >= 6) {
            resumeLastStaffSessionOrChooseMode()
            return
        }
        if (db.isAdminSetupDone()) {
            db.setMode("GREENHOUSE")
            showHome()
            restoreFirebaseSessionIfNeeded()
            return
        }
        // Resume the previous staff session automatically when no local mode is
        // available. No username/password prompt is shown for a valid saved session.
        resumeLastStaffSessionOrChooseMode()
    }

    private fun showModeChooser() {
        val root = base("گل نگار")
        root.addView(sectionTitle("انتخاب نوع حساب"))
        root.addView(listCard("🏭 گلخانه / مدیر", "مدیریت کامل گلخانه و حساب‌ها") {
            if (db.isAdminSetupDone()) {
                db.setMode("GREENHOUSE")
                if (!firebaseAuth.currentUser?.email.equals(db.adminFirebaseEmail(), ignoreCase = true)) firebaseAuth.signOut()
                restoreFirebaseSessionIfNeeded()
                showHome()
            } else greenhouseLogin()
        })
        root.addView(listCard("👤 فروشنده", "ثبت فروش، پرداخت و مشاهده حساب") { showSellerChooser() })
        root.addView(listCard("👥 کاربر گلخانه", "ورود با حساب کارمند تعریف‌شده") { showStaffLogin() })
        if (db.getMode() != null) root.addView(outlineAction("ادامه با حساب فعلی") { showHome() })
        setScreen(root)
    }

    private fun showStaffLogin() {
        val box = formBox()
        val savedStaffUsername = secureCredentials.get("last_staff_username").orEmpty()
        val savedStaffPassword = secureCredentials.get("last_staff_password").orEmpty()
        val user = field("نام کاربری کاربر گلخانه", savedStaffUsername)
        val pass = passwordField("رمز عبور", savedStaffPassword)
        box.addView(user); box.addView(pass)
        AlertDialog.Builder(this)
            .setTitle("ورود کاربر گلخانه")
            .setMessage("هر کاربر گلخانه حساب Firebase مستقل خودش را دارد و می‌تواند همزمان با کاربران دیگر کار کند.")
            .setView(box)
            .setPositiveButton("ورود") { _, _ ->
                val username = user.text.toString().trim()
                val password = (pass.tag as EditText).text.toString()
                if (username.isBlank() || password.length < 6) {
                    info("نام کاربری و رمز عبور را کامل وارد کنید.") { showStaffLogin() }
                    return@setPositiveButton
                }
                val email = firebaseEmail(username, "STAFF")
                firebaseAuth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener { result ->
                        val uid = result.user?.uid
                        if (uid == null) { info("حساب کاربر گلخانه قابل شناسایی نیست."); return@addOnSuccessListener }
                        FirebaseFirestore.getInstance().collection("users").document(uid).get()
                            .addOnSuccessListener { snap ->
                                if (snap.getString("role") != "STAFF") { info("این حساب، حساب کاربر گلخانه نیست."); return@addOnSuccessListener }
                                db.setMode("GREENHOUSE:STAFF:$uid")
                                db.setSettingText("staff_display_name", snap.getString("name")?.trim().takeUnless { it.isNullOrBlank() } ?: username)
                                val granted=(snap.get("permissions") as? List<*>)?.filterIsInstance<String>()?.toSet()
                                val prefs=getSharedPreferences("golnegar_staff_permissions",Context.MODE_PRIVATE)
                                prefs.edit().clear().putStringSet("$uid",granted ?: setOf("delivery","returns","payments","warnings")).apply()
                                secureCredentials.put("staff_firebase_$uid", password)
                                secureCredentials.put("staff_email_$uid", email)
                                secureCredentials.put("last_staff_username", username)
                                secureCredentials.put("last_staff_password", password)
                                syncWithFirebaseIfOnline(false) { ok ->
                                    runOnUiThread {
                                        showHome()
                                        if (!ok) info("ورود انجام شد، اما همگام‌سازی کامل نشد.\nعلت: ${db.settingTextPublic("last_sync_error", "خطای نامشخص")}")
                                    }
                                }
                            }
                            .addOnFailureListener { e -> info("دریافت مشخصات کاربر انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای دسترسی"}") }
                    }
                    .addOnFailureListener { info("نام کاربری یا رمز عبور کاربر گلخانه صحیح نیست.") }
            }
            .setNegativeButton("بازگشت") { _, _ -> showModeChooser() }
            .show()
    }

    private fun showSellerChooser() {
        val box = formBox()
        val user = field("نام کاربری فروشنده", "")
        val pass = field("رمز عبور", "")
        pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(user)
        box.addView(pass)

        AlertDialog.Builder(this)
            .setTitle("ورود فروشنده")
            .setMessage("حساب فروشنده باید قبلاً توسط گلخانه در Firebase ایجاد شده باشد.")
            .setView(box)
            .setPositiveButton("ورود") { _, _ ->
                val username = user.text.toString().trim()
                val password = pass.text.toString()
                if (username.isBlank() || password.length < 6) {
                    info("نام کاربری و رمز عبور را کامل وارد کنید.") { showSellerChooser() }
                    return@setPositiveButton
                }

                val email = firebaseEmail(username, "SELLER")
                firebaseAuth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener { result ->
                        val uid = result.user?.uid
                        if (uid == null) {
                            info("حساب فروشنده در Firebase قابل شناسایی نیست.")
                            return@addOnSuccessListener
                        }

                        // The users/{uid} document is the authoritative identity for a seller.
                        // Do not make login depend on the optional sellers/{seller_id} document:
                        // that document can be absent on a newly provisioned account and older
                        // Firestore Rules may deny its read. We can still establish the local
                        // seller identity from users/{uid}, then pull the seller's transactions.
                        FirebaseFirestore.getInstance().collection("users").document(uid).get()
                            .addOnSuccessListener { snap ->
                                val sellerId = snap.getLong("seller_id")
                                val role = snap.getString("role")
                                if (role != "SELLER" || sellerId == null || sellerId <= 0L) {
                                    info("این حساب Firebase به یک فروشنده معتبر متصل نیست.")
                                    return@addOnSuccessListener
                                }

                                // Firestore seller_id is the global seller identity. It can differ from the local SQLite id on this phone.
                                db.setSettingText("firebase_seller_id", sellerId.toString())

                                val firebaseSellerName = snap.getString("name")?.trim().orEmpty()
                                val firebaseUsername = snap.getString("username")?.trim().takeUnless { it.isNullOrBlank() } ?: username
                                val sellerRemoteId = snap.getString("seller_remote_id")?.trim().takeUnless { it.isNullOrBlank() } ?: sellerId.toString()

                                // Upgrade older seller identity documents once. The Rules allow
                                // a seller to update only its own role/seller_id-preserving profile.
                                if (snap.getString("seller_remote_id").isNullOrBlank()) {
                                    FirebaseFirestore.getInstance().collection("users").document(uid)
                                        .set(mapOf("seller_remote_id" to sellerRemoteId), com.google.firebase.firestore.SetOptions.merge())
                                }

                                // Bootstrap the local seller using the Firebase-stable identity.
                                // Local SQLite ids may differ between phones; seller_remote_id must
                                // therefore be the identity used by all cross-device synchronization.
                                var localSeller = db.sellerByRemoteId(sellerRemoteId) ?: db.sellerById(sellerId)
                                if (localSeller == null) {
                                    // Do not force the Firebase/admin numeric seller_id into a fresh
                                    // phone's SQLite primary key. SQLite ids are device-local.
                                    db.upsertSeller(
                                        null,
                                        firebaseSellerName.ifBlank { firebaseUsername },
                                        "",
                                        firebaseUsername,
                                        "",
                                        20.0,
                                        sellerRemoteId
                                    )
                                    localSeller = db.sellerByRemoteId(sellerRemoteId)
                                } else {
                                    db.upsertSeller(
                                        localSeller.id,
                                        firebaseSellerName.ifBlank { localSeller.name },
                                        localSeller.phone,
                                        firebaseUsername,
                                        db.sellerPassword(localSeller.id),
                                        20.0,
                                        sellerRemoteId
                                    )
                                    localSeller = db.sellerById(localSeller.id)
                                }
                                val localSellerId = localSeller?.id
                                if (localSellerId == null) {
                                    info("اطلاعات فروشنده در حافظه محلی ثبت نشد.")
                                    return@addOnSuccessListener
                                }

                                // Best-effort enrichment from sellers/{seller_id}. Login must not
                                // fail if this optional document is missing/temporarily denied.
                                FirebaseFirestore.getInstance().collection("sellers")
                                    .document(sellerId.toString()).get()
                                    .addOnSuccessListener { sellerSnap ->
                                        if (sellerSnap.exists()) {
                                            db.importFirebaseRecord("sellers", sellerSnap.id, sellerSnap.data ?: emptyMap())
                                        }
                                        completeSellerLoginAfterIdentity(localSellerId, sellerRemoteId, password)
                                    }
                                    .addOnFailureListener {
                                        completeSellerLoginAfterIdentity(localSellerId, sellerRemoteId, password)
                                    }
                            }
                            .addOnFailureListener { e ->
                                info("دریافت مشخصات حساب فروشنده از Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای دسترسی یا اتصال"}")
                            }
                    }
                    .addOnFailureListener { error ->
                        val code = (error as? FirebaseAuthException)?.errorCode.orEmpty()
                        if (code == "ERROR_USER_NOT_FOUND") {
                            info("این حساب فروشنده در Firebase وجود ندارد. حساب فروشنده باید ابتدا از نسخه گلخانه ایجاد و فعال شود.")
                        } else {
                            info("نام کاربری یا رمز عبور فروشنده صحیح نیست.")
                        }
                    }
            }
            .setNegativeButton("بازگشت") { _, _ -> showModeChooser() }
            .show()
    }

    private fun completeSellerLoginAfterIdentity(sellerId: Long, sellerRemoteId: String, password: String) {
        db.setMode("SELLER:$sellerId")
        secureCredentials.put("seller_firebase_$sellerId", password)

        // IMPORTANT: sellers is deliberately NOT pulled again here. The seller identity has
        // already been bootstrapped locally and the sellers collection is not needed to obtain
        // the seller's inventory. Pull only collections whose Rules authorize seller_id.
        syncWithFirebaseIfOnline(false) { ok ->
            runOnUiThread {
                if (ok) {
                    showHome()
                } else {
                    val detail = db.settingTextPublic("last_sync_error", "خطای نامشخص")
                    showHome()
                    info("ورود فروشنده انجام شد، اما همگام‌سازی کامل نشد.\nعلت: $detail")
                }
            }
        }
    }

    private data class HomeShortcut(val key:String,val title:String,val icon:String,val action:()->Unit)

    /** Permissions for greenhouse staff are enforced both in navigation and at screen entry. */
    private fun staffHasPermission(key: String): Boolean {
        if (!db.isStaffMode()) return true
        val uid = db.getMode()?.substringAfter("GREENHOUSE:STAFF:").orEmpty()
        if (uid.isBlank()) return false
        return getSharedPreferences("golnegar_staff_permissions", Context.MODE_PRIVATE)
            .getStringSet(uid, emptySet())?.contains(key) == true
    }

    private fun requireStaffPermission(key: String, title: String): Boolean {
        if (staffHasPermission(key)) return true
        info("دسترسی «$title» برای حساب شما فعال نیست. برای فعال‌سازی با مدیر گلخانه تماس بگیرید.")
        return false
    }

    private fun homeRoleKey():String = when {
        db.isSellerMode() -> "SELLER"
        db.isStaffMode() -> "STAFF"
        else -> "GREENHOUSE"
    }

    private fun homeShortcutPrefs() = getSharedPreferences("golnegar_home_shortcuts", Context.MODE_PRIVATE)

    private fun homeShortcutEnabled(key:String, defaultValue:Boolean = true):Boolean =
        homeShortcutPrefs().getBoolean("${homeRoleKey()}_$key", defaultValue)

    private fun setHomeShortcutEnabled(key:String, enabled:Boolean) {
        homeShortcutPrefs().edit().putBoolean("${homeRoleKey()}_$key", enabled).apply()
    }

    private fun resetHomeShortcutLayout() {
        val prefix = "${homeRoleKey()}_"
        val editor = homeShortcutPrefs().edit()
        homeShortcutKeysForCurrentRole().forEach { editor.remove(prefix + it.key) }
        editor.apply()
    }

    private fun homeShortcutDefinitions():List<HomeShortcut> {
        if (db.isSellerMode()) {
            return listOf(
                HomeShortcut("sale", "ثبت فروش", "🧾") { showSale() },
                HomeShortcut("settlement", "پرداخت به گلخانه", "💳") { showSettlement() },
                HomeShortcut("inventory", "موجودی من", "📦") { showSellerInventoryReport() },
                HomeShortcut("report", "گزارش من", "📊") { showSellerReportsNew() },
                HomeShortcut("returns", "برگشتی", "↩️") { showSellerReturnsAndSales() },
                HomeShortcut("settings", "تنظیمات", "⚙️") { showSettings() }
            )
        }
        return listOf(
            HomeShortcut("flower", "گل‌ها و ثبت گل", "🌹") { showFlowers() },
            HomeShortcut("sellers", "فروشندگان", "👥") { showSellers() },
            HomeShortcut("delivery", "تحویل گل", "📦") { showDelivery() },
            HomeShortcut("misc_sale", "فروش متفرقه", "🧾") { showMiscSale() },
            HomeShortcut("returns", "برگشتی", "↩️") { showReturn() },
            HomeShortcut("payments", "پرداخت‌ها", "💳") { showAllPaymentsHistory() },
            HomeShortcut("expense", "هزینه گلخانه", "💰") { showGreenhouseExpense() },
            HomeShortcut("warnings", "هشدارها", "⚠️") { showPriceWarnings() },
            HomeShortcut("financial_report", "گزارش مالی", "📈") { showFinancialReport() }
        )
    }

    private fun homeShortcutKeysForCurrentRole():List<HomeShortcut> = homeShortcutDefinitions()

    private fun showHomeIconSettings() {
        val root = base("مدیریت آیکن‌های صفحه اصلی", "آیکن‌های دلخواه را روشن یا خاموش کنید؛ خاموش کردن فقط آیکن را از خانه پنهان می‌کند و اطلاعات حذف نمی‌شود.")
        root.addView(sectionTitle("انتخاب آیکن‌ها"))
        root.addView(cardText("هر تغییری بلافاصله ذخیره می‌شود. آیکن‌های خاموش‌شده همچنان از بخش «ثبت‌ها» یا «گزارش‌ها» قابل دسترسی هستند."))

        homeShortcutDefinitions().forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = cardBackground()
                val lp = LinearLayout.LayoutParams(-1, dp(66))
                lp.setMargins(0, dp(2), 0, dp(2))
                layoutParams = lp
            }
            row.addView(TextView(this).apply {
                text = "${item.icon}  ${item.title}"
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(palette().text)
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            })
            row.addView(Switch(this).apply {
                isChecked = homeShortcutEnabled(item.key, true)
                setOnCheckedChangeListener { _, checked ->
                    setHomeShortcutEnabled(item.key, checked)
                }
            })
            root.addView(row)
        }

        root.addView(Space(this).apply { minimumHeight = dp(8) })
        root.addView(actionButton("↺ بازگردانی چیدمان پیش‌فرض") {
            AlertDialog.Builder(this)
                .setTitle("بازگردانی آیکن‌ها")
                .setMessage("همه آیکن‌های این صفحه دوباره فعال شوند؟")
                .setNegativeButton("انصراف", null)
                .setPositiveButton("بازگردانی") { _, _ ->
                    resetHomeShortcutLayout()
                    showHomeIconSettings()
                }.show()
        })
        root.addView(actionButton("✓ ذخیره و بازگشت به خانه") { showHome() })
        root.addView(actionButton("↩️ بازگشت به تنظیمات") { showSettings() })
        setScreen(root)
    }

    /** Animated, tappable shortcut cards. Replaces the unreliable drag-to-rotate wheel. */
    private fun addCircularShortcutWheel(root: LinearLayout, shortcuts: List<HomeShortcut>) {
        if (shortcuts.isEmpty()) {
            root.addView(cardText("هیچ میان‌بری برای نمایش فعال نیست. از تنظیمات، میان‌برهای صفحه اصلی را فعال کنید."))
            return
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(2), dp(4), dp(2), dp(4))
        }
        root.addView(panel)
        shortcuts.chunked(2).forEachIndexed { rowIndex, rowItems ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER
            }
            rowItems.forEachIndexed { columnIndex, item ->
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setPadding(dp(8), dp(10), dp(8), dp(10))
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(18).toFloat()
                        setColor(Color.WHITE)
                        setStroke(dp(1), Color.rgb(225, 232, 226))
                    }
                    elevation = dp(2).toFloat()
                    isClickable = true
                    isFocusable = true
                    contentDescription = item.title
                    layoutParams = LinearLayout.LayoutParams(0, dp(104), 1f).apply {
                        setMargins(dp(4), dp(4), dp(4), dp(4))
                    }
                }
                val icon = TextView(this).apply {
                    text = item.icon
                    textSize = 29f
                    gravity = Gravity.CENTER
                    setTextColor(Color.rgb(177, 28, 75))
                    includeFontPadding = false
                }
                val title = TextView(this).apply {
                    text = item.title
                    textSize = 12.5f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setTextColor(Color.rgb(38, 65, 47))
                    maxLines = 2
                    setPadding(0, dp(5), 0, 0)
                }
                tile.addView(icon)
                tile.addView(title)
                tile.setOnClickListener { item.action() }
                tile.setOnTouchListener { v, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(75).start(); false }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.animate().scaleX(1f).scaleY(1f).setDuration(110).start(); false }
                        else -> false
                    }
                }
                row.addView(tile)
                tile.alpha = 0f
                tile.translationY = dp(12).toFloat()
                tile.animate().alpha(1f).translationY(0f)
                    .setStartDelay((rowIndex * 90L) + (columnIndex * 45L))
                    .setDuration(240L).start()
            }
            if (rowItems.size == 1) {
                row.addView(View(this), LinearLayout.LayoutParams(0, dp(1), 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
            }
            panel.addView(row)
        }
        root.addView(cardText("برای باز کردن هر بخش، کارت آن را لمس کنید."))
    }

    private fun showHome() {
        screenBackStack.clear()
        restoringScreen = false
        val sellerMode = db.isSellerMode()
        val sid = if (sellerMode) db.currentSellerId() else null
        val seller = sid?.let { id -> db.sellers().firstOrNull { it.id == id } }
        val d = db.dashboard(sid)
        val activeSubtitle = when {
            sellerMode -> seller?.name ?: "فروشنده"
            db.isStaffMode() -> db.settingTextPublic("staff_display_name", "کاربر گلخانه").ifBlank { "کاربر گلخانه" }
            else -> db.adminUsername().ifBlank { "مدیر گلخانه" }
        }
        val root = base("گل نگار", activeSubtitle)
        root.tag = "GOL_NEGAR_HOME_ROOT"

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(0), dp(4), dp(6))
        }
        top.addView(TextView(this).apply {
            text = todayJalali()
            textSize = 14f
            setTextColor(Color.rgb(86, 99, 91))
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
        })
        root.addView(top)
        root.addView(syncStatusCard(homeSyncStatusText()))
        val staffGranted = if (db.isStaffMode()) getSharedPreferences("golnegar_staff_permissions",Context.MODE_PRIVATE).getStringSet(db.getMode()?.substringAfter("GREENHOUSE:STAFF:"), null) else null
        val shortcuts = homeShortcutDefinitions().filter { homeShortcutEnabled(it.key, true) && (!db.isStaffMode() || staffHasPermission(it.key)) }
        addCircularShortcutWheel(root, shortcuts)

        if (sellerMode) {
            root.addView(sectionTitle("وضعیت مالی"))
            root.addView(financialCard(
                listOf(
                    "فروش ماه جاری" to money(db.sellerSalesTotal(sid ?: 0)),
                    "سهم فروشنده" to money(db.sellerCommission(sid ?: 0)),
                    "پرداخت به گلخانه" to money(db.paidToGreenhouse(sid ?: 0)),
                    "مانده حساب" to money(abs(db.greenhouseBalance(sid ?: 0)))
                ),
                if (d.greenhouseDue == 0L) "تسویه" else if (d.greenhouseDue > 0) "بدهکار گلخانه" else "طلبکار از گلخانه"
            ))
        } else {
            val todayMetrics = buildList {
                if (!db.isStaffMode() || staffHasPermission("sellers") || staffHasPermission("misc_sale")) add("فروش امروز" to money(d.salesToday))
                if (!db.isStaffMode() || staffHasPermission("delivery")) add("تحویل امروز" to "${d.deliveredToday} دسته")
                if (!db.isStaffMode() || staffHasPermission("returns")) add("برگشتی امروز" to "${d.returnedToday} دسته")
                if (!db.isStaffMode() || staffHasPermission("sellers")) add("موجودی نزد فروشندگان" to "${d.stock} دسته")
            }
            if (todayMetrics.isNotEmpty()) {
                root.addView(sectionTitle("نمای کلی امروز"))
                val summary = if (!db.isStaffMode() || staffHasPermission("financial_report")) "مطالبات فروشندگان: ${money(d.greenhouseDue)}" else "وضعیت عملیات مجاز شما"
                root.addView(financialCard(todayMetrics, summary))
            }
            if (!db.isStaffMode() || staffHasPermission("warnings")) {
                root.addView(sectionTitle("هشدارها"))
                root.addView(alertCard("فروش زیر حداقل قیمت", "${db.lowPriceWarningCount(null)} مورد", db.lowPriceWarningCount(null) > 0) { showPriceWarnings() })
            }
        }
        addBottomNavigation(root, "خانه")
        setScreen(root, true)
    }

    private fun showSellerReportsNew() {
        val sid = db.currentSellerId() ?: return
        val root = base("گزارش من", "فروش، موجودی و حساب فروشنده")
        root.addView(financialCard(listOf(
            "کل فروش" to money(db.sellerSalesTotal(sid)),
            "سهم فروشنده" to money(db.sellerCommission(sid)),
            "پرداخت به گلخانه" to money(db.paidToGreenhouse(sid)),
            "موجودی" to "${db.sellerStock(sid)} دسته"
        ), sellerBalanceText(sid).replace("\n", " • ")))
        root.addView(sectionTitle("دسترسی به گزارش‌ها"))
        root.addView(listCard("فروش‌های من", "ریز فروش‌ها، اندازه، تعداد و مبلغ") { showSalesHistory() })
        root.addView(listCard("پرداخت‌های من", "تاریخ و مبالغ پرداختی") { showPaymentHistory(db.sellers().firstOrNull { it.id == sid } ?: return@listCard) })
        root.addView(listCard("موجودی من", "موجودی تفکیک‌شده بر اساس گل و اندازه") { showSellerInventoryReport() })
        root.addView(listCard("حساب و تسویه", "بدهی، طلب و پرداخت‌ها") { showSettlement() })
        addBottomNavigation(root, "گزارش‌ها")
        setScreen(root)
    }

    private fun addBottomNavigation(root: LinearLayout, selected: String) {
        root.addView(Space(this).apply { minimumHeight = dp(4) })
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = cardBackground()
            setPadding(dp(4), dp(1), dp(4), dp(1))
            tag = "APP_BOTTOM_NAV"
        }
        listOf("خانه" to "⌂", "ثبت‌ها" to "＋", "گزارش‌ها" to "▤", "تنظیمات" to "⚙").forEach { (title, icon) ->
            val b = TextView(this).apply {
                text = "$icon\n$title"
                textSize = if (title == selected) 13.5f else 12.5f
                typeface = if (title == selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                gravity = Gravity.CENTER
                setTextColor(if (title == selected) palette().primary else palette().muted)
                setPadding(dp(2), dp(1), dp(2), dp(1))
                layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f)
                setOnClickListener {
                    when (title) {
                        "خانه" -> showHome()
                        "ثبت‌ها" -> showRegistrations()
                        "گزارش‌ها" -> showReportsHub()
                        "تنظیمات" -> showSettings()
                    }
                }
            }
            nav.addView(b)
        }
        root.addView(nav)
    }

    private fun showRegistrations() {
        screenBackStack.clear()
        restoringScreen = false
        val root = base("ثبت‌ها", "هر عملیات را از اینجا ثبت کنید")
        if (db.isSellerMode()) {
            root.addView(listCard("ثبت سریع فروش", "گل ← اندازه ← تعداد و قیمت ← تأیید") { showSale() })
            root.addView(listCard("پرداخت به گلخانه", "مبلغ، روش پرداخت و مانده حساب") { showSettlement() })
            root.addView(listCard("برگشت گل", "ثبت برگشتی‌های فروشنده") { showSellerReturnsAndSales() })
        } else {
            if (staffHasPermission("flower")) root.addView(listCard("ثبت و ویرایش نوع گل", "نام، اندازه، قیمت مرجع و حداقل قیمت") { showFlowers() })
            if (staffHasPermission("sellers")) root.addView(listCard("ثبت فروشنده", "مشخصات و حساب ورود فروشنده") { sellerDialog(null) })
            if (staffHasPermission("delivery")) root.addView(listCard("تحویل گل", "فروشنده، گل، اندازه، تعداد و قیمت مرجع") { showDelivery() })
            if (staffHasPermission("misc_sale")) root.addView(listCard("ثبت فروش متفرقه", "فروش مستقیم گلخانه به اشخاص مختلف") { showMiscSale() })
            if (staffHasPermission("returns")) root.addView(listCard("ثبت برگشتی", "گل، اندازه، تعداد و علت") { showReturn() })
            if (staffHasPermission("expense")) {
                root.addView(listCard("ثبت هزینه گلخانه", "هر هزینه همان لحظه به‌عنوان پرداخت ثبت می‌شود") { showGreenhouseExpense() })
                root.addView(listCard("تعریف نوع هزینه", "انواع هزینه‌های قابل ثبت در گلخانه") { showExpenseTypes() })
            }
            if (staffHasPermission("payments")) root.addView(listCard("پرداخت‌ها", "مشاهده پرداخت‌های فروشندگان") { showAllPaymentsHistory() })
        }
        addBottomNavigation(root, "ثبت‌ها")
        setScreen(root)
    }

    private fun showReportsHub() {
        screenBackStack.clear()
        restoringScreen = false
        val root = base("گزارش‌ها", "گزارش‌ها بر اساس موضوع دسته‌بندی شده‌اند")
        if (db.isSellerMode()) {
            root.addView(sectionTitle("گزارش‌های حساب فروشنده"))
            root.addView(listCard("فروش و برگشتی‌ها", "فروش‌های ثبت‌شده و تاریخچه برگشت گل") {
                showReportCategory("فروش و برگشتی‌ها", "سوابق عملیات فروشنده", listOf(
                    Triple("فروش‌های من", "تاریخ، گل، اندازه، تعداد و مبلغ", { showSalesHistory() }),
                    Triple("برگشتی‌ها", "تاریخچه برگشت گل", { showSellerReturnsAndSales() })
                ), true)
            })
            root.addView(listCard("موجودی", "موجودی هر گل و اندازه") { showSellerInventoryReport() })
            root.addView(listCard("پرداخت‌ها", "تاریخچه پرداخت‌ها به گلخانه") { showPaymentHistory(db.sellers().firstOrNull { it.id == db.currentSellerId() } ?: return@listCard) })
            root.addView(listCard("گزارش مالی و آرشیو", "سهم، پرداخت، مانده حساب و ماه‌های بسته‌شده") {
                showReportCategory("گزارش مالی و آرشیو", "وضعیت مالی حساب شما", listOf(
                    Triple("گزارش مالی", "سهم، پرداخت و مانده حساب", { showSellerReportsNew() }),
                    Triple("آرشیو ماه‌های مالی من", "گزارش ماه‌های بسته‌شده", { db.currentSellerId()?.let { showSellerFinancialArchives(it) } })
                ), true)
            })
        } else {
            root.addView(sectionTitle("گروه‌های گزارش گلخانه"))
            root.addView(listCard("📦 تحویل، فروش و برگشتی‌ها", "گزارش‌های روزمره و سوابق عملیات گل") {
                val items = mutableListOf<Triple<String,String,()->Unit>>()
                if (staffHasPermission("delivery")) items += Triple("تحویل گل", "فهرست تحویل‌های ثبت‌شده به فروشندگان", { showGreenhouseDeliveryReport() })
                if (staffHasPermission("sellers")) items += Triple("فروش فروشندگان", "فروش‌ها به تفکیک فروشنده و گل", { showGreenhouseSellerSalesReport() })
                if (staffHasPermission("misc_sale")) items += Triple("فروش متفرقه گلخانه", "فروش مستقیم و بدون فروشنده", { showMiscSalesReport() })
                if (staffHasPermission("returns")) items += Triple("برگشتی‌ها", "تمام برگشتی‌ها به تفکیک فروشنده و گل", { showReturnReport() })
                if (staffHasPermission("payments")) items += Triple("پرداخت‌های فروشندگان", "پرداخت‌های ثبت‌شده توسط فروشندگان", { showAllPaymentsHistory() })
                showReportCategory("تحویل، فروش و برگشتی‌ها", "گزارش‌های عملیاتی", items, true)
            })
            root.addView(listCard("💰 گزارش‌های مالی", "هزینه‌ها، بدهی‌ها، پرداخت‌ها و آرشیو ماهانه") {
                val items = mutableListOf<Triple<String,String,()->Unit>>()
                if (staffHasPermission("expense")) {
                    items += Triple("هزینه‌های گلخانه", "ریز هزینه‌ها و جمع کل", { showGreenhouseExpensesReport() })
                    items += Triple("انواع هزینه", "تعریف و ویرایش دسته‌های هزینه", { showExpenseTypes() })
                }
                if (!db.isStaffMode() || staffHasPermission("financial_report")) items += Triple("آرشیو ماه‌های مالی", "گزارش ماه‌های بسته‌شده و مانده انتقالی", { showFinancialArchives() })
                if (staffHasPermission("financial_report")) items += Triple("گزارش مالی جامع", "بدهی، طلب، پرداخت و سهم فروشنده و گلخانه", { showFinancialReport() })
                showReportCategory("گزارش‌های مالی", "هزینه و وضعیت مالی", items, true)
            })
            root.addView(listCard("📊 تحلیل فروش و موجودی", "گزارش‌های تفصیلی و کنترل موجودی") {
                val items = mutableListOf<Triple<String,String,()->Unit>>()
                if (staffHasPermission("financial_report")) {
                    items += Triple("گزارش تفصیلی فروش", "فیلتر بر اساس فروشنده و بازه تاریخ", { showDetailedReport() })
                    items += Triple("گزارش موجودی", "موجودی گلخانه و موجودی نزد فروشندگان", { showGreenhouseInventoryReport() })
                }
                if (staffHasPermission("warnings")) items += Triple("هشدارهای قیمت", "فروش‌های زیر حداقل قیمت و فروشنده", { showPriceWarnings() })
                if (staffHasPermission("flower")) items += Triple("فهرست گل‌ها و قیمت‌ها", "اندازه‌ها، قیمت پایه و حداقل قیمت", { showFlowers() })
                if (staffHasPermission("sellers")) items += Triple("فهرست فروشندگان", "موجودی، فروش و حساب هر فروشنده", { showSellers() })
                showReportCategory("تحلیل فروش و موجودی", "کنترل عملکرد و اقلام", items, true)
            })
        }
        addBottomNavigation(root, "گزارش‌ها")
        setScreen(root)
    }

    private fun showReportCategory(title: String, subtitle: String, items: List<Triple<String, String, () -> Unit>>, showNavigation: Boolean) {
        val root = base(title, subtitle)
        if (items.isEmpty()) root.addView(cardText("برای این بخش دسترسی فعالی وجود ندارد. در صورت نیاز از مدیر بخواهید مجوز مربوط را فعال کند."))
        else items.forEach { (name, detail, action) -> root.addView(listCard(name, detail, action)) }
        root.addView(actionButton("↩️ بازگشت به دسته‌بندی گزارش‌ها") { showReportsHub() })
        if (showNavigation) addBottomNavigation(root, "گزارش‌ها")
        setScreen(root)
    }

    private fun heroCard(title: String, subtitle: String, icon: String, action: () -> Unit): LinearLayout {
        val box = cardContainer()
        box.addView(TextView(this).apply { text = icon; textSize = 34f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(2)) })
        box.addView(TextView(this).apply { text = title; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(palette().text) })
        box.addView(TextView(this).apply { text = subtitle; textSize = 14f; gravity = Gravity.CENTER; setTextColor(palette().muted); setPadding(dp(8), dp(4), dp(8), dp(12)) })
        box.setOnClickListener { action() }
        return box
    }

    private fun iconGrid(items: List<Triple<String, String, () -> Unit>>): LinearLayout {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        items.chunked(3).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            rowItems.forEach { (title, icon, action) ->
                val card = cardContainer().apply { gravity = Gravity.CENTER; setPadding(dp(5), dp(10), dp(5), dp(8)); setOnClickListener { action() } }
                card.addView(TextView(this).apply { text = icon; textSize = 28f; gravity = Gravity.CENTER })
                card.addView(TextView(this).apply { text = title; textSize = 12.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(palette().text); setPadding(0, dp(5), 0, 0) })
                val lp = LinearLayout.LayoutParams(0, dp(108), 1f); lp.setMargins(dp(3), dp(3), dp(3), dp(3)); row.addView(card, lp)
            }
            repeat(3 - rowItems.size) { row.addView(Space(this), LinearLayout.LayoutParams(0, dp(108), 1f)) }
            grid.addView(row)
        }
        return grid
    }

    private fun cardContainer(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        background = cardBackground()
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(5), 0, dp(6)); layoutParams = lp
        setPadding(dp(14), dp(10), dp(14), dp(10))
        elevation = dp(1).toFloat()
    }

    private fun listCard(title: String, subtitle: String, action: () -> Unit): LinearLayout {
        val box = cardContainer().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setOnClickListener { action() } }
        box.addView(TextView(this).apply { text = "›"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(palette().primary); layoutParams = LinearLayout.LayoutParams(dp(32), dp(58)) })
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; layoutParams = LinearLayout.LayoutParams(0, dp(66), 1f) }
        textBox.addView(TextView(this).apply { text = title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(palette().text) })
        textBox.addView(TextView(this).apply { text = subtitle; textSize = 12.5f; setTextColor(palette().muted); setPadding(0, dp(4), 0, 0) })
        box.addView(textBox)
        return box
    }

    private fun outlineAction(title: String, action: () -> Unit): Button = Button(this).apply {
        text = title; isAllCaps = false; textSize = 15f; setOnClickListener { action() }; layoutDirection = View.LAYOUT_DIRECTION_RTL
        background = cardBackground(); setTextColor(palette().primary); minHeight = dp(54)
        layoutParams = LinearLayout.LayoutParams(-1, dp(56)).also { it.setMargins(0, dp(2), 0, dp(3)) }
    }

    private fun statusCard(text: String): TextView = TextView(this).apply {
        this.text = text; textSize = 12.5f; setTextColor(palette().text); gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT; background = cardBackground(); setPadding(dp(14), 0, dp(14), 0); layoutParams = LinearLayout.LayoutParams(-1, dp(52)).also { it.setMargins(0, dp(4), 0, dp(8)) }
    }

    private fun homeSyncStatusText(): String {
        val last = db.lastFirebaseSync()
        val error = db.settingTextPublic("last_sync_error", "").trim()
        return when {
            syncInProgress -> "🔄  همگام‌سازی: در حال انجام..."
            !isNetworkAvailable() -> "⚪  همگام‌سازی: آفلاین — اطلاعات پس از اتصال اینترنت همگام می‌شوند"
            !firebaseSignedIn() -> "🔴  همگام‌سازی: اتصال Firebase برقرار نیست"
            error.isNotBlank() && last == null -> "🔴  همگام‌سازی ناموفق — ${error.take(90)}"
            error.isNotBlank() -> "🟠  همگام‌سازی ناموفق — آخرین موفق: ${jalaliDateTime(last!!)}\n${error.take(90)}"
            last == null -> "🟡  همگام‌سازی: آماده — هنوز همگام‌سازی موفقی ثبت نشده است"
            else -> "🟢  همگام‌سازی موفق — آخرین بروزرسانی: ${jalaliDateTime(last)}"
        }
    }

    private fun refreshHomeSyncStatus() {
        if (!isHomeScreen) return
        runOnUiThread {
            val root = window.decorView.findViewWithTag<LinearLayout>("GOL_NEGAR_HOME_ROOT") ?: return@runOnUiThread
            val card = root.findViewWithTag<TextView>("GOL_NEGAR_SYNC_CARD") ?: return@runOnUiThread
            card.text = homeSyncStatusText()
        }
    }

    private fun syncStatusCard(text: String): TextView = statusCard(text).apply {
        tag = "GOL_NEGAR_SYNC_CARD"
        isClickable = true
        setOnClickListener {
            syncStatusTapHandler.removeCallbacks(resetSyncStatusTapCount)
            syncStatusTapCount++
            if (syncStatusTapCount >= 5) {
                syncStatusTapCount = 0
                info("درخواست همگام‌سازی دستی ارسال شد.")
                syncWithFirebaseIfOnline(true)
            } else {
                syncStatusTapHandler.postDelayed(resetSyncStatusTapCount, 1800L)
            }
        }
    }

    private fun financialCard(items: List<Pair<String, String>>, footer: String): LinearLayout {
        val box = cardContainer()
        items.forEach { (k, v) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6)) }
            row.addView(TextView(this).apply { text = k; textSize = 13f; setTextColor(palette().muted); layoutParams = LinearLayout.LayoutParams(0, dp(34), 1f) })
            row.addView(TextView(this).apply { text = v; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(palette().text); gravity = Gravity.LEFT; layoutParams = LinearLayout.LayoutParams(dp(150), dp(34)) })
            box.addView(row)
        }
        box.addView(TextView(this).apply { text = footer; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(palette().primary); gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), dp(4)) })
        return box
    }

    private fun alertCard(title: String, value: String, attention: Boolean, action: () -> Unit): LinearLayout {
        val box = listCard(title, value, action)
        if (attention) box.setBackgroundColor(Color.rgb(255, 248, 235))
        return box
    }

    private fun showFlowers() {
        if (!requireStaffPermission("flower", "تعریف و ویرایش گل")) return
        val root = base("انواع گل")
        root.addView(actionButton("＋  تعریف نوع گل") { flowerDialog(null) })
        db.flowers().forEach { f ->
            root.addView(cardRow("🌹  ${f.name} | اندازه: ${f.size}\nقیمت پایه: ${money(f.basePrice)}  |  حداقل فروش: ${money(f.minPrice)}") {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                row.addView(actionButton("ویرایش") { flowerDialog(f) }, LinearLayout.LayoutParams(0, dp(56), 1f))
                row.addView(actionButton("حذف") { confirmDelete("حذف ${f.name}؟") { db.delete("flowers", f.id); showFlowers(); syncWithFirebaseIfOnline(false) } }, LinearLayout.LayoutParams(0, dp(56), 1f))
                it.addView(row)
            })
        }
        root.addView(actionButton("بازگشت") { goBack() })
        setScreen(root)
    }

    private fun flowerDialog(f: Flower?) {
        val box = formBox(); val name = field("نام گل", f?.name ?: ""); val size = field("اندازه گل (مثلاً ۴۰ سانتی / ۵۰ سانتی)", f?.size ?: ""); val base = moneyField("قیمت پایه هر دسته (ریال)", f?.basePrice?.toString() ?: ""); val min = moneyField("حداقل قیمت مجاز (ریال)", f?.minPrice?.toString() ?: "")
        box.addView(name); box.addView(size); box.addView(base); box.addView(min)
        AlertDialog.Builder(this).setTitle(if (f == null) "تعریف گل" else "ویرایش گل").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val n=name.text.toString().trim(); val z=size.text.toString().trim(); val b=parseMoney(base); val m=parseMoney(min)
                if(n.isNotEmpty() && z.isNotEmpty() && b>0 && m>0) db.upsertFlower(f?.id,n,z,b,m); else info("نام، اندازه و قیمت‌ها را کامل وارد کنید.")
                if(n.isNotEmpty() && z.isNotEmpty() && b>0 && m>0) { showFlowers(); syncWithFirebaseIfOnline(false) }
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showSellers() {
        if (!requireStaffPermission("sellers", "مدیریت فروشندگان")) return
        val root = base("فروشندگان", "درصد سهم هر فروشنده از مبلغ فروش قابل تنظیم است")
        root.addView(actionButton("＋  تعریف فروشنده") { sellerDialog(null) })
        db.sellers().forEach { s ->
            root.addView(cardRow("👤  ${s.name}\n${s.phone}\nنام کاربری: ${s.username}\nرمز عبور: ${db.sellerPassword(s.id).ifBlank { "ثبت نشده" }}\nسهم فروشنده از فروش خودش: ${fmtPercent(db.sellerShare(s.id))}%") {
                it.addView(actionButton("✏️ ویرایش نام، نام کاربری و رمز") { sellerDialog(s) })
                it.addView(actionButton("حذف فروشنده") { confirmDelete("فروشنده «${s.name}» حذف شود؟ اگر سابقه مالی داشته باشد، برای حفظ سوابق مالی غیرفعال می‌شود.") { db.deleteSeller(s.id); showSellers(); syncWithFirebaseIfOnline(false) } })
            })
        }
        root.addView(actionButton("بازگشت") { goBack() }); setScreen(root)
    }

    private fun sellerDialog(s: Seller?) {
        val box=formBox()
        box.addView(sectionTitle("👤 اطلاعات فروشنده"))
        val name=field("نام فروشنده",s?.name?:"")
        val phone=field("شماره تماس",s?.phone?:"")
        box.addView(name)
        box.addView(phone)

        box.addView(sectionTitle("🔐 اطلاعات ورود"))
        val username=field("نام کاربری",s?.username?:"")
        val currentPassword = s?.let { db.sellerPassword(it.id) } ?: ""
        // Seller passwords are intentionally visible in the greenhouse seller-management form.
        // Firebase still requires at least 6 characters; there is no need for a hide/show toggle here.
        val password=field("رمز عبور فروشنده (همیشه قابل مشاهده)",currentPassword)
        password.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        password.transformationMethod = null
        box.addView(username)
        box.addView(password)
        box.addView(cardText("رمز عبور باید حداقل ۶ کاراکتر باشد."))

        box.addView(sectionTitle("💰 امور مالی"))
        val share=numberField("درصد توافقی فروشنده",s?.let{db.sellerShare(it.id).toString()}?:db.getDefaultSellerShare().toString())
        box.addView(share)

        AlertDialog.Builder(this)
            .setTitle(if(s==null) "تعریف فروشنده جدید" else "ویرایش فروشنده")
            .setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val n=name.text.toString().trim()
                val u=username.text.toString().trim()
                val p=password.text.toString()
                val pct=share.text.toString().toDoubleOrNull()
                if(n.isBlank() || u.isBlank()) {
                    info("نام فروشنده و نام کاربری را کامل وارد کنید.")
                } else if((s==null && p.isBlank()) || (p.isNotBlank() && p.length < 6)) {
                    info("رمز عبور فروشنده باید حداقل ۶ کاراکتر باشد.")
                } else if(pct==null || pct !in 0.0..100.0) {
                    info("درصد سهم فروشنده باید بین صفر تا صد باشد.")
                } else {
                    val finalPassword=if(p.isBlank() && s!=null) db.sellerPassword(s.id) else p
                    db.upsertSeller(s?.id,n,phone.text.toString().trim(),u,finalPassword,pct)
                    showSellers()
                    syncWithFirebaseIfOnline(false)
                }
            }
            .setNegativeButton("انصراف",null)
            .show()
    }

    private fun showMiscSale() {
        if (!requireStaffPermission("misc_sale", "ثبت فروش متفرقه")) return
        if (db.isSellerMode()) { info("ثبت فروش متفرقه فقط در نسخه گلخانه انجام می‌شود."); return }
        val root=base("ثبت فروش متفرقه گلخانه","فروش مستقیم گل به اشخاص مختلف؛ این فروش به حساب فروشندگان وارد نمی‌شود.")
        val flowers=db.flowers(); if(flowers.isEmpty()){info("ابتدا حداقل یک نوع گل تعریف کنید.");return}
        val buyer=field("نام خریدار","")
        val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64)
        val qty=numberField("تعداد دسته","1")
        val price=moneyField("قیمت فروش هر دسته (ریال)","")
        val payment=spinner("نوع دریافتی",listOf("نقدی","کارتخوان","کارت به کارت","واریز بانکی","چک","سایر"),64)
        val cashPeople=db.pettyCashPeople(); val cashSpinner=spinner("دریافت توسط تنخواه",cashPeople.map{it.name},64)
        val cashLabel=label("دریافت توسط تنخواه")
        if(!db.isSellerMode()){
            root.addView(actionButton("👛 تعریف صندوق تنخواه"){showPettyCashPeople()})
        }
        val date=Calendar.getInstance().apply{timeInMillis=db.appDate()}; val dateLabel=label("تاریخ فروش: ${jalali(date)}")
        root.addView(label("نام خریدار"));root.addView(buyer);root.addView(label("نوع گل / اندازه"));root.addView(flower);root.addView(qty);root.addView(price);root.addView(label("نوع دریافتی"));root.addView(payment)
        if(cashPeople.isNotEmpty()){root.addView(cashLabel);root.addView(cashSpinner)} else root.addView(cardText("برای فروش نقدی ابتدا در تنظیمات، صندوق تنخواه را تعریف کنید."))
        root.addView(dateLabel);root.addView(actionButton("📅 انتخاب تاریخ فروش"){DatePickerDialog(this,{_,y,m,d->date.set(y,m,d,12,0,0);date.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ فروش: ${jalali(date)}"},date.get(Calendar.YEAR),date.get(Calendar.MONTH),date.get(Calendar.DAY_OF_MONTH)).show()})
        root.addView(actionButton("ثبت فروش متفرقه"){val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val p=parseMoney(price);if(buyer.text.toString().trim().isBlank()){info("نام خریدار را وارد کنید.");return@actionButton};if(q<=0||p<=0){info("تعداد و قیمت فروش را صحیح وارد کنید.");return@actionButton};if(payment.selectedItemPosition==0&&cashPeople.isEmpty()){info("برای دریافتی نقدی ابتدا صندوق تنخواه را تعریف کنید.");return@actionButton};val petty=if(payment.selectedItemPosition==0) cashPeople[cashSpinner.selectedItemPosition].id else null;val saved=db.addMiscSale(buyer.text.toString().trim(),flowers[flower.selectedItemPosition].id,q,p,payment.selectedItem.toString(),petty,date.timeInMillis);if(!saved){info("ثبت فروش متفرقه در حافظه برنامه انجام نشد. لطفاً دوباره تلاش کنید.");return@actionButton};buyer.setText("");qty.setText("1");price.setText("");info("فروش متفرقه ثبت شد.");syncWithFirebaseIfOnline(false)})
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun refreshAdminDataAndShow(after: () -> Unit) {
        // Reports are local-first: show the current local ledger immediately, then refresh
        // from Firebase. Do not yank the user back from another page if they navigate while
        // the request is in flight, and do not create duplicate Back-stack entries.
        after()
        val shownTag = currentScreenRoot?.tag
        if (db.isSellerMode() || !isNetworkAvailable() || !firebaseSignedIn()) return
        syncWithFirebaseIfOnline(false) { ok ->
            if (ok) runOnUiThread {
                if (shownTag != null && currentScreenRoot?.tag == shownTag) {
                    val wasRestoring = restoringScreen
                    restoringScreen = true
                    try { after() } finally { restoringScreen = wasRestoring }
                }
            }
        }
    }

    private fun showMiscSalesHistory(){
        if (!requireStaffPermission("misc_sale", "گزارش فروش متفرقه")) return
        refreshAdminDataAndShow { renderMiscSalesPage("فروش‌های متفرقه", "فهرست فروش‌های مستقیم گلخانه به خریداران") }
    }

    private fun showMiscSalesReport(){
        if (!requireStaffPermission("misc_sale", "گزارش فروش متفرقه")) return
        refreshAdminDataAndShow { renderMiscSalesPage("گزارش فروش متفرقه", "ریز فروش و جمع کل؛ مطابق دفتر مالی گلخانه") }
    }

    private fun renderMiscSalesPage(title: String, subtitle: String){
        val root=base(title,subtitle)
        val rows=try { db.miscSales() } catch (_: Exception) { emptyList() }
        val total=rows.sumOf{it.total}
        val qty=rows.sumOf{it.qty}
        root.addView(financialCard(listOf(
            "تعداد فروش‌ها" to rows.size.toString(),
            "تعداد دسته فروخته‌شده" to qty.toString(),
            "جمع فروش متفرقه" to money(total)
        ), if(rows.isEmpty()) "هنوز فروش متفرقه‌ای ثبت نشده است" else "مبنای محاسبه همان دفتر فروش متفرقه است"))
        if(rows.isNotEmpty()){
            root.addView(tableHeader(listOf("تاریخ","خریدار","گل/اندازه","تعداد","مبلغ")))
            rows.forEach{r->root.addView(tableRow(listOf(r.date,r.buyerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.total))))}
            root.addView(tableRow(listOf("جمع کل","","",qty.toString(),money(total)),true))
        }
        root.addView(actionButton("＋ ثبت فروش متفرقه جدید"){showMiscSale()})
        root.addView(actionButton("بازگشت"){goBack()})
        setScreen(root)
    }

    private fun showExpenseTypes(){
        if (!requireStaffPermission("expense", "مدیریت انواع هزینه")) return
        val root=base("انواع هزینه گلخانه","نوع هزینه را یک‌بار تعریف کنید و هنگام ثبت هزینه انتخاب کنید.")
        root.addView(actionButton("＋ تعریف نوع هزینه"){
            val f=field("نام نوع هزینه","")
            AlertDialog.Builder(this).setTitle("تعریف نوع هزینه").setView(f)
                .setPositiveButton("ثبت"){_,_->
                    val n=f.text.toString().trim()
                    if(n.isBlank()){info("نام نوع هزینه را وارد کنید.");return@setPositiveButton}
                    if(db.addExpenseType(n)){showExpenseTypes();syncWithFirebaseIfOnline(false)} else info("این نوع هزینه قبلاً تعریف شده است.")
                }.setNegativeButton("انصراف",null).show()
        })
        db.expenseTypes().forEach { t ->
            root.addView(cardRow("💰 ${t}"){
                it.addView(actionButton("ویرایش"){
                    val f=field("نام نوع هزینه",t)
                    AlertDialog.Builder(this).setTitle("ویرایش نوع هزینه").setView(f)
                        .setPositiveButton("ذخیره"){_,_->
                            val n=f.text.toString().trim()
                            if(n.isBlank()){info("نام نوع هزینه را وارد کنید.");return@setPositiveButton}
                            if(db.updateExpenseType(t,n)){showExpenseTypes();syncWithFirebaseIfOnline(false)} else info("این نام قبلاً استفاده شده است.")
                        }.setNegativeButton("انصراف",null).show()
                })
            })
        }
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showGreenhouseExpense(){
        if (!requireStaffPermission("expense", "ثبت هزینه گلخانه")) return
        if(db.isSellerMode()){info("ثبت هزینه گلخانه فقط در نسخه گلخانه انجام می‌شود.");return}
        val root=base("ثبت هزینه گلخانه","هزینه و پرداخت هم‌زمان ثبت می‌شوند و پرداخت از تنخواه‌های فعلی برنامه انجام می‌شود.")
        val types=db.expenseTypes()
        val people=db.pettyCashPeople()
        if(people.isEmpty()){root.addView(cardText("برای ثبت هزینه ابتدا حداقل یک شخص را در «صندوق تنخواه» تعریف کنید."));root.addView(actionButton("مدیریت صندوق تنخواه"){showPettyCashPeople()});root.addView(actionButton("بازگشت"){goBack()});setScreen(root);return}
        val box=formBox()
        val type=spinner("نوع هزینه",types,64)
        val amount=moneyField("مبلغ هزینه (ریال)","")
        val petty=spinner("پرداخت از تنخواه",people.map{it.name},64)
        val desc=field("شرح هزینه","")
        val date=Calendar.getInstance().apply{timeInMillis=db.appDate()}
        val dl=label("تاریخ هزینه: ${jalali(date)}")
        box.addView(label("نوع هزینه"));box.addView(type);box.addView(amount);box.addView(label("پرداخت از تنخواه"));box.addView(petty);box.addView(desc);box.addView(dl)
        box.addView(actionButton("📅 انتخاب تاریخ"){DatePickerDialog(this,{_,y,m,d->date.set(y,m,d,12,0,0);date.set(Calendar.MILLISECOND,0);dl.text="تاریخ هزینه: ${jalali(date)}"},date.get(Calendar.YEAR),date.get(Calendar.MONTH),date.get(Calendar.DAY_OF_MONTH)).show()})
        root.addView(box)
        root.addView(actionButton("ثبت هزینه"){
            val a=parseMoney(amount)
            if(a<=0){info("مبلغ هزینه را صحیح وارد کنید.");return@actionButton}
            val saved=db.addGreenhouseExpense(type.selectedItem.toString(),a,people[petty.selectedItemPosition].id,desc.text.toString().trim(),date.timeInMillis)
            if(!saved){info("ثبت هزینه در حافظه برنامه انجام نشد. لطفاً دوباره تلاش کنید.");return@actionButton}
            info("هزینه با موفقیت ثبت شد."){goBack()}
            syncWithFirebaseIfOnline(false)
        })
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showGreenhousePaymentsHistory(){
        refreshAdminDataAndShow { renderGreenhouseExpensesPage("هزینه‌های گلخانه", "فهرست تمام هزینه‌های پرداخت‌شده") }
    }

    private fun showGreenhouseExpensesReport(){
        if (!requireStaffPermission("expense", "گزارش هزینه‌ها")) return
        refreshAdminDataAndShow { renderGreenhouseExpensesPage("گزارش هزینه‌های گلخانه", "ریز هزینه‌ها و جمع کل؛ مطابق دفتر مالی گلخانه") }
    }

    private fun renderGreenhouseExpensesPage(title: String, subtitle: String){
        val root=base(title,subtitle)
        root.addView(actionButton("＋ ثبت هزینه جدید"){showGreenhouseExpense()})
        val rows=try { db.greenhousePayments() } catch (_: Exception) { emptyList() }
        val total=rows.sumOf{it.amount}
        root.addView(financialCard(listOf(
            "تعداد هزینه‌ها" to rows.size.toString(),
            "جمع هزینه‌های گلخانه" to money(total)
        ), if(rows.isEmpty()) "هنوز هزینه‌ای در دفتر هزینه گلخانه ثبت نشده است" else "مبنای محاسبه همان دفتر هزینه‌های گلخانه است"))
        if(rows.isNotEmpty()){
            root.addView(tableHeader(listOf("تاریخ","نوع هزینه","شرح","مبلغ")))
            rows.forEach{r->root.addView(tableRow(listOf(r.date,r.expenseType,r.description.ifBlank{"بدون شرح"},money(r.amount))))}
            root.addView(tableRow(listOf("جمع کل","","",money(total)),true))
        }
        root.addView(actionButton("بازگشت به گزارش‌ها"){goBack()})
        setScreen(root)
    }

    private fun showDelivery() {
        if (!requireStaffPermission("delivery", "ثبت تحویل گل")) return
        val root=base("تحویل امانی به فروشنده","تحویل گل تا زمان فروش، امانت نزد فروشنده است و بدهی ایجاد نمی‌کند.")
        val flowers=db.flowers(); val sellers=db.sellers()
        if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا حداقل یک گل و یک فروشنده تعریف کنید.");return}
        val seller=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64)
        val flower=spinner("نوع گل",flowers.map{"${it.name} | ${it.size}"},64)
        val qty=numberField("تعداد دسته",""); val price=moneyField("قیمت مرجع هر دسته (ریال)","")
        val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}
        val dateLabel=label("تاریخ تحویل امانی: ${jalali(selectedDate)}")
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل / اندازه"));root.addView(flower);root.addView(qty);root.addView(price);root.addView(dateLabel)
        root.addView(actionButton("📅 انتخاب تاریخ"){val initial=selectedDate.clone() as Calendar;DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ تحویل امانی: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()})
        val historyBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val totalBox=TextView(this).apply{textSize=16f;setTextColor(Color.DKGRAY);setPadding(dp(12),dp(12),dp(12),dp(12))}
        fun refreshHistory(){
            historyBox.removeAllViews()
            val sid=if(seller.selectedItemPosition==0)null else sellers[seller.selectedItemPosition-1].id
            val rows=db.greenhouseSalesFiltered(sid,selectedDate.timeInMillis)
            historyBox.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","قیمت مرجع","ارزش مرجع")))
            if(rows.isEmpty()) historyBox.addView(label("رکوردی برای این تاریخ وجود ندارد."))
            else rows.forEach{r->historyBox.addView(tableRow(listOf(r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))}
            val totals=db.greenhouseDayTotals(sid,selectedDate.timeInMillis)
            totalBox.text="جمع تحویل: ${totals.qty} دسته\nارزش مرجع تحویل‌ها: ${money(totals.total)} ریال\nمیانگین قیمت مرجع: ${money(totals.avg)} ریال\nنکته: تحویل امانی تا زمان فروش برای فروشنده بدهی ایجاد نمی‌کند."
        }
        seller.setOnItemSelectedListener(simpleListener{refreshHistory()})
        root.addView(actionButton("ثبت تحویل امانی"){
            val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val p=parseMoney(price);val f=flowers[flower.selectedItemPosition]
            if(q<=0||p<=0){info("تعداد و قیمت را صحیح وارد کنید.");return@actionButton}
            val targets=if(seller.selectedItemPosition==0)sellers else listOf(sellers[seller.selectedItemPosition-1])
            if(targets.size>1){info("برای ثبت یک فروش باید یک فروشنده مشخص انتخاب کنید.");return@actionButton}
            val ss=targets[0]
            db.addDelivery(ss.id,f.id,q,p,selectedDate.timeInMillis)
            qty.setText("");price.setText("");refreshHistory()
            info("تحویل امانی ثبت شد؛ تا زمان فروش، برای فروشنده بدهی ایجاد نمی‌شود.")
            syncWithFirebaseIfOnline(false)
        })
        root.addView(label("📋 تحویل‌های امانی در تاریخ انتخاب‌شده"));root.addView(historyBox);root.addView(totalBox);refreshHistory()
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showSale() {
        if (db.isSellerMode() && isNetworkAvailable() && firebaseSignedIn()) {
            val loading=base("ثبت فروش جدید")
            loading.addView(cardText("در حال بروزرسانی فهرست گل‌ها و اندازه‌ها…"))
            setScreen(loading)
            syncWithFirebaseIfOnline(false) { runOnUiThread { renderSalePage() } }
            return
        }
        renderSalePage()
    }

    private fun renderSalePage() {
        val root=base("ثبت فروش جدید")
        val flowers=db.flowers(); val sellerId=db.currentSellerId(); val seller=db.sellerById(sellerId ?: -1L) ?: run { info("اطلاعات حساب فروشنده پیدا نشد. لطفاً یک‌بار از حساب خارج و دوباره وارد شوید."); return }
        if(flowers.isEmpty()){info("ابتدا نوع گل را تعریف کنید.");return}
        val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64); val qty=numberField("تعداد دسته فروخته‌شده",""); val price=moneyField("قیمت فروش هر دسته به مشتری (ریال)","")
        val stockText=label(""); val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}; val dateLabel=label("تاریخ فروش: ${jalali(selectedDate)}")
        val salesBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}; val totalBox=label("")
        fun refresh(){val f=flowers[flower.selectedItemPosition];stockText.text="موجودی امانی ${f.name} | ${f.size}: ${db.sellerFlowerStock(seller.id,f.id)} دسته";if(price.text.toString().isBlank()) price.setText(money(f.basePrice))}
        fun refreshSalesTable(){
            salesBox.removeAllViews()
            val rows=db.sellerSalesDetailed(seller.id).take(5)
            var total=0L; var commissionTotal=0L; var qtyTotal=0
            rows.forEach{r->total+=r.total; commissionTotal+=(r.total*db.sellerShare(seller.id)/100.0).toLong(); qtyTotal+=r.qty}
            if(rows.isEmpty()) {
                salesBox.addView(cardText("هیچ فروش جدیدی ثبت نشده است.\nپس از ثبت فروش، خلاصه آن در همین بخش نمایش داده می‌شود."))
            } else {
                salesBox.addView(cardText("📊 ${rows.size} فروش اخیر\nمجموع فروش: ${money(total)} ریال\nمجموع سهم فروشنده: ${money(commissionTotal)} ریال"))
                rows.forEach{r->
                    val part=(r.total*db.sellerShare(seller.id)/100.0).toLong()
                    salesBox.addView(cardRow("${r.flowerName} | ${r.size}\n${r.qty} دسته × ${money(r.unitPrice)} ریال\nفروش: ${money(r.total)} ریال | سهم فروشنده: ${money(part)} ریال\n${r.date}") {})
                }
            }
            val avg=if(qtyTotal==0)0 else total/qtyTotal
            totalBox.text="جمع ۵ فروش اخیر: $qtyTotal دسته\nمیانگین قیمت: ${money(avg)} ریال\n${sellerBalanceText(seller.id)}"
        }
        flower.setOnItemSelectedListener(simpleListener{refresh()});refresh();refreshSalesTable()
        root.addView(label("گل / اندازه"));root.addView(flower);root.addView(stockText);root.addView(qty);root.addView(price);root.addView(dateLabel)
        root.addView(actionButton("📅 انتخاب تاریخ فروش"){val initial=selectedDate.clone() as Calendar;DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ فروش: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()})
        root.addView(actionButton("ثبت فروش") {
            val q=qty.text.toString().replace(",","").toIntOrNull()?:0
            val p=parseMoney(price)
            val f=flowers[flower.selectedItemPosition]
            val stock=db.sellerFlowerStock(seller.id,f.id)
            if(q<=0||p<=0){info("تعداد و قیمت را صحیح وارد کنید.");return@actionButton}
            if(q>stock){info("موجودی کافی نیست. موجودی فعلی: $stock دسته");return@actionButton}
            if(p<f.minPrice){
                AlertDialog.Builder(this)
                    .setTitle("⚠️ هشدار قیمت")
                    .setMessage("قیمت فروش واردشده کمتر از حداقل قیمت تعیین‌شده است.\n\nقیمت تعیین‌شده: ${money(f.basePrice)} ریال\nحداقل قیمت مجاز: ${money(f.minPrice)} ریال\nقیمت فروش شما: ${money(p)} ریال\n\nآیا با وجود این هشدار، فروش ثبت شود؟")
                    .setNegativeButton("انصراف",null)
                    .setPositiveButton("ثبت فروش") { _, _ -> saveSale(seller.id,f.id,q,p,selectedDate.timeInMillis,qty,price,stockText){refreshSalesTable()} }
                    .show()
                return@actionButton
            }
            saveSale(seller.id,f.id,q,p,selectedDate.timeInMillis,qty,price,stockText){refreshSalesTable()}
        })
        root.addView(label("📋 خلاصه فروش‌های اخیر"));root.addView(salesBox);root.addView(totalBox)
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun saveSale(sellerId:Long,flowerId:Long,qty:Int,price:Long,saleDate:Long,qtyField:EditText,priceField:EditText,stockText:TextView,onSaved:(()->Unit)?=null){db.addSale(sellerId,flowerId,qty,price,saleDate);qtyField.setText("");priceField.setText("");stockText.text="موجودی قابل فروش: ${db.sellerFlowerStock(sellerId,flowerId)} دسته";onSaved?.invoke();info("فروش فروشنده ثبت شد.\nتاریخ فروش: ${jalaliDate(saleDate)}\nمبلغ: ${money(qty.toLong()*price)} ریال");syncWithFirebaseIfOnline(false)}

    private fun showSellerReturnsAndSales() {
        if (db.isSellerMode() && isNetworkAvailable() && firebaseSignedIn()) {
            val loading=base("برگشت کالا / مشاهده فروش‌ها")
            loading.addView(cardText("در حال بروزرسانی اطلاعات…"))
            setScreen(loading)
            syncWithFirebaseIfOnline(false) { runOnUiThread { renderSellerReturnsAndSales() } }
            return
        }
        renderSellerReturnsAndSales()
    }

    private fun renderSellerReturnsAndSales() {
        val root=base("برگشت کالا / مشاهده فروش‌ها","فروش‌های اخیر و برگشت‌های ثبت‌شده شما")
        val sid=db.currentSellerId()?:return
        root.addView(label("🧾 فروش‌های اخیر"))
        val sales=db.sellerSalesDetailed(sid).take(10)
        if(sales.isEmpty()) root.addView(label("هنوز فروشی ثبت نشده است."))
        else sales.forEach{r->root.addView(cardRow("${r.flowerName} | ${r.size} | ${r.qty} دسته\nقیمت هر دسته: ${money(r.unitPrice)} ریال\nمبلغ کل: ${money(r.total)} ریال\n${r.date}") {})}

        root.addView(sectionTitle("↩️ ثبت برگشت کالا"))
        val flowers=db.flowers()
        if(flowers.isEmpty()) root.addView(label("نوع گلی برای برگشت وجود ندارد."))
        else {
            val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64)
            val qty=numberField("تعداد دسته برگشتی","")
            val reason=field("علت برگشت","فروش نرفته / خراب / کیفیت / سایر")
            val stockLabel=label("")
            fun refreshStock(){val f=flowers[flower.selectedItemPosition];stockLabel.text="موجودی فعلی: ${db.sellerFlowerStock(sid,f.id)} دسته"}
            flower.setOnItemSelectedListener(simpleListener{refreshStock()})
            root.addView(label("نوع گل / اندازه"));root.addView(flower);root.addView(stockLabel);root.addView(qty);root.addView(reason)
            root.addView(actionButton("ثبت برگشت کالا"){
                val f=flowers[flower.selectedItemPosition]
                val q=qty.text.toString().replace(",","").toIntOrNull()?:0
                val stock=db.sellerFlowerStock(sid,f.id)
                if(q<=0){info("تعداد برگشتی را وارد کنید.");return@actionButton}
                if(q>stock){info("تعداد برگشتی بیشتر از موجودی است. موجودی فعلی: $stock دسته");return@actionButton}
                db.addReturn(sid,f.id,q,reason.text.toString().trim().ifBlank{"سایر"})
                qty.setText("");reason.setText("");refreshStock();info("برگشت کالا ثبت شد.");syncWithFirebaseIfOnline(false)
            })
            refreshStock()
        }

        root.addView(label("📋 آخرین برگشت‌ها"))
        val returns=db.returnsForSeller(sid).take(10)
        if(returns.isEmpty()) root.addView(label("برگشتی ثبت نشده است."))
        else returns.forEach{r->root.addView(cardRow("${r.flowerName} | ${r.size} | ${r.qty} دسته\nعلت: ${r.reason}") {})}
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showSalesHistory() {
        val root=base("فروش‌های ثبت‌شده من")
        val sid=db.currentSellerId()?:return
        val sales=db.sales(sid)
        if(sales.isEmpty()) root.addView(label("هنوز فروشی ثبت نشده است."))
        sales.forEach{root.addView(cardRow("${it.flowerName} | ${it.size}  |  ${it.qty} دسته\nقیمت هر دسته: ${money(it.price)} ریال\nمبلغ کل فروش: ${money(it.qty*it.price)} ریال\nتاریخ فروش: ${it.date}\nوضعیت ارسال: ${if(it.synced) "آماده ارسال/همگام‌شده" else "در انتظار اتصال به گلخانه"}") {})}
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showReturn(){
        if (!requireStaffPermission("returns", "ثبت برگشتی")) return
        if(db.isSellerMode()){info("ثبت برگشت در نسخه گلخانه انجام می‌شود.");return}
        val root=base("ثبت برگشت گل","برگشت از موجودی فروشنده کم می‌شود و دلیل آن ثبت می‌گردد.");val flowers=db.flowers();val sellers=db.sellers();if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا اطلاعات پایه را وارد کنید.");return}
        val seller=spinner("فروشنده",sellers.map{it.name},64);val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64);val qty=numberField("تعداد دسته برگشتی","");val reason=field("علت برگشت","فروش نرفته / خراب / کیفیت / سایر")
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل"));root.addView(flower);root.addView(qty);root.addView(reason)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        fun refresh(){box.removeAllViews();box.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","دلیل")));db.allReturns().take(20).forEach{box.addView(tableRow(listOf(it.sellerName,"${it.flowerName} | ${it.size}",it.qty.toString(),it.reason)))};if(box.childCount==1)box.addView(label("برگشتی ثبت نشده است."))}
        root.addView(actionButton("ثبت برگشت"){val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val ss=sellers[seller.selectedItemPosition];val f=flowers[flower.selectedItemPosition];if(q<=0||q>db.sellerFlowerStock(ss.id,f.id)){info("تعداد برگشتی بیشتر از موجودی است.");return@actionButton};db.addReturn(ss.id,f.id,q,reason.text.toString());qty.setText("");reason.setText("");refresh();info("برگشت ثبت شد.");syncWithFirebaseIfOnline(false)})
        root.addView(label("📋 برگشت‌های ثبت‌شده"));root.addView(box);refresh();root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showSettlement(){
        if(db.isSellerMode()) {
            val seller=db.sellerById(db.currentSellerId() ?: -1L)
            if(seller==null){
                info("اطلاعات حساب فروشنده پیدا نشد. لطفاً یک‌بار از حساب خارج و دوباره وارد شوید.")
                return
            }
            showSellerGreenhousePaymentPage(seller)
            return
        }
        val root=base("تسویه حساب فروشندگان")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        else {
            val sp=spinner("فروشنده",sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp)
            val detail=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(detail)
            fun refresh(){detail.removeAllViews();addSellerAccountSection(detail,sellers[sp.selectedItemPosition],false)}
            sp.setOnItemSelectedListener(simpleListener{refresh()});refresh()
        }
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showSellerGreenhousePaymentPage(s:Seller){
        val root=base("پرداخت به گلخانه","ثبت سریع، شفاف و قابل پیگیری")
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        root.addView(content)

        fun refreshPage(){
            content.removeAllViews()
            val balance=db.greenhouseBalance(s.id)
            val salesTotal=db.sellerSalesTotal(s.id)
            val share=db.sellerCommission(s.id)
            val paid=db.paidToGreenhouse(s.id)

            content.addView(cardText("👤 ${s.name}\nحساب اختصاصی فروشنده"))
            content.addView(financialCard(listOf(
                "فروش کل" to money(salesTotal),
                "سهم فروشنده" to money(share),
                "پرداخت‌های قبلی" to money(paid)
            ),"مبالغ به ریال"))

            val status=when{
                balance>0L -> "بدهکار به گلخانه • ${money(balance)} ریال"
                balance<0L -> "طلبکار از گلخانه • ${money(-balance)} ریال"
                else -> "تسویه کامل • مانده صفر"
            }
            content.addView(statusCard("وضعیت حساب: $status"))
            content.addView(sectionTitle("ثبت پرداخت جدید"))

            val amount=moneyField("مبلغ پرداختی (ریال)",if(balance>0L) money(balance) else "")
            val method=spinner("روش پرداخت",listOf("نقدی","کارتخوان","کارت به کارت","واریز بانکی","چک","سایر"),64)
            val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}
            val dateLabel=label("تاریخ پرداخت: ${jalali(selectedDate)}")
            val remaining=label("")

            fun updateRemaining(){
                val a=parseMoney(amount)
                val after=balance-a
                remaining.text=when{
                    a<=0L -> "مانده فعلی: ${if(balance>0) money(balance)+" ریال بدهی" else if(balance<0) money(-balance)+" ریال طلب" else "تسویه"}"
                    after>0L -> "بعد از پرداخت: ${money(after)} ریال بدهی"
                    after<0L -> "بعد از پرداخت: ${money(-after)} ریال طلب از گلخانه"
                    else -> "بعد از پرداخت: تسویه کامل"
                }
            }
            updateRemaining()

            content.addView(label("مبلغ"));content.addView(amount)
            content.addView(label("روش پرداخت"));content.addView(method)
            content.addView(dateLabel)
            content.addView(actionButton("📅 انتخاب تاریخ"){DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ پرداخت: ${jalali(selectedDate)}"},selectedDate.get(Calendar.YEAR),selectedDate.get(Calendar.MONTH),selectedDate.get(Calendar.DAY_OF_MONTH)).show()})
            content.addView(remaining)
            amount.addTextChangedListener(object:TextWatcher{
                override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
                override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){}
                override fun afterTextChanged(e:Editable?){updateRemaining()}
            })

            content.addView(actionButton("✓ ثبت پرداخت"){ 
                val a=parseMoney(amount)
                if(a<=0L){info("مبلغ پرداختی را وارد کنید.");return@actionButton}
                val type=method.selectedItem?.toString().orEmpty().ifBlank{"سایر"}
                db.addPayment(s.id,a,selectedDate.timeInMillis,type)
                syncWithFirebaseIfOnline(false)
                info("پرداخت ${money(a)} ریال با موفقیت ثبت شد."){refreshPage()}
            })

            content.addView(sectionTitle("آخرین پرداخت‌ها"))
            val history=db.payments(s.id).take(10)
            if(history.isEmpty()) content.addView(cardText("هنوز پرداختی ثبت نشده است."))
            else history.forEachIndexed{index,p->
                content.addView(cardText("پرداخت ${index+1}\n${money(p.amount)} ریال • ${p.paymentType}\nتاریخ: ${p.date}"))
            }
        }

        refreshPage()
        root.addView(actionButton("بازگشت به خانه"){showHome()})
        setScreen(root)
    }

    private fun addSellerAccountSection(root:LinearLayout,s:Seller,showPaymentTable:Boolean){
        // Settlement is calculated from the accounting tables directly. No UI field
        // depends on a previous screen having been opened.
        val stock=db.sellerStock(s.id)
        val salesTotal=db.sellerSalesTotal(s.id)
        val sharePercent=db.sellerShare(s.id)
        val sellerShareAmount=db.sellerCommission(s.id)
        val greenhouseDue=db.sellerNetDue(s.id)
        val paid=db.paidToGreenhouse(s.id)
        val balance=db.greenhouseBalance(s.id)

        val status = when {
            balance > 0L -> "باقی‌مانده بدهی فروشنده به گلخانه: ${money(balance)} ریال"
            balance < 0L -> "طلب فروشنده از گلخانه: ${money(-balance)} ریال"
            else -> "حساب این فروشنده کاملاً تسویه است."
        }
        if(showPaymentTable){
            root.addView(cardText("فروشنده: ${s.name}\nمجموع فروش: ${money(salesTotal)} ریال\nسهم فروشنده: ${money(sellerShareAmount)} ریال\nپرداخت به گلخانه: ${money(paid)} ریال\n$status"))
            root.addView(actionButton("💳 ثبت پرداخت به گلخانه"){paymentDialog(s)})
        } else {
            root.addView(cardText("👤 فروشنده: ${s.name}\nموجودی امانی: ${stock} دسته"))
            root.addView(cardText("💵 مجموع فروش: ${money(salesTotal)} ریال\nسهم فروشنده (${fmtPercent(sharePercent)}٪): ${money(sellerShareAmount)} ریال\nخالص سهم گلخانه: ${money(greenhouseDue)} ریال"))
            root.addView(cardText("💳 مجموع پرداخت به گلخانه: ${money(paid)} ریال"))
            root.addView(cardText("📊 وضعیت نهایی حساب\n$status"))
        }
        root.addView(label("📋 آخرین فروش‌ها"))
        val sales=db.sellerSalesDetailed(s.id).take(8)
        if(sales.isEmpty()) root.addView(label("هنوز فروشی برای این فروشنده ثبت نشده است."))
        else sales.forEach{r->
            val sellerPart=(r.total*sharePercent/100.0).toLong()
            root.addView(cardText("${r.flowerName} | ${r.size}\n${r.qty} دسته × ${money(r.unitPrice)} ریال = ${money(r.total)} ریال\nسهم فروشنده: ${money(sellerPart)} ریال\n${r.date}"))
        }

        root.addView(label("📋 آخرین پرداخت‌ها"))
        val ps=db.payments(s.id).take(8)
        if(ps.isEmpty()) root.addView(label("پرداختی برای این فروشنده ثبت نشده است."))
        else ps.forEach{p->root.addView(cardText("${money(p.amount)} ریال\nروش پرداخت: ${p.paymentType}\n${p.date}"))}
    }

    private fun showPaymentHistory(s:Seller){
        if (!isNetworkAvailable() || !firebaseSignedIn()) {
            showPaymentHistoryImpl(s, if (isNetworkAvailable()) "نشست Firebase برقرار نیست؛ پرداخت‌های ذخیره‌شده روی این دستگاه نمایش داده می‌شوند." else "اتصال اینترنت برقرار نیست؛ پرداخت‌های ذخیره‌شده روی این دستگاه نمایش داده می‌شوند.")
            return
        }
        val fs = FirebaseFirestore.getInstance()
        val firebaseSellerId = db.settingTextPublic("firebase_seller_id", "").toLongOrNull()
        val remoteId = db.sellerRemoteId(s.id)
        val found = linkedMapOf<String, com.google.firebase.firestore.DocumentSnapshot>()
        val errors = mutableListOf<String>()
        val queries = mutableListOf<com.google.firebase.firestore.Query>()
        val ids = linkedSetOf<Long>()
        if (firebaseSellerId != null && firebaseSellerId > 0L) ids.add(firebaseSellerId)
        if (s.id > 0L) ids.add(s.id)
        ids.forEach { id ->
            queries.add(fs.collection("payments").whereEqualTo("seller_id", id))
            queries.add(fs.collection("payments").whereEqualTo("seller_id", id.toString()))
            queries.add(fs.collection("payments").whereEqualTo("sellerId", id))
        }
        if (remoteId.isNotBlank()) {
            queries.add(fs.collection("payments").whereEqualTo("seller_remote_id", remoteId))
            queries.add(fs.collection("payments").whereEqualTo("sellerRemoteId", remoteId))
        }
        fun runQuery(i: Int) {
            if (i >= queries.size) {
                found.values.forEach { doc ->
                    val data = (doc.data ?: emptyMap()).toMutableMap()
                    if (data["seller_id"] == null && firebaseSellerId != null) data["seller_id"] = firebaseSellerId
                    if (data["seller_remote_id"] == null && remoteId.isNotBlank()) data["seller_remote_id"] = remoteId
                    db.importFirebaseRecord("payments", doc.id, data)
                }
                val detail = when {
                    found.isNotEmpty() -> null
                    errors.isNotEmpty() -> "دریافت پرداخت‌ها از Firebase ناموفق بود. خطای دسترسی یا ساختار شناسهٔ فروشنده را بررسی کنید. جزئیات: ${errors.distinct().take(3).joinToString(" | ")}"
                    else -> "در Firebase پرداختی با شناسه‌های این فروشنده پیدا نشد. اگر در گلخانه پرداخت ثبت شده، همگام‌سازی و شناسهٔ فروشنده را بررسی کنید."
                }
                showPaymentHistoryImpl(s, detail)
                return
            }
            queries[i].get()
                .addOnSuccessListener { snap -> snap.documents.forEach { found[it.id] = it }; runQuery(i + 1) }
                .addOnFailureListener { e -> errors.add("${(e as? com.google.firebase.firestore.FirebaseFirestoreException)?.code ?: "خطا"}: ${e.localizedMessage ?: e.message ?: "نامشخص"}"); runQuery(i + 1) }
        }
        if (queries.isEmpty()) showPaymentHistoryImpl(s, "شناسهٔ فروشنده برای دریافت پرداخت‌ها در دسترس نیست.") else runQuery(0)
    }

    private fun showPaymentHistoryImpl(s:Seller, notice:String? = null){
        val root = base("پرداخت‌های من", "تاریخچهٔ پرداخت‌های شما به گلخانه")
        root.addView(cardText("فروشنده: ${s.name}").apply { setTextColor(Color.BLACK) })
        val payments = db.payments(s.id)
        val total = payments.sumOf { it.amount }
        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(Color.rgb(239, 249, 242)); setStroke(dp(1), Color.rgb(188, 220, 198)) }
        }
        summary.addView(TextView(this).apply { text = "مجموع پرداخت‌ها"; textSize = 14f; setTextColor(Color.BLACK); gravity = Gravity.RIGHT })
        summary.addView(TextView(this).apply { text = "${money(total)} ریال"; textSize = 23f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(22, 105, 56)); gravity = Gravity.RIGHT; setPadding(0, dp(5), 0, 0) })
        summary.addView(TextView(this).apply { text = "تعداد پرداخت‌ها: ${payments.size}"; textSize = 13f; setTextColor(Color.BLACK); gravity = Gravity.RIGHT; setPadding(0, dp(5), 0, 0) })
        root.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, dp(12)) })
        if (!notice.isNullOrBlank()) root.addView(cardText(notice).apply { setTextColor(Color.BLACK) })
        root.addView(actionButton("↻ دریافت دوبارهٔ پرداخت‌ها") { showPaymentHistory(s) })
        root.addView(label("جزئیات پرداخت‌ها").apply { setTextColor(Color.BLACK) })
        if (payments.isEmpty()) {
            root.addView(cardText("هنوز پرداختی برای این حساب دریافت نشده است. اگر پرداخت در گلخانه ثبت شده، اتصال اینترنت، مجوز خواندن مجموعهٔ payments و شناسهٔ فروشنده در Firebase باید بررسی شود.").apply { setTextColor(Color.BLACK) })
        } else {
            payments.forEachIndexed { index, p ->
                val item = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(15), dp(12), dp(15), dp(12))
                    background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.WHITE); setStroke(dp(1), Color.rgb(220, 228, 222)) }
                }
                item.addView(TextView(this).apply { text = "پرداخت ${payments.size - index}"; textSize = 13f; setTextColor(Color.DKGRAY); gravity = Gravity.RIGHT })
                item.addView(TextView(this).apply { text = "${money(p.amount)} ریال"; textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.BLACK); gravity = Gravity.RIGHT; setPadding(0, dp(4), 0, dp(4)) })
                item.addView(TextView(this).apply { text = "روش پرداخت: ${p.paymentType}"; textSize = 14f; setTextColor(Color.BLACK); gravity = Gravity.RIGHT })
                item.addView(TextView(this).apply { text = "تاریخ: ${p.date}"; textSize = 13f; setTextColor(Color.BLACK); gravity = Gravity.RIGHT; setPadding(0, dp(4), 0, 0) })
                root.addView(item, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(8)) })
            }
        }
        root.addView(actionButton("بازگشت") { goBack() })
        forceBlackText(root)
        setScreen(root)
    }

    private fun paymentDialog(s:Seller){
        val balance=db.greenhouseBalance(s.id)
        val box=formBox()
        val amount=moneyField("مبلغ پرداختی (ریال)",if(balance>0)money(balance) else "")
        val method=spinner("روش پرداخت",listOf("نقدی","کارتخوان","کارت به کارت","واریز بانکی","چک","سایر"),64)
        val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}
        val dateLabel=label("تاریخ پرداخت: ${jalali(selectedDate)}")
        val balanceLabel=label(if(balance>0) "بدهی فعلی به گلخانه: ${money(balance)} ریال" else if(balance<0) "طلب فعلی فروشنده از گلخانه: ${money(-balance)} ریال" else "حساب فعلاً تسویه است")
        box.addView(balanceLabel);box.addView(amount);box.addView(label("روش پرداخت"));box.addView(method);box.addView(dateLabel)
        box.addView(actionButton("📅 انتخاب تاریخ پرداخت"){
            val initial=Calendar.getInstance().apply{timeInMillis=selectedDate.timeInMillis}
            DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ پرداخت: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()
        })
        AlertDialog.Builder(this).setTitle("پرداخت به گلخانه — ${s.name}").setView(box).setPositiveButton("ثبت پرداخت"){_,_->
            val a=parseMoney(amount)
            if(a<=0) info("مبلغ پرداختی باید بیشتر از صفر باشد.") else {
                db.addPayment(s.id,a,selectedDate.timeInMillis,method.selectedItem.toString())
                val newBalance=db.greenhouseBalance(s.id)
                val result=if(newBalance>0) "باقی‌مانده بدهی: ${money(newBalance)} ریال" else if(newBalance<0) "طلب فروشنده از گلخانه: ${money(-newBalance)} ریال" else "حساب تسویه شد"
                info("پرداخت ${money(a)} ریال ثبت شد.\nروش پرداخت: ${method.selectedItem}\n$result"){showSettlement()}
                syncWithFirebaseIfOnline(false)
            }
        }.setNegativeButton("انصراف",null).show()
    }

    private fun showReports(){
        if(db.isSellerMode()){showSellerInventoryReport();return}
        val root=base("گزارش‌های گلخانه","گزارش‌های مدیریتی و عملیاتی گلخانه")
        root.addView(actionButton("👤 گزارش فروشندگان") { showGreenhouseSellerSalesReport() })
        root.addView(actionButton("📦 گزارش تحویل گل") { showGreenhouseDeliveryReport() })
        root.addView(actionButton("💰 گزارش مالی و بدهی فروشندگان") { showFinancialReport() })
        root.addView(actionButton("📦 گزارش موجودی نزد فروشندگان") { showGreenhouseInventoryReport() })
        root.addView(actionButton("📋 گزارش برگشت گل") { showReturnReport() })
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showSellerInventoryReport(){
        val root=base("موجودی امانی من","فقط گل‌های موجود نزد من، قیمت و مشخصات آن‌ها")
        val sid=db.currentSellerId()?:return
        root.addView(tableHeader(listOf("نام گل","اندازه","موجودی","قیمت پایه","حداقل قیمت")))
        var count=0;var totalQty=0;var totalValue=0L;db.flowers().forEach{f->val stock=db.sellerFlowerStock(sid,f.id);if(stock>0){count++;totalQty+=stock;totalValue+=stock.toLong()*f.basePrice;root.addView(tableRow(listOf(f.name,f.size,stock.toString(),money(f.basePrice),money(f.minPrice))))}}
        if(count==0)root.addView(label("در حال حاضر گل موجودی ندارید."))
        root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showGreenhouseDeliveryReport(){
        if (!requireStaffPermission("delivery", "گزارش تحویل")) return
        val root=base("گزارش تحویل‌های امانی","این گزارش بدهی فروشنده را نشان نمی‌دهد؛ فقط تحویل‌های امانی را ثبت می‌کند.")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("فروشنده"));root.addView(sp)
        val date=Calendar.getInstance().apply{timeInMillis=db.appDate()};val dl=label("تاریخ: ${jalali(date)}");root.addView(dl)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val sid=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1].id;val rows=db.greenhouseSalesFiltered(sid,date.timeInMillis);box.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","قیمت مرجع","ارزش مرجع")));if(rows.isEmpty())box.addView(label("رکوردی برای این تاریخ وجود ندارد."))else {var qty=0;var total=0L;rows.forEach{r->qty+=r.qty;total+=r.total;box.addView(tableRow(listOf(r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))};val avg=if(qty==0)0 else total/qty;box.addView(tableRow(listOf("جمع کل","",qty.toString(),money(avg),money(total)),true))}}
        sp.setOnItemSelectedListener(simpleListener{refresh()})
        root.addView(actionButton("📅 انتخاب تاریخ"){val i=date.clone() as Calendar;DatePickerDialog(this,{_,y,m,d->date.set(y,m,d,12,0,0);date.set(Calendar.MILLISECOND,0);dl.text="تاریخ: ${jalali(date)}";refresh()},i.get(Calendar.YEAR),i.get(Calendar.MONTH),i.get(Calendar.DAY_OF_MONTH)).show()})
        refresh();root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showFinancialReport(){
        if (!requireStaffPermission("financial_report", "گزارش مالی")) return
        // v1.3.6: render the local ledger first; Firebase is only a refresh layer.
        refreshAdminDataAndShow {
            val root=base("گزارش مالی جامع","فروش فروشندگان، فروش متفرقه، پرداخت‌های دریافتی و هزینه‌های گلخانه")
            val sellers=db.sellers()
            if(sellers.isNotEmpty()){
                root.addView(sectionTitle("👤 فروش و حساب فروشندگان"))
                sellers.forEach{s->
                    val saleRows=db.sellerSalesDetailed(s.id)
                    val saleTotal=saleRows.sumOf{it.total}
                    val sellerSharePercent=db.sellerShare(s.id)
                    val shareTotal=saleRows.sumOf{(it.total*sellerSharePercent/100.0).toLong()}
                    val paid=db.payments(s.id).sumOf{it.amount}
                    root.addView(cardText("👤 ${s.name}\nفروش ثبت‌شده: ${money(saleTotal)} ریال\nسهم فروشنده: ${money(shareTotal)} ریال\nپرداخت به گلخانه: ${money(paid)} ریال\n${sellerBalanceText(s.id)}"))
                }
            } else {
                root.addView(cardText("هنوز فروشنده‌ای ثبت نشده است؛ فروش متفرقه و هزینه‌های گلخانه مستقل از فروشندگان در ادامه گزارش می‌شوند."))
            }

            root.addView(sectionTitle("🧾 فروش متفرقه گلخانه"))
            val misc=db.miscSales()
            val miscTotal=misc.sumOf{it.total}
            val miscQty=misc.sumOf{it.qty}
            root.addView(financialCard(listOf(
                "تعداد فروش متفرقه" to misc.size.toString(),
                "جمع فروش متفرقه" to money(miscTotal),
                "تعداد دسته فروخته‌شده" to miscQty.toString()
            ), if(misc.isEmpty()) "هنوز فروش متفرقه‌ای ثبت نشده است" else "فروش مستقیم گلخانه"))
            if(misc.isNotEmpty()){
                root.addView(tableHeader(listOf("تاریخ","خریدار","گل/اندازه","تعداد","مبلغ")))
                misc.forEach{r->root.addView(tableRow(listOf(r.date,r.buyerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.total))))}
                root.addView(tableRow(listOf("جمع کل","","",miscQty.toString(),money(miscTotal)),true))
            }

            root.addView(sectionTitle("💰 هزینه‌های گلخانه"))
            val expenses=db.greenhousePayments()
            val expenseTotal=expenses.sumOf{it.amount}
            root.addView(financialCard(listOf(
                "تعداد هزینه‌ها" to expenses.size.toString(),
                "جمع هزینه‌های گلخانه" to money(expenseTotal),
                "خالص فروش متفرقه پس از هزینه" to money(miscTotal-expenseTotal)
            ), if(expenses.isEmpty()) "هنوز هزینه‌ای ثبت نشده است" else "تمام هزینه‌های ثبت‌شده در دفتر گلخانه"))
            if(expenses.isNotEmpty()){
                root.addView(tableHeader(listOf("تاریخ","نوع هزینه","شرح","مبلغ")))
                expenses.forEach{r->root.addView(tableRow(listOf(r.date,r.expenseType,r.description.ifBlank{"بدون شرح"},money(r.amount))))}
                root.addView(tableRow(listOf("جمع کل","","",money(expenseTotal)),true))
            }

            root.addView(sectionTitle("📊 جمع‌بندی"))
            root.addView(cardText("فروش متفرقه: ${money(miscTotal)} ریال\nهزینه‌های گلخانه: ${money(expenseTotal)} ریال\nخالص فروش متفرقه پس از هزینه: ${money(miscTotal-expenseTotal)} ریال\n\nتوجه: این خالص فقط فروش متفرقه منهای هزینه‌های ثبت‌شده است و سود نهایی گلخانه محسوب نمی‌شود؛ سهم فروشندگان و سایر اقلام در آن لحاظ نشده است."))
            root.addView(actionButton("بازگشت به گزارش‌ها"){goBack()})
            setScreen(root)
        }
    }

    private fun showGreenhouseInventoryReport(){
        if (!requireStaffPermission("financial_report", "گزارش موجودی")) return
        val root=base("موجودی امانی فروشندگان","گل‌های تحویلی تا زمان فروش، امانی هستند و بدهی ایجاد نمی‌کنند.")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val selected=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1];val list=if(selected==null)sellers else listOf(selected);box.addView(tableHeader(listOf("فروشنده","گل/اندازه","موجودی")));var totalQty=0;var count=0;list.forEach{s->db.flowers().forEach{f->val st=db.sellerFlowerStock(s.id,f.id);if(st>0){count++;totalQty+=st;box.addView(tableRow(listOf(s.name,"${f.name} | ${f.size}",st.toString())))}}};if(count==0)box.addView(label("موجودی نزد فروشندگان ثبت نشده است."));box.addView(tableRow(listOf("جمع کل","",totalQty.toString()),true))}
        sp.setOnItemSelectedListener(simpleListener{refresh()});refresh();root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showReturnReport(){
        if (!requireStaffPermission("returns", "گزارش برگشتی‌ها")) return
        val root=base("گزارش برگشت گل","با انتخاب هر فروشنده یا همه فروشندگان، برگشت‌های ثبت‌شده نمایش داده می‌شود.")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val sid=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1].id;val rows=if(sid==null)db.allReturns() else db.returnsForSeller(sid);box.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","دلیل")));var qty=0;if(rows.isEmpty())box.addView(label("برگشتی ثبت نشده است."))else rows.forEach{r->qty+=r.qty;box.addView(tableRow(listOf(r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),r.reason)))};box.addView(tableRow(listOf("جمع کل","",qty.toString(),""),true))}
        sp.setOnItemSelectedListener(simpleListener{refresh()});refresh();root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showGreenhouseSellerSalesReport(){
        if (!requireStaffPermission("sellers", "گزارش فروش فروشندگان")) return
        val root=base("گزارش فروشندگان")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){
            box.removeAllViews()
            val selected=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1]
            val list=if(selected==null)sellers else listOf(selected)
            list.forEach{s->
                box.addView(label("👤 ${s.name}"))
                box.addView(label("📦 خرید گل از گلخانه"))
                box.addView(tableHeader(listOf("تاریخ","گل/اندازه","تعداد","قیمت","مبلغ")))
                val purchases=db.greenhouseSales(s.id);var pq=0;var pt=0L
                if(purchases.isEmpty())box.addView(label("خریدی ثبت نشده است."))else purchases.forEach{r->pq+=r.qty;pt+=r.total;box.addView(tableRow(listOf(r.date,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))}
                val pavg=if(pq==0)0 else pt/pq;box.addView(tableRow(listOf("جمع کل","",pq.toString(),money(pavg),money(pt)),true))
                box.addView(label("🧾 تک‌تک فروش‌ها"))
                box.addView(tableHeader(listOf("تاریخ","گل/اندازه","تعداد","قیمت","مبلغ","سهم فروشنده")))
                val sales=db.sellerSalesDetailed(s.id);var sq=0;var st=0L;var sc=0L
                if(sales.isEmpty())box.addView(label("فروشی ثبت نشده است."))else sales.forEach{r->val share=(r.total*db.sellerShare(s.id)/100.0).toLong();sq+=r.qty;st+=r.total;sc+=share;box.addView(tableRow(listOf(r.date,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total),money(share))))}
                val savg=if(sq==0)0 else st/sq;box.addView(tableRow(listOf("جمع کل","",sq.toString(),money(savg),money(st),money(sc)),true));box.addView(label("جمع سهم سود فروشنده: ${money(sc)} ریال"))
            }
        }
        sp.setOnItemSelectedListener(simpleListener{refresh()});refresh();root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showDetailedReport(){
        if (!requireStaffPermission("financial_report", "گزارش تفصیلی فروش")) return
        val root=base("گزارش تفصیلی فروش","فیلتر بر اساس فروشنده و بازه تاریخ")
        val sellers=db.sellers(); if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val seller=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("فروشنده"));root.addView(seller)
        val from=Calendar.getInstance().apply{timeInMillis=db.appDate();set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}
        val to=Calendar.getInstance().apply{timeInMillis=db.appDate();set(Calendar.HOUR_OF_DAY,23);set(Calendar.MINUTE,59);set(Calendar.SECOND,59);set(Calendar.MILLISECOND,999)}
        val fromLabel=label("از تاریخ: ${jalali(from)}");val toLabel=label("تا تاریخ: ${jalali(to)}");root.addView(fromLabel);root.addView(actionButton("📅 انتخاب تاریخ شروع"){DatePickerDialog(this,{_,y,m,d->from.set(y,m,d,0,0,0);from.set(Calendar.MILLISECOND,0);fromLabel.text="از تاریخ: ${jalali(from)}"},from.get(Calendar.YEAR),from.get(Calendar.MONTH),from.get(Calendar.DAY_OF_MONTH)).show()});root.addView(toLabel);root.addView(actionButton("📅 انتخاب تاریخ پایان"){DatePickerDialog(this,{_,y,m,d->to.set(y,m,d,23,59,59);to.set(Calendar.MILLISECOND,999);toLabel.text="تا تاریخ: ${jalali(to)}"},to.get(Calendar.YEAR),to.get(Calendar.MONTH),to.get(Calendar.DAY_OF_MONTH)).show()})
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val sid=if(seller.selectedItemPosition==0)null else sellers[seller.selectedItemPosition-1].id;val rows=db.detailedSales(sid,from.timeInMillis,to.timeInMillis);box.addView(tableHeader(listOf("تاریخ","فروشنده","گل/اندازه","تعداد","قیمت","مبلغ","سهم فروشنده")));if(rows.isEmpty())box.addView(label("رکوردی در این بازه وجود ندارد.")) else {var total=0L;var commission=0L;rows.forEach{r->val share=r.sellerShareAmount;total+=r.total;commission+=share;box.addView(tableRow(listOf(r.date,r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.price),money(r.total),money(share))))};box.addView(tableRow(listOf("جمع کل","","","","",money(total),money(commission)),true));box.addView(cardText("جمع مبلغ فروش این فیلتر: ${money(total)} ریال\nجمع سهم سود فروشنده: ${money(commission)} ریال"))}}
        seller.setOnItemSelectedListener(simpleListener{refresh()});root.addView(actionButton("🔎 اعمال فیلتر"){refresh()});refresh();root.addView(actionButton("بازگشت"){goBack()});setScreen(root)
    }

    private fun showAllPaymentsHistory(){
        if (!requireStaffPermission("payments", "پرداخت‌ها")) return
        refreshAdminDataAndShow {
            val root=base("پرداخت‌ها","تاریخچه کامل پرداخت‌های فروشندگان به گلخانه")
            val rows=db.allPayments()
            val total=rows.sumOf{it.amount}
            val sellersCount=rows.map{it.sellerName}.distinct().size

            root.addView(financialCard(listOf(
                "تعداد پرداخت" to rows.size.toString(),
                "مجموع پرداخت" to money(total),
                "فروشندگان پرداخت‌کننده" to sellersCount.toString()
            ), if(rows.isEmpty()) "هنوز پرداختی ثبت نشده است" else "آخرین پرداخت‌ها در پایین نمایش داده می‌شود"))

            if(rows.isEmpty()){
                root.addView(cardRow("پرداختی ثبت نشده است") { box ->
                    box.addView(label("پس از ثبت اولین پرداخت فروشنده، اطلاعات آن اینجا نمایش داده می‌شود."))
                })
            } else {
                var lastSeller=""
                rows.forEachIndexed{index,p ->
                    if(p.sellerName!=lastSeller){
                        lastSeller=p.sellerName
                        root.addView(sectionTitle("👤 ${p.sellerName}"))
                    }
                    root.addView(cardRow("پرداخت ${index+1}  •  ${p.date}") { box ->
                        box.addView(label("مبلغ: ${money(p.amount)} ریال"))
                        box.addView(label("روش پرداخت: ${p.paymentType}"))
                    })
                }
            }
            root.addView(actionButton("ثبت پرداخت جدید"){showSettlement()})
            root.addView(actionButton("بازگشت به خانه"){showHome()})
            setScreen(root)
        }
    }

    private fun showDatabaseManagement(){
        val root=base("مدیریت دیتابیس","پشتیبان‌گیری، بازنشانی و پاک‌سازی اطلاعات")

        root.addView(sectionTitle("💾 نسخه پشتیبان"))
        root.addView(cardText("نسخه پشتیبان شامل اطلاعات عملیاتی، تنظیمات برنامه و اطلاعات حساب‌های محلی است. فایل پشتیبان را در محل امن نگهداری کنید."))
        root.addView(actionButton("📤 تهیه نسخه پشتیبان"){
            val intent=android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply{
                addCategory(android.content.Intent.CATEGORY_OPENABLE)
                type="application/json"
                putExtra(android.content.Intent.EXTRA_TITLE,"GolNegar_Backup_${BuildConfig.VERSION_NAME}.json")
            }
            startActivityForResult(intent,8101)
        })
        root.addView(actionButton("📥 بازنشانی اطلاعات از فایل پشتیبان"){
            val intent=android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply{
                addCategory(android.content.Intent.CATEGORY_OPENABLE)
                type="application/json"
            }
            startActivityForResult(intent,8102)
        })

        root.addView(sectionTitle("🔄 پشتیبان‌گیری خودکار"))
        val autoBackupLast = db.settingTextPublic("auto_backup_last", "")
        val autoBackupStatus = if (autoBackupLast.isBlank()) {
            "هنوز پشتیبان خودکاری ساخته نشده است."
        } else {
            "آخرین پشتیبان خودکار: ${jalaliDate(autoBackupLast.toLongOrNull() ?: 0L)}"
        }
        root.addView(cardText("پشتیبان خودکار هنگام خروج یا رفتن برنامه به پس‌زمینه ساخته می‌شود و آخرین نسخه جایگزین نسخه قبلی می‌شود.\n$autoBackupStatus"))
        root.addView(actionButton("📤 ذخیره آخرین پشتیبان خودکار در فایل"){
            exportAutomaticBackupToUserFile()
        })

        root.addView(sectionTitle("🧹 پاک‌سازی اطلاعات"))
        root.addView(cardText("پیشنهاد: قبل از حذف، نسخه پشتیبان بگیرید. حساب مدیر، حساب‌های ورود، تنظیمات اتصال و تنظیمات امنیتی حفظ می‌شوند. حذف محلی فقط اطلاعات همین گوشی را پاک می‌کند و ممکن است اطلاعات باقی‌مانده در Firebase در همگام‌سازی بعدی دوباره دریافت شوند."))
        root.addView(actionButton("🗑️ حذف اطلاعات عملیاتی این گوشی"){
            if(syncInProgress || destructiveDeleteInProgress){ info("ابتدا صبر کنید همگام‌سازی یا عملیات حذف جاری تمام شود."); return@actionButton }
            AlertDialog.Builder(this).setTitle("حذف اطلاعات محلی")
                .setMessage("اطلاعات عملیاتی این گوشی، از جمله هزینه‌های ثبت‌شده، صندوق‌های تنخواه و انواع هزینه پاک می‌شوند. اطلاعات موجود در Firebase حذف نمی‌شوند و ممکن است بعداً دوباره همگام شوند. حساب مدیر و تنظیمات اتصال حفظ می‌شوند.")
                .setNegativeButton("انصراف",null)
                .setPositiveButton("حذف محلی"){_,_->
                    db.clearOperationalData()
                    info("اطلاعات عملیاتی محلی حذف شد. داده‌های Firebase همچنان باقی هستند.")
                }.show()
        })
        root.addView(actionButton("☁️ حذف اطلاعات عملیاتی Firebase"){
            if(!isNetworkAvailable()){ info("برای حذف اطلاعات Firebase اتصال اینترنت لازم است."); return@actionButton }
            if(!firebaseSignedIn()){ info("ابتدا اتصال مدیر به Firebase را برقرار کنید."); return@actionButton }
            if(syncInProgress || destructiveDeleteInProgress){ info("ابتدا صبر کنید همگام‌سازی یا عملیات حذف جاری تمام شود."); return@actionButton }
            AlertDialog.Builder(this).setTitle("⚠️ حذف اطلاعات Firebase")
                .setMessage("فقط اطلاعات عملیاتی Firebase از جمله انواع هزینه حذف می‌شوند؛ اطلاعات محلی گوشی و پروفایل حساب‌های کاربری باقی می‌مانند و ممکن است دوباره همگام شوند. برای پاک‌سازی کامل اطلاعات و پروفایل کاربران به‌جز مدیر، گزینه «حذف کامل از گوشی و Firebase» را انتخاب کنید.")
                .setNegativeButton("انصراف",null)
                .setPositiveButton("حذف از Firebase"){_,_->deleteOperationalFirebaseData(false)}.show()
        })
        root.addView(actionButton("⚠️ حذف کامل از گوشی و Firebase"){
            if(!isNetworkAvailable()){ info("برای حذف کامل، اتصال اینترنت لازم است."); return@actionButton }
            if(!firebaseSignedIn()){ info("ابتدا اتصال مدیر به Firebase را برقرار کنید."); return@actionButton }
            if(syncInProgress || destructiveDeleteInProgress){ info("ابتدا صبر کنید همگام‌سازی یا عملیات حذف جاری تمام شود."); return@actionButton }
            AlertDialog.Builder(this).setTitle("⚠️ حذف کامل اطلاعات و کاربران")
                .setMessage("تمام رکوردهای عملیاتی از گوشی و Firebase حذف می‌شوند؛ همچنین پروفایل تمام کاربران گلخانه و فروشندگان از مجموعه users پاک می‌شود، اما پروفایل مدیر فعلی و تنظیمات اتصال حفظ می‌شوند. رمزهای ذخیره‌شده کاربران عادی روی این گوشی هم پاک می‌شوند. محدودیت مهم: حذف هویت‌های ورود از Firebase Authentication از داخل برنامه اندروید مجاز نیست؛ پس حساب‌های ورود حذف فیزیکی نمی‌شوند، اما پروفایل برنامه‌شان حذف خواهد شد و برای حذف فیزیکی باید Firebase Admin SDK یا سرویس مدیریتی امن سمت سرور تنظیم شود. عملیات برگشت‌ناپذیر است؛ قبل از ادامه پشتیبان بگیرید.")
                .setNegativeButton("انصراف",null)
                .setPositiveButton("حذف کامل"){_,_->deleteOperationalFirebaseData(true)}.show()
        })

        root.addView(sectionTitle("🛠️ نگهداری"))
        root.addView(actionButton("🔄 بازسازی وضعیت همگام‌سازی محلی"){
            db.resetPendingSyncStates()
            info("وضعیت همگام‌سازی رکوردهای محلی بازسازی شد.")
        })
        root.addView(actionButton("📊 وضعیت دیتابیس"){
            val syncState = when {
                destructiveDeleteInProgress -> "در حال حذف اطلاعات"
                syncInProgress -> "در حال همگام‌سازی"
                db.settingTextPublic("last_sync_error", "").isNotBlank() -> "آخرین همگام‌سازی با خطا مواجه شده است"
                else -> "آماده"
            }
            info(db.databaseSummary() + "\n\nوضعیت عملیات: $syncState")
        })
        root.addView(actionButton("↩️ بازگشت به تنظیمات مدیر"){goBack()})
        setScreen(root)
    }

    private fun deleteOperationalFirebaseData(clearLocalAfter: Boolean = false){
        if (syncInProgress || destructiveDeleteInProgress) {
            info("ابتدا صبر کنید همگام‌سازی یا عملیات حذف جاری تمام شود.")
            return
        }
        val adminUid = firebaseAuth.currentUser?.uid
        if (clearLocalAfter && adminUid.isNullOrBlank()) {
            info("برای حفظ حساب مدیر و حذف امن پروفایل سایر کاربران، ابتدا ورود مدیر به Firebase را برقرار کنید.")
            return
        }
        destructiveDeleteInProgress = true
        val collections=listOf("flowers","sellers","deliveries","sales","returns","payments","misc_sales","greenhouse_payments","petty_cash_people","expense_types")
        val fs=FirebaseFirestore.getInstance()
        fun fail(name:String, detail:String){
            destructiveDeleteInProgress = false
            info("حذف اطلاعات «$name» کامل نشد: $detail. اطلاعات محلی دست‌نخورده باقی ماندند؛ توجه کنید که مجموعه‌های Firebase که پیش از خطا حذف شده‌اند، قابل بازگشت خودکار نیستند.")
        }
        fun finishSuccessfully(){
            if(clearLocalAfter){
                db.clearOperationalData()
                db.clearLastSyncMetadata()
                // Remove saved login credentials for ordinary greenhouse users and sellers,
                // while keeping the current administrator's Firebase credential intact.
                secureCredentials.removeByPrefixes(listOf("staff_", "last_staff_", "seller_firebase_"))
                destructiveDeleteInProgress = false
                refreshHomeSyncStatus()
                info("پاک‌سازی انجام شد: اطلاعات عملیاتی گوشی و Firebase و پروفایل کاربران غیرمدیر حذف شدند؛ حساب مدیر و تنظیمات اتصال حفظ شدند. هویت‌های Firebase Authentication به دلیل محدودیت امنیتی حذف فیزیکی نشده‌اند.")
            } else {
                destructiveDeleteInProgress = false
                info("اطلاعات عملیاتی Firebase حذف شد. اطلاعات محلی و پروفایل حساب‌های کاربری باقی مانده‌اند.")
            }
        }
        fun deleteOtherUserProfiles(){
            if (!clearLocalAfter) { finishSuccessfully(); return }
            val preservedAdminUid = adminUid ?: run { fail("users", "شناسه مدیر در دسترس نیست"); return }
            fs.collection("users").get()
                .addOnSuccessListener { snap ->
                    val docs = snap.documents.filter { it.id != preservedAdminUid }
                    fun batchChunk(start:Int){
                        if(start>=docs.size){ finishSuccessfully(); return }
                        val batch=fs.batch()
                        docs.subList(start,minOf(start+450,docs.size)).forEach{batch.delete(it.reference)}
                        batch.commit().addOnSuccessListener{batchChunk(start+450)}
                            .addOnFailureListener{e->fail("users (پروفایل کاربران غیرمدیر)",e.localizedMessage ?: e.message ?: "خطای Firebase")}
                    }
                    batchChunk(0)
                }
                .addOnFailureListener { e -> fail("users (پروفایل کاربران غیرمدیر)",e.localizedMessage ?: e.message ?: "خطای دسترسی یا اتصال Firebase") }
        }
        fun deleteNext(index:Int){
            if(index>=collections.size){ deleteOtherUserProfiles(); return }
            val name=collections[index]
            fs.collection(name).get()
                .addOnSuccessListener { snap ->
                    val docs=snap.documents
                    fun batchChunk(start:Int){
                        if(start>=docs.size){deleteNext(index+1);return}
                        val batch=fs.batch()
                        docs.subList(start,minOf(start+450,docs.size)).forEach{batch.delete(it.reference)}
                        batch.commit().addOnSuccessListener{batchChunk(start+450)}
                            .addOnFailureListener{e->fail(name,e.localizedMessage ?: e.message ?: "خطای Firebase")}
                    }
                    batchChunk(0)
                }
                .addOnFailureListener { e->fail(name,e.localizedMessage ?: e.message ?: "خطای دسترسی یا اتصال Firebase") }
        }
        deleteNext(0)
    }

    private fun showPettyCashPeople(){
        val root=base("صندوق تنخواه","موجودی و گردش هر صندوق مشخص است؛ حذف فقط طبق ضوابط مالی انجام می‌شود.")
        root.addView(cardText("ضابطه حذف: صندوقی که مانده غیرصفر دارد قابل حذف یا بایگانی نیست. صندوق بدون گردش و با مانده صفر غیرفعال می‌شود؛ اگر گردش داشته باشد، فقط با مانده صفر قابل بایگانی است تا سوابق حسابداری حفظ شوند."))
        val people=db.pettyCashPeople()
        if(people.isEmpty()) root.addView(cardRow("هنوز صندوق تنخواه فعالی تعریف نشده است.\nبرای شروع، دکمه «افزودن صندوق تنخواه» را بزنید.", {}))
        people.forEachIndexed { index, person ->
            val stats = db.pettyCashStats(person.id)
            val incoming = stats.first
            val outgoing = stats.second
            val count = stats.third
            val balance = incoming - outgoing
            root.addView(cardRow("👛  ${index + 1}. ${person.name}\nدریافتی نقدی: ${money(incoming)} ریال\nپرداخت از تنخواه: ${money(outgoing)} ریال\nمانده صندوق: ${money(balance)} ریال\nتعداد گردش‌ها: $count") { row ->
                row.addView(actionButton("✏️ ویرایش نام تنخواه") {
                    val nameField = field("نام جدید صندوق تنخواه", person.name)
                    AlertDialog.Builder(this).setTitle("ویرایش صندوق تنخواه")
                        .setMessage("تغییر نام روی سابقه‌های قبلی هم اثر نمایشی دارد؛ هیچ گردش مالی حذف نمی‌شود.")
                        .setView(nameField).setPositiveButton("ذخیره") { _, _ ->
                            val newName = nameField.text.toString().trim()
                            if (newName.isBlank()) info("نام تنخواه نمی‌تواند خالی باشد.")
                            else if (newName != person.name) { db.updatePettyCashPerson(person.id, newName); showPettyCashPeople(); syncWithFirebaseIfOnline(false) }
                        }.setNegativeButton("انصراف", null).show()
                })
                if (balance != 0L) {
                    row.addView(cardText("🔒 حذف/بایگانی غیرفعال است: ابتدا مانده صندوق را به صفر برسانید. گردش مالی موجود حفظ می‌شود."))
                } else {
                    val actionLabel = if (count == 0) "🗑️ حذف صندوق بدون گردش" else "📁 بایگانی صندوق با حفظ سوابق"
                    row.addView(actionButton(actionLabel) {
                        val explanation = if (count == 0) "این صندوق مانده و گردش مالی ندارد. صندوق از فهرست فعال خارج می‌شود؛ رکورد برای جلوگیری از بازگشت از همگام‌سازی حفظ خواهد شد." else "مانده صندوق صفر است اما $count گردش مالی دارد. حذف فیزیکی ممنوع است؛ صندوق فقط بایگانی می‌شود و تمام سوابق مالی باقی می‌مانند."
                        AlertDialog.Builder(this).setTitle(if (count == 0) "حذف صندوق تنخواه؟" else "بایگانی صندوق تنخواه؟")
                            .setMessage(explanation).setPositiveButton(if (count == 0) "حذف" else "بایگانی") { _, _ ->
                                db.archivePettyCashPerson(person.id)
                                showPettyCashPeople()
                                syncWithFirebaseIfOnline(false)
                            }.setNegativeButton("انصراف", null).show()
                    })
                }
            })
        }
        root.addView(actionButton("＋ افزودن صندوق تنخواه"){val f=field("نام شخص/صندوق","");AlertDialog.Builder(this).setTitle("صندوق تنخواه جدید").setView(f).setPositiveButton("ثبت"){_,_->if(f.text.toString().trim().isNotBlank()){db.addPettyCashPerson(f.text.toString().trim());showPettyCashPeople();syncWithFirebaseIfOnline(false)}else info("نام صندوق را وارد کنید.")}.setNegativeButton("انصراف",null).show()})
        root.addView(actionButton("↩️ بازگشت به تنظیمات"){showSettings()});setScreen(root)
    }

    private fun greenhouseCredentialsDialog(){ showAdminSettings() }

    private fun sellerCredentialsDialog(sid:Long){
        if(db.currentSellerId()!=sid) return
        sellerAccountSettings()
    }

    private fun firebaseSyncDialog(){
        syncWithFirebaseIfOnline(true)
    }

    private fun isNetworkAvailable(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun registerNetworkSync(){
        if (networkCallback != null) return
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread { syncWithFirebaseIfOnline(false) }
            }
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            connectivityManager.registerDefaultNetworkCallback(networkCallback!!)
        }
    }

    override fun onResume() {
        super.onResume()
        autoSyncHandler.removeCallbacks(autoSyncRunnable)
        autoSyncHandler.post(autoSyncRunnable)
        if (db.isStaffMode() && firebaseSignedIn() && isNetworkAvailable()) refreshStaffPermissionsFromCloud()
        db.closeCompletedFinancialMonths()
        if (FirebaseApp.getApps(this).isNotEmpty() && firebaseSignedIn() && isNetworkAvailable()) {
            syncWithFirebaseIfOnline(false)
            syncMonthlyArchivesWithCloud()
        }
    }

    private fun refreshStaffPermissionsFromCloud() {
        val uid = db.getMode()?.substringAfter("GREENHOUSE:STAFF:").orEmpty()
        if (uid.isBlank()) return
        FirebaseFirestore.getInstance().collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                if (!doc.exists() || doc.getString("role") != "STAFF") return@addOnSuccessListener
                val latest = (doc.get("permissions") as? List<*>)?.filterIsInstance<String>()?.toSet() ?: emptySet()
                val prefs = getSharedPreferences("golnegar_staff_permissions", Context.MODE_PRIVATE)
                val old = prefs.getStringSet(uid, emptySet())?.toSet() ?: emptySet()
                if (old != latest) {
                    prefs.edit().putStringSet(uid, latest).apply()
                    // Re-render the active page so revoked options disappear immediately.
                    if (currentScreenRoot != null && !isFinishing) showHome()
                }
            }
    }

    override fun onPause() {
        autoSyncHandler.removeCallbacks(autoSyncRunnable)
        super.onPause()
    }

    override fun onStop() {
        // Android does not guarantee onDestroy() before a process is killed.
        // Save the latest complete local database snapshot when the app leaves
        // the foreground, so a normal close/background transition gets a fresh backup.
        automaticBackupOnExit()
        super.onStop()
    }

    override fun onDestroy() {
        networkCallback?.let {
            runCatching { connectivityManager.unregisterNetworkCallback(it) }
        }
        networkCallback = null
        super.onDestroy()
    }

    private fun automaticBackupOnExit() {
        if (!::db.isInitialized) return
        runCatching {
            val target = File(noBackupFilesDir, "GolNegar_AutoBackup.json")
            val temp = File(noBackupFilesDir, "GolNegar_AutoBackup.tmp")
            temp.writeText(db.exportBackupJson(), Charsets.UTF_8)
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) {
                target.writeText(temp.readText(Charsets.UTF_8), Charsets.UTF_8)
                temp.delete()
            }
            db.setSettingText("auto_backup_last", System.currentTimeMillis().toString())
        }
    }

    private fun exportAutomaticBackupToUserFile() {
        val target = File(noBackupFilesDir, "GolNegar_AutoBackup.json")
        if (!target.exists()) {
            info("هنوز نسخه پشتیبان خودکار ساخته نشده است.")
            return
        }
        val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(android.content.Intent.EXTRA_TITLE, "GolNegar_AutoBackup_${BuildConfig.VERSION_NAME}.json")
        }
        startActivityForResult(intent, 8103)
    }

    private fun syncWithFirebaseIfOnline(showMessage: Boolean, onDone: (Boolean) -> Unit = {}){
        if (destructiveDeleteInProgress) {
            if (showMessage) info("همگام‌سازی تا پایان عملیات حذف متوقف می‌ماند.")
            onDone(false)
            return
        }
        if (syncInProgress) {
            synchronized(syncWaiters) { syncWaiters.add(onDone) }
            return
        }
        if (FirebaseApp.getApps(this).isEmpty()) { db.setSettingText("last_sync_error", "Firebase به برنامه متصل نشده است."); refreshHomeSyncStatus(); if (showMessage) info("Firebase به برنامه متصل نشده است."); onDone(false); return }
        if (!firebaseSignedIn()) {
            if (showMessage && !db.isSellerMode()) {
                firebaseAdminLogin { ok ->
                    if (ok) syncWithFirebaseIfOnline(true, onDone)
                    else onDone(false)
                }
            } else {
                db.setSettingText("last_sync_error", "نشست Firebase برقرار نیست.")
                refreshHomeSyncStatus()
                onDone(false)
            }
            return
        }
        if (!isNetworkAvailable()) { db.setSettingText("last_sync_error", "اینترنت در دسترس نیست."); refreshHomeSyncStatus(); if (showMessage) info("اینترنت در دسترس نیست؛ اطلاعات هنگام اتصال دوباره خودکار همگام می‌شوند."); onDone(false); return }

        syncInProgress = true
        syncWatchdogHandler.removeCallbacks(syncWatchdog)
        syncWatchdogHandler.postDelayed(syncWatchdog, 45_000L)
        db.setSettingText("last_sync_error", "")
        refreshHomeSyncStatus()
        val syncErrors = mutableListOf<String>()
        val fs = FirebaseFirestore.getInstance()
        val admin = !db.isSellerMode()
        db.ensureRemoteIds()
        val localFirebase = db.firebaseCollections()
        val collections: List<Pair<String, List<Map<String, Any?>>>> =
            if (admin && !db.isStaffMode()) {
                localFirebase.entries.map { it.key to it.value }
            } else if (db.isStaffMode()) {
                // Staff accounts can work on operational greenhouse data, but they do not
                // overwrite global settings or expense-type definitions during sync.
                listOf(
                    "flowers", "sellers", "deliveries", "sales", "returns", "payments",
                    "misc_sales", "greenhouse_payments", "petty_cash_people"
                ).map { it to localFirebase[it].orEmpty() }
            } else {
                val sid = db.currentSellerId()
                listOf(
                    "sales" to localFirebase["sales"].orEmpty().filter { ((it["seller_id"] as? Number)?.toLong() == sid || it["seller_remote_id"]?.toString() == db.sellerRemoteId(sid ?: -1L)) && it["sync_state"]?.toString() == "PENDING" },
                    "returns" to localFirebase["returns"].orEmpty().filter { ((it["seller_id"] as? Number)?.toLong() == sid || it["seller_remote_id"]?.toString() == db.sellerRemoteId(sid ?: -1L)) && it["sync_state"]?.toString() == "PENDING" },
                    "payments" to localFirebase["payments"].orEmpty().filter { ((it["seller_id"] as? Number)?.toLong() == sid || it["seller_remote_id"]?.toString() == db.sellerRemoteId(sid ?: -1L)) && it["sync_state"]?.toString() == "PENDING" }
                )
            }

        val greenhouseManager = !db.isSellerMode() && !db.isStaffMode()

        fun finish(ok: Boolean, message: String? = null) {
            if (!syncInProgress) return
            syncWatchdogHandler.removeCallbacks(syncWatchdog)
            syncInProgress = false
            if (ok) {
                db.setLastFirebaseSync(System.currentTimeMillis())
                db.setSettingText("last_sync_error", "")
            } else {
                val detail = if (syncErrors.isNotEmpty()) syncErrors.joinToString(" | ") else (message ?: "خطای نامشخص")
                db.setSettingText("last_sync_error", detail)
            }
            refreshHomeSyncStatus()
            onDone(ok)
            val waiting = synchronized(syncWaiters) { val copy = syncWaiters.toList(); syncWaiters.clear(); copy }
            waiting.forEach { it(ok) }
            if (showMessage && message != null) info(message)
            if (ok && isHomeScreen) runOnUiThread { showHome() }
        }

        fun pullCollection(name: String, sellerId: Long?, sellerRemoteId: String?, done: (Boolean) -> Unit) {
            fun fail(e: Exception){
                val raw=e.localizedMessage ?: e.message ?: "خطای نامشخص"
                val detail=when(e){
                    is com.google.firebase.firestore.FirebaseFirestoreException -> "${e.code}: $raw"
                    else -> raw
                }
                syncErrors.add("$name: $detail")
                done(false)
            }
            fun importSnapshot(snap: com.google.firebase.firestore.QuerySnapshot) {
                snap.documents.forEach { d ->
                    val m = d.data ?: return@forEach
                    db.importFirebaseRecord(name, d.id, m)
                }
            }
            if (name == "sellers" && sellerId != null) {
                // Seller documents are mirrored under the numeric local seller_id.
                // This matches the existing Firestore Rules exactly:
                // sellers/{id} is readable when id == userDoc().seller_id.
                // It also avoids a collection query that older Rules cannot authorize.
                fs.collection(name).document(sellerId.toString()).get()
                    .addOnSuccessListener { snap ->
                        if (snap.exists()) {
                            db.importFirebaseRecord(name, snap.id, snap.data ?: emptyMap())
                            done(true)
                        } else {
                            if (showMessage) info("اطلاعات فروشنده در Firebase پیدا نشد. ابتدا از نسخه گلخانه یک‌بار همگام‌سازی کنید.")
                            done(false)
                        }
                    }
                    .addOnFailureListener { e ->
                        fail(e)
                        if (showMessage) info("دریافت اطلاعات فروشنده از Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای دسترسی یا اتصال"}")
                    }
            } else if (sellerId != null && sellerId > 0L) {
                // Read only this seller's rows using fields that are explicitly allowed by
                // Firestore Rules. In particular, an auth_uid-only query for payments is
                // denied by rules that authorize through seller_id/seller_remote_id.
                val queries = mutableListOf<com.google.firebase.firestore.Query>()
                queries.add(fs.collection(name).whereEqualTo("seller_id", sellerId))
                if (!sellerRemoteId.isNullOrBlank()) {
                    queries.add(fs.collection(name).whereEqualTo("seller_remote_id", sellerRemoteId))
                }
                val found = linkedMapOf<String, com.google.firebase.firestore.DocumentSnapshot>()
                val queryErrors = mutableListOf<String>()
                fun runQuery(index: Int) {
                    if (index >= queries.size) {
                        if (found.isNotEmpty() || queryErrors.isEmpty()) {
                            found.values.forEach { d -> db.importFirebaseRecord(name, d.id, d.data ?: emptyMap()) }
                            done(true)
                        } else {
                            val detail = queryErrors.distinct().joinToString(" | ")
                            val error = IllegalStateException("همهٔ مسیرهای مجاز دریافت $name ناموفق بود: $detail")
                            fail(error)
                            if (showMessage) info("دریافت «$name» از Firebase انجام نشد: $detail")
                        }
                        return
                    }
                    queries[index].get()
                        .addOnSuccessListener { snap ->
                            snap.documents.forEach { d -> found[d.id] = d }
                            runQuery(index + 1)
                        }
                        .addOnFailureListener { e ->
                            queryErrors.add("${(e as? com.google.firebase.firestore.FirebaseFirestoreException)?.code ?: "خطا"}: ${e.localizedMessage ?: e.message ?: "نامشخص"}")
                            runQuery(index + 1)
                        }
                }
                runQuery(0)
            } else {
                fs.collection(name).get()
                    .addOnSuccessListener { snap -> importSnapshot(snap); done(true) }
                    .addOnFailureListener { e ->
                        fail(e)
                        if (showMessage) info("دریافت «$name» از Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}")
                    }
            }
        }

        fun pullAll(done: (Boolean) -> Unit) {
            val names = if (admin) listOf("flowers", "sellers", "deliveries", "sales", "returns", "payments", "misc_sales", "greenhouse_payments", "petty_cash_people", "expense_types", "settings") else listOf("flowers", "deliveries", "sales", "returns", "payments")
            val sid = db.currentSellerId()
            val firebaseSid = db.settingTextPublic("firebase_seller_id", "").toLongOrNull()
            val sellerRemoteId = sid?.let { db.sellerRemoteId(it) }
            var allOk = true
            fun next(i: Int) {
                if (i >= names.size) { done(allOk); return }
                val name = names[i]
                val filter = if (!admin && name != "flowers" && name != "sellers" && name != "settings") firebaseSid else null
                val remoteFilter = if (!admin && name != "flowers" && name != "sellers" && name != "settings") sellerRemoteId else null
                pullCollection(name, filter, remoteFilter) { ok -> allOk = allOk && ok; next(i + 1) }
            }
            next(0)
        }

        fun writeCollection(index: Int, afterWrite: () -> Unit) {
            if (index >= collections.size) { afterWrite(); return }
            val entry = collections[index]
            val batch = fs.batch()
            entry.second.forEach { row ->
                val docId = row["remote_id"]?.toString()?.takeIf { it.isNotBlank() }
                    ?: return@forEach
                val data = HashMap<String, Any>()
                row.forEach { (k, v) ->
                    if (v != null && k != "id") data[k] = v
                }
                data["updated_at"] = System.currentTimeMillis()
                if (!admin) {
                    val firebaseSid = db.settingTextPublic("firebase_seller_id", "").toLongOrNull()
                    if (firebaseSid == null || firebaseSid <= 0L) {
                        syncErrors.add("${entry.first}: شناسه فروشنده Firebase در حساب کاربر پیدا نشد.")
                        return@forEach
                    }
                    data["seller_id"] = firebaseSid
                    data["seller_remote_id"] = db.sellerRemoteId(db.currentSellerId() ?: -1L)
                    data["seller_auth_uid"] = firebaseAuth.currentUser?.uid.orEmpty()
                }
                if (!admin && (entry.first == "sales" || entry.first == "returns" || entry.first == "payments")) {
                    data["auth_uid"] = firebaseAuth.currentUser!!.uid
                    data["seller_auth_uid"] = firebaseAuth.currentUser!!.uid
                    data["created_by"] = firebaseAuth.currentUser!!.uid
                    data["updated_by"] = firebaseAuth.currentUser!!.uid
                } else if (admin && firebaseAuth.currentUser != null) {
                    data["created_by"] = firebaseAuth.currentUser!!.uid
                    data["updated_by"] = firebaseAuth.currentUser!!.uid
                }
                batch.set(fs.collection(entry.first).document(docId), data, com.google.firebase.firestore.SetOptions.merge())
                // Keep a seller document mirrored under seller_id so seller devices
                // can read it using the existing Firestore Rules without a broad query.
                if (admin && entry.first == "sellers") {
                    val sid = row["seller_id"]?.toString()?.toLongOrNull()
                    if (sid != null && sid > 0L) {
                        batch.set(
                            fs.collection("sellers").document(sid.toString()),
                            data,
                            com.google.firebase.firestore.SetOptions.merge()
                        )
                    }
                }
            }
            batch.commit()
                .addOnSuccessListener {
                    if (!admin && (entry.first == "sales" || entry.first == "returns" || entry.first == "payments")) {
                        db.markSynced(entry.first, entry.second.mapNotNull { it["remote_id"]?.toString()?.takeIf { id -> id.isNotBlank() } })
                    }
                    writeCollection(index + 1, afterWrite)
                }
                .addOnFailureListener { e ->
                    syncErrors.add("${entry.first}: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}")
                    finish(false, "همگام‌سازی «${entry.first}» انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}")
                }
        }

        // Local pending changes are written first. Then the same Firebase snapshot is
        // pulled back so the local database also receives records created on another device.
        writeCollection(0) {
            if (greenhouseManager) {
                provisionSellerFirebaseAccounts { ok, error ->
                    pullAll { pullOk ->
                        if (!pullOk) finish(false, "اطلاعات به Firebase ارسال شد، اما دریافت کامل اطلاعات مشترک انجام نشد.")
                        else if (!ok) finish(true, error ?: "اطلاعات اصلی همگام شد، اما ساخت حساب Firebase یکی از فروشندگان کامل نشد.")
                        else finish(true, "همگام‌سازی گلخانه با Firebase با موفقیت انجام شد.")
                    }
                }
            } else {
                pullAll { ok -> finish(ok, if (ok) "همگام‌سازی فروشنده با Firebase با موفقیت انجام شد." else "بخشی از اطلاعات فروشنده از Firebase دریافت نشد.") }
            }
        }
    }

    private fun firstGreenhouseSetup(){
        val box=formBox()
        val u=field("نام کاربری مدیر","admin")
        val p=field("رمز عبور مدیر","")
        val p2=field("تکرار رمز عبور","")
        val email=field("ایمیل حساب Firebase",db.adminFirebaseEmail())
        val fp=field("رمز عبور Firebase","")
        p.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        p2.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        fp.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(u);box.addView(p);box.addView(p2);box.addView(email);box.addView(fp)
        AlertDialog.Builder(this)
            .setTitle("راه‌اندازی اولیه گل نگار")
            .setMessage("نام کاربری و رمز مدیر و همچنین اطلاعات حساب Firebase فقط یک‌بار وارد می‌شوند. پس از اتصال موفق، دفعات بعد برنامه بدون نمایش صفحه ورود باز می‌شود.")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("اتصال و شروع") { _, _ ->
                val a=u.text.toString().trim(); val b=p.text.toString(); val b2=p2.text.toString()
                val em=email.text.toString().trim(); val fpass=fp.text.toString()
                if(a.isBlank()||b.length<6||b!=b2||!android.util.Patterns.EMAIL_ADDRESS.matcher(em).matches()||fpass.length<6){
                    info("نام کاربری را وارد کنید، رمز مدیر را حداقل ۶ کاراکتر انتخاب کنید و ایمیل و رمز Firebase را کامل وارد کنید."){firstGreenhouseSetup()}
                    return@setPositiveButton
                }
                db.setAdminCredentials(a,b)
                db.setAdminFirebaseEmail(em)
                firebaseAuth.signInWithEmailAndPassword(em,fpass)
                    .addOnSuccessListener { result ->
                        secureCredentials.put("admin_firebase_password",fpass)
                        db.setAdminSetupDone(); db.setMode("GREENHOUSE")
                        ensureFirebaseUserDoc(result.user,"ADMIN",null){ ok ->
                            runOnUiThread { if(ok){ syncWithFirebaseIfOnline(false); showHome() } else info("اتصال Firebase برقرار شد، اما ثبت حساب مدیر کامل نشد.") }
                        }
                    }
                    .addOnFailureListener { err ->
                        val code=(err as? FirebaseAuthException)?.errorCode.orEmpty()
                        if(code=="ERROR_USER_NOT_FOUND" || code=="ERROR_EMAIL_NOT_FOUND"){
                            AlertDialog.Builder(this)
                                .setTitle("حساب Firebase پیدا نشد")
                                .setMessage("برای این ایمیل حساب Firebase وجود ندارد. آیا حساب جدید ساخته شود؟")
                                .setNegativeButton("لغو",null)
                                .setPositiveButton("ساخت حساب"){_,_->
                                    firebaseAuth.createUserWithEmailAndPassword(em,fpass)
                                        .addOnSuccessListener { result ->
                                            secureCredentials.put("admin_firebase_password",fpass); db.setAdminSetupDone(); db.setMode("GREENHOUSE")
                                            ensureFirebaseUserDoc(result.user,"ADMIN",null){ ok -> runOnUiThread { if(ok){syncWithFirebaseIfOnline(false);showHome()} else info("حساب ساخته شد، اما ثبت پروفایل مدیر کامل نشد.") } }
                                        }
                                        .addOnFailureListener { e -> info("ساخت حساب Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}") }
                                }.show()
                        } else {
                            info("اتصال Firebase انجام نشد: ${err.localizedMessage ?: err.message ?: "ایمیل یا رمز Firebase صحیح نیست."}"){firstGreenhouseSetup()}
                        }
                    }
            }.show()
    }

    private fun greenhouseLogin(){
        if(db.isAdminSetupDone()){
            showHome(); restoreFirebaseSessionIfNeeded(); return
        }
        firstGreenhouseSetup()
    }

    private fun passwordField(label:String, value:String, revealLabel:String = "نمایش رمز"): LinearLayout {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val e=field(label,value)
        e.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val show=CheckBox(this).apply{text="👁 $revealLabel";isChecked=false}
        show.setOnCheckedChangeListener { _, checked ->
            e.inputType=if(checked) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            e.setSelection(e.text.length)
        }
        box.addView(e);box.addView(show)
        box.tag=e
        return box
    }

    private fun showAdminSettings(){
        val root=base("تنظیمات مدیر","مدیریت حساب، اتصال، اطلاعات مالی و تنظیمات برنامه")

        root.addView(sectionTitle("👤 حساب مدیر و امنیت"))
        root.addView(cardText("نام کاربری: ${db.adminUsername()}\nبرای تغییر اطلاعات ورود از گزینه‌های زیر استفاده کنید."))
        root.addView(actionButton("✏️ تغییر نام کاربری و رمز عبور مدیر"){adminAccountDialog()})

        root.addView(sectionTitle("☁️ Firebase و همگام‌سازی"))
        root.addView(cardText(if(firebaseSignedIn()) "🟢 اتصال Firebase برقرار است" else "🔴 نشست Firebase برقرار نیست"))
        root.addView(actionButton("🔌 آزمایش اتصال"){testDatabaseConnection()})
        root.addView(actionButton("🔄 همگام‌سازی اکنون"){syncWithFirebaseIfOnline(true)})
        root.addView(actionButton("⚙️ تنظیم مجدد اتصال Firebase"){resetDatabaseConnectionDialog()})
        root.addView(actionButton("👥 مدیریت کاربران گلخانه"){showGreenhouseUsers()})
        root.addView(actionButton("🗄️ مدیریت دیتابیس"){showDatabaseManagement()})

        root.addView(sectionTitle("💰 امور مالی و صندوق"))
        root.addView(actionButton("👛 مدیریت صندوق تنخواه"){showPettyCashPeople()})
        root.addView(actionButton("📈 تنظیم سهم پیش‌فرض فروشنده"){defaultSellerShareDialog()})

        root.addView(sectionTitle("📅 برنامه و تاریخ"))
        val date=Calendar.getInstance().apply{timeInMillis=db.appDate()}
        root.addView(cardText("تاریخ کاری فعلی: ${jalali(date)}"))
        root.addView(actionButton("📅 تغییر تاریخ کاری"){dateSettingsDialog()})
        root.addView(actionButton("🔁 تغییر نسخه"){showVersionSwitcher()})
        root.addView(cardText("طراح و برنامه‌نویس: مهدی ساریخانی فرد\n۰۹۱۲۱۳۹۸۸۹۳"))

        root.addView(actionButton("↩️ بازگشت"){goBack()})
        setScreen(root)
    }

    private fun showSellerSettings(){
        val sid=db.currentSellerId()?:return
        val s=db.sellers().firstOrNull{it.id==sid}
        val root=base("تنظیمات فروشنده","فقط تنظیمات حساب و وضعیت اتصال خودتان")

        root.addView(sectionTitle("👤 حساب کاربری"))
        if(s!=null) root.addView(cardText("نام فروشنده: ${s.name}\nنام کاربری: ${s.username}"))
        root.addView(actionButton("✏️ تغییر نام کاربری و رمز عبور"){sellerAccountSettings()})

        root.addView(sectionTitle("☁️ اتصال و همگام‌سازی"))
        root.addView(cardText(if(firebaseSignedIn()) "🟢 اتصال Firebase برقرار است" else "🟡 اتصال در انتظار / آفلاین"))
        root.addView(actionButton("🔌 آزمایش اتصال"){testDatabaseConnection()})
        root.addView(actionButton("🔄 همگام‌سازی اکنون"){syncWithFirebaseIfOnline(true)})

        root.addView(sectionTitle("📅 ماه‌های مالی"))
        root.addView(actionButton("🗃️ آرشیو ماه‌های مالی من") { showSellerFinancialArchives(sid) })

        root.addView(sectionTitle("📅 برنامه"))
        root.addView(actionButton("🔁 تغییر نسخه"){showVersionSwitcher()})
        root.addView(actionButton("↩️ بازگشت"){goBack()})
        setScreen(root)
    }

    private fun defaultSellerShareDialog(){
        val f=numberField("سهم پیش‌فرض فروشنده (%)",db.getDefaultSellerShare().toString())
        AlertDialog.Builder(this).setTitle("سهم پیش‌فرض فروشنده").setMessage("این مقدار فقط برای فروشندگان جدید استفاده می‌شود؛ سهم فروشندگان قبلی تغییر نمی‌کند.").setView(f)
            .setPositiveButton("ذخیره"){_,_->
                val v=f.text.toString().toDoubleOrNull()
                if(v==null || v<0 || v>100) info("درصد باید بین صفر تا صد باشد.")
                else { db.setDefaultSellerShare(v); info("سهم پیش‌فرض فروشنده ذخیره شد.") }
            }.setNegativeButton("انصراف",null).show()
    }

    private fun dateSettingsDialog(){
        val current=Calendar.getInstance().apply{timeInMillis=db.appDate()}
        val box=formBox()
        val dateLabel=label("تاریخ کاری فعلی: ${jalali(current)}")
        box.addView(dateLabel)
        val picker=DatePicker(this).apply{
            init(current.get(Calendar.YEAR),current.get(Calendar.MONTH),current.get(Calendar.DAY_OF_MONTH),null)
        }
        box.addView(picker)
        AlertDialog.Builder(this).setTitle("تغییر تاریخ کاری").setView(box)
            .setPositiveButton("ذخیره"){_,_->
                val c=Calendar.getInstance()
                c.set(picker.year,picker.month,picker.dayOfMonth,12,0,0)
                c.set(Calendar.MILLISECOND,0)
                db.setAppDate(c.timeInMillis)
                info("تاریخ کاری برنامه تغییر کرد.")
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showStaffSettings(){
        val root=base("تنظیمات کاربر گلخانه","حساب مستقل، اتصال و تنظیمات شخصی")
        root.addView(sectionTitle("👤 حساب کاربری"))
        val uid=db.getMode()?.substringAfter("GREENHOUSE:STAFF:").orEmpty()
        val email=secureCredentials.get("staff_email_$uid").orEmpty()
        root.addView(cardText("حساب Firebase: ${email.ifBlank { "کاربر گلخانه" }}"))
        root.addView(actionButton("🔄 همگام‌سازی اکنون"){syncWithFirebaseIfOnline(true)})
        root.addView(sectionTitle("📅 برنامه"))
        root.addView(actionButton("📅 تاریخ کاری"){dateSettingsDialog()})
        root.addView(actionButton("🔁 تغییر نسخه"){showVersionSwitcher()})
        root.addView(actionButton("🚪 خروج از حساب"){confirmGreenhouseLogout()})
        root.addView(actionButton("↩️ بازگشت به خانه"){goBack()})
        setScreen(root)
    }

    private fun adminAccountDialog(){
        val box=formBox()
        val username=field("نام کاربری جدید مدیر",db.adminUsername())
        val old=passwordField("رمز فعلی مدیر","")
        val np=passwordField("رمز جدید (در صورت نیاز)","")
        val cp=passwordField("تکرار رمز جدید","")
        box.addView(username); box.addView(old); box.addView(np); box.addView(cp)
        AlertDialog.Builder(this).setTitle("تغییر اطلاعات حساب مدیر").setView(box)
            .setPositiveButton("ذخیره"){_,_->
                val u=username.text.toString().trim()
                val o=(old.tag as EditText).text.toString()
                val n=(np.tag as EditText).text.toString()
                val c=(cp.tag as EditText).text.toString()
                if(u.isBlank()) info("نام کاربری نمی‌تواند خالی باشد.")
                else if(o!=db.adminLocalPassword()) info("رمز فعلی صحیح نیست.")
                else if(n.isNotBlank() && (n.length<6 || n!=c)) info("رمز جدید باید حداقل ۶ کاراکتر و با تکرار آن یکسان باشد.")
                else {
                    db.setSettingText("admin_username",u)
                    if(n.isNotBlank()) db.setSettingText("admin_password",n)
                    info("اطلاعات حساب مدیر ذخیره شد.")
                    showAdminSettings()
                }
            }.setNegativeButton("انصراف",null).show()
    }

    private fun adminUsernameDialog(){
        val f=field("نام کاربری جدید",db.adminUsername())
        AlertDialog.Builder(this).setTitle("تغییر نام کاربری مدیر").setView(f).setPositiveButton("ذخیره"){_,_->val v=f.text.toString().trim();if(v.isBlank())info("نام کاربری نمی‌تواند خالی باشد.")else{db.setSettingText("admin_username",v);info("نام کاربری مدیر تغییر کرد.")}}.setNegativeButton("انصراف",null).show()
    }

    private fun adminPasswordDialog(){
        val box=formBox();val old=passwordField("رمز فعلی","");val np=passwordField("رمز جدید","");val cp=passwordField("تکرار رمز جدید","");box.addView(old);box.addView(np);box.addView(cp)
        AlertDialog.Builder(this).setTitle("تغییر رمز عبور مدیر").setView(box).setPositiveButton("ذخیره"){_,_->
            val o=(old.tag as EditText).text.toString();val n=(np.tag as EditText).text.toString();val c=(cp.tag as EditText).text.toString()
            if(o!=db.adminLocalPassword())info("رمز فعلی صحیح نیست.") else if(n.length<6||n!=c)info("رمز جدید باید حداقل ۶ کاراکتر و با تکرار آن یکسان باشد.") else{db.setSettingText("admin_password",n);info("رمز مدیر تغییر کرد.")}
        }.setNegativeButton("انصراف",null).show()
    }

    private fun testDatabaseConnection(){
        if(!isNetworkAvailable()){info("اینترنت در دسترس نیست. برنامه آفلاین کار می‌کند و بعداً دوباره تلاش می‌کند.");return}
        if(!firebaseSignedIn()){restoreFirebaseSessionIfNeeded();info("در حال برقراری اتصال با حساب ذخیره‌شده هستیم.");return}
        FirebaseFirestore.getInstance().collection("settings").document("app").get().addOnSuccessListener{info("🟢 اتصال به دیتابیس برقرار است و دسترسی خواندن تأیید شد.")}.addOnFailureListener{e->info("🔴 اتصال برقرار نشد: ${e.localizedMessage ?: e.message ?: "خطای دسترسی"}")}
    }

    private fun resetDatabaseConnectionDialog(){
        val box=formBox();val em=field("ایمیل Firebase",db.adminFirebaseEmail());val p=passwordField("رمز Firebase","");box.addView(em);box.addView(p)
        AlertDialog.Builder(this).setTitle("تنظیم مجدد اتصال Firebase").setMessage("فقط زمانی استفاده کنید که حساب یا رمز Firebase تغییر کرده باشد.").setView(box).setPositiveButton("اتصال مجدد"){_,_->
            val email=em.text.toString().trim();val pass=(p.tag as EditText).text.toString()
            if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()||pass.length<6){info("ایمیل و رمز Firebase را صحیح وارد کنید.");return@setPositiveButton}
            firebaseAuth.signInWithEmailAndPassword(email,pass).addOnSuccessListener{db.setAdminFirebaseEmail(email);secureCredentials.put("admin_firebase_password",pass);info("🟢 اتصال Firebase با موفقیت تنظیم شد.");syncWithFirebaseIfOnline(false)}.addOnFailureListener{e->info("اتصال مجدد انجام نشد: ${e.localizedMessage ?: e.message ?: "ایمیل یا رمز صحیح نیست."}")}
        }.setNegativeButton("انصراف",null).show()
    }

    private fun forceBlackText(view: View) {
        if (view is TextView) view.setTextColor(Color.BLACK)
        if (view is ViewGroup) for (i in 0 until view.childCount) forceBlackText(view.getChildAt(i))
    }

    private fun showGreenhouseUsers() {
        if (!requireStaffPermission("sellers", "مدیریت کاربران گلخانه")) return
        val root = base("کاربران گلخانه", "هر کاربر حساب مستقل Firebase دارد و همزمان می‌تواند با کاربران دیگر کار کند.")
        root.addView(actionButton("＋ افزودن کاربر گلخانه") { createGreenhouseUserDialog() })

        // Keep navigation visible immediately. Previously the Back button was only
        // appended after the async Firestore request, which could leave an empty gap
        // and make an invisible/failed user list look like a layout problem.
        val status = cardText("در حال دریافت فهرست کاربران گلخانه…").apply {
            setTextColor(Color.rgb(35, 58, 43))
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        root.addView(status)
        root.addView(actionButton("بازگشت") { goBack() })
        forceBlackText(root)
        setScreen(root)

        if (!isNetworkAvailable()) {
            status.text = "برای نمایش کاربران گلخانه، اتصال اینترنت لازم است. حساب‌های ثبت‌شده در Firebase حذف نشده‌اند."
            return
        }
        if (firebaseAuth.currentUser == null) {
            status.text = "نشست Firebase برقرار نیست. ابتدا از حساب مدیر وارد شوید و دوباره این صفحه را باز کنید."
            return
        }

        FirebaseFirestore.getInstance().collection("users").whereEqualTo("role", "STAFF").get()
            .addOnSuccessListener { snap ->
                root.removeView(status)
                if (snap.isEmpty) {
                    val empty = cardText("هنوز کاربر مستقلی برای گلخانه تعریف نشده است.")
                    empty.setTextColor(Color.rgb(35, 58, 43))
                    forceBlackText(empty)
                    root.addView(empty, root.indexOfChild(root.getChildAt(root.childCount - 1)))
                } else {
                    snap.documents.forEach { d ->
                        val username = d.getString("username") ?: d.getString("firebase_email") ?: d.id
                        val displayName = d.getString("name")?.trim().takeUnless { it.isNullOrBlank() } ?: username
                        val email = d.getString("firebase_email") ?: ""
                        val savedPassword = secureCredentials.get("staff_firebase_${d.id}")
                        val item = cardRow("👤 $displayName\nنام کاربری: $username\nایمیل: $email\nرمز عبور: ${savedPassword ?: "برای امنیت در این دستگاه ذخیره نشده"}") {
                            it.addView(actionButton("✏️ ویرایش نام و اطلاعات ورود") {
                                editGreenhouseUserDialog(d.id, displayName, username, email, (d.get("permissions") as? List<*>)?.filterIsInstance<String>()?.toSet() ?: emptySet())
                            })
                            it.addView(actionButton("🗑️ حذف کاربر گلخانه") {
                                AlertDialog.Builder(this@MainActivity)
                                    .setTitle("حذف کاربر گلخانه")
                                    .setMessage("پروفایل «$displayName» از فهرست کاربران برنامه حذف می‌شود و این حساب دیگر از طریق برنامه گل نگار پذیرفته نخواهد شد. حذف کامل حساب از Firebase Authentication از داخل برنامه اندروید امکان‌پذیر نیست و برای حذف نهایی آن به Firebase Admin SDK یا کنسول مدیر Firebase نیاز است. ادامه می‌دهید؟")
                                    .setNegativeButton("انصراف", null)
                                    .setPositiveButton("حذف پروفایل") { _, _ ->
                                        if (!isNetworkAvailable()) {
                                            info("برای حذف کاربر اتصال اینترنت لازم است.")
                                        } else {
                                            FirebaseFirestore.getInstance().collection("users").document(d.id).delete()
                                                .addOnSuccessListener {
                                                    secureCredentials.remove("staff_firebase_${d.id}")
                                                    secureCredentials.remove("staff_email_${d.id}")
                                                    info("پروفایل کاربر حذف شد. برای حذف کامل حساب ورود از Firebase Authentication نیز باید از کنسول مدیر یا Admin SDK استفاده شود.")
                                                    showGreenhouseUsers()
                                                }
                                                .addOnFailureListener { e -> info("حذف پروفایل انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}") }
                                        }
                                    }.show()
                            })
                        }
                        item.setPadding(dp(14), dp(12), dp(14), dp(12))
                        forceBlackText(item)
                        root.addView(item, root.childCount - 1)
                    }
                }
            }
            .addOnFailureListener { e ->
                status.text = "فهرست کاربران دریافت نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}\nاگر کاربر ساخته شده باشد، این خطا به معنی حذف حساب نیست؛ مجوز خواندن users در Firestore بررسی شود."
                status.setTextColor(Color.rgb(150, 35, 35))
            }
    }

    private fun createGreenhouseUserDialog() {
        val box = formBox()
        val displayName = field("نام و نام خانوادگی کاربر", "")
        val username = field("نام کاربری", "")
        val password = passwordField("رمز عبور حداقل ۶ کاراکتر", "")
        val permissionTitle=TextView(this).apply{text="دسترسی‌های این کاربر";textSize=15f;typeface=Typeface.DEFAULT_BOLD;setTextColor(palette().text);setPadding(0,dp(6),0,dp(2))}
        val permissionOptions=linkedMapOf(
            "flower" to "تعریف و ویرایش گل", "sellers" to "مدیریت فروشندگان", "delivery" to "ثبت تحویل گل",
            "misc_sale" to "ثبت فروش متفرقه", "returns" to "ثبت برگشتی", "payments" to "مشاهده و ثبت پرداخت‌ها",
            "expense" to "ثبت هزینه گلخانه", "warnings" to "مشاهده هشدارها", "financial_report" to "مشاهده گزارش مالی")
        val permissionChecks=linkedMapOf<String,CheckBox>()
        box.addView(displayName); box.addView(username); box.addView(password); box.addView(permissionTitle)
        permissionOptions.forEach{(key,label)-> val cb=CheckBox(this).apply{text=label;isChecked=key in setOf("delivery","returns","payments","warnings");setTextColor(Color.BLACK);setPadding(0,0,0,0)};permissionChecks[key]=cb;box.addView(cb) }
        AlertDialog.Builder(this)
            .setTitle("افزودن کاربر گلخانه")
            .setMessage("حساب مستقل ساخته می‌شود. دسترسی‌ها را متناسب با وظیفه کاربر انتخاب کنید.")
            .setView(box)
            .setPositiveButton("ساخت حساب") { _, _ ->
                val display = displayName.text.toString().trim()
                val u = username.text.toString().trim()
                val p = (password.tag as EditText).text.toString()
                if (display.isBlank() || u.isBlank() || p.length < 6) { info("نام کاربر، نام کاربری و رمز عبور حداقل ۶ کاراکتری را وارد کنید."); return@setPositiveButton }
                if (!isNetworkAvailable()) { info("برای ساخت حساب کاربر گلخانه اتصال اینترنت لازم است."); return@setPositiveButton }
                val adminUser = firebaseAuth.currentUser
                if (adminUser == null || !adminUser.email.equals(db.adminFirebaseEmail(), ignoreCase = true)) {
                    info("نشست مدیر Firebase فعال نیست. ابتدا اتصال مدیر را برقرار کنید."); return@setPositiveButton
                }
                val email = firebaseEmail(u, "STAFF")
                val fs = FirebaseFirestore.getInstance()
                val secondaryName = "golyarStaff_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
                val secondaryApp = runCatching { FirebaseApp.initializeApp(this, FirebaseApp.getInstance().options, secondaryName) }.getOrNull()
                if (secondaryApp == null) { info("اتصال مستقل برای ساخت حساب ایجاد نشد."); return@setPositiveButton }
                val secondaryAuth = FirebaseAuth.getInstance(secondaryApp)
                fun saveProfile(authResult: com.google.firebase.auth.AuthResult) {
                    val uid = authResult.user?.uid
                    if (uid.isNullOrBlank()) { secondaryAuth.signOut(); info("Firebase شناسه حساب را برنگرداند."); return }
                    val profile = hashMapOf<String, Any>("role" to "STAFF", "name" to display, "username" to u, "firebase_email" to email,
                        "created_by" to adminUser.uid, "created_at" to System.currentTimeMillis(), "updated_at" to System.currentTimeMillis(),
                        "permissions" to permissionChecks.filterValues { it.isChecked }.keys.toList())
                    // This write uses the primary (admin-authenticated) Firestore instance.
                    fs.collection("users").document(uid).set(profile)
                        .addOnSuccessListener {
                            secondaryAuth.signOut()
                            secureCredentials.put("staff_firebase_$uid", p)
                            secureCredentials.put("staff_email_$uid", email)
                            info("کاربر گلخانه «$display» با نام کاربری «$u» ساخته و مشخصاتش ثبت شد.")
                            showGreenhouseUsers()
                        }
                        .addOnFailureListener { e ->
                            secondaryAuth.signOut()
                            val detail = (e as? com.google.firebase.firestore.FirebaseFirestoreException)?.let { "${it.code}: ${it.localizedMessage}" } ?: (e.localizedMessage ?: "خطای دسترسی")
                            info("حساب ورود ساخته شد اما مشخصات کاربر در users ثبت نشد: $detail. قوانین Firestore برای ثبت پروفایل کاربر را بررسی کنید.")
                        }
                }
                secondaryAuth.createUserWithEmailAndPassword(email, p)
                    .addOnSuccessListener { saveProfile(it) }
                    .addOnFailureListener { createError ->
                        val code = (createError as? FirebaseAuthException)?.errorCode.orEmpty()
                        if (code == "ERROR_EMAIL_ALREADY_IN_USE") {
                            secondaryAuth.signInWithEmailAndPassword(email, p)
                                .addOnSuccessListener { saveProfile(it) }
                                .addOnFailureListener { info("این نام کاربری قبلاً وجود دارد، اما رمز واردشده با آن حساب مطابقت ندارد.") }
                        } else info("ساخت حساب کاربر انجام نشد: ${createError.localizedMessage ?: createError.message ?: "خطای نامشخص"}")
                    }
            }
            .setNegativeButton("بازگشت", null)
            .show()
    }

    private fun editGreenhouseUserDialog(uid: String, currentName: String, currentUsername: String, currentEmail: String, currentPermissions: Set<String> = emptySet()) {
        val box = formBox()
        val displayName = field("نام و نام خانوادگی", currentName)
        val username = field("نام کاربری", currentUsername)
        val savedOldPassword = secureCredentials.get("staff_firebase_$uid").orEmpty()
        val currentPassword = passwordField("رمز فعلی ورود این کاربر", savedOldPassword)
        val password = passwordField("رمز ورود جدید (برای حفظ رمز فعلی خالی بگذارید)", "")
        val permissionTitle = TextView(this).apply { text = "دسترسی‌های این کاربر"; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(palette().text); setPadding(0, dp(10), 0, dp(2)) }
        val permissionOptions = linkedMapOf(
            "flower" to "تعریف و ویرایش گل", "sellers" to "مدیریت فروشندگان", "delivery" to "ثبت تحویل گل",
            "misc_sale" to "ثبت فروش متفرقه", "returns" to "ثبت برگشتی", "payments" to "مشاهده و ثبت پرداخت‌ها",
            "expense" to "ثبت هزینه گلخانه", "warnings" to "مشاهده هشدارها", "financial_report" to "مشاهده گزارش مالی")
        val permissionChecks = linkedMapOf<String, CheckBox>()
        box.addView(displayName); box.addView(username); box.addView(currentPassword); box.addView(password); box.addView(permissionTitle)
        permissionOptions.forEach { (key, label) ->
            val cb = CheckBox(this).apply { text = label; isChecked = key in currentPermissions; setTextColor(Color.BLACK); setPadding(0, 0, 0, 0) }
            permissionChecks[key] = cb
            box.addView(cb)
        }
        forceBlackText(box)
        // A scroll container keeps the action buttons visible on shorter phone screens.
        val permissionScroll = ScrollView(this).apply {
            isFillViewport = false
            addView(box)
            // Reserve a permanent footer area for the dialog action buttons on small screens.
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                minOf(dp(430), (resources.displayMetrics.heightPixels - dp(300)).coerceAtLeast(dp(180))))
        }
        AlertDialog.Builder(this)
            .setTitle("ویرایش کاربر گلخانه")
            .setMessage("نام نمایشی قابل تغییر است. برای تغییر نام کاربری یا رمز، رمز فعلی را وارد کنید؛ رمز جدید را فقط در صورت تغییر پر کنید.")
            .setView(permissionScroll)
            .setPositiveButton("ذخیره تغییرات") { _, _ ->
                val newName = displayName.text.toString().trim()
                val newUsername = username.text.toString().trim()
                val oldPassword = (currentPassword.tag as EditText).text.toString()
                val newPassword = (password.tag as EditText).text.toString()
                if (newName.isBlank() || newUsername.isBlank()) {
                    info("نام و نام کاربری را وارد کنید.")
                    return@setPositiveButton
                }
                if (newPassword.isNotBlank() && newPassword.length < 6) {
                    info("رمز جدید باید حداقل ۶ کاراکتر باشد.")
                    return@setPositiveButton
                }
                if (!isNetworkAvailable()) { info("برای ویرایش حساب کاربر اینترنت لازم است."); return@setPositiveButton }
                val newEmail = firebaseEmail(newUsername, "STAFF")
                val needsAuthChange = newEmail != currentEmail || newPassword.isNotBlank()
                val fs = FirebaseFirestore.getInstance()
                fun updateProfile() {
                    val updates = hashMapOf<String, Any>(
                        "name" to newName,
                        "username" to newUsername,
                        "firebase_email" to newEmail,
                        "permissions" to permissionChecks.filterValues { it.isChecked }.keys.toList(),
                        "updated_at" to System.currentTimeMillis()
                    )
                    fs.collection("users").document(uid).update(updates as Map<String, Any>)
                        .addOnSuccessListener {
                            getSharedPreferences("golnegar_staff_permissions", Context.MODE_PRIVATE)
                                .edit().putStringSet(uid, permissionChecks.filterValues { it.isChecked }.keys.toSet()).apply()
                            val effectivePassword = if (newPassword.isNotBlank()) newPassword else oldPassword
                            secureCredentials.put("staff_firebase_$uid", effectivePassword)
                            secureCredentials.put("staff_email_$uid", newEmail)
                            secureCredentials.put("last_staff_username", newUsername)
                            secureCredentials.put("last_staff_password", effectivePassword)
                            info("اطلاعات کاربر «$newName» به‌روزرسانی شد.")
                            showGreenhouseUsers()
                        }
                        .addOnFailureListener { e -> info("ذخیره مشخصات کاربر انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}") }
                }
                if (!needsAuthChange) { updateProfile(); return@setPositiveButton }
                if (oldPassword.length < 6) {
                    info("برای تغییر نام کاربری یا رمز ورود، رمز فعلی کاربر را وارد کنید. رمز فعلی باید حداقل ۶ کاراکتر باشد.")
                    return@setPositiveButton
                }
                val appName = "golyarStaffEdit_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}"
                val app = runCatching { FirebaseApp.initializeApp(this, FirebaseApp.getInstance().options, appName) }.getOrNull()
                if (app == null) { info("اتصال امن برای ویرایش حساب ایجاد نشد."); return@setPositiveButton }
                val auth = FirebaseAuth.getInstance(app)
                auth.signInWithEmailAndPassword(currentEmail, oldPassword)
                    .addOnSuccessListener {
                        val user = auth.currentUser
                        fun finishAuthChange() { updateProfile(); auth.signOut() }
                        fun changePassword() {
                            if (newPassword.isBlank()) { finishAuthChange(); return }
                            user?.updatePassword(newPassword)
                                ?.addOnSuccessListener { finishAuthChange() }
                                ?.addOnFailureListener { e -> auth.signOut(); info("تغییر رمز Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}") }
                        }
                        if (newEmail == currentEmail) changePassword()
                        else user?.updateEmail(newEmail)
                            ?.addOnSuccessListener { changePassword() }
                            ?.addOnFailureListener { e -> auth.signOut(); info("تغییر نام کاربری Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}") }
                    }
                    .addOnFailureListener { e -> auth.signOut(); info("ورود امن برای ویرایش حساب انجام نشد: ${e.localizedMessage ?: e.message ?: "رمز فعلی یا اتصال صحیح نیست"}") }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun sellerAccountSettings(){
        val sid=db.currentSellerId()?:return;val s=db.sellers().firstOrNull{it.id==sid}?:return
        val box=formBox();val u=field("نام کاربری",s.username);val p=passwordField("رمز عبور",db.sellerPassword(sid));box.addView(u);box.addView(p)
        AlertDialog.Builder(this).setTitle("حساب فروشنده").setView(box).setPositiveButton("ذخیره"){_,_->
            val newU=u.text.toString().trim();val newP=(p.tag as EditText).text.toString();if(newU.isBlank()||newP.length<6){info("نام کاربری و رمز عبور را کامل وارد کنید.");return@setPositiveButton}
            val oldU=s.username;val oldP=db.sellerPassword(sid);val current=firebaseAuth.currentUser
            fun saveLocal(firebaseUser: FirebaseUser? = current){
                db.updateSellerCredentials(sid,newU,newP)
                secureCredentials.put("seller_firebase_$sid",newP)
                if (firebaseUser != null) {
                    FirebaseFirestore.getInstance().collection("users").document(firebaseUser.uid)
                        .set(mapOf(
                            "username" to newU,
                            "firebase_email" to firebaseUser.email.orEmpty(),
                            "seller_id" to sid,
                            "seller_remote_id" to db.sellerRemoteId(sid),
                            "role" to "SELLER",
                            "updated_at" to System.currentTimeMillis()
                        ), com.google.firebase.firestore.SetOptions.merge())
                        .addOnSuccessListener { info("اطلاعات حساب فروشنده تغییر کرد.") }
                        .addOnFailureListener { info("اطلاعات محلی تغییر کرد، اما پروفایل Firebase بروزرسانی نشد: ${it.localizedMessage ?: it.message ?: "خطای دسترسی"}") }
                } else info("اطلاعات حساب فروشنده تغییر کرد.")
            }
            if(current!=null&&current.email?.equals(firebaseEmail(oldU,"SELLER"),true)==true){
                val emailChanged=newU!=oldU;val passwordChanged=newP!=oldP
                fun afterEmail(){if(passwordChanged)current.updatePassword(newP).addOnSuccessListener{saveLocal()}.addOnFailureListener{info("رمز Firebase تغییر نکرد: ${it.localizedMessage ?: it.message ?: "نیاز به احراز مجدد دارد."}")}else saveLocal()}
                if(emailChanged)current.updateEmail(firebaseEmail(newU,"SELLER")).addOnSuccessListener{afterEmail()}.addOnFailureListener{info("نام کاربری Firebase تغییر نکرد: ${it.localizedMessage ?: it.message ?: "نیاز به احراز مجدد دارد."}")} else afterEmail()
            } else saveLocal()
        }.setNegativeButton("انصراف",null).show()
    }

    private fun showSellerFinancialArchives(sellerId: Long) {
        db.closeCompletedFinancialMonths()
        val seller = db.sellers().firstOrNull { it.id == sellerId }
        val root = base("آرشیو مالی من", "گزارش ماه‌های بسته‌شدهٔ همین فروشنده؛ سوابق قبلی فقط‌خواندنی هستند و بدهی تسویه‌نشده در حساب جاری باقی می‌ماند.")
        val archives = db.financialArchives()
        if (archives.isEmpty()) {
            root.addView(cardRow("هنوز ماه مالی بسته‌شده‌ای وجود ندارد. پس از شروع ماه جدید، ماه‌های گذشته در این بخش نمایش داده می‌شوند.", {}))
        } else {
            var shown = 0
            archives.forEach { (month, json) ->
                val data = try { JSONObject(json) } catch (_: Exception) { JSONObject() }
                fun rows(key: String): org.json.JSONArray {
                    val all = data.optJSONArray(key) ?: org.json.JSONArray()
                    val filtered = org.json.JSONArray()
                    for (i in 0 until all.length()) {
                        val row = all.optJSONObject(i) ?: continue
                        if (row.optLong("seller_id", -1L) == sellerId) filtered.put(row)
                    }
                    return filtered
                }
                val sales = rows("sales_rows")
                val deliveries = rows("delivery_rows")
                val returns = rows("return_rows")
                val payments = rows("payment_rows")
                if (sales.length() + deliveries.length() + returns.length() + payments.length() == 0) return@forEach
                shown++
                val salesTotal = (0 until sales.length()).sumOf { i -> sales.optJSONObject(i)?.let { it.optLong("qty") * it.optLong("price") } ?: 0L }
                val paid = (0 until payments.length()).sumOf { i -> payments.optJSONObject(i)?.optLong("amount") ?: 0L }
                var balance = 0L
                val balances = data.optJSONArray("seller_balances") ?: org.json.JSONArray()
                for (i in 0 until balances.length()) {
                    val b = balances.optJSONObject(i) ?: continue
                    if (b.optLong("seller_id", -1L) == sellerId) { balance = b.optLong("balance"); break }
                }
                val summary = "فروش ثبت‌شده: ${money(salesTotal)} ریال\nپرداخت به گلخانه: ${money(paid)} ریال\nمانده پایان ماه: ${money(balance)} ریال\nتعداد فروش‌ها: ${sales.length()} | تحویل‌ها: ${deliveries.length()} | برگشتی‌ها: ${returns.length()}"
                root.addView(listCard("ماه مالی $month", summary) { showSellerFinancialArchiveDetail(sellerId, month, json) })
            }
            if (shown == 0) root.addView(cardRow("برای این فروشنده در ماه‌های بسته‌شده سابقه‌ای ثبت نشده است.", {}))
        }
        root.addView(actionButton("بازگشت به تنظیمات فروشنده") { showSellerSettings() })
        setScreen(root)
    }

    private fun showSellerFinancialArchiveDetail(sellerId: Long, month: String, json: String) {
        val data = try { JSONObject(json) } catch (_: Exception) { JSONObject() }
        val seller = db.sellers().firstOrNull { it.id == sellerId }
        val root = base("آرشیو مالی $month", "${seller?.name ?: "فروشنده"} — گزارش بسته‌شده و فقط‌خواندنی")
        val sections = listOf("sales_rows" to "فروش‌های ثبت‌شده", "delivery_rows" to "تحویل گل", "return_rows" to "برگشتی‌ها", "payment_rows" to "پرداخت به گلخانه")
        sections.forEach { (key, title) ->
            val all = data.optJSONArray(key) ?: org.json.JSONArray()
            val selected = (0 until all.length()).mapNotNull { all.optJSONObject(it) }.filter { it.optLong("seller_id", -1L) == sellerId }
            root.addView(sectionTitle("$title (${selected.size})"))
            if (selected.isEmpty()) root.addView(cardRow("در این بخش رکوردی وجود ندارد.", {}))
            selected.forEach { row ->
                val flowerNames = data.optJSONObject("flower_names") ?: JSONObject()
                val flower = flowerNames.optString(row.opt("flower_id")?.toString().orEmpty(), "")
                val amount = when (key) {
                    "sales_rows" -> row.optLong("qty") * row.optLong("price")
                    "delivery_rows" -> row.optLong("qty") * row.optLong("price")
                    else -> row.optLong("amount")
                }
                val dateRaw = row.optLong("created_at", row.optLong("payment_date", 0L))
                val details = buildString {
                    if (flower.isNotBlank()) append("$flower\n")
                    if (row.has("qty")) append("تعداد: ${row.optLong("qty")} | ")
                    append("مبلغ: ${money(amount)} ریال")
                    if (dateRaw > 0) append("\nتاریخ: ${jalaliDate(dateRaw)}")
                    if (row.has("payment_type")) append("\nروش پرداخت: ${row.optString("payment_type")}")
                    if (row.has("reason") && row.optString("reason").isNotBlank()) append("\nعلت: ${row.optString("reason")}")
                }
                root.addView(cardRow(details, {}))
            }
        }
        root.addView(actionButton("بازگشت به آرشیو من") { showSellerFinancialArchives(sellerId) })
        setScreen(root)
    }

    private fun showFinancialArchives() {
        db.closeCompletedFinancialMonths()
        val root = base("آرشیو ماه‌های مالی", "ماه‌های گذشته به‌صورت فقط‌خواندنی نگهداری می‌شوند؛ بدهی تسویه‌نشده به دوره بعد منتقل می‌شود.")
        val archives = db.financialArchives()
        if (archives.isEmpty()) {
            root.addView(cardText("هنوز ماه مالی بسته‌شده‌ای وجود ندارد. در شروع ماه جدید، ماه‌های گذشته به‌صورت خودکار آرشیو می‌شوند."))
        } else {
            archives.forEach { (month, json) ->
                val data = try { JSONObject(json) } catch (_: Exception) { JSONObject() }
                val summary = "فروش: ${money(data.optLong("sales_total"))} ریال | پرداخت فروشندگان: ${money(data.optLong("payments_total"))} ریال\nهزینه‌های گلخانه: ${money(data.optLong("expenses_total"))} ریال | تعداد ثبت‌ها: ${data.optInt("records_count")}"
                root.addView(listCard("ماه مالی $month", summary) { showFinancialArchiveDetail(month, json) })
            }
        }
        root.addView(actionButton("بازگشت به گزارش‌ها") { showReportsHub() })
        addBottomNavigation(root, "گزارش‌ها")
        setScreen(root)
        syncMonthlyArchivesWithCloud()
    }

    private fun showFinancialArchiveDetail(month: String, json: String) {
        val data = try { JSONObject(json) } catch (_: Exception) { JSONObject() }
        val root = base("آرشیو مالی $month", "گزارش بسته‌شده؛ اطلاعات آرشیو در این صفحه قابل ویرایش نیست.")
        root.addView(cardText("خلاصه مالی ماه $month\nفروش ثبت‌شده: ${money(data.optLong("sales_total"))} ریال\nفروش متفرقه: ${money(data.optLong("misc_sales_total"))} ریال\nپرداخت فروشندگان: ${money(data.optLong("payments_total"))} ریال\nهزینه‌های گلخانه: ${money(data.optLong("expenses_total"))} ریال\nتعداد کل رکوردهای آرشیوشده: ${data.optInt("records_count")}\n\nمانده پایان ماه به تفکیک فروشنده:"))
        val balances = data.optJSONArray("seller_balances") ?: org.json.JSONArray()
        if (balances.length() == 0) root.addView(label("برای این ماه مانده فروشنده‌ای ثبت نشده است."))
        for (i in 0 until balances.length()) {
            val b = balances.optJSONObject(i) ?: continue
            root.addView(cardRow("${b.optString("name")}\nمانده بدهی به گلخانه: ${money(b.optLong("balance"))} ریال", {}))
        }
        val sellerNames = data.optJSONObject("seller_names") ?: JSONObject()
        val flowerNames = data.optJSONObject("flower_names") ?: JSONObject()
        val fieldNames = mapOf("seller_id" to "فروشنده", "flower_id" to "گل", "qty" to "تعداد", "price" to "قیمت واحد", "amount" to "مبلغ", "created_at" to "تاریخ ثبت", "payment_date" to "تاریخ پرداخت", "sale_date" to "تاریخ فروش", "reason" to "علت", "recipient" to "دریافت‌کننده", "expense_type" to "نوع هزینه", "payment_type" to "روش پرداخت", "description" to "توضیحات", "greenhouse_amount" to "سهم گلخانه", "seller_share_amount" to "سهم فروشنده", "seller_share_percent" to "درصد سهم فروشنده", "below_minimum" to "فروش زیر حداقل", "buyer_name" to "خریدار", "name" to "نام", "phone" to "تلفن", "share" to "درصد سهم", "base_price" to "قیمت پایه", "min_price" to "حداقل قیمت", "active" to "فعال")
        val sections = listOf(
            "sales_rows" to "فروش‌ها", "delivery_rows" to "تحویل‌ها", "return_rows" to "برگشتی‌ها",
            "payment_rows" to "پرداخت‌های فروشندگان", "misc_sale_rows" to "فروش متفرقه", "expense_rows" to "هزینه‌های گلخانه"
        )
        sections.forEach { (key, title) ->
            val rows = data.optJSONArray(key) ?: org.json.JSONArray()
            root.addView(sectionTitle("$title (${rows.length()})"))
            if (rows.length() == 0) root.addView(label("رکوردی در این بخش نیست."))
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val parts = mutableListOf<String>()
                val keys = row.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    if (k in setOf("id", "remote_id", "sync_state")) continue
                    val v = row.opt(k)
                    val shown = when {
                        k == "seller_id" -> sellerNames.optString(v.toString(), v.toString())
                        k == "flower_id" -> flowerNames.optString(v.toString(), v.toString())
                        k.endsWith("_at") || k.endsWith("_date") -> (v.toString().toLongOrNull()?.let { jalaliDate(it) } ?: v.toString())
                        k == "below_minimum" -> if (v.toString() == "1") "بله" else "خیر"
                        else -> v.toString()
                    }
                    parts.add("${fieldNames[k] ?: k}: $shown")
                }
                root.addView(cardRow(parts.joinToString("\n"), {}))
            }
        }
        root.addView(actionButton("بازگشت به آرشیو ماه‌ها") { showFinancialArchives() })
        addBottomNavigation(root, "گزارش‌ها")
        setScreen(root)
    }

    private fun syncMonthlyArchivesWithCloud() {
        if (db.isSellerMode() || !firebaseSignedIn() || !isNetworkAvailable() || FirebaseApp.getApps(this).isEmpty()) return
        val fs = FirebaseFirestore.getInstance()
        db.financialArchives().forEach { (month, json) ->
            fs.collection("financial_month_archives").document(month).set(mapOf(
                "month_key" to month, "snapshot_json" to json, "closed_at" to System.currentTimeMillis(),
                "updated_by" to (firebaseAuth.currentUser?.uid ?: "")
            ))
        }
        fs.collection("financial_month_archives").get().addOnSuccessListener { snap ->
            snap.documents.forEach { doc ->
                val key = doc.getString("month_key") ?: doc.id
                val json = doc.getString("snapshot_json") ?: return@forEach
                db.saveCloudFinancialArchive(key, json)
            }
        }
    }

    private fun showSettings(){
        screenBackStack.clear()
        restoringScreen = false
        val root=base("تنظیمات","تنظیمات بر اساس کاربرد مرتب شده‌اند")
        root.addView(listCard("🎨 ظاهر و رنگ‌بندی", "تم، رنگ‌ها و ظاهر برنامه") { showThemeSettings() })
        if (db.isSellerMode()) {
            root.addView(listCard("👤 حساب و امنیت", "نام کاربری و رمز عبور فروشنده") { showAdminSettingsCategory("حساب و امنیت", "اطلاعات ورود فروشنده", listOf(
                Triple("تغییر نام کاربری و رمز عبور", "ویرایش اطلاعات حساب", { sellerAccountSettings() })
            )) })
            root.addView(listCard("☁️ اتصال و همگام‌سازی", "بررسی اتصال و همگام‌سازی اطلاعات") { showAdminSettingsCategory("اتصال و همگام‌سازی", "وضعیت ارتباط با گلخانه", listOf(
                Triple("آزمایش اتصال", "بررسی اتصال به Firebase", { testDatabaseConnection() }),
                Triple("همگام‌سازی اکنون", "همگام‌سازی اطلاعات حساب", { syncWithFirebaseIfOnline(true) })
            )) })
            root.addView(listCard("📅 برنامه و آرشیو مالی", "آرشیو ماه‌های مالی بسته‌شده") { showAdminSettingsCategory("برنامه و آرشیو مالی", "آرشیو مالی فروشنده", listOf(
                Triple("آرشیو ماه‌های مالی من", "گزارش ماه‌های بسته‌شده", { db.currentSellerId()?.let { showSellerFinancialArchives(it) } })
            )) })
        } else if (db.isStaffMode()) {
            root.addView(listCard("👤 حساب و دسترسی", "حساب کاربر گلخانه و خروج امن") { showAdminSettingsCategory("حساب و دسترسی", "مدیریت نشست کاربر گلخانه", listOf(
                Triple("خروج از حساب", "پایان نشست این کاربر", { confirmGreenhouseLogout() })
            )) })
            root.addView(listCard("☁️ اتصال و همگام‌سازی", "همگام‌سازی و وضعیت اتصال") { showAdminSettingsCategory("اتصال و همگام‌سازی", "وضعیت ارتباط با گلخانه", listOf(
                Triple("همگام‌سازی اکنون", "همگام‌سازی اطلاعات", { syncWithFirebaseIfOnline(true) })
            )) })
            root.addView(listCard("📅 برنامه و تاریخ", "تاریخ کاری و نسخه برنامه") { showAdminSettingsCategory("برنامه و تاریخ", "تنظیمات برنامه", listOf(
                Triple("تاریخ کاری", "تغییر تاریخ کاری", { dateSettingsDialog() }),
                Triple("تغییر نسخه", "تغییر حالت برنامه", { showVersionSwitcher() })
            )) })
        } else {
            root.addView(listCard("🔐 حساب مدیر و امنیت", "نام کاربری و رمز عبور مدیر") { showAdminSettingsCategory("حساب مدیر و امنیت", "مدیریت اطلاعات ورود", listOf(
                Triple("تغییر نام کاربری و رمز عبور مدیر", "ویرایش اطلاعات ورود", { adminAccountDialog() })
            )) })
            root.addView(listCard("☁️ اتصال و همگام‌سازی", "وضعیت Firebase و ابزارهای اتصال") { showAdminSettingsCategory("اتصال و همگام‌سازی", "مدیریت ارتباط با پایگاه داده", listOf(
                Triple("آزمایش اتصال", "بررسی دسترسی به Firebase", { testDatabaseConnection() }),
                Triple("همگام‌سازی اکنون", "اجرای همگام‌سازی دستی در صورت نیاز", { syncWithFirebaseIfOnline(true) }),
                Triple("تنظیم مجدد اتصال Firebase", "بازبینی تنظیمات اتصال", { resetDatabaseConnectionDialog() })
            )) })
            root.addView(listCard("💰 امور مالی و صندوق", "صندوق تنخواه و سهم پیش‌فرض فروشنده") { showAdminSettingsCategory("امور مالی و صندوق", "تنظیمات پایه امور مالی", listOf(
                Triple("مدیریت صندوق تنخواه", "تعریف و مدیریت صندوق‌ها", { showPettyCashPeople() }),
                Triple("تنظیم سهم پیش‌فرض فروشنده", "مقدار پیش‌فرض برای فروشندگان جدید", { defaultSellerShareDialog() })
            )) })
            root.addView(listCard("👥 کاربران و پایگاه داده", "مدیریت کاربران گلخانه و دیتابیس") { showAdminSettingsCategory("کاربران و پایگاه داده", "مدیریت داده‌ها و کاربران", listOf(
                Triple("مدیریت کاربران گلخانه", "افزودن و مدیریت کاربران", { showGreenhouseUsers() }),
                Triple("مدیریت دیتابیس", "ابزارهای مدیریت اطلاعات", { showDatabaseManagement() })
            )) })
        }
        root.addView(listCard("🏠 صفحه اصلی", "مدیریت میان‌برها و آیکن‌های خانه") { showHomeIconSettings() })
        root.addView(listCard("📅 تاریخ و نسخه برنامه", "تاریخ کاری، تغییر نسخه و اطلاعات برنامه") {
            showAdminSettingsCategory("تاریخ و نسخه برنامه", "تنظیمات عمومی برنامه", listOf(
                Triple("تاریخ کاری", "تغییر تاریخ کاری برنامه", { dateSettingsDialog() }),
                Triple("تغییر نسخه", "انتخاب حالت مدیر، فروشنده یا کاربر گلخانه", { showVersionSwitcher() })
            ))
        })
        if (!db.isSellerMode()) root.addView(actionButton("🚪 خروج از حساب گلخانه") { confirmGreenhouseLogout() })
        root.addView(actionButton("↩️ بازگشت به خانه"){showHome()})
        setScreen(root)
    }

    private fun showAdminSettingsCategory(title: String, subtitle: String, items: List<Triple<String, String, () -> Unit>>) {
        val root = base(title, subtitle)
        if (title == "اتصال و همگام‌سازی") root.addView(cardText(if (firebaseSignedIn()) "🟢 اتصال Firebase برقرار است" else "🔴 نشست Firebase برقرار نیست"))
        items.forEach { (name, detail, action) -> root.addView(listCard(name, detail, action)) }
        root.addView(actionButton("↩️ بازگشت به تنظیمات") { showSettings() })
        setScreen(root)
    }

    private fun confirmGreenhouseLogout(){
        AlertDialog.Builder(this)
            .setTitle("خروج از حساب گلخانه")
            .setMessage("اطلاعات حساب حذف نمی‌شود؛ فقط حساب فعلی از این دستگاه خارج می‌شود. برای ورود بعدی می‌توانید دوباره حساب موردنظر را انتخاب کنید.")
            .setNegativeButton("انصراف",null)
            .setPositiveButton("خروج") { _, _ ->
                db.setMode("")
                firebaseAuth.signOut()
                showModeChooser()
            }.show()
    }

    private fun showVersionSwitcher(){
        val options=arrayOf("نسخه گلخانه / مدیر", "نسخه فروشنده", "کاربر گلخانه")
        val current=when { db.isSellerMode() -> 1; db.isStaffMode() -> 2; else -> 0 }
        AlertDialog.Builder(this)
            .setTitle("تغییر حساب یا نسخه")
            .setSingleChoiceItems(options,current){dialog,which->
                dialog.dismiss()
                when(which){
                    0 -> {
                        db.setMode("GREENHOUSE")
                        if (!firebaseAuth.currentUser?.email.equals(db.adminFirebaseEmail(), ignoreCase = true)) firebaseAuth.signOut()
                        restoreFirebaseSessionIfNeeded()
                        showHome()
                    }
                    1 -> showSellerChooser()
                    2 -> showStaffLogin()
                }
            }
            .setNegativeButton("انصراف",null)
            .show()
    }

    private fun showPriceWarnings(){
        if (!requireStaffPermission("warnings", "هشدارها")) return
        refreshAdminDataAndShow {
            val root=base("هشدارهای قیمت","فقط فروش‌هایی که واقعاً پایین‌تر از حداقل قیمت ثبت شده‌اند")
            val sid=if(db.isSellerMode()) db.currentSellerId() else null
            val rows=db.priceWarnings(sid).sortedByDescending{it.createdAt}
            val total=rows.sumOf{it.qty.toLong()*it.price}
            val shortage=rows.sumOf{(it.minPrice-it.price).coerceAtLeast(0L)*it.qty}

            root.addView(financialCard(listOf(
                "تعداد هشدار" to rows.size.toString(),
                "مبلغ فروش هشدارشده" to money(total),
                "مجموع اختلاف با حداقل" to money(shortage)
            ), if(rows.isEmpty()) "وضعیت: بدون هشدار" else "نیازمند بررسی") )

            if(rows.isEmpty()){
                root.addView(cardRow("✓ هیچ فروش زیر حداقل قیمت پیدا نشد") {
                    it.addView(label("در حال حاضر رکوردی که قیمت فروش آن از حداقل قیمت تعیین‌شده کمتر باشد وجود ندارد."))
                })
            } else {
                rows.forEachIndexed { index,r ->
                    val diff=(r.minPrice-r.price).coerceAtLeast(0L)
                    root.addView(cardRow("هشدار ${index+1}  •  ${r.date}") { box ->
                        box.addView(label("فروشنده: ${r.sellerName}"))
                        box.addView(label("گل: ${r.flowerName}   |   اندازه: ${r.size}"))
                        box.addView(label("تعداد: ${r.qty} دسته"))
                        box.addView(label("قیمت فروش: ${money(r.price)} ریال"))
                        box.addView(label("حداقل قیمت: ${money(r.minPrice)} ریال"))
                        box.addView(label("کمتر از حداقل: ${money(diff)} ریال برای هر دسته"))
                    })
                }
            }
            root.addView(actionButton("بازگشت به گزارش‌ها"){showReportsHub()})
            setScreen(root)
        }
    }

    private fun sellerBalanceText(id:Long):String { val b=db.greenhouseBalance(id); return "بدهی به گلخانه: ${money(maxOf(b,0L))} ریال\nطلب از گلخانه: ${money(maxOf(-b,0L))} ریال\nوضعیت: ${if(b==0L) "تسویه" else if(b>0) "بدهکار گلخانه" else "طلبکار از گلخانه"}" }

    private fun tableHeader(cells:List<String>):LinearLayout=tableRow(cells,true)
    private fun tableRow(cells:List<String>,header:Boolean=false):LinearLayout{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(4),dp(2),dp(4),dp(2));background=GradientDrawable().apply{cornerRadius=dp(8).toFloat();setColor(if(header) palette().primary else palette().surface);setStroke(dp(1),palette().border)};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).also{it.setMargins(0,dp(1),0,dp(1))}}
        cells.forEach{value->row.addView(TextView(this).apply{text=value;textSize=if(header)14f else 13.5f;setTextColor(if(header) Color.WHITE else palette().text);gravity=Gravity.CENTER;setTypeface(Typeface.DEFAULT,if(header)Typeface.BOLD else Typeface.NORMAL);setPadding(dp(4),0,dp(4),0);layoutParams=LinearLayout.LayoutParams(0,-1,1f)})};return row}
    private fun cardBackground() = themeCardBackground()
    private fun cardText(text:String):TextView=TextView(this).apply{textSize=16f;setTextColor(palette().text);setPadding(dp(4),dp(4),dp(4),dp(5));gravity=Gravity.CENTER_VERTICAL;includeFontPadding=true;setBackgroundColor(Color.TRANSPARENT);val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(1),0,dp(2));layoutParams=lp}
    private fun cardRow(text:String, build:(LinearLayout)->Unit):LinearLayout{val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(8),dp(6),dp(8),dp(6));background=cardBackground();val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(1),0,dp(2));layoutParams=lp};box.addView(TextView(this).apply{this.text=text;textSize=16f;setTextColor(palette().text);gravity=Gravity.CENTER_VERTICAL;includeFontPadding=true;setPadding(dp(8),dp(8),dp(8),dp(12))});build(box);return box}
    private fun sectionTitle(t:String)=TextView(this).apply {
        text=t
        textSize=17f
        typeface=Typeface.DEFAULT_BOLD
        setTextColor(palette().text)
        gravity=Gravity.RIGHT
        setPadding(dp(10),dp(10),dp(10),dp(10))
        includeFontPadding=true
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(mixColor(palette().primary, palette().surface, 0.86f), palette().surface)).apply {
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), mixColor(palette().primary, palette().surface, 0.62f))
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, dp(8), 0, dp(4))
        layoutParams = lp
    }

    private fun label(t:String)=TextView(this).apply{text=t;textSize=15f;setTextColor(palette().muted);setPadding(dp(6),dp(10),dp(6),dp(5));includeFontPadding=true}
    private fun formBox()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(12),dp(4));layoutDirection=View.LAYOUT_DIRECTION_RTL}
    private fun field(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;setTextColor(palette().text);setHintTextColor(Color.rgb(100,112,104));inputType=InputType.TYPE_CLASS_TEXT;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8))}
    private fun numberField(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;setTextColor(palette().text);setHintTextColor(Color.rgb(100,112,104));inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8))}
    private fun moneyField(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(if(value.isBlank()) "" else value.replace(",",""));textSize=17f;setTextColor(palette().text);setHintTextColor(Color.rgb(100,112,104));inputType=InputType.TYPE_CLASS_NUMBER;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8));addTextChangedListener(object:TextWatcher{private var busy=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(e:Editable?){if(busy)return;val raw=e?.toString()?.replace(",","")?.filter{it.isDigit()}?:"";if(raw.isEmpty())return;val n=raw.toLongOrNull()?:return;val formatted=nf.format(n);if(e.toString()!=formatted){busy=true;setText(formatted);setSelection(formatted.length);busy=false}}})}
    private fun parseMoney(e:EditText):Long=e.text.toString().replace(",","").filter{it.isDigit()}.toLongOrNull()?:0L
    private fun jalaliDateTime(ms:Long):String{
        val c=Calendar.getInstance().apply{timeInMillis=ms}
        return "${jalaliDate(ms)} ${"%02d:%02d".format(Locale.US,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE))}"
    }

    private fun jalaliDate(ms:Long):String{val c=Calendar.getInstance();c.timeInMillis=ms;return jalali(c)}
    private fun spinner(label:String,items:List<String>,height:Int)=Spinner(this).apply{
        adapter=object:ArrayAdapter<String>(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items){
            private fun style(v:View):View{
                val t=v as TextView
                t.textSize=17f
                t.setTextColor(palette().text)
                t.setBackgroundColor(Color.WHITE)
                t.gravity=Gravity.CENTER_VERTICAL or Gravity.RIGHT
                t.setPadding(dp(12),dp(8),dp(12),dp(8))
                return t
            }
            override fun getView(position:Int,convertView:View?,parent:ViewGroup):View=style(super.getView(position,convertView,parent))
            override fun getDropDownView(position:Int,convertView:View?,parent:ViewGroup):View=style(super.getDropDownView(position,convertView,parent))
        }
        contentDescription=label;layoutDirection=View.LAYOUT_DIRECTION_RTL;minimumHeight=dp(height)
    }
    private fun divider()=Space(this).apply{minimumHeight=dp(8)}
    private fun simpleListener(fn:()->Unit)=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){fn()}}
    private fun money(v:Long)=nf.format(v)
    private fun fmtPercent(v:Double)=String.format(Locale.US,"%.1f",v).trimEnd('0').trimEnd('.')
    private fun confirmDelete(msg:String,action:()->Unit){AlertDialog.Builder(this).setMessage(msg).setNegativeButton("انصراف",null).setPositiveButton("حذف"){_,_->action()}.show()}
    private fun info(msg:String,after:(()->Unit)?=null){AlertDialog.Builder(this).setMessage(msg).setPositiveButton("باشه"){_,_->after?.invoke()}.show()}

    data class Flower(val id:Long,val name:String,val size:String,val basePrice:Long,val minPrice:Long)
    data class Seller(val id:Long,val name:String,val phone:String,val username:String)
    data class SaleRow(val flowerName:String,val size:String,val qty:Int,val price:Long,val date:String,val synced:Boolean)
    data class PaymentRow(val amount:Long,val paymentType:String,val date:String)
    data class PaymentHistoryRow(val sellerName:String,val amount:Long,val paymentType:String,val date:String)
    data class PettyCashPerson(val id:Long,val name:String)
    data class MiscSaleRow(val buyerName:String,val flowerName:String,val size:String,val qty:Int,val total:Long,val paymentType:String,val pettyCashName:String?,val date:String)
    data class GreenhousePaymentRow(val expenseType:String,val amount:Long,val pettyCashName:String?,val description:String,val date:String)
    data class GreenhouseSaleRow(val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
    data class SellerSaleReportRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
    data class ReturnReportRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val reason:String,val date:String="")
    data class Dash(val deliveredToday:Int,val soldToday:Int,val returnedToday:Int,val salesToday:Long,val stock:Int,val greenhouseDue:Long)

    private fun todayJalali():String = jalali(Calendar.getInstance().apply{timeInMillis=db.appDate()})
    private fun jalali(c:Calendar):String {
        val gy=c.get(Calendar.YEAR); val gm=c.get(Calendar.MONTH)+1; val gd=c.get(Calendar.DAY_OF_MONTH)
        val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31)
        var days=355666 + 365*gy + ((gy+3)/4) - ((gy+99)/100) + ((gy+399)/400) + gd
        for(i in 1 until gm) days += gdm[i]
        if(gm>2 && isLeapGregorian(gy)) days++
        var jy=-1595 + 33*(days/12053); days%=12053
        jy += 4*(days/1461); days%=1461
        if(days>365){jy += (days-1)/365; days=(days-1)%365}
        val jm=if(days<186) 1 + days/31 else 7 + (days-186)/30
        val jd=1 + if(days<186) days%31 else (days-186)%30
        return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
    }
    private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)

    class GolYarDb(ctx:Context):SQLiteOpenHelper(ctx,"golyar.db",null,14){
        private val appContext = ctx.applicationContext
        override fun onCreate(db:SQLiteDatabase){
            db.execSQL("CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,size TEXT NOT NULL,base_price INTEGER NOT NULL,min_price INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,username TEXT NOT NULL DEFAULT '',password TEXT NOT NULL DEFAULT '',share REAL NOT NULL DEFAULT 20,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER NOT NULL DEFAULT 0,created_at INTEGER,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,created_at INTEGER,sync_state TEXT DEFAULT 'PENDING',remote_id TEXT UNIQUE,seller_share_percent REAL NOT NULL DEFAULT 20,seller_share_amount INTEGER NOT NULL DEFAULT 0,greenhouse_amount INTEGER NOT NULL DEFAULT 0,min_price_snapshot INTEGER NOT NULL DEFAULT 0,below_minimum INTEGER NOT NULL DEFAULT 0)")
            db.execSQL("CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,reason TEXT,created_at INTEGER,sync_state TEXT DEFAULT 'PENDING',remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,created_at INTEGER,payment_date INTEGER,payment_type TEXT NOT NULL DEFAULT 'نامشخص',sync_state TEXT DEFAULT 'PENDING',remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE petty_cash_people(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE misc_sales(id INTEGER PRIMARY KEY AUTOINCREMENT,buyer_name TEXT NOT NULL,flower_id INTEGER,qty INTEGER NOT NULL,price INTEGER NOT NULL,payment_type TEXT NOT NULL,petty_cash_id INTEGER,created_at INTEGER,sale_date INTEGER,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE greenhouse_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,recipient TEXT NOT NULL,amount INTEGER NOT NULL,payment_type TEXT NOT NULL,petty_cash_id INTEGER,description TEXT,created_at INTEGER,payment_date INTEGER,remote_id TEXT UNIQUE,expense_type TEXT NOT NULL DEFAULT 'متفرقه')")
            db.execSQL("CREATE TABLE IF NOT EXISTS expense_types(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
            db.execSQL("INSERT OR IGNORE INTO expense_types(name,active,remote_id) VALUES('متفرقه',1,'expense_type_misc')")
            db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT)")
            db.execSQL("CREATE TABLE financial_month_archives(month_key TEXT PRIMARY KEY,closed_at INTEGER NOT NULL,snapshot_json TEXT NOT NULL,source TEXT NOT NULL DEFAULT 'LOCAL')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('default_seller_share','20')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('admin_username','admin')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('admin_password','1234')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('app_date',?)",arrayOf(System.currentTimeMillis().toString()))
            db.execSQL("INSERT INTO settings(key,value) VALUES('admin_setup_done','0')")
        }
        override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){
            if(oldVersion<14) db.execSQL("CREATE TABLE IF NOT EXISTS financial_month_archives(month_key TEXT PRIMARY KEY,closed_at INTEGER NOT NULL,snapshot_json TEXT NOT NULL,source TEXT NOT NULL DEFAULT 'LOCAL')")
            if(oldVersion<2){db.execSQL("ALTER TABLE sellers ADD COLUMN share REAL NOT NULL DEFAULT 20");db.execSQL("ALTER TABLE sales ADD COLUMN sync_state TEXT DEFAULT 'PENDING'");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('default_seller_share','20')")}
            if(oldVersion<3){db.execSQL("ALTER TABLE payments ADD COLUMN payment_date INTEGER");db.execSQL("UPDATE payments SET payment_date=created_at WHERE payment_date IS NULL")}
            if(oldVersion<4){db.execSQL("ALTER TABLE deliveries ADD COLUMN price INTEGER NOT NULL DEFAULT 0");db.execSQL("UPDATE deliveries SET price=COALESCE((SELECT base_price FROM flowers WHERE flowers.id=deliveries.flower_id),0) WHERE price=0")}
            if(oldVersion<5){db.execSQL("ALTER TABLE flowers ADD COLUMN size TEXT NOT NULL DEFAULT 'استاندارد'");db.execSQL("ALTER TABLE sellers ADD COLUMN username TEXT NOT NULL DEFAULT ''");db.execSQL("ALTER TABLE sellers ADD COLUMN password TEXT NOT NULL DEFAULT ''");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_username','admin')");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_password','1234')");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('app_date',?)",arrayOf(System.currentTimeMillis().toString()))}
            if(oldVersion<6){db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_setup_done','0')")}
            if(oldVersion<7){
                db.execSQL("ALTER TABLE flowers ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE sellers ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE deliveries ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE sales ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE returns ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE payments ADD COLUMN remote_id TEXT")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_flowers_remote ON flowers(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_sellers_remote ON sellers(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_deliveries_remote ON deliveries(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_remote ON sales(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_returns_remote ON returns(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_remote ON payments(remote_id)")
            }
            if(oldVersion<9){
                db.execSQL("ALTER TABLE sellers ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
                db.execSQL("CREATE TABLE IF NOT EXISTS petty_cash_people(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
                db.execSQL("CREATE TABLE IF NOT EXISTS misc_sales(id INTEGER PRIMARY KEY AUTOINCREMENT,buyer_name TEXT NOT NULL,flower_id INTEGER,qty INTEGER NOT NULL,price INTEGER NOT NULL,payment_type TEXT NOT NULL,petty_cash_id INTEGER,created_at INTEGER,sale_date INTEGER,remote_id TEXT UNIQUE)")
                db.execSQL("CREATE TABLE IF NOT EXISTS greenhouse_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,recipient TEXT NOT NULL,amount INTEGER NOT NULL,payment_type TEXT NOT NULL,petty_cash_id INTEGER,description TEXT,created_at INTEGER,payment_date INTEGER,remote_id TEXT UNIQUE)")
            }
            if(oldVersion<10){
                db.execSQL("ALTER TABLE flowers ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
            }
            if(oldVersion<12){
                db.execSQL("ALTER TABLE returns ADD COLUMN sync_state TEXT DEFAULT 'SYNCED'")
                db.execSQL("ALTER TABLE payments ADD COLUMN sync_state TEXT DEFAULT 'SYNCED'")
            }
            if(oldVersion<13){
                db.execSQL("CREATE TABLE IF NOT EXISTS expense_types(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
                db.execSQL("INSERT OR IGNORE INTO expense_types(name,active,remote_id) VALUES('متفرقه',1,'expense_type_misc')")
                db.execSQL("ALTER TABLE greenhouse_payments ADD COLUMN expense_type TEXT NOT NULL DEFAULT 'متفرقه'")
            }
            if(oldVersion<11){
                db.execSQL("ALTER TABLE payments ADD COLUMN payment_type TEXT NOT NULL DEFAULT 'نامشخص'")
            }
            if(oldVersion<8){
                db.execSQL("ALTER TABLE sales ADD COLUMN seller_share_percent REAL NOT NULL DEFAULT 20")
                db.execSQL("ALTER TABLE sales ADD COLUMN seller_share_amount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE sales ADD COLUMN greenhouse_amount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE sales ADD COLUMN min_price_snapshot INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE sales ADD COLUMN below_minimum INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE sales SET seller_share_percent=COALESCE((SELECT share FROM sellers WHERE sellers.id=sales.seller_id),20), min_price_snapshot=COALESCE((SELECT min_price FROM flowers WHERE flowers.id=sales.flower_id),0), seller_share_amount=CAST((qty*price)*COALESCE((SELECT share FROM sellers WHERE sellers.id=sales.seller_id),20)/100 AS INTEGER), greenhouse_amount=(qty*price)-CAST((qty*price)*COALESCE((SELECT share FROM sellers WHERE sellers.id=sales.seller_id),20)/100 AS INTEGER), below_minimum=CASE WHEN price<COALESCE((SELECT min_price FROM flowers WHERE flowers.id=sales.flower_id),0) THEN 1 ELSE 0 END")
            }
        }
        private fun cv(vararg p:Pair<String,Any?>)=ContentValues().also{p.forEach{(k,v)->when(v){is String->it.put(k,v);is Int->it.put(k,v);is Long->it.put(k,v);is Double->it.put(k,v);null->it.putNull(k)}}}
        fun setMode(v:String?){val sp=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE);sp.edit().putString("mode",v).apply()}
        fun getMode():String?=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE).getString("mode",null)
        fun isSellerMode()=getMode()?.startsWith("SELLER:")==true
        fun isStaffMode()=getMode()?.startsWith("GREENHOUSE:STAFF:")==true
        fun currentSellerId():Long?=getMode()?.substringAfter("SELLER:")?.toLongOrNull()
        fun upsertFlower(id:Long?,name:String,size:String,base:Long,min:Long){if(id==null){val newId=writableDatabase.insert("flowers",null,cv("name" to name,"size" to size,"base_price" to base,"min_price" to min));if(newId>0)writableDatabase.update("flowers",cv("remote_id" to newId.toString()),"id=?",arrayOf(newId.toString()))}else{writableDatabase.update("flowers",cv("name" to name,"size" to size,"base_price" to base,"min_price" to min),"id=?",arrayOf(id.toString()));writableDatabase.execSQL("UPDATE flowers SET remote_id=COALESCE(remote_id,?) WHERE id=?",arrayOf(id.toString(),id))}}
        fun upsertSeller(id:Long?,name:String,phone:String,username:String,password:String,share:Double,remoteId:String?=null){
            if(id==null){
                val newId=writableDatabase.insert("sellers",null,cv("name" to name,"phone" to phone,"username" to username,"password" to password,"share" to share))
                if(newId>0) writableDatabase.update("sellers",cv("remote_id" to (remoteId?.takeIf{it.isNotBlank()} ?: newId.toString())),"id=?",arrayOf(newId.toString()))
            } else {
                writableDatabase.update("sellers",cv("name" to name,"phone" to phone,"username" to username,"password" to password,"share" to share),"id=?",arrayOf(id.toString()))
                if(!remoteId.isNullOrBlank()) writableDatabase.execSQL("UPDATE sellers SET remote_id=? WHERE id=?",arrayOf(remoteId,id))
                else writableDatabase.execSQL("UPDATE sellers SET remote_id=COALESCE(remote_id,?) WHERE id=?",arrayOf(id.toString(),id))
            }
        }
        fun sellerByRemoteId(remoteId:String):Seller?=readableDatabase.rawQuery("SELECT id,name,phone,username FROM sellers WHERE remote_id=?",arrayOf(remoteId)).use{c->if(c.moveToFirst())Seller(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:"") else null}
        fun flowers():List<Flower>{
            val l=mutableListOf<Flower>()
            q("SELECT id,name,size,base_price,min_price FROM flowers WHERE COALESCE(active,1)=1"){c->l.add(Flower(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getLong(4)))}
            val collator=Collator.getInstance(Locale("fa","IR")).apply{strength=Collator.PRIMARY}
            fun normalized(v:String)=v.trim().replace('ي','ی').replace('ك','ک').replace('ۀ','ه').replace(Regex("[ًٌٍَُِّْـ]"),"").lowercase(Locale("fa","IR"))
            l.sortWith(Comparator{a,b->
                val byName=collator.compare(normalized(a.name),normalized(b.name))
                if(byName!=0) byName else collator.compare(normalized(a.size),normalized(b.size))
            })
            return l
        }
        fun sellers():List<Seller>{val l=mutableListOf<Seller>();q("SELECT id,name,phone,username FROM sellers WHERE COALESCE(active,1)=1 ORDER BY name"){c->l.add(Seller(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:""))};return l}
        fun sellerById(id:Long):Seller?=readableDatabase.rawQuery("SELECT id,name,phone,username FROM sellers WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst())Seller(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:"") else null}
        fun sellerUsername(id:Long):String=readableDatabase.rawQuery("SELECT username FROM sellers WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getString(0)?:"" else ""}

        fun repairSellerActiveState(){
            val d=writableDatabase
            val activeCount=d.rawQuery("SELECT COUNT(*) FROM sellers WHERE COALESCE(active,1)=1",null).use{if(it.moveToFirst())it.getInt(0) else 0}
            val totalCount=d.rawQuery("SELECT COUNT(*) FROM sellers",null).use{if(it.moveToFirst())it.getInt(0) else 0}
            // Do not reactivate inactive sellers. They are deletion/disable tombstones.
            // Legacy records without the column already default to active=1.

        }

        fun ensureRemoteIds(){
            val db=writableDatabase
            db.execSQL("UPDATE flowers SET remote_id=COALESCE(NULLIF(remote_id,''),CAST(id AS TEXT)) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE sellers SET remote_id=COALESCE(NULLIF(remote_id,''),CAST(id AS TEXT)) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE deliveries SET remote_id=COALESCE(NULLIF(remote_id,''),'delivery_'||seller_id||'_'||id) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE sales SET remote_id=COALESCE(NULLIF(remote_id,''),'sale_'||seller_id||'_'||id) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE returns SET remote_id=COALESCE(NULLIF(remote_id,''),'return_'||seller_id||'_'||id) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE payments SET remote_id=COALESCE(NULLIF(remote_id,''),'payment_'||seller_id||'_'||id) WHERE remote_id IS NULL OR remote_id='' ")
        }

        fun sellerRemoteId(s:Long):String = readableDatabase.rawQuery("SELECT COALESCE(remote_id,'') FROM sellers WHERE id=?", arrayOf(s.toString())).use { if (it.moveToFirst()) it.getString(0) ?: "" else "" }
        fun flowerRemoteId(f:Long):String = readableDatabase.rawQuery("SELECT COALESCE(remote_id,'') FROM flowers WHERE id=?", arrayOf(f.toString())).use { if (it.moveToFirst()) it.getString(0) ?: "" else "" }

        fun markSynced(collection:String, remoteIds:List<String>){
            if(remoteIds.isEmpty()) return
            val table=when(collection){"sales"->"sales";"returns"->"returns";"payments"->"payments";else->return}
            val placeholders=remoteIds.joinToString(",") { "?" }
            writableDatabase.execSQL("UPDATE $table SET sync_state='SYNCED' WHERE remote_id IN ($placeholders)", remoteIds.toTypedArray())
        }

        fun firebaseCollections():Map<String,List<Map<String,Any?>>> {
            fun rows(sql:String, mapper:(android.database.Cursor)->Map<String,Any?>):List<Map<String,Any?>>{
                val out=mutableListOf<Map<String,Any?>>(); readableDatabase.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(mapper(c))}; return out
            }
            return linkedMapOf(
                "flowers" to rows("SELECT id,remote_id,name,size,base_price,min_price,active FROM flowers"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"name" to it.getString(2),"size" to it.getString(3),"base_price" to it.getLong(4),"min_price" to it.getLong(5),"active" to it.getInt(6))},
                "sellers" to rows("SELECT id,remote_id,name,phone,username,share,COALESCE(active,1) FROM sellers"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(0),"name" to it.getString(2),"phone" to (it.getString(3)?:""),"username" to it.getString(4),"firebase_email" to ((it.getString(4) ?: "").trim().lowercase(Locale.US).replace(Regex("[^a-z0-9._-]"), "_") + "@golyar.app"),"share" to it.getDouble(5),"active" to it.getInt(6))},
                "deliveries" to rows("SELECT d.id,d.remote_id,d.seller_id,d.flower_id,d.qty,d.price,d.created_at,s.remote_id,f.remote_id FROM deliveries d LEFT JOIN sellers s ON s.id=d.seller_id LEFT JOIN flowers f ON f.id=d.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(7)?:""),"flower_remote_id" to (it.getString(8)?:""),"qty" to it.getInt(4),"price" to it.getLong(5),"created_at" to it.getLong(6))},
                "sales" to rows("SELECT sa.id,sa.remote_id,sa.seller_id,sa.flower_id,sa.qty,sa.price,sa.created_at,sa.sync_state,sa.seller_share_percent,sa.seller_share_amount,sa.greenhouse_amount,sa.min_price_snapshot,sa.below_minimum,s.remote_id,f.remote_id FROM sales sa LEFT JOIN sellers s ON s.id=sa.seller_id LEFT JOIN flowers f ON f.id=sa.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(13)?:""),"flower_remote_id" to (it.getString(14)?:""),"qty" to it.getInt(4),"price" to it.getLong(5),"created_at" to it.getLong(6),"sync_state" to it.getString(7),"seller_share_percent" to it.getDouble(8),"seller_share_amount" to it.getLong(9),"greenhouse_amount" to it.getLong(10),"min_price_snapshot" to it.getLong(11),"below_minimum" to it.getInt(12))},
                "returns" to rows("SELECT r.id,r.remote_id,r.seller_id,r.flower_id,r.qty,r.reason,r.created_at,r.sync_state,s.remote_id,f.remote_id FROM returns r LEFT JOIN sellers s ON s.id=r.seller_id LEFT JOIN flowers f ON f.id=r.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(8)?:""),"flower_remote_id" to (it.getString(9)?:""),"qty" to it.getInt(4),"reason" to it.getString(5),"created_at" to it.getLong(6),"sync_state" to it.getString(7))},
                "payments" to rows("SELECT p.id,p.remote_id,p.seller_id,p.amount,p.created_at,p.payment_date,COALESCE(p.payment_type,'نامشخص'),p.sync_state,s.remote_id FROM payments p LEFT JOIN sellers s ON s.id=p.seller_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"seller_remote_id" to (it.getString(8)?:""),"amount" to it.getLong(3),"created_at" to it.getLong(4),"payment_date" to it.getLong(5),"payment_type" to (it.getString(6)?:"نامشخص"),"sync_state" to it.getString(7))},
                "misc_sales" to rows("SELECT m.id,m.remote_id,m.buyer_name,m.flower_id,m.qty,m.price,m.payment_type,m.petty_cash_id,m.created_at,m.sale_date,f.remote_id FROM misc_sales m LEFT JOIN flowers f ON f.id=m.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"buyer_name" to it.getString(2),"flower_id" to it.getLong(3),"flower_remote_id" to (it.getString(10)?:""),"qty" to it.getInt(4),"price" to it.getLong(5),"payment_type" to it.getString(6),"petty_cash_id" to it.getLong(7),"created_at" to it.getLong(8),"sale_date" to it.getLong(9))},
                "greenhouse_payments" to rows("SELECT id,remote_id,recipient,amount,payment_type,petty_cash_id,description,created_at,payment_date,COALESCE(expense_type,recipient,'متفرقه') FROM greenhouse_payments"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"recipient" to it.getString(2),"amount" to it.getLong(3),"payment_type" to it.getString(4),"petty_cash_id" to it.getLong(5),"description" to it.getString(6),"created_at" to it.getLong(7),"payment_date" to it.getLong(8),"expense_type" to it.getString(9))},
                "petty_cash_people" to rows("SELECT id,remote_id,name,active FROM petty_cash_people"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"name" to it.getString(2),"active" to it.getInt(3))},
                "expense_types" to rows("SELECT id,remote_id,name,active FROM expense_types"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"name" to it.getString(2),"active" to it.getInt(3))},
                "settings" to listOf(mapOf("id" to "app", "remote_id" to "app", "app_date" to appDate(), "default_seller_share" to getDefaultSellerShare(), "admin_username" to adminUsername(), "admin_firebase_email" to adminFirebaseEmail()))
            )
        }

        private fun q(sql:String,block:(android.database.Cursor)->Unit){readableDatabase.rawQuery(sql,null).use{while(it.moveToNext())block(it)}}
        fun delete(table:String,id:Long){ if(table=="flowers") writableDatabase.update("flowers",cv("active" to 0),"id=?",arrayOf(id.toString())) else writableDatabase.delete(table,"id=?",arrayOf(id.toString())) }
        fun addDelivery(s:Long,f:Long,q:Int,p:Long,createdAt:Long=appDate()){val id=writableDatabase.insert("deliveries",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to createdAt));if(id>0)writableDatabase.update("deliveries",cv("remote_id" to "delivery_${UUID.randomUUID()}"),"id=?",arrayOf(id.toString()))}
        fun addSale(s:Long,f:Long,q:Int,p:Long,saleDate:Long){
            val share=sellerShare(s); val total=q.toLong()*p; val sellerAmount=(total*share/100.0).toLong(); val greenhouseAmount=total-sellerAmount
            val min=readableDatabase.rawQuery("SELECT min_price FROM flowers WHERE id=?",arrayOf(f.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
            val below=if(min>0 && p<min)1 else 0
            val id=writableDatabase.insert("sales",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to saleDate,"sync_state" to "PENDING","seller_share_percent" to share,"seller_share_amount" to sellerAmount,"greenhouse_amount" to greenhouseAmount,"min_price_snapshot" to min,"below_minimum" to below))
            if(id>0)writableDatabase.update("sales",cv("remote_id" to "sale_${UUID.randomUUID()}"),"id=?",arrayOf(id.toString()))
        }
        fun addReturn(s:Long,f:Long,q:Int,r:String){val id=writableDatabase.insert("returns",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"reason" to r,"created_at" to appDate(),"sync_state" to "PENDING"));if(id>0)writableDatabase.update("returns",cv("remote_id" to "return_${UUID.randomUUID()}"),"id=?",arrayOf(id.toString()))}
        fun addPayment(s:Long,a:Long,paymentDate:Long,paymentType:String="نامشخص"){val id=writableDatabase.insert("payments",null,cv("seller_id" to s,"amount" to a,"created_at" to appDate(),"payment_date" to paymentDate,"payment_type" to paymentType,"sync_state" to "PENDING"));if(id>0)writableDatabase.update("payments",cv("remote_id" to "payment_${UUID.randomUUID()}"),"id=?",arrayOf(id.toString()))}
        fun sellerFlowerStock(s:Long,f:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=? AND flower_id=?),0)",arrayOf(s,f,s,f,s,f)).toInt()
        fun sellerStock(s:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=?),0)",arrayOf(s,s,s)).toInt()
        fun sellerShare(s:Long):Double=readableDatabase.rawQuery("SELECT share FROM sellers WHERE id=?",arrayOf(s.toString())).use{if(it.moveToFirst())it.getDouble(0) else getDefaultSellerShare()}
        fun getDefaultSellerShare():Double=setting("default_seller_share",20.0)
        fun setDefaultSellerShare(v:Double){writableDatabase.update("settings",cv("value" to v.toString()),"key='default_seller_share'",null)}
        fun sellerSalesTotal(s:Long):Long=one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE seller_id=?",arrayOf(s))
        fun sellerCommission(s:Long):Long=one("SELECT COALESCE(SUM(seller_share_amount),0) FROM sales WHERE seller_id=?",arrayOf(s))
        fun sellerNetDue(s:Long):Long=one("SELECT COALESCE(SUM(greenhouse_amount),0) FROM sales WHERE seller_id=?",arrayOf(s))
        fun paidToGreenhouse(s:Long):Long=one("SELECT COALESCE(SUM(amount),0) FROM payments WHERE seller_id=?",arrayOf(s))
        // Deliveries are consignments: they never create a seller debt.
        fun greenhouseCharges(s:Long):Long=sellerNetDue(s)
        fun returnCredits(s:Long):Long=0L
        fun greenhouseBalance(s:Long):Long=greenhouseCharges(s)-paidToGreenhouse(s)
        fun greenhouseDue(s:Long):Long=greenhouseBalance(s)
        fun payments(s:Long):List<PaymentRow>{val l=mutableListOf<PaymentRow>();readableDatabase.rawQuery("SELECT amount,COALESCE(payment_type,'نامشخص'),COALESCE(payment_date,created_at) FROM payments WHERE seller_id=? ORDER BY COALESCE(payment_date,created_at) DESC,id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(PaymentRow(c.getLong(0),c.getString(1),jalaliDate(c.getLong(2))))};return currentMonthRows(l){it.date}}
        fun allPayments():List<PaymentHistoryRow>{val l=mutableListOf<PaymentHistoryRow>();readableDatabase.rawQuery("SELECT s.name,p.amount,COALESCE(p.payment_type,'نامشخص'),COALESCE(p.payment_date,p.created_at) FROM payments p JOIN sellers s ON s.id=p.seller_id ORDER BY s.name,COALESCE(p.payment_date,p.created_at) DESC,p.id DESC",null).use{c->while(c.moveToNext())l.add(PaymentHistoryRow(c.getString(0),c.getLong(1),c.getString(2),jalaliDate(c.getLong(3))))};return currentMonthRows(l){it.date}}
        fun dashboard(sellerId:Long?):Dash{val condition=sellerId?.let { " AND seller_id=$it" } ?: "";val todayStart=dayStart();val todayEnd=todayStart+86400000;val deliveredToday=one("SELECT COALESCE(SUM(qty),0) FROM deliveries WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val soldToday=one("SELECT COALESCE(SUM(qty),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val returnedToday=one("SELECT COALESCE(SUM(qty),0) FROM returns WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val salesToday=if(sellerId!=null)one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)) else one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE created_at>=? AND created_at<?",arrayOf(todayStart,todayEnd));val stock=if(sellerId!=null)sellerStock(sellerId) else one("SELECT COALESCE(SUM(qty),0) FROM deliveries").toInt()-one("SELECT COALESCE(SUM(qty),0) FROM sales").toInt()-one("SELECT COALESCE(SUM(qty),0) FROM returns").toInt();val due=if(sellerId!=null)greenhouseBalance(sellerId) else sellers().sumOf{greenhouseBalance(it.id)};return Dash(deliveredToday,soldToday,returnedToday,salesToday,stock,due)}
        fun greenhouseSales(s:Long):List<GreenhouseSaleRow>{val l=mutableListOf<GreenhouseSaleRow>();readableDatabase.rawQuery("SELECT f.name,f.size,d.qty,d.price,d.qty*d.price,d.created_at FROM deliveries d JOIN flowers f ON f.id=d.flower_id WHERE d.seller_id=? ORDER BY d.created_at DESC,d.id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(GreenhouseSaleRow(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),c.getLong(4),jalaliDate(c.getLong(5))))};return currentMonthRows(l){it.date}}
        fun allReturns():List<ReturnReportRow>{val l=mutableListOf<ReturnReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,r.qty,r.reason,r.created_at FROM returns r JOIN sellers s ON s.id=r.seller_id JOIN flowers f ON f.id=r.flower_id ORDER BY r.created_at DESC,r.id DESC",null).use{c->while(c.moveToNext())l.add(ReturnReportRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(4)?:"",jalaliDate(c.getLong(5))))};return currentMonthRows(l){it.date}}
        fun returnsForSeller(s:Long):List<ReturnReportRow>{val l=mutableListOf<ReturnReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,r.qty,r.reason,r.created_at FROM returns r JOIN sellers s ON s.id=r.seller_id JOIN flowers f ON f.id=r.flower_id WHERE r.seller_id=? ORDER BY r.created_at DESC,r.id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(ReturnReportRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(4)?:"",jalaliDate(c.getLong(5))))};return currentMonthRows(l){it.date}}
        fun allSellerSalesReport():List<SellerSaleReportRow>{val l=mutableListOf<SellerSaleReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,sa.qty,sa.price,sa.qty*sa.price,sa.created_at FROM sales sa JOIN sellers s ON s.id=sa.seller_id JOIN flowers f ON f.id=sa.flower_id ORDER BY s.name,sa.created_at DESC,sa.id DESC",null).use{c->while(c.moveToNext())l.add(SellerSaleReportRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getLong(4),c.getLong(5),jalaliDate(c.getLong(6))))};return currentMonthRows(l){it.date}}
        fun sales(s:Long):List<SaleRow>{val l=mutableListOf<SaleRow>();readableDatabase.rawQuery("SELECT f.name,f.size,s.qty,s.price,s.created_at,s.sync_state FROM sales s JOIN flowers f ON f.id=s.flower_id WHERE s.seller_id=? ORDER BY s.created_at DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(SaleRow(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),jalaliDate(c.getLong(4)),c.getString(5)!="PENDING"))};return currentMonthRows(l){it.date}}
        data class DayTotals(val qty:Int,val total:Long,val avg:Long,val balance:Long)
        fun greenhouseSalesFiltered(sellerId:Long?,dateMs:Long):List<DetailedGreenhouseRow>{val c=Calendar.getInstance().apply{timeInMillis=dateMs;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)};val from=c.timeInMillis;val to=from+86400000;val where=if(sellerId==null)"" else " AND d.seller_id=$sellerId";val l=mutableListOf<DetailedGreenhouseRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,d.qty,d.price,d.qty*d.price,d.created_at FROM deliveries d JOIN sellers s ON s.id=d.seller_id JOIN flowers f ON f.id=d.flower_id WHERE d.created_at>=? AND d.created_at<?$where ORDER BY s.name,d.created_at DESC,d.id DESC",arrayOf(from.toString(),to.toString())).use{curs->while(curs.moveToNext())l.add(DetailedGreenhouseRow(curs.getString(0),curs.getString(1),curs.getString(2),curs.getInt(3),curs.getLong(4),curs.getLong(5),jalaliDate(curs.getLong(6))))};return l}
        fun greenhouseDayTotals(sellerId:Long?,dateMs:Long):DayTotals{val c=Calendar.getInstance().apply{timeInMillis=dateMs;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)};val from=c.timeInMillis;val to=from+86400000;val where=if(sellerId==null)"" else " AND d.seller_id=$sellerId";val q=one("SELECT COALESCE(SUM(qty),0) FROM deliveries d WHERE d.created_at>=? AND d.created_at<?$where",arrayOf(from,to));val total=one("SELECT COALESCE(SUM(qty*price),0) FROM deliveries d WHERE d.created_at>=? AND d.created_at<?$where",arrayOf(from,to));val avg=if(q==0L)0 else total/q;val bal=if(sellerId==null)sellers().sumOf{greenhouseBalance(it.id)} else greenhouseBalance(sellerId);return DayTotals(q.toInt(),total,avg,bal)}
        data class SellerSaleDetail(val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
        fun sellerSalesDetailed(s:Long):List<SellerSaleDetail>{val l=mutableListOf<SellerSaleDetail>();readableDatabase.rawQuery("SELECT COALESCE(f.name,'گل حذف‌شده'),COALESCE(f.size,''),sa.qty,sa.price,sa.qty*sa.price,sa.created_at FROM sales sa LEFT JOIN flowers f ON f.id=sa.flower_id WHERE sa.seller_id=? ORDER BY sa.created_at DESC,sa.id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(SellerSaleDetail(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),c.getLong(4),jalaliDate(c.getLong(5))))};return currentMonthRows(l){it.date}}
        data class DetailedGreenhouseRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)

        fun firebaseSnapshot():Map<String,Any>{
            ensureRemoteIds()
            fun rows(sql:String, mapper:(android.database.Cursor)->Map<String,Any?>):List<Map<String,Any?>>{val out=mutableListOf<Map<String,Any?>>();readableDatabase.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(mapper(c))};return out}
            return mapOf(
                "flowers" to rows("SELECT id,remote_id,name,size,base_price,min_price,active FROM flowers"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"name" to it.getString(2),"size" to it.getString(3),"base_price" to it.getLong(4),"min_price" to it.getLong(5),"active" to it.getInt(6))},
                "sellers" to rows("SELECT id,remote_id,name,phone,username,share,COALESCE(active,1) FROM sellers"){mapOf("id" to it.getLong(0),"seller_id" to it.getLong(0),"remote_id" to it.getString(1),"name" to it.getString(2),"phone" to (it.getString(3)?:""),"username" to it.getString(4),"share" to it.getDouble(5),"active" to it.getInt(6))},
                "deliveries" to rows("SELECT d.id,d.remote_id,d.seller_id,d.flower_id,d.qty,d.price,d.created_at,s.remote_id,f.remote_id FROM deliveries d LEFT JOIN sellers s ON s.id=d.seller_id LEFT JOIN flowers f ON f.id=d.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(7)?:("")),"flower_remote_id" to (it.getString(8)?:("")),"qty" to it.getInt(4),"price" to it.getLong(5),"created_at" to it.getLong(6))},
                "sales" to rows("SELECT sa.id,sa.remote_id,sa.seller_id,sa.flower_id,sa.qty,sa.price,sa.created_at,sa.sync_state,sa.seller_share_percent,sa.seller_share_amount,sa.greenhouse_amount,sa.min_price_snapshot,sa.below_minimum,s.remote_id,f.remote_id FROM sales sa LEFT JOIN sellers s ON s.id=sa.seller_id LEFT JOIN flowers f ON f.id=sa.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(13)?:("")),"flower_remote_id" to (it.getString(14)?:("")),"qty" to it.getInt(4),"price" to it.getLong(5),"created_at" to it.getLong(6),"sync_state" to it.getString(7),"seller_share_percent" to it.getDouble(8),"seller_share_amount" to it.getLong(9),"greenhouse_amount" to it.getLong(10),"min_price_snapshot" to it.getLong(11),"below_minimum" to it.getInt(12))},
                "returns" to rows("SELECT r.id,r.remote_id,r.seller_id,r.flower_id,r.qty,r.reason,r.created_at,r.sync_state,s.remote_id,f.remote_id FROM returns r LEFT JOIN sellers s ON s.id=r.seller_id LEFT JOIN flowers f ON f.id=r.flower_id WHERE r.sync_state='PENDING'"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(8)?:""),"flower_remote_id" to (it.getString(9)?:""),"qty" to it.getInt(4),"reason" to it.getString(5),"created_at" to it.getLong(6),"sync_state" to it.getString(7))},
                "payments" to rows("SELECT p.id,p.remote_id,p.seller_id,p.amount,p.created_at,p.payment_date,COALESCE(p.payment_type,'نامشخص'),p.sync_state,s.remote_id FROM payments p LEFT JOIN sellers s ON s.id=p.seller_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"seller_remote_id" to (it.getString(8)?:""),"amount" to it.getLong(3),"created_at" to it.getLong(4),"payment_date" to it.getLong(5),"payment_type" to (it.getString(6)?:"نامشخص"),"sync_state" to it.getString(7))}
            )
        }

        fun importFirebaseRecord(collection:String,docId:String,m:Map<String,Any>) {
            fun str(k:String)=m[k]?.toString() ?: ""
            fun lng(k:String)=when(val v=m[k]){is Number->v.toLong();else->v?.toString()?.toLongOrNull()?:0L}
            fun int(k:String)=if(m.containsKey(k)) lng(k).toInt() else 1
            val remoteId=str("remote_id").ifBlank { docId }

            fun findSeller():Long {
                val stable=str("seller_remote_id")
                if (stable.isNotBlank()) {
                    val byRemote=readableDatabase.rawQuery("SELECT id FROM sellers WHERE remote_id=?",arrayOf(stable)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byRemote>0) return byRemote
                }
                val legacy=lng("seller_id")
                if(legacy>0){
                    val byId=readableDatabase.rawQuery("SELECT id FROM sellers WHERE id=?",arrayOf(legacy.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byId>0) return byId
                    val byRemote=readableDatabase.rawQuery("SELECT id FROM sellers WHERE remote_id=?",arrayOf(legacy.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byRemote>0) return byRemote
                }
                return 0L
            }
            fun findFlower():Long {
                val stable=str("flower_remote_id")
                if (stable.isNotBlank()) {
                    val byRemote=readableDatabase.rawQuery("SELECT id FROM flowers WHERE remote_id=?",arrayOf(stable)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byRemote>0) return byRemote
                }
                val legacy=lng("flower_id")
                if(legacy>0){
                    val byId=readableDatabase.rawQuery("SELECT id FROM flowers WHERE id=?",arrayOf(legacy.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byId>0) return byId
                    val byRemote=readableDatabase.rawQuery("SELECT id FROM flowers WHERE remote_id=?",arrayOf(legacy.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byRemote>0) return byRemote
                }
                val name=str("flower_name"); val size=str("flower_size")
                if(name.isNotBlank() && size.isNotBlank()) {
                    return readableDatabase.rawQuery("SELECT id FROM flowers WHERE name=? AND size=? ORDER BY id LIMIT 1",arrayOf(name,size)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                }
                return 0L
            }

            when(collection){
                "flowers" -> {
                    val localId=lng("id")
                    val remoteActive=(if(m.containsKey("active")) int("active") else 1).coerceIn(0,1)
                    var existing=readableDatabase.rawQuery("SELECT id FROM flowers WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(existing==0L) existing=readableDatabase.rawQuery("SELECT id FROM flowers WHERE name=? AND size=? ORDER BY id LIMIT 1",arrayOf(str("name"),str("size"))).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(existing>0){
                        val localActive=readableDatabase.rawQuery("SELECT COALESCE(active,1) FROM flowers WHERE id=?",arrayOf(existing.toString())).use{if(it.moveToFirst())it.getInt(0) else 1}
                        val finalActive=if(localActive==0) 0 else remoteActive
                        val values=cv("name" to str("name"),"size" to str("size"),"base_price" to lng("base_price"),"min_price" to lng("min_price"),"active" to finalActive,"remote_id" to remoteId)
                        writableDatabase.update("flowers",values,"id=?",arrayOf(existing.toString()))
                    } else {
                        val idExists=localId>0 && readableDatabase.rawQuery("SELECT 1 FROM flowers WHERE id=?",arrayOf(localId.toString())).use{it.moveToFirst()}
                        writableDatabase.insert("flowers",null,if(localId>0 && !idExists) cv("id" to localId,"name" to str("name"),"size" to str("size"),"base_price" to lng("base_price"),"min_price" to lng("min_price"),"active" to remoteActive,"remote_id" to remoteId) else cv("name" to str("name"),"size" to str("size"),"base_price" to lng("base_price"),"min_price" to lng("min_price"),"active" to remoteActive,"remote_id" to remoteId))
                    }
                }
                "sellers" -> {
                    val share=(m["share"] as? Number)?.toDouble() ?: 20.0
                    val active=(if(m.containsKey("active")) int("active") else 1).coerceIn(0,1)
                    var existing=readableDatabase.rawQuery("SELECT id FROM sellers WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(existing==0L && str("username").isNotBlank()) existing=readableDatabase.rawQuery("SELECT id FROM sellers WHERE username=? ORDER BY id LIMIT 1",arrayOf(str("username"))).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(existing>0){
                        // A locally deleted/disabled seller is a tombstone. Never let an
                        // older Firebase document recreate it as active.
                        val localActive=readableDatabase.rawQuery("SELECT COALESCE(active,1) FROM sellers WHERE id=?",arrayOf(existing.toString())).use{if(it.moveToFirst())it.getInt(0) else 1}
                        val finalActive=if(localActive==0) 0 else active
                        val values=cv("name" to str("name"),"phone" to str("phone"),"username" to str("username"),"share" to share,"active" to finalActive,"remote_id" to remoteId)
                        writableDatabase.update("sellers",values,"id=?",arrayOf(existing.toString()))
                    } else {
                        val localId=lng("id"); val idExists=localId>0 && readableDatabase.rawQuery("SELECT 1 FROM sellers WHERE id=?",arrayOf(localId.toString())).use{it.moveToFirst()}
                        writableDatabase.insert("sellers",null,if(localId>0 && !idExists) cv("id" to localId,"name" to str("name"),"phone" to str("phone"),"username" to str("username"),"password" to "","share" to share,"active" to active,"remote_id" to remoteId) else cv("name" to str("name"),"phone" to str("phone"),"username" to str("username"),"password" to "","share" to share,"active" to active,"remote_id" to remoteId))
                    }
                }
                "deliveries","sales","returns","payments" -> {
                    val table=collection
                    var existing=readableDatabase.rawQuery("SELECT id FROM $table WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    val sellerId=findSeller()
                    val flowerId=if(collection=="payments")0L else findFlower()
                    if(sellerId<=0L || (collection!="payments" && flowerId<=0L)) return
                    val values=when(collection){
                        "deliveries"->cv("seller_id" to sellerId,"flower_id" to flowerId,"qty" to int("qty"),"price" to lng("price"),"created_at" to lng("created_at"),"remote_id" to remoteId)
                        "sales"->cv("seller_id" to sellerId,"flower_id" to flowerId,"qty" to int("qty"),"price" to lng("price"),"created_at" to lng("created_at"),"sync_state" to "SYNCED","seller_share_percent" to ((m["seller_share_percent"] as? Number)?.toDouble() ?: 20.0),"seller_share_amount" to lng("seller_share_amount"),"greenhouse_amount" to lng("greenhouse_amount"),"min_price_snapshot" to lng("min_price_snapshot"),"below_minimum" to int("below_minimum"),"remote_id" to remoteId)
                        "returns"->cv("seller_id" to sellerId,"flower_id" to flowerId,"qty" to int("qty"),"reason" to str("reason"),"created_at" to lng("created_at"),"sync_state" to "SYNCED","remote_id" to remoteId)
                        else->cv("seller_id" to sellerId,"amount" to lng("amount"),"created_at" to lng("created_at"),"payment_date" to lng("payment_date"),"payment_type" to str("payment_type").ifBlank { "نامشخص" },"sync_state" to "SYNCED","remote_id" to remoteId)
                    }
                    if(existing>0) writableDatabase.update(table,values,"id=?",arrayOf(existing.toString())) else writableDatabase.insert(table,null,values)
                }
                "petty_cash_people" -> {
                    val existing=readableDatabase.rawQuery("SELECT id FROM petty_cash_people WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    val values=cv("name" to str("name"),"active" to int("active"),"remote_id" to remoteId)
                    if(existing>0) writableDatabase.update("petty_cash_people",values,"id=?",arrayOf(existing.toString())) else writableDatabase.insert("petty_cash_people",null,values)
                }
                "misc_sales" -> {
                    val existing=readableDatabase.rawQuery("SELECT id FROM misc_sales WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}; val flowerId=findFlower(); val values=cv("buyer_name" to str("buyer_name"),"flower_id" to flowerId,"qty" to int("qty"),"price" to lng("price"),"payment_type" to str("payment_type"),"petty_cash_id" to lng("petty_cash_id"),"created_at" to lng("created_at"),"sale_date" to lng("sale_date"),"remote_id" to remoteId); if(existing>0) writableDatabase.update("misc_sales",values,"id=?",arrayOf(existing.toString())) else writableDatabase.insert("misc_sales",null,values)
                }
                "greenhouse_payments" -> {
                    val existing=readableDatabase.rawQuery("SELECT id FROM greenhouse_payments WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}; val values=cv("recipient" to str("recipient"),"amount" to lng("amount"),"payment_type" to str("payment_type").ifBlank { "تنخواه" },"petty_cash_id" to lng("petty_cash_id"),"description" to str("description"),"created_at" to lng("created_at"),"payment_date" to lng("payment_date"),"remote_id" to remoteId,"expense_type" to str("expense_type").ifBlank { str("recipient").ifBlank { "متفرقه" } }); if(existing>0) writableDatabase.update("greenhouse_payments",values,"id=?",arrayOf(existing.toString())) else writableDatabase.insert("greenhouse_payments",null,values)
                }
                "expense_types" -> {
                    val existing=readableDatabase.rawQuery("SELECT id FROM expense_types WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    val byName=readableDatabase.rawQuery("SELECT id FROM expense_types WHERE name=?",arrayOf(str("name"))).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    val id=if(existing>0) existing else byName
                    val values=cv("name" to str("name"),"active" to int("active"),"remote_id" to remoteId)
                    if(id>0) writableDatabase.update("expense_types",values,"id=?",arrayOf(id.toString())) else writableDatabase.insert("expense_types",null,values)
                }
                "settings" -> {
                    if (str("id") == "app" || remoteId == "app") {
                        if (m.containsKey("app_date")) setAppDate(lng("app_date"))
                        if (m.containsKey("default_seller_share")) setDefaultSellerShare((m["default_seller_share"] as? Number)?.toDouble() ?: getDefaultSellerShare())
                    }
                }
            }
        }

        fun flowerDelivered(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM deliveries WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun flowerSold(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM sales WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun flowerReturned(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM returns WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun deleteSeller(id:Long){
            // Soft-delete every seller. This preserves history and prevents the next Firebase
            // pull from recreating a physically deleted seller.
            writableDatabase.update("sellers",cv("active" to 0),"id=?",arrayOf(id.toString()))
        }
        fun pettyCashPeople():List<PettyCashPerson>{val l=mutableListOf<PettyCashPerson>();readableDatabase.rawQuery("SELECT id,name FROM petty_cash_people WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())l.add(PettyCashPerson(c.getLong(0),c.getString(1)))};return l}
        // Incoming cash is cash miscellaneous sales assigned to this fund; outgoing is greenhouse expenses/payments assigned to it.
        // Triple = incoming amount, outgoing amount, number of related ledger rows.
        fun pettyCashStats(id:Long):Triple<Long,Long,Int>{
            val incoming=one("SELECT COALESCE(SUM(qty*price),0) FROM misc_sales WHERE petty_cash_id=? AND payment_type='نقدی'",arrayOf(id.toString()))
            val outgoing=one("SELECT COALESCE(SUM(amount),0) FROM greenhouse_payments WHERE petty_cash_id=?",arrayOf(id.toString()))
            val count=one("SELECT (SELECT COUNT(*) FROM misc_sales WHERE petty_cash_id=? AND payment_type='نقدی') + (SELECT COUNT(*) FROM greenhouse_payments WHERE petty_cash_id=?)",arrayOf(id.toString(),id.toString())).toInt()
            return Triple(incoming,outgoing,count)
        }
        fun archivePettyCashPerson(id:Long){writableDatabase.update("petty_cash_people",cv("active" to 0),"id=? AND active=1",arrayOf(id.toString()))}
        fun addPettyCashPerson(name:String){writableDatabase.insert("petty_cash_people",null,cv("name" to name.trim(),"active" to 1,"remote_id" to "petty_${UUID.randomUUID()}"))}
        fun updatePettyCashPerson(id:Long,name:String){writableDatabase.update("petty_cash_people",cv("name" to name.trim()),"id=? AND active=1",arrayOf(id.toString()))}
        fun addMiscSale(buyer:String,flowerId:Long,qty:Int,price:Long,paymentType:String,pettyCashId:Long?,saleDate:Long):Boolean{
            return try {
                writableDatabase.insert("misc_sales",null,cv("buyer_name" to buyer,"flower_id" to flowerId,"qty" to qty,"price" to price,"payment_type" to paymentType,"petty_cash_id" to pettyCashId,"created_at" to appDate(),"sale_date" to saleDate,"remote_id" to "misc_${UUID.randomUUID()}") ) > 0L
            } catch (_:Exception) { false }
        }
        fun miscSales():List<MiscSaleRow>{val l=mutableListOf<MiscSaleRow>();readableDatabase.rawQuery("SELECT m.buyer_name,COALESCE(f.name,'گل حذف‌شده'),COALESCE(f.size,''),m.qty,m.qty*m.price,m.payment_type,p.name,COALESCE(m.sale_date,m.created_at) FROM misc_sales m LEFT JOIN flowers f ON f.id=m.flower_id LEFT JOIN petty_cash_people p ON p.id=m.petty_cash_id ORDER BY COALESCE(m.sale_date,m.created_at) DESC,m.id DESC",null).use{c->while(c.moveToNext())l.add(MiscSaleRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getLong(4),c.getString(5),c.getString(6),jalaliDate(c.getLong(7))))};return currentMonthRows(l){it.date}}
        fun expenseTypes():List<String>{val l=mutableListOf<String>();readableDatabase.rawQuery("SELECT name FROM expense_types WHERE active=1 ORDER BY CASE WHEN name='متفرقه' THEN 1 ELSE 0 END,name",null).use{c->while(c.moveToNext())l.add(c.getString(0))};return l}
        fun addExpenseType(name:String):Boolean{return try{val id=writableDatabase.insert("expense_types",null,cv("name" to name.trim(),"active" to 1,"remote_id" to "expense_type_${UUID.randomUUID()}"));id>0}catch(_:Exception){false}}
        fun updateExpenseType(old:String,newName:String):Boolean{return try{val rows=writableDatabase.update("expense_types",cv("name" to newName.trim()),"name=?",arrayOf(old));rows>0}catch(_:Exception){false}}
        fun addGreenhouseExpense(expenseType:String,amount:Long,pettyCashId:Long,description:String,paymentDate:Long):Boolean{
            return try {
                writableDatabase.insert("greenhouse_payments",null,cv("recipient" to expenseType,"amount" to amount,"payment_type" to "تنخواه","petty_cash_id" to pettyCashId,"description" to description,"created_at" to appDate(),"payment_date" to paymentDate,"remote_id" to "ghpay_${UUID.randomUUID()}","expense_type" to expenseType)) > 0L
            } catch (_:Exception) { false }
        }
        fun greenhousePayments():List<GreenhousePaymentRow>{val l=mutableListOf<GreenhousePaymentRow>();readableDatabase.rawQuery("SELECT COALESCE(g.expense_type,g.recipient,'متفرقه'),g.amount,p.name,COALESCE(g.description,''),COALESCE(g.payment_date,g.created_at) FROM greenhouse_payments g LEFT JOIN petty_cash_people p ON p.id=g.petty_cash_id ORDER BY COALESCE(g.payment_date,g.created_at) DESC,g.id DESC",null).use{c->while(c.moveToNext())l.add(GreenhousePaymentRow(c.getString(0),c.getLong(1),c.getString(2),c.getString(3),jalaliDate(c.getLong(4))))};return currentMonthRows(l){it.date}}
        fun sellerPassword(id:Long):String=readableDatabase.rawQuery("SELECT password FROM sellers WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getString(0)?:"" else ""}
        fun verifySellerLogin(id:Long,u:String,p:String):Boolean=readableDatabase.rawQuery("SELECT 1 FROM sellers WHERE id=? AND username=? AND password=?",arrayOf(id.toString(),u,p)).use{it.moveToFirst()}
        fun verifySellerLogin(u:String,p:String):Long?=readableDatabase.rawQuery("SELECT id FROM sellers WHERE username=? AND password=? AND username<>'' AND password<>'' AND COALESCE(active,1)=1 ORDER BY id LIMIT 1",arrayOf(u,p)).use{if(it.moveToFirst())it.getLong(0) else null}
        fun adminUsername():String=settingText("admin_username","admin")
        fun exportBackupJson():String{
            val root=JSONObject()
            root.put("format","GolNegarBackup")
            root.put("version",1)
            root.put("app_version",BuildConfig.VERSION_NAME)
            root.put("exported_at",System.currentTimeMillis())
            val tables=JSONArray()
            val tableNames=listOf("flowers","sellers","deliveries","sales","returns","payments","petty_cash_people","misc_sales","greenhouse_payments","expense_types","settings")
            for(name in tableNames){
                val table=JSONObject().put("name",name)
                val rows=JSONArray()
                readableDatabase.rawQuery("SELECT * FROM $name",null).use{c->
                    while(c.moveToNext()){
                        val row=JSONObject()
                        for(i in 0 until c.columnCount){
                            val key=c.getColumnName(i)
                            if(c.isNull(i)) row.put(key,JSONObject.NULL) else when(c.getType(i)){
                                android.database.Cursor.FIELD_TYPE_INTEGER -> row.put(key,c.getLong(i))
                                android.database.Cursor.FIELD_TYPE_FLOAT -> row.put(key,c.getDouble(i))
                                android.database.Cursor.FIELD_TYPE_STRING -> row.put(key,c.getString(i))
                                else -> row.put(key,c.getString(i))
                            }
                        }
                        rows.put(row)
                    }
                }
                table.put("rows",rows);tables.put(table)
            }
            root.put("tables",tables)
            return root.toString(2)
        }

        fun restoreBackupJson(text:String){
            val root=JSONObject(text)
            if(root.optString("format")!="GolNegarBackup") throw IllegalArgumentException("فرمت فایل پشتیبان گل نگار نیست.")
            val tables=root.optJSONArray("tables") ?: throw IllegalArgumentException("فایل پشتیبان ناقص است.")
            val allowed=setOf("flowers","sellers","deliveries","sales","returns","payments","petty_cash_people","misc_sales","greenhouse_payments","expense_types","settings")
            writableDatabase.beginTransaction()
            try{
                for(name in listOf("sales","returns","payments","deliveries","misc_sales","greenhouse_payments","expense_types","petty_cash_people","sellers","flowers","settings")) writableDatabase.delete(name,null,null)
                for(i in 0 until tables.length()){
                    val table=tables.getJSONObject(i);val name=table.getString("name");if(!allowed.contains(name))continue
                    val rows=table.optJSONArray("rows") ?: continue
                    for(j in 0 until rows.length()){
                        val obj=rows.getJSONObject(j);val values=ContentValues()
                        obj.keys().forEach{key->
                            val v=obj.get(key)
                            when(v){
                                JSONObject.NULL -> values.putNull(key)
                                is Boolean -> values.put(key,v)
                                is Int -> values.put(key,v)
                                is Long -> values.put(key,v)
                                is Double -> values.put(key,v)
                                is Number -> values.put(key,v.toString().toDouble())
                                else -> values.put(key,v.toString())
                            }
                        }
                        writableDatabase.insertOrThrow(name,null,values)
                    }
                }
                writableDatabase.setTransactionSuccessful()
            }finally{writableDatabase.endTransaction()}
        }

        fun clearOperationalData(){
            writableDatabase.beginTransaction()
            try{
                listOf("sales","returns","payments","deliveries","misc_sales","greenhouse_payments","expense_types","petty_cash_people","sellers","flowers").forEach{writableDatabase.delete(it,null,null)}
                writableDatabase.setTransactionSuccessful()
            }finally{writableDatabase.endTransaction()}
        }

        fun clearLastSyncMetadata(){
            setSettingText("last_firebase_sync", "")
            setSettingText("last_sync_error", "")
        }

        fun resetPendingSyncStates(){
            writableDatabase.execSQL("UPDATE sales SET sync_state='PENDING' WHERE remote_id IS NULL OR remote_id=''")
            writableDatabase.execSQL("UPDATE returns SET sync_state='PENDING' WHERE remote_id IS NULL OR remote_id=''")
            writableDatabase.execSQL("UPDATE payments SET sync_state='PENDING' WHERE remote_id IS NULL OR remote_id=''")
        }

        private fun monthKey(ms: Long): String = jalaliDate(ms).substring(0, 7)
        private fun currentMonthPrefix(): String = monthKey(System.currentTimeMillis())
        private fun <T> currentMonthRows(rows: List<T>, dateOf: (T) -> String): List<T> = rows.filter { dateOf(it).startsWith(currentMonthPrefix()) }

        fun closeCompletedFinancialMonths(): List<String> {
            val current = monthKey(System.currentTimeMillis())
            val keys = sortedSetOf<String>()
            val sources = listOf(
                "sales" to "created_at", "deliveries" to "created_at", "returns" to "created_at",
                "payments" to "COALESCE(payment_date,created_at)", "misc_sales" to "COALESCE(sale_date,created_at)",
                "greenhouse_payments" to "COALESCE(payment_date,created_at)"
            )
            sources.forEach { (table, dateExpr) ->
                readableDatabase.rawQuery("SELECT $dateExpr FROM $table WHERE $dateExpr IS NOT NULL", null).use { c ->
                    while (c.moveToNext()) {
                        val ts = c.getLong(0)
                        if (ts > 0) monthKey(ts).takeIf { it < current }?.let { keys.add(it) }
                    }
                }
            }
            val created = mutableListOf<String>()
            keys.forEach { key -> if (archiveMonth(key)) created.add(key) }
            setSettingText("last_financial_month", current)
            return created
        }

        private fun archiveMonth(month: String): Boolean {
            if (readableDatabase.rawQuery("SELECT 1 FROM financial_month_archives WHERE month_key=?", arrayOf(month)).use { it.moveToFirst() }) return false
            val snapshot = org.json.JSONObject()
            val salesRows = rowsForMonth("sales", "created_at", month)
            val deliveryRows = rowsForMonth("deliveries", "created_at", month)
            val returnRows = rowsForMonth("returns", "created_at", month)
            val paymentRows = rowsForMonth("payments", "COALESCE(payment_date,created_at)", month)
            val miscRows = rowsForMonth("misc_sales", "COALESCE(sale_date,created_at)", month)
            val expenseRows = rowsForMonth("greenhouse_payments", "COALESCE(payment_date,created_at)", month)
            snapshot.put("month_key", month)
            snapshot.put("closed_at", System.currentTimeMillis())
            val sellerNames = org.json.JSONObject()
            readableDatabase.rawQuery("SELECT id,name FROM sellers", null).use { c -> while (c.moveToNext()) sellerNames.put(c.getLong(0).toString(), c.getString(1)) }
            val flowerNames = org.json.JSONObject()
            readableDatabase.rawQuery("SELECT id,name || ' / ' || size FROM flowers", null).use { c -> while (c.moveToNext()) flowerNames.put(c.getLong(0).toString(), c.getString(1)) }
            snapshot.put("seller_names", sellerNames)
            snapshot.put("flower_names", flowerNames)
            snapshot.put("sales_rows", salesRows)
            snapshot.put("delivery_rows", deliveryRows)
            snapshot.put("return_rows", returnRows)
            snapshot.put("payment_rows", paymentRows)
            snapshot.put("misc_sale_rows", miscRows)
            snapshot.put("expense_rows", expenseRows)
            snapshot.put("sales_total", sumRows(salesRows, "qty", "price"))
            snapshot.put("misc_sales_total", sumRows(miscRows, "qty", "price"))
            snapshot.put("payments_total", sumRows(paymentRows, "amount", null))
            snapshot.put("expenses_total", sumRows(expenseRows, "amount", null))
            snapshot.put("records_count", salesRows.length() + deliveryRows.length() + returnRows.length() + paymentRows.length() + miscRows.length() + expenseRows.length())
            val balances = org.json.JSONArray()
            readableDatabase.rawQuery("SELECT id,name FROM sellers ORDER BY name", null).use { c ->
                while (c.moveToNext()) {
                    val sid = c.getLong(0)
                    val salesDue = sumBeforeMonth("sales", "greenhouse_amount", "created_at", sid, month)
                    val paid = sumBeforeMonth("payments", "amount", "COALESCE(payment_date,created_at)", sid, month)
                    balances.put(org.json.JSONObject().put("seller_id", sid).put("name", c.getString(1)).put("balance", salesDue - paid))
                }
            }
            snapshot.put("seller_balances", balances)
            val values = ContentValues().apply { put("month_key", month); put("closed_at", System.currentTimeMillis()); put("snapshot_json", snapshot.toString()); put("source", "LOCAL") }
            return writableDatabase.insertWithOnConflict("financial_month_archives", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1L
        }

        private fun rowsForMonth(table: String, dateExpr: String, month: String): org.json.JSONArray {
            val result = org.json.JSONArray()
            readableDatabase.rawQuery("SELECT * FROM $table ORDER BY id", null).use { c ->
                while (c.moveToNext()) {
                    val dateIndex = c.getColumnIndex(if (dateExpr.contains("payment_date")) "payment_date" else if (dateExpr.contains("sale_date")) "sale_date" else "created_at")
                    var ts = if (dateIndex >= 0 && !c.isNull(dateIndex)) c.getLong(dateIndex) else 0L
                    if (ts == 0L && dateExpr.contains("COALESCE")) { val fallback = c.getColumnIndex("created_at"); if (fallback >= 0 && !c.isNull(fallback)) ts = c.getLong(fallback) }
                    if (ts <= 0L || monthKey(ts) != month) continue
                    val row = org.json.JSONObject()
                    for (i in 0 until c.columnCount) {
                        if (c.isNull(i)) row.put(c.getColumnName(i), org.json.JSONObject.NULL)
                        else row.put(c.getColumnName(i), when (c.getType(i)) {
                            android.database.Cursor.FIELD_TYPE_INTEGER -> c.getLong(i)
                            android.database.Cursor.FIELD_TYPE_FLOAT -> c.getDouble(i)
                            android.database.Cursor.FIELD_TYPE_BLOB -> Base64.encodeToString(c.getBlob(i), Base64.NO_WRAP)
                            else -> c.getString(i)
                        })
                    }
                    result.put(row)
                }
            }
            return result
        }

        private fun sumRows(rows: org.json.JSONArray, first: String, second: String?): Long {
            var total = 0L
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val a = row.optLong(first)
                total += if (second == null) a else a * row.optLong(second)
            }
            return total
        }

        private fun sumBeforeMonth(table: String, amountColumn: String, dateExpr: String, sellerId: Long, month: String): Long {
            var total = 0L
            readableDatabase.rawQuery("SELECT $amountColumn,$dateExpr FROM $table WHERE seller_id=?", arrayOf(sellerId.toString())).use { c ->
                while (c.moveToNext()) {
                    val ts = c.getLong(1)
                    if (ts > 0 && monthKey(ts) <= month) total += c.getLong(0)
                }
            }
            return total
        }

        fun financialArchives(): List<Pair<String, String>> {
            val out = mutableListOf<Pair<String, String>>()
            readableDatabase.rawQuery("SELECT month_key,snapshot_json FROM financial_month_archives ORDER BY month_key DESC", null).use { c ->
                while (c.moveToNext()) out.add(c.getString(0) to c.getString(1))
            }
            return out
        }

        fun saveCloudFinancialArchive(month: String, json: String) {
            val cv = cv("month_key" to month, "closed_at" to System.currentTimeMillis(), "snapshot_json" to json, "source" to "CLOUD")
            writableDatabase.insertWithOnConflict("financial_month_archives", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        }

        fun databaseSummary():String{
            fun count(table:String)=one("SELECT COUNT(*) FROM $table").toInt()
            return "وضعیت دیتابیس محلی\n\nگل‌ها: ${count("flowers")}\nفروشندگان: ${count("sellers")}\nتحویل‌ها: ${count("deliveries")}\nفروش‌ها: ${count("sales")}\nبرگشتی‌ها: ${count("returns")}\nپرداخت‌ها: ${count("payments")}\nفروش متفرقه: ${count("misc_sales")}\nهزینه‌های گلخانه: ${count("greenhouse_payments")}\nتنخواه: ${count("petty_cash_people")}\nانواع هزینه: ${count("expense_types")}\n\nآخرین همگام‌سازی: ${lastFirebaseSync()?.let{jalaliDate(it)} ?: "ثبت نشده"}"
        }

        fun adminFirebaseEmail():String=settingText("admin_firebase_email","msf@asia.com")
        fun setAdminFirebaseEmail(email:String)=setSettingText("admin_firebase_email",email.trim())
        fun setAdminCredentials(u:String,p:String){setSettingText("admin_username",u);setSettingText("admin_password",p)}
        fun adminLocalPassword():String=settingText("admin_password","")
        fun isAdminSetupDone():Boolean=settingText("admin_setup_done","0")=="1"
        fun setAdminSetupDone(){setSettingText("admin_setup_done","1")}
        fun verifyAdminLogin(u:String,p:String):Boolean=u==adminUsername()&&p==settingText("admin_password","1234")
        fun updateSellerCredentials(id:Long,u:String,p:String){writableDatabase.update("sellers",cv("username" to u,"password" to p),"id=?",arrayOf(id.toString()))}
        fun appDate():Long=settingText("app_date",System.currentTimeMillis().toString()).toLongOrNull()?:System.currentTimeMillis()
        fun setAppDate(ms:Long)=setSettingText("app_date",ms.toString())
        fun lastFirebaseSync():Long?=settingText("last_firebase_sync","").toLongOrNull()
        fun setLastFirebaseSync(ms:Long)=setSettingText("last_firebase_sync",ms.toString())
        private fun settingText(k:String,d:String):String=readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0)?:d else d}
        fun settingTextPublic(k:String,d:String):String=settingText(k,d)
        fun setSettingText(k:String,v:String){writableDatabase.insertWithOnConflict("settings",null,cv("key" to k,"value" to v),SQLiteDatabase.CONFLICT_REPLACE)}
        data class DetailedSaleRow(val sellerId:Long,val sellerName:String,val flowerName:String,val size:String,val qty:Int,val price:Long,val total:Long,val sellerShareAmount:Long,val date:String)
        fun detailedSales(sellerId:Long?,from:Long,to:Long):List<DetailedSaleRow>{val l=mutableListOf<DetailedSaleRow>();val extra=if(sellerId==null)"" else " AND sa.seller_id=$sellerId";readableDatabase.rawQuery("SELECT s.id,s.name,f.name,f.size,sa.qty,sa.price,sa.qty*sa.price,sa.seller_share_amount,sa.created_at FROM sales sa JOIN sellers s ON s.id=sa.seller_id JOIN flowers f ON f.id=sa.flower_id WHERE sa.created_at>=? AND sa.created_at<=?$extra ORDER BY sa.created_at DESC,sa.id DESC",arrayOf(from.toString(),to.toString())).use{c->while(c.moveToNext())l.add(DetailedSaleRow(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),c.getLong(5),c.getLong(6),c.getLong(7),jalaliDate(c.getLong(8))))};return l}
        data class PriceWarning(val type:String,val sellerName:String,val flowerName:String,val size:String,val qty:Int,val price:Long,val basePrice:Long,val minPrice:Long,val date:String,val createdAt:Long)
        fun lowPriceWarningCount(sellerId:Long?):Int=priceWarnings(sellerId).size
        fun priceWarnings(sellerId:Long?):List<PriceWarning>{
            val l=mutableListOf<PriceWarning>()
            readableDatabase.rawQuery("SELECT 'فروش فروشنده',COALESCE(s.name,'فروشنده حذف‌شده'),COALESCE(f.name,'گل حذف‌شده'),COALESCE(f.size,''),sa.qty,sa.price,COALESCE(f.base_price,0),sa.min_price_snapshot,COALESCE(f.min_price,0),sa.created_at,sa.seller_id FROM sales sa LEFT JOIN sellers s ON s.id=sa.seller_id LEFT JOIN flowers f ON f.id=sa.flower_id WHERE (sa.below_minimum=1 OR (COALESCE(NULLIF(sa.min_price_snapshot,0),COALESCE(f.min_price,0))>0 AND sa.price<COALESCE(NULLIF(sa.min_price_snapshot,0),COALESCE(f.min_price,0)))) ORDER BY sa.created_at DESC,sa.id DESC",null).use{c->
                while(c.moveToNext()){
                    val seller=c.getLong(10); val price=c.getLong(5); val base=c.getLong(6); val snapshot=c.getLong(7); val min=if(snapshot>0L) snapshot else c.getLong(8)
                    if(min>0L && price<min && (sellerId==null || sellerId==seller)){
                        val ts=c.getLong(9); l.add(PriceWarning(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),price,base,min,jalaliDate(ts),ts))
                    }
                }
            }
            return l
        }

        private fun setting(k:String,d:Double):Double=readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0).toDoubleOrNull()?:d else d}
        private fun one(sql:String,args:Array<Any?> = emptyArray()):Long{val a=args.map{it.toString()}.toTypedArray();readableDatabase.rawQuery(sql,a).use{it.moveToFirst();return it.getLong(0)}}
        private fun dayStart():Long{val c=Calendar.getInstance();c.timeInMillis=appDate();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.timeInMillis}
        private fun jalaliDateTime(ms:Long):String{
            val c=Calendar.getInstance().apply{timeInMillis=ms}
            return "${jalaliDate(ms)} ${"%02d:%02d".format(Locale.US,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE))}"
        }
        private fun jalaliDate(ms:Long):String{val c=Calendar.getInstance();c.timeInMillis=ms;val gy=c.get(Calendar.YEAR);val gm=c.get(Calendar.MONTH)+1;val gd=c.get(Calendar.DAY_OF_MONTH);val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31);var days=355666+365*gy+((gy+3)/4)-((gy+99)/100)+((gy+399)/400)+gd;for(i in 1 until gm)days+=gdm[i];if(gm>2&&isLeapGregorian(gy))days++;var jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365};val jm=if(days<186)1+days/31 else 7+(days-186)/30;val jd=1+if(days<186)days%31 else(days-186)%30;return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)}
        private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)
    }
}
