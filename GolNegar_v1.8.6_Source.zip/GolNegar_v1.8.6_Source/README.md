

## Release 1.5.3

Build version: 1.5.3 (versionCode 83). This revision applies the requested visual changes in source: a transparent pale-rose launcher icon with the app label «گل نگار», smaller and more widely spaced draggable radial-menu circles without an outer frame, corrected status/navigation-bar insets so the title remains visible and the bottom navigation/back buttons sit above the system bar. The existing financial, navigation, and Firebase regression checks are retained. APK compilation must be confirmed by GitHub Actions.


## نسخه ۱.۷.۴
این نسخه شامل ۶ تم رنگی و امکان انتخاب رنگ اصلی سفارشی است. تنظیمات ظاهر مدیر گلخانه، فروشنده و کاربر گلخانه به‌صورت جداگانه روی دستگاه ذخیره می‌شود. برای ساخت، فایل `GolNegar_v1.7.4_Source.zip` و Workflow هم‌نسخه را در ریشه مخزن قرار دهید.
