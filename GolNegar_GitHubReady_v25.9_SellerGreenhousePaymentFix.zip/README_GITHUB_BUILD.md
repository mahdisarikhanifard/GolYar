# Build GolNegar on GitHub

The repository builds directly from the project root. The workflow is `.github/workflows/build.yml`.

1. Commit the project files to the `main` branch.
2. Open GitHub Actions → **Build GolNegar APK**.
3. Use **Run workflow** or push to `main`.
4. Download the `GolNegar-v25.3-debug-apk` artifact after a successful build.
