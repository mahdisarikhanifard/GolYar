# Gol Negar v1.3.0 audit

Static audit covered startup/authentication, greenhouse/seller dashboards, home shortcuts, registration flows, unified reports, flower CRUD and Persian sorting, seller CRUD, delivery/sale/return/settlement, miscellaneous sales, greenhouse expenses/petty cash, Firebase read/write chains, Firestore ownership fields, navigation stack, and SQLite schema upgrades.

Critical fixes:
1. Seller `payments` pull now executes `.get()` and continues the sync chain.
2. Explicit Back buttons use the same stack as Android Back.
3. Home/root navigation clears stale history.
4. Flower soft-delete is synced to Firebase.
5. Seller credential changes update `users/{uid}`.
6. Delivery totals are labeled as consignment deliveries, not sales/debt.
7. Unified reports expose the detailed sales report directly.

Build limitation: no Android SDK/Gradle cache is available in this environment, so final APK compilation must be verified by GitHub Actions.
