Gol Negar v1.1.4
Database management added: local JSON backup/restore, operational local clear, operational Firebase clear, sync-state repair, and database summary.
