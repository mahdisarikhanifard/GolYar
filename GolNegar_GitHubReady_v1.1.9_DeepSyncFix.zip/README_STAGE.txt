Gol Negar v1.1.9 — Deep Sync Fix

Based on v1.1.8. Keeps the seller sync race fix. Records exact Firebase collection/query errors when seller sync fails, shows the seller home with the sync error instead of trapping the user in login, and verifies the Firebase payment export mapping. GitHub Actions selects only the exact v1.1.9 ZIP.
