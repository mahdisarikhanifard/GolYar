Gol Negar v1.1.4
Database management added: local JSON backup/restore, operational local clear, operational Firebase clear, sync-state repair, and database summary.

Automatic exit/background backup added in v1.1.5: latest complete local backup is stored in Android no-backup app storage and can be exported from Database Management.
