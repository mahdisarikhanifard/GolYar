package com.example.golnegar

import android.animation.ValueAnimator
import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private data class CircularMenuItem(val label: String, val id: Int, val color: Int)
private data class AppRecord(
    val type: String,
    val title: String,
    val details: String,
    val amount: Double,
    val date: Long,
    val role: String = "greenhouse",
    val ownerUid: String = ""
)

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var toolbar: MaterialToolbar
    private lateinit var content: FrameLayout
    private lateinit var bottomNav: BottomNavigationView
    private val records = mutableListOf<AppRecord>()
    private val prefsName = "golnegar_local_data"
    private val prefsKey = "records_v1"
    private val roleKey = "active_role"
    private var activeRole = ""
    private lateinit var database: GolNegarDatabase
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val cloud: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private var signedInEmail: String = ""
    private var signedInUid: String = ""
    private var syncStatus: String = "همگام‌سازی هنوز انجام نشده است"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        database = GolNegarDatabase(this)
        activeRole = ""
        loadRecords()
        try { FirebaseApp.initializeApp(this) } catch (_: Exception) { }

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 248, 251))
        }
        toolbar = MaterialToolbar(this).apply {
            title = "گل نگار"
            setTitleTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(34, 115, 83))
            elevation = dp(3).toFloat()
        }
        content = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        bottomNav = BottomNavigationView(this).apply {
            setBackgroundColor(Color.WHITE)
            labelVisibilityMode = BottomNavigationView.LABEL_VISIBILITY_LABELED
            menu.add(0, 1, 0, "منو").setIcon(android.R.drawable.ic_menu_sort_by_size)
            menu.add(0, 2, 1, "خانه").setIcon(android.R.drawable.ic_menu_view)
            menu.add(0, 3, 2, "ثبت‌ها").setIcon(android.R.drawable.ic_input_add)
            menu.add(0, 4, 3, "سوابق").setIcon(android.R.drawable.ic_menu_recent_history)
            menu.add(0, 5, 4, "تنظیمات").setIcon(android.R.drawable.ic_menu_preferences)
            setOnItemSelectedListener { item -> showPage(item.itemId); true }
        }
        root.addView(toolbar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)))
        root.addView(content)
        root.addView(bottomNav, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        val user = auth.currentUser
        if (user == null) showLoginPage() else resolveSignedInUser(user.uid, user.email ?: "")
    }

    private fun showPage(page: Int) {
        when (page) {
            1 -> showMenuPage()
            2 -> showHomePage()
            3 -> showRegistrationsPage()
            4 -> showHistoryPage()
            5 -> showSettingsPage()
        }
    }

    private fun setPageTitle(title: String) { toolbar.title = title }

    private fun setContentViewPage(view: View) {
        content.removeAllViews()
        content.addView(view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
    }

    private fun showLoginPage(message: String = "") {
        activeRole = ""
        setPageTitle("ورود امن به گل نگار")
        bottomNav.visibility = View.GONE
        val page = pageColumn()
        page.addView(text("ورود به گل نگار", 24f, green(), true), marginParams(bottom = 8))
        page.addView(text("برای حفاظت از اطلاعات، ورود با حساب Firebase الزامی است.", 14f, Color.DKGRAY), marginParams(bottom = 16))
        if (message.isNotBlank()) page.addView(infoCard("پیام", message), marginParams(bottom = 12))
        val email = EditText(this).apply {
            hint = "ایمیل حساب Firebase یا نام‌کاربری ثبت‌شده"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            setSingleLine(true); setTextColor(Color.BLACK); setHintTextColor(Color.GRAY)
        }
        val password = EditText(this).apply {
            hint = "رمز عبور"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true); setTextColor(Color.BLACK); setHintTextColor(Color.GRAY)
        }
        page.addView(text("ایمیل / نام کاربری", 14f, Color.DKGRAY, true), marginParams(bottom = 4))
        page.addView(email, marginParams(bottom = 12))
        page.addView(text("رمز عبور", 14f, Color.DKGRAY, true), marginParams(bottom = 4))
        page.addView(password, marginParams(bottom = 14))
        page.addView(actionCard("ورود") {
            val e = normalizeLogin(email.text.toString())
            val p = password.text.toString()
            if (e.isBlank() || p.isBlank()) { toast("ایمیل و رمز عبور را وارد کنید"); return@actionCard }
            setLoginBusy(true)
            auth.signInWithEmailAndPassword(e, p).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val u = auth.currentUser
                    if (u == null) { setLoginBusy(false); showLoginPage("ورود انجام نشد؛ دوباره تلاش کنید.") }
                    else resolveSignedInUser(u.uid, u.email ?: e)
                } else {
                    setLoginBusy(false)
                    showLoginPage("ورود ناموفق بود. ایمیل/نام کاربری و رمز را بررسی کن؛ حساب فروشنده باید از قبل در Firebase تعریف شده باشد.")
                }
            }
        }, marginParams(bottom = 10))
        page.addView(actionCard("ساخت حساب مدیر (فقط ایمیل مدیرِ ثبت‌شده در Firebase)") {
            val e = normalizeLogin(email.text.toString()); val p = password.text.toString()
            if (e.isBlank() || p.length < 8) { toast("ایمیل را وارد کن و برای حساب مدیر رمزی حداقل ۸ کاراکتری بگذار"); return@actionCard }
            setLoginBusy(true)
            cloud.collection("settings").document("admin_bootstrap").get()
                .addOnSuccessListener { doc ->
                    val bootstrapEmail = (doc.getString("email") ?: "").trim().lowercase()
                    if (bootstrapEmail.isBlank() || bootstrapEmail != e.lowercase()) {
                        setLoginBusy(false); showLoginPage("این ایمیل با ایمیل مدیر در settings/admin_bootstrap مطابقت ندارد؛ حساب ساخته نشد.")
                    } else {
                        auth.createUserWithEmailAndPassword(e, p).addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val u = auth.currentUser
                                if (u == null) { setLoginBusy(false); showLoginPage("ساخت حساب انجام نشد.") }
                                else createAdminProfile(u.uid, e)
                            } else { setLoginBusy(false); showLoginPage("ساخت حساب مدیر ناموفق بود: ${task.exception?.localizedMessage ?: "خطای Firebase"}") }
                        }
                    }
                }
                .addOnFailureListener { setLoginBusy(false); showLoginPage("به تنظیم admin_bootstrap دسترسی نیست. تنظیمات Firestore و قوانین آن را بررسی کن.") }
        }, marginParams(bottom = 10))
        page.addView(actionCard("بازیابی رمز عبور") {
            val e = normalizeLogin(email.text.toString())
            if (e.isBlank()) toast("ابتدا ایمیل حساب را وارد کن") else auth.sendPasswordResetEmail(e).addOnCompleteListener { task ->
                toast(if (task.isSuccessful) "درخواست بازیابی رمز ارسال شد؛ صندوق ایمیل را بررسی کن." else "ارسال درخواست ناموفق بود؛ ایمیل را بررسی کن.")
            }
        }, marginParams(bottom = 10))
        page.addView(infoCard("امنیت", "رمز عبور در برنامه یا SQLite ذخیره نمی‌شود؛ ورود و بررسی نقش از طریق Firebase Authentication و Firestore انجام می‌شود."), marginParams(top = 8))
        setContentViewPage(scroll(page))
    }

    private fun normalizeLogin(value: String): String {
        val v = value.trim().lowercase()
        return if (v.contains("@")) v else if (v.isNotBlank()) "$v@golyar.app" else ""
    }

    private fun setLoginBusy(busy: Boolean) {
        // Prevent repeated submissions while Firebase is processing. UI remains recoverable on callback.
        if (busy) toast("در حال ارتباط امن با Firebase…")
    }

    private fun createAdminProfile(uid: String, email: String) {
        val profile = hashMapOf("role" to "ADMIN", "firebase_email" to email.trim().lowercase(), "created_at" to System.currentTimeMillis())
        cloud.collection("users").document(uid).set(profile)
            .addOnSuccessListener { resolveSignedInUser(uid, email) }
            .addOnFailureListener { auth.signOut(); setLoginBusy(false); showLoginPage("حساب ساخته شد اما پروفایل مدیر ذخیره نشد. قوانین Firestore را بررسی کن.") }
    }

    private fun resolveSignedInUser(uid: String, email: String) {
        signedInUid = uid; signedInEmail = email
        cloud.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    applyProfileRole(doc.getString("role") ?: "", doc.getLong("seller_id"))
                } else {
                    cloud.collection("settings").document("admin_bootstrap").get()
                        .addOnSuccessListener { settings ->
                            val adminEmail = (settings.getString("email") ?: "").trim().lowercase()
                            if (adminEmail.isNotBlank() && adminEmail == email.trim().lowercase()) createAdminProfile(uid, email)
                            else { auth.signOut(); showLoginPage("برای این حساب نقش تعریف نشده است. مدیر باید پروفایل STAFF یا SELLER را در users بسازد.") }
                        }
                        .addOnFailureListener { auth.signOut(); showLoginPage("پروفایل کاربر پیدا نشد و بررسی مدیر ناموفق بود.") }
                }
            }
            .addOnFailureListener { auth.signOut(); showLoginPage("بررسی مجوز کاربر در Firestore ناموفق بود؛ قوانین و اینترنت را بررسی کن.") }
    }

    private fun applyProfileRole(role: String, sellerId: Long?) {
        when (role.uppercase()) {
            "ADMIN", "STAFF" -> activeRole = "greenhouse"
            "SELLER" -> activeRole = "vendor"
            else -> { auth.signOut(); showLoginPage("نقش این حساب معتبر نیست؛ فقط ADMIN، STAFF یا SELLER مجاز است."); return }
        }
        // Isolate local records by authenticated Firebase UID before any cloud upload.
        val accountPrefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val previousUid = accountPrefs.getString("last_account_uid", "") ?: ""
        if (previousUid != signedInUid) {
            val unowned = records.filter { it.ownerUid.isBlank() }
            if (unowned.isNotEmpty() && !accountPrefs.contains("pre_login_backup_v27")) {
                val backup = JSONArray()
                unowned.forEach { r -> backup.put(JSONObject().put("type", r.type).put("title", r.title).put("details", r.details).put("amount", r.amount).put("date", r.date).put("role", r.role)) }
                accountPrefs.edit().putString("pre_login_backup_v27", backup.toString()).apply()
            }
            records.clear()
            records.addAll(database.readAll().filter { it.ownerUid == signedInUid })
            database.replaceAll(records)
            accountPrefs.edit().putString("last_account_uid", signedInUid).apply()
        } else {
            records.removeAll { it.ownerUid.isNotBlank() && it.ownerUid != signedInUid }
        }
        accountPrefs.edit().putString(roleKey, activeRole).apply()
        bottomNav.visibility = View.VISIBLE
        bottomNav.selectedItemId = 1
        if (activeRole == "vendor") showVendorMenuPage() else showMenuPage()
        syncPrivateRecords()
    }

    private fun signOutAndShowLogin() {
        auth.signOut(); signedInUid = ""; signedInEmail = ""; activeRole = ""
        getSharedPreferences(prefsName, Context.MODE_PRIVATE).edit().remove(roleKey).apply()
        bottomNav.visibility = View.GONE
        showLoginPage("از حساب خارج شدی.")
    }

    private fun syncPrivateRecords() {
        val uid = auth.currentUser?.uid ?: return
        syncStatus = "در حال همگام‌سازی امن اطلاعات حساب…"
        val collection = cloud.collection("users").document(uid).collection("records")
        collection.get().addOnSuccessListener { snapshot ->
            val merged = records.toMutableList()
            for (doc in snapshot.documents) {
                val type = doc.getString("type") ?: continue
                val title = doc.getString("title") ?: ""
                val details = doc.getString("details") ?: ""
                val amount = doc.getDouble("amount") ?: 0.0
                val date = doc.getLong("date") ?: 0L
                val role = doc.getString("role") ?: activeRole
                if (role != activeRole) continue
                if (merged.none { cloudRecordId(it) == doc.id }) merged.add(AppRecord(type, title, details, amount, date, role, uid))
            }
            records.clear(); records.addAll(merged)
            try { database.replaceAll(records) } catch (_: Exception) { }
            val batch = cloud.batch()
            records.filter { it.role == activeRole && it.ownerUid == uid }.forEach { record ->
                val data = hashMapOf<String, Any>("type" to record.type, "title" to record.title, "details" to record.details,
                    "amount" to record.amount, "date" to record.date, "role" to record.role, "owner_uid" to uid, "updated_at" to System.currentTimeMillis())
                batch.set(collection.document(cloudRecordId(record)), data, SetOptions.merge())
            }
            batch.commit().addOnSuccessListener {
                syncStatus = "همگام‌سازی موفق: ${java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}"
                if (isFinishing || isDestroyed) return@addOnSuccessListener
                if (activeRole == "vendor") showVendorMenuPage() else showMenuPage()
            }.addOnFailureListener { syncStatus = "همگام‌سازی ناموفق؛ اطلاعات محلی حفظ شد." }
        }.addOnFailureListener { syncStatus = "اتصال به Firebase ناموفق؛ اطلاعات محلی حفظ شد." }
    }

    private fun cloudRecordId(record: AppRecord): String = ("${record.date}_${record.type}_${record.title}_${record.details}_${record.amount}_${record.role}").hashCode().toUInt().toString(16)

    private fun setActiveRole(role: String) {
        activeRole = role
        getSharedPreferences(prefsName, Context.MODE_PRIVATE).edit().putString(roleKey, role).apply()
        bottomNav.selectedItemId = 1
        if (role == "vendor") showVendorMenuPage() else showMenuPage()
    }

    private fun showVendorMenuPage() {
        setPageTitle("بخش فروشنده")
        val page = pageColumn()
        page.addView(text("پنل فروشنده", 23f, green(), true), marginParams(bottom = 8))
        page.addView(text("ثبت فروش و پرداخت‌های خودتان در این بخش نگهداری می‌شود.", 13f, Color.DKGRAY), marginParams(bottom = 14))
        page.addView(actionCard("ثبت فروش گل") { showForm("فروش") }, marginParams(bottom = 9))
        page.addView(actionCard("ثبت برگشتی") { showForm("برگشتی") }, marginParams(bottom = 9))
        page.addView(actionCard("ثبت پرداخت به گلخانه") { showForm("پرداخت") }, marginParams(bottom = 9))
        page.addView(actionCard("مشاهده سوابق فروشنده") { showRecordsPage(null, "سوابق فروشنده") }, marginParams(bottom = 9))
        page.addView(actionCard("گزارش فروشنده") { showReportsPage() }, marginParams(bottom = 9))
        page.addView(actionCard("خروج امن از حساب") { signOutAndShowLogin() }, marginParams(bottom = 9))
        setContentViewPage(scroll(page))
    }

    private fun showMenuPage() {
        if (activeRole == "vendor") { showVendorMenuPage(); return }
        setPageTitle("بخش گلخانه")
        setContentViewPage(CircularMenuView(this) { action ->
            when (action) {
                1 -> showForm("تحویل گل")
                2 -> bottomNav.selectedItemId = 3
                3 -> showReportsPage()
                4 -> bottomNav.selectedItemId = 5
                5 -> showRecordsPage("فروشنده", "فروشندگان")
                6 -> showRecordsPage("نوع گل", "انواع گل")
                7 -> bottomNav.selectedItemId = 2
            }
        })
    }

    private fun showHomePage() {
        setPageTitle(if (activeRole == "vendor") "خانه فروشنده" else "خانه گلخانه")
        val page = pageColumn()
        if (activeRole == "vendor") {
            val mine = records.filter { it.role == "vendor" }
            page.addView(text("داشبورد فروشنده", 23f, green(), true), marginParams(bottom = 8))
            page.addView(summaryCard("فروش‌های ثبت‌شده", "${mine.count { it.type == "فروش" }} مورد • ${money(mine.filter { it.type == "فروش" }.sumOf { it.amount })}", Color.rgb(47, 112, 190)), marginParams(bottom = 10))
            page.addView(summaryCard("پرداخت به گلخانه", "${mine.count { it.type == "پرداخت" }} مورد • ${money(mine.filter { it.type == "پرداخت" }.sumOf { it.amount })}", Color.rgb(39, 137, 97)), marginParams(bottom = 10))
            page.addView(summaryCard("برگشتی‌ها", "${mine.count { it.type == "برگشتی" }} مورد", Color.rgb(219, 143, 40)), marginParams(bottom = 10))
            page.addView(actionCard("ثبت فروش") { showForm("فروش") }, marginParams(bottom = 9))
            page.addView(actionCard("ثبت پرداخت به گلخانه") { showForm("پرداخت") }, marginParams(bottom = 9))
            page.addView(actionCard("مشاهده سوابق") { showRecordsPage(null, "سوابق فروشنده") }, marginParams(bottom = 9))
            setContentViewPage(scroll(page))
            return
        }
        page.addView(text("داشبورد گل نگار", 23f, green(), true), marginParams(bottom = 8))
        page.addView(text("خلاصه ثبت‌های ذخیره‌شده روی این دستگاه", 13f, Color.DKGRAY), marginParams(bottom = 14))
        page.addView(summaryCard("تحویل گل", "${countType("تحویل گل")} مورد ثبت شده", green()), marginParams(bottom = 10))
        page.addView(summaryCard("فروش ثبت‌شده", "${countType("فروش")} مورد  •  جمع مبلغ: ${money(sumType("فروش"))}", Color.rgb(47, 112, 190)), marginParams(bottom = 10))
        page.addView(summaryCard("پرداخت‌های فروشندگان", "${countType("پرداخت")} مورد  •  جمع مبلغ: ${money(sumType("پرداخت"))}", Color.rgb(219, 143, 40)), marginParams(bottom = 10))
        page.addView(summaryCard("تسویه‌ها", "${countType("تسویه")} مورد  •  جمع مبلغ: ${money(sumType("تسویه"))}", Color.rgb(147, 84, 180)), marginParams(bottom = 10))
        page.addView(summaryCard("تعداد فروشندگان / انواع گل", "${countType("فروشنده")} فروشنده  •  ${countType("نوع گل")} نوع گل", Color.rgb(32, 150, 150)), marginParams(bottom = 16))
        page.addView(actionCard("ثبت تحویل گل") { showForm("تحویل گل") }, marginParams(bottom = 10))
        page.addView(actionCard("ثبت فروش") { showForm("فروش") }, marginParams(bottom = 10))
        page.addView(actionCard("ثبت پرداخت") { showForm("پرداخت") }, marginParams(bottom = 10))
        page.addView(actionCard("مشاهده گزارش‌ها") { showReportsPage() }, marginParams(bottom = 10))
        setContentViewPage(scroll(page))
    }

    private fun showRegistrationsPage() {
        setPageTitle("ثبت‌ها")
        val page = pageColumn()
        page.addView(text("ثبت اطلاعات", 23f, green(), true), marginParams(bottom = 8))
        page.addView(text("برای هر عملیات، فرم مربوط را باز و ذخیره کنید.", 13f, Color.DKGRAY), marginParams(bottom = 14))
        val options = if (activeRole == "vendor") listOf(
            "ثبت فروش گل" to "فروش",
            "ثبت برگشتی" to "برگشتی",
            "ثبت پرداخت به گلخانه" to "پرداخت"
        ) else listOf(
            "ثبت نوع گل" to "نوع گل",
            "ثبت فروشنده" to "فروشنده",
            "ثبت تحویل گل" to "تحویل گل",
            "ثبت فروش" to "فروش",
            "ثبت برگشتی" to "برگشتی",
            "ثبت پرداخت فروشنده" to "پرداخت",
            "ثبت تسویه حساب" to "تسویه",
            "ثبت هزینه" to "هزینه"
        )
        options.forEach { (label, type) ->
            page.addView(actionCard(label) { showForm(type) }, marginParams(bottom = 9))
        }
        if (activeRole == "greenhouse") {
            page.addView(actionCard("فهرست فروشندگان") { showRecordsPage("فروشنده", "فروشندگان") }, marginParams(bottom = 9))
            page.addView(actionCard("فهرست انواع گل") { showRecordsPage("نوع گل", "انواع گل") }, marginParams(bottom = 9))
        }
        page.addView(actionCard(if (activeRole == "vendor") "فهرست ثبت‌های من" else "فهرست همه ثبت‌ها") { showRecordsPage(null, if (activeRole == "vendor") "سوابق فروشنده" else "همه ثبت‌ها") }, marginParams(bottom = 9))
        setContentViewPage(scroll(page))
    }

    private fun showHistoryPage() {
        setPageTitle("سوابق")
        val page = pageColumn()
        page.addView(text("سوابق و گزارش‌ها", 23f, green(), true), marginParams(bottom = 14))
        (if (activeRole == "vendor") listOf(
            "همه ثبت‌های من" to null,
            "فروش‌ها" to "فروش",
            "برگشتی‌ها" to "برگشتی",
            "پرداخت‌ها به گلخانه" to "پرداخت"
        ) else listOf(
            "همه ثبت‌ها" to null,
            "تحویل‌های گل" to "تحویل گل",
            "فروش‌ها" to "فروش",
            "برگشتی‌ها" to "برگشتی",
            "پرداخت‌ها" to "پرداخت",
            "تسویه‌ها" to "تسویه",
            "هزینه‌ها" to "هزینه",
            "فروشندگان" to "فروشنده",
            "انواع گل" to "نوع گل"
        )).forEach { (label, type) ->
            page.addView(actionCard(label) { showRecordsPage(type, label) }, marginParams(bottom = 9))
        }
        page.addView(actionCard("گزارش مالی خلاصه") { showReportsPage() }, marginParams(bottom = 9))
        setContentViewPage(scroll(page))
    }

    private fun showSettingsPage() {
        setPageTitle("تنظیمات")
        val page = pageColumn()
        page.addView(text("تنظیمات برنامه", 23f, green(), true), marginParams(bottom = 14))
        page.addView(infoCard("بخش فعال", if (activeRole == "vendor") "فروشنده" else "گلخانه"), marginParams(bottom = 10))
        page.addView(infoCard("ذخیره اطلاعات", "اطلاعات در پایگاه داده SQLite روی همین دستگاه ذخیره می‌شود. داده‌های گلخانه و فروشنده با ستون بخش از هم جدا هستند."), marginParams(bottom = 10))
        page.addView(actionCard("خروج امن از حساب") { signOutAndShowLogin() }, marginParams(bottom = 10))
        page.addView(infoCard("حساب فعال", if (signedInEmail.isBlank()) "وارد نشده" else signedInEmail), marginParams(bottom = 10))
        page.addView(infoCard("همگام‌سازی اینترنتی", syncStatus), marginParams(bottom = 10))
        page.addView(actionCard("همگام‌سازی دوباره") { syncPrivateRecords(); toast("همگام‌سازی درخواست شد") }, marginParams(bottom = 10))
        page.addView(infoCard("تعداد ثبت‌ها", "${records.count { it.role == activeRole && it.ownerUid == signedInUid }} ثبت در بخش فعلی"), marginParams(bottom = 10))
        if (getSharedPreferences(prefsName, Context.MODE_PRIVATE).contains("pre_login_backup_v27")) page.addView(infoCard("اطلاعات محلی قدیمی", "ثبت‌های نسخه قبل از ورود، برای جلوگیری از انتقال اشتباه بین حساب‌ها در پشتیبان محلی جدا نگهداری شده‌اند و خودکار به فضای ابری منتقل نمی‌شوند."), marginParams(bottom = 10))
        page.addView(actionCard("خروجی متنی از ثبت‌ها") { showExportDialog() }, marginParams(bottom = 10))
        page.addView(actionCard("پاک کردن همه اطلاعات") { confirmClearRecords() }, marginParams(bottom = 10))
        page.addView(infoCard("نام برنامه", "گل نگار"), marginParams(bottom = 10))
        setContentViewPage(scroll(page))
    }

    private fun showForm(type: String) {
        setPageTitle("ثبت $type")
        val page = pageColumn()
        page.addView(text("ثبت $type", 22f, green(), true), marginParams(bottom = 8))
        page.addView(text("اطلاعات را وارد و دکمه ذخیره را بزنید.", 13f, Color.DKGRAY), marginParams(bottom = 14))

        val fields = when (type) {
            "نوع گل" -> listOf("نام نوع گل" to true, "اندازه گل (سانتی‌متر)" to false, "قیمت پایه هر شاخه/دسته" to false, "توضیحات" to false)
            "فروشنده" -> listOf("نام فروشنده" to true, "شماره تماس (اختیاری)" to false, "نام کاربری (اختیاری)" to false, "توضیحات" to false)
            "تحویل گل" -> listOf("نام فروشنده" to true, "نوع گل" to true, "اندازه گل (سانتی‌متر)" to false, "تعداد" to true, "قیمت هر واحد (تومان، اختیاری)" to false, "توضیحات" to false)
            "فروش" -> if (activeRole == "vendor") listOf("نوع گل" to true, "اندازه گل (سانتی‌متر)" to false, "تعداد" to true, "قیمت فروش هر واحد (تومان)" to true, "توضیحات" to false) else listOf("نام فروشنده" to true, "نوع گل" to true, "اندازه گل (سانتی‌متر)" to false, "تعداد" to true, "قیمت فروش هر واحد (تومان)" to true, "توضیحات" to false)
            "برگشتی" -> if (activeRole == "vendor") listOf("نوع گل" to true, "اندازه گل (سانتی‌متر)" to false, "تعداد برگشتی" to true, "مبلغ برگشتی (تومان، اختیاری)" to false, "علت / توضیحات" to false) else listOf("نام فروشنده" to true, "نوع گل" to true, "اندازه گل (سانتی‌متر)" to false, "تعداد برگشتی" to true, "مبلغ برگشتی (تومان، اختیاری)" to false, "علت / توضیحات" to false)
            "پرداخت" -> if (activeRole == "vendor") listOf("مبلغ پرداخت به گلخانه (تومان)" to true, "روش پرداخت" to false, "شماره پیگیری (اختیاری)" to false, "توضیحات" to false) else listOf("نام فروشنده" to true, "مبلغ پرداخت (تومان)" to true, "روش پرداخت" to false, "شماره پیگیری (اختیاری)" to false, "توضیحات" to false)
            "تسویه" -> listOf("نام فروشنده" to true, "مبلغ تسویه (تومان)" to true, "نوع تسویه / بابت" to false, "توضیحات" to false)
            "هزینه" -> listOf("عنوان هزینه" to true, "مبلغ هزینه (تومان)" to true, "دسته هزینه" to false, "توضیحات" to false)
            else -> listOf("عنوان" to true, "توضیحات" to false)
        }

        val inputs = linkedMapOf<String, EditText>()
        fields.forEach { (label, required) ->
            page.addView(text(label + if (required) " *" else "", 14f, Color.DKGRAY, true), marginParams(bottom = 5))
            val input = EditText(this).apply {
                hint = label
                textSize = 15f
                setSingleLine(label != "توضیحات" && label != "علت / توضیحات")
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setTextColor(Color.rgb(35, 48, 58))
                setHintTextColor(Color.rgb(112, 125, 137))
                setBackgroundColor(Color.rgb(232, 241, 247))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(232, 241, 247))
                    cornerRadius = dp(10).toFloat()
                    setStroke(dp(1), Color.rgb(174, 198, 211))
                }
                if (label.contains("مبلغ") || label.contains("قیمت") || label == "تعداد" || label == "تعداد برگشتی" || label.contains("اندازه")) {
                    inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                }
            }
            inputs[label] = input
            page.addView(input, marginParams(bottom = 12))
        }

        page.addView(actionCard("ذخیره ثبت") {
            val values = linkedMapOf<String, String>()
            var missing = false
            fields.forEach { (label, required) ->
                val value = inputs[label]?.text?.toString()?.trim().orEmpty()
                if (required && value.isBlank()) missing = true
                values[label] = value
            }
            if (missing) {
                Toast.makeText(this, "لطفاً فیلدهای ستاره‌دار را تکمیل کنید.", Toast.LENGTH_LONG).show()
            } else {
                val title = when (type) {
                    "نوع گل" -> values["نام نوع گل"].orEmpty()
                    "فروشنده" -> values["نام فروشنده"].orEmpty()
                    "هزینه" -> values["عنوان هزینه"].orEmpty()
                    else -> values.values.firstOrNull { it.isNotBlank() } ?: type
                }
                val amountLabel = fields.firstOrNull { it.first.contains("مبلغ") || it.first.contains("قیمت فروش") || it.first.contains("قیمت پایه") }
                val amount = amountLabel?.let { values[it.first]?.replace(",", "")?.toDoubleOrNull() } ?: 0.0
                val details = values.entries.joinToString("\n") { "${it.key}: ${it.value.ifBlank { "—" }}" }
                records.add(AppRecord(type, title, details, amount, System.currentTimeMillis(), activeRole.ifBlank { "greenhouse" }, signedInUid))
                saveRecords()
                Toast.makeText(this, "ثبت ذخیره شد.", Toast.LENGTH_SHORT).show()
                if (type == "فروشنده" || type == "نوع گل") showRecordsPage(type, if (type == "فروشنده") "فروشندگان" else "انواع گل")
                else showRegistrationsPage()
            }
        }, marginParams(bottom = 10))
        page.addView(actionCard("انصراف و بازگشت") { bottomNav.selectedItemId = 3 }, marginParams(bottom = 10))
        setContentViewPage(scroll(page))
    }

    private fun showRecordsPage(type: String?, title: String) {
        setPageTitle(title)
        val page = pageColumn()
        page.addView(text(title, 22f, green(), true), marginParams(bottom = 12))
        val filtered = records.filter { it.role == activeRole && (type == null || it.type == type) }.sortedByDescending { it.date }
        page.addView(text("تعداد موارد: ${filtered.size}", 13f, Color.DKGRAY), marginParams(bottom = 10))
        if (filtered.isEmpty()) {
            page.addView(infoCard("هنوز موردی ثبت نشده", "از صفحه ثبت‌ها، مورد جدید اضافه کنید."), marginParams(bottom = 12))
        } else {
            filtered.forEach { record ->
                page.addView(recordCard(record) {
                    AlertDialog.Builder(this)
                        .setTitle(record.title)
                        .setMessage("${record.type}\n${record.details}\n\nتاریخ: ${dateText(record.date)}\nمبلغ: ${money(record.amount)}")
                        .setPositiveButton("بستن", null)
                        .setNeutralButton("حذف ثبت") { _, _ ->
                            records.remove(record)
                            saveRecords()
                            showRecordsPage(type, title)
                        }
                        .show()
                }, marginParams(bottom = 9))
            }
        }
        page.addView(actionCard("بازگشت") { bottomNav.selectedItemId = if (type == "فروشنده" || type == "نوع گل") 3 else 4 }, marginParams(bottom = 10))
        setContentViewPage(scroll(page))
    }

    private fun showReportsPage() {
        setPageTitle("گزارش مالی")
        val page = pageColumn()
        page.addView(text(if (activeRole == "vendor") "گزارش مالی فروشنده" else "گزارش مالی گلخانه", 23f, green(), true), marginParams(bottom = 12))
        page.addView(summaryCard("جمع فروش ثبت‌شده", money(sumType("فروش")), Color.rgb(47, 112, 190)), marginParams(bottom = 10))
        page.addView(summaryCard("جمع پرداخت‌ها", money(sumType("پرداخت")), Color.rgb(39, 137, 97)), marginParams(bottom = 10))
        page.addView(summaryCard("جمع تسویه‌ها", money(sumType("تسویه")), Color.rgb(147, 84, 180)), marginParams(bottom = 10))
        page.addView(summaryCard("جمع هزینه‌ها", money(sumType("هزینه")), Color.rgb(219, 143, 40)), marginParams(bottom = 10))
        page.addView(summaryCard("تعداد تحویل‌ها", countType("تحویل گل").toString(), Color.rgb(32, 150, 150)), marginParams(bottom = 10))
        page.addView(infoCard("محدودیت گزارش", "این گزارش بر اساس ثبت‌های ذخیره‌شده روی همین دستگاه محاسبه می‌شود و فعلاً جایگزین گزارش حسابداری نهایی یا اطلاعات همگام‌شده با سرور نیست."), marginParams(bottom = 12))
        page.addView(actionCard("مشاهده همه ثبت‌ها") { showRecordsPage(null, "همه ثبت‌ها") }, marginParams(bottom = 10))
        setContentViewPage(scroll(page))
    }

    private fun showExportDialog() {
        val export = records.filter { it.role == activeRole }.sortedBy { it.date }.joinToString("\n\n") {
            "${it.type} | ${it.title} | ${dateText(it.date)} | ${money(it.amount)}\n${it.details}"
        }.ifBlank { "هنوز ثبتی وجود ندارد." }
        AlertDialog.Builder(this)
            .setTitle("خلاصه ثبت‌ها")
            .setMessage(export)
            .setPositiveButton("بستن", null)
            .show()
    }

    private fun confirmClearRecords() {
        AlertDialog.Builder(this)
            .setTitle("پاک کردن اطلاعات")
            .setMessage("تمام ثبت‌های بخش فعلی حذف شوند؟ اطلاعات بخش دیگر دست‌نخورده می‌ماند. این کار قابل بازگشت نیست.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("حذف همه") { _, _ ->
                records.removeAll { it.role == activeRole }
                saveRecords()
                showSettingsPage()
                Toast.makeText(this, "اطلاعات بخش فعلی پاک شد.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun loadRecords() {
        records.clear()
        val stored = database.readAll()
        if (stored.isNotEmpty()) {
            records.addAll(stored)
            return
        }
        // One-time migration: preserve any records saved by v26 in SharedPreferences as greenhouse data.
        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val raw = prefs.getString(prefsKey, "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                records.add(AppRecord(
                    obj.optString("type"), obj.optString("title"), obj.optString("details"),
                    obj.optDouble("amount", 0.0), obj.optLong("date", System.currentTimeMillis()), "greenhouse"
                ))
            }
            if (records.isNotEmpty()) database.replaceAll(records)
            // Remove the legacy copy so deleted records cannot reappear on a later launch.
            prefs.edit().remove(prefsKey).apply()
        } catch (_: Exception) {
            records.clear()
        }
    }

    private fun saveRecords() {
        database.replaceAll(records)
        if (auth.currentUser != null) syncPrivateRecords()
    }

    private fun countType(type: String): Int = records.count { it.role == activeRole && it.type == type }
    private fun sumType(type: String): Double = records.filter { it.role == activeRole && it.type == type }.sumOf { it.amount }
    private fun money(value: Double): String = String.format("%,.0f تومان", value)
    private fun dateText(time: Long): String = java.text.SimpleDateFormat("yyyy/MM/dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(time))
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    private fun green(): Int = Color.rgb(34, 115, 83)

    private fun pageColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(20))
    }

    private fun scroll(view: View): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER_VERTICAL
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun summaryCard(title: String, description: String, accent: Int): MaterialCardView {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            addView(text(title, 17f, accent, true))
            addView(text(description, 13f, Color.DKGRAY), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        }
        return MaterialCardView(this).apply {
            radius = dp(14).toFloat()
            cardElevation = dp(2).toFloat()
            setCardBackgroundColor(Color.WHITE)
            addView(layout)
        }
    }

    private fun actionCard(title: String, action: () -> Unit): MaterialCardView {
        val label = text("●   $title", 16f, green(), true).apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        return MaterialCardView(this).apply {
            radius = dp(14).toFloat()
            cardElevation = dp(2).toFloat()
            setCardBackgroundColor(Color.WHITE)
            isClickable = true
            isFocusable = true
            addView(label)
            setOnClickListener { action() }
        }
    }

    private fun infoCard(title: String, description: String): MaterialCardView {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            addView(text(title, 16f, green(), true))
            addView(text(description, 14f, Color.DKGRAY).apply { setPadding(0, dp(8), 0, 0) })
        }
        return MaterialCardView(this).apply {
            radius = dp(14).toFloat()
            cardElevation = dp(2).toFloat()
            setCardBackgroundColor(Color.WHITE)
            addView(layout)
        }
    }

    private fun recordCard(record: AppRecord, action: () -> Unit): MaterialCardView {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(text(record.title, 16f, green(), true))
            addView(text("${record.type}  •  ${dateText(record.date)}", 12f, Color.GRAY).apply { setPadding(0, dp(4), 0, 0) })
            if (record.amount != 0.0) addView(text(money(record.amount), 14f, Color.rgb(47, 112, 190), true).apply { setPadding(0, dp(5), 0, 0) })
        }
        return MaterialCardView(this).apply {
            radius = dp(12).toFloat()
            cardElevation = dp(1).toFloat()
            setCardBackgroundColor(Color.WHITE)
            isClickable = true
            isFocusable = true
            addView(layout)
            setOnClickListener { action() }
        }
    }

    private fun marginParams(bottom: Int = 0): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(bottom) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private inner class CircularMenuView(context: Context, private val onSelect: (Int) -> Unit) : View(context) {
        private val items = listOf(
            CircularMenuItem("تحویل گل", 1, Color.rgb(39, 137, 97)),
            CircularMenuItem("ثبت‌ها", 2, Color.rgb(47, 112, 190)),
            CircularMenuItem("گزارش‌ها", 3, Color.rgb(219, 143, 40)),
            CircularMenuItem("تنظیمات", 4, Color.rgb(147, 84, 180)),
            CircularMenuItem("فروشندگان", 5, Color.rgb(204, 77, 83)),
            CircularMenuItem("نوع گل", 6, Color.rgb(32, 150, 150))
        )
        private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = dp(12).toFloat()
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        }
        private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(34, 115, 83) }
        private val centerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = dp(16).toFloat()
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        private var rotation = -Math.PI / 2.0
        private var downAngle = 0.0
        private var downRotation = 0.0
        private var downX = 0f
        private var downY = 0f
        private var lastX = 0f
        private var lastY = 0f
        private var dragging = false
        private var moved = false
        private var lastDelta = 0.0
        private var flingAnimator: ValueAnimator? = null
        private var centerX = 0f
        private var centerY = 0f
        private var orbitRadius = 0f
        private var nodeRadius = 0f
        private var centerRadius = 0f

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            centerX = width / 2f
            centerY = height / 2f
            val available = min(width, height).toFloat()
            orbitRadius = available * 0.31f
            nodeRadius = available * 0.105f
            centerRadius = available * 0.16f
            val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(246, 248, 251) }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
            val orbitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(221, 229, 235)
                style = Paint.Style.STROKE
                strokeWidth = dp(2).toFloat()
            }
            canvas.drawCircle(centerX, centerY, orbitRadius, orbitPaint)
            items.forEachIndexed { index, item ->
                val angle = rotation + index * (Math.PI * 2.0 / items.size)
                val x = centerX + cos(angle).toFloat() * orbitRadius
                val y = centerY + sin(angle).toFloat() * orbitRadius
                circlePaint.shader = RadialGradient(
                    x - nodeRadius * 0.2f, y - nodeRadius * 0.25f, nodeRadius * 1.7f,
                    intArrayOf(lighten(item.color), item.color, darken(item.color)),
                    floatArrayOf(0f, 0.7f, 1f), Shader.TileMode.CLAMP
                )
                canvas.drawCircle(x, y, nodeRadius, circlePaint)
                circlePaint.shader = null
                canvas.drawText(item.label, x, y + dp(4).toFloat(), textPaint)
            }
            centerPaint.shader = RadialGradient(
                centerX - centerRadius * 0.25f, centerY - centerRadius * 0.3f, centerRadius * 1.5f,
                intArrayOf(Color.rgb(72, 161, 120), Color.rgb(34, 115, 83), Color.rgb(21, 83, 60)),
                null, Shader.TileMode.CLAMP
            )
            canvas.drawCircle(centerX, centerY, centerRadius, centerPaint)
            centerPaint.shader = null
            canvas.drawText("گل نگار", centerX, centerY + dp(5).toFloat(), centerTextPaint)
            val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(100, 111, 120)
                textSize = dp(13).toFloat()
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("برای چرخاندن، انگشت را روی صفحه بکشید", centerX, height - dp(28).toFloat(), hintPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    flingAnimator?.cancel()
                    dragging = true
                    moved = false
                    downX = event.x
                    downY = event.y
                    lastX = event.x
                    lastY = event.y
                    downRotation = rotation
                    downAngle = angleAt(event.x, event.y)
                    lastDelta = 0.0
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging) return true
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (sqrt((dx * dx + dy * dy).toDouble()) > dp(8)) moved = true
                    val currentAngle = angleAt(event.x, event.y)
                    var delta = currentAngle - downAngle
                    if (delta > Math.PI) delta -= Math.PI * 2.0
                    if (delta < -Math.PI) delta += Math.PI * 2.0
                    rotation = downRotation + delta
                    val previousAngle = angleAt(lastX, lastY)
                    var frameDelta = currentAngle - previousAngle
                    if (frameDelta > Math.PI) frameDelta -= Math.PI * 2.0
                    if (frameDelta < -Math.PI) frameDelta += Math.PI * 2.0
                    lastDelta = frameDelta
                    lastX = event.x
                    lastY = event.y
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val selected = findItemAt(event.x, event.y)
                        if (selected != null) onSelect(selected.id)
                        else if (distance(event.x, event.y, centerX, centerY) <= centerRadius * 1.15f) onSelect(7)
                    } else startFling(lastDelta)
                    dragging = false
                    parent?.requestDisallowInterceptTouchEvent(false)
                    performClick()
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    parent?.requestDisallowInterceptTouchEvent(false)
                    return true
                }
            }
            return true
        }

        override fun performClick(): Boolean {
            super.performClick()
            return true
        }

        private fun angleAt(x: Float, y: Float): Double = atan2((y - centerY).toDouble(), (x - centerX).toDouble())

        private fun findItemAt(x: Float, y: Float): CircularMenuItem? {
            items.forEachIndexed { index, item ->
                val angle = rotation + index * (Math.PI * 2.0 / items.size)
                val itemX = centerX + cos(angle).toFloat() * orbitRadius
                val itemY = centerY + sin(angle).toFloat() * orbitRadius
                if (distance(x, y, itemX, itemY) <= nodeRadius * 1.2f) return item
            }
            return null
        }

        private fun startFling(delta: Double) {
            if (kotlin.math.abs(delta) < 0.015) return
            val start = rotation
            val end = rotation + delta * 12.0
            flingAnimator = ValueAnimator.ofFloat(start.toFloat(), end.toFloat()).apply {
                duration = 650
                interpolator = DecelerateInterpolator(1.8f)
                addUpdateListener {
                    rotation = (it.animatedValue as Float).toDouble()
                    invalidate()
                }
                start()
            }
        }

        private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
            val dx = x1 - x2
            val dy = y1 - y2
            return sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }

        private fun lighten(color: Int): Int = Color.rgb(
            (Color.red(color) + 255) / 2,
            (Color.green(color) + 255) / 2,
            (Color.blue(color) + 255) / 2
        )

        private fun darken(color: Int): Int = Color.rgb(
            (Color.red(color) * 0.65f).toInt(),
            (Color.green(color) * 0.65f).toInt(),
            (Color.blue(color) * 0.65f).toInt()
        )
    }

    private class GolNegarDatabase(context: Context) : SQLiteOpenHelper(context, "golnegar.db", null, 3) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE records (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, title TEXT NOT NULL, details TEXT NOT NULL, amount REAL NOT NULL, date INTEGER NOT NULL, role TEXT NOT NULL DEFAULT 'greenhouse', owner_uid TEXT NOT NULL DEFAULT '')")
            db.execSQL("CREATE INDEX idx_records_role_date ON records(role, date DESC)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            if (oldVersion < 2) {
                try { db.execSQL("ALTER TABLE records ADD COLUMN role TEXT NOT NULL DEFAULT 'greenhouse'") } catch (_: Exception) { }
                db.execSQL("CREATE INDEX IF NOT EXISTS idx_records_role_date ON records(role, date DESC)")
            }
            if (oldVersion < 3) {
                try { db.execSQL("ALTER TABLE records ADD COLUMN owner_uid TEXT NOT NULL DEFAULT ''") } catch (_: Exception) { }
            }
        }

        fun readAll(): List<AppRecord> {
            val result = mutableListOf<AppRecord>()
            readableDatabase.query("records", arrayOf("type", "title", "details", "amount", "date", "role", "owner_uid"), null, null, null, null, "date DESC").use { cursor ->
                while (cursor.moveToNext()) result.add(AppRecord(
                    cursor.getString(0) ?: "", cursor.getString(1) ?: "", cursor.getString(2) ?: "",
                    cursor.getDouble(3), cursor.getLong(4), cursor.getString(5) ?: "greenhouse", cursor.getString(6) ?: ""
                ))
            }
            return result
        }

        fun replaceAll(records: List<AppRecord>) {
            val db = writableDatabase
            db.beginTransaction()
            try {
                db.delete("records", null, null)
                records.forEach { record ->
                    val values = ContentValues().apply {
                        put("type", record.type)
                        put("title", record.title)
                        put("details", record.details)
                        put("amount", record.amount)
                        put("date", record.date)
                        put("role", record.role)
                        put("owner_uid", record.ownerUid)
                    }
                    db.insertOrThrow("records", null, values)
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }
    }

}
