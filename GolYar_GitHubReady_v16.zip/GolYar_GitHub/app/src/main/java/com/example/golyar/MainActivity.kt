package com.example.golyar

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var db: GolYarDb
    private var isHomeScreen = false
    private val nf = NumberFormat.getNumberInstance(Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        db = GolYarDb(this)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!isHomeScreen) {
                    showHome()
                } else {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("خروج از گل‌یار")
                        .setMessage("آیا قصد خروج از برنامه را دارید؟")
                        .setNegativeButton("خیر", null)
                        .setPositiveButton("بله") { _, _ -> finish() }
                        .show()
                }
            }
        })
        if (db.getMode() == null) showModeChooser() else showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun base(title: String, subtitle: String? = null): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            setBackgroundColor(Color.rgb(18, 15, 23))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(dp(20), bars.top + dp(88), dp(20), bars.bottom + dp(28))
            insets
        }
        ViewCompat.requestApplyInsets(root)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(16))
        }
        header.addView(TextView(this).apply {
            text = title
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            includeFontPadding = true
        })
        if (subtitle != null) header.addView(TextView(this).apply {
            text = subtitle
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(5), 0, 0)
            includeFontPadding = true
        })
        root.addView(header)
        return root
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 17f
        isAllCaps = false
        gravity = Gravity.CENTER
        minHeight = dp(56)
        minimumHeight = dp(56)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.rgb(91, 88, 94))
        }
        stateListAnimator = null
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, dp(56))
        lp.setMargins(0, dp(5), 0, dp(5))
        layoutParams = lp
    }

    private fun setScreen(root: LinearLayout, home: Boolean = false) {
        isHomeScreen = home
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.rgb(18, 15, 23))
            clipToPadding = false
        }
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun showModeChooser() {
        val root = base("گل‌یار", "انتخاب نوع برنامه")
        root.addView(TextView(this).apply {
            text = "نسخه مورد استفاده را انتخاب کنید. این انتخاب بعداً از تنظیمات قابل تغییر است."
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(12, 12, 12, 24)
            setTextColor(Color.WHITE)
        })
        root.addView(actionButton("🏭  نسخه گلخانه",) { db.setMode("GREENHOUSE"); showHome() })
        root.addView(actionButton("👤  نسخه فروشنده") { showSellerChooser() })
        if (db.getMode() != null) {
            root.addView(actionButton("↩️  بازگشت به صفحه اصلی") { showHome() })
        }
        setScreen(root)
    }

    private fun showSellerChooser() {
        val sellers = db.sellers()
        if (sellers.isEmpty()) {
            info("برای ورود به نسخه فروشنده، ابتدا در نسخه گلخانه حداقل یک فروشنده تعریف کنید.")
            return
        }
        val names = sellers.map { "${it.name}  |  ${it.phone}" }
        val box = formBox()
        box.addView(spinner("انتخاب فروشنده", names, 60))
        AlertDialog.Builder(this).setTitle("ورود به نسخه فروشنده").setView(box)
            .setPositiveButton("ورود") { _, _ ->
                val sp = box.getChildAt(0) as Spinner
                db.setMode("SELLER:${sellers[sp.selectedItemPosition].id}")
                showHome()
            }.setNegativeButton("انصراف", null).show()
    }

    private fun showHome() {
        isHomeScreen = true
        val root = base("گل‌یار", if (db.isSellerMode()) "نسخه فروشنده" else "مدیریت گلخانه")
        val d = db.dashboard(if (db.isSellerMode()) db.currentSellerId() else null)
        val date = todayJalali()
        root.addView(summaryCard(date, d))

        if (db.isSellerMode()) {
            root.addView(actionButton("🧾  ثبت فروش جدید") { showSale() })
            root.addView(actionButton("📦  موجودی من") { showReports() })
            root.addView(actionButton("💰  حساب و پرداخت به گلخانه") { showSettlement() })
        } else {
            root.addView(actionButton("🌹  انواع گل") { showFlowers() })
            root.addView(actionButton("👤  فروشندگان") { showSellers() })
            root.addView(actionButton("📦  ثبت تحویل / فروش گلخانه") { showDelivery() })
            root.addView(actionButton("↩️  ثبت برگشت گل") { showReturn() })
            root.addView(actionButton("💰  تسویه حساب فروشندگان") { showSettlement() })
            root.addView(actionButton("📊  گزارش‌ها") { showReports() })
        }
        root.addView(actionButton("⚙️  تنظیمات") { showSettings() })
        root.addView(actionButton("🔄  تغییر نسخه / فروشنده") { showModeChooser() })
        setScreen(root, true)
    }

    private fun summaryCard(date: String, d: Dash): TextView = TextView(this).apply {
        text = if (db.isSellerMode()) { val sid=db.currentSellerId()?:0; val b=db.greenhouseBalance(sid); "امروز  |  $date\n\nفروش امروز من: ${d.soldToday} دسته\nفروش امروز من: ${money(d.salesToday)} ریال\nموجودی من: ${d.stock} دسته\n${if(b>0) "بدهی من به گلخانه: ${money(b)} ریال" else if(b<0) "طلب من از گلخانه: ${money(-b)} ریال" else "حساب گلخانه تسویه است"}" } else "امروز  |  $date\n\nتحویل / فروش گلخانه امروز: ${d.deliveredToday} دسته\nفروش گلخانه امروز: ${money(d.salesToday)} ریال\nموجودی نزد فروشندگان: ${d.stock} دسته\nمطالبات گلخانه: ${money(d.greenhouseDue)} ریال"
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(20), dp(18), dp(20), dp(18))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, dp(14))
        layoutParams = lp
    }

    private fun showFlowers() {
        val root = base("انواع گل")
        root.addView(actionButton("＋  تعریف نوع گل") { flowerDialog(null) })
        db.flowers().forEach { f ->
            root.addView(cardRow("🌹  ${f.name}\nقیمت پایه: ${money(f.basePrice)}  |  حداقل فروش: ${money(f.minPrice)}") {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                row.addView(actionButton("ویرایش") { flowerDialog(f) }, LinearLayout.LayoutParams(0, dp(56), 1f))
                row.addView(actionButton("حذف") { confirmDelete("حذف ${f.name}؟") { db.delete("flowers", f.id); showFlowers() } }, LinearLayout.LayoutParams(0, dp(56), 1f))
                it.addView(row)
            })
        }
        root.addView(actionButton("بازگشت") { showHome() })
        setScreen(root)
    }

    private fun flowerDialog(f: Flower?) {
        val box = formBox(); val name = field("نام گل", f?.name ?: ""); val base = moneyField("قیمت پایه هر دسته (ریال)", f?.basePrice?.toString() ?: ""); val min = moneyField("حداقل قیمت مجاز (ریال)", f?.minPrice?.toString() ?: "")
        box.addView(name); box.addView(base); box.addView(min)
        AlertDialog.Builder(this).setTitle(if (f == null) "تعریف گل" else "ویرایش گل").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val n=name.text.toString().trim(); val b=parseMoney(base); val m=parseMoney(min)
                if(n.isNotEmpty()) db.upsertFlower(f?.id,n,b,m); showFlowers()
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showSellers() {
        val root = base("فروشندگان", "درصد سهم هر فروشنده از مبلغ فروش قابل تنظیم است")
        root.addView(actionButton("＋  تعریف فروشنده") { sellerDialog(null) })
        db.sellers().forEach { s ->
            root.addView(cardRow("👤  ${s.name}\n${s.phone}\nسهم فروشنده از فروش خودش: ${fmtPercent(db.sellerShare(s.id))}%\nموجودی: ${db.sellerStock(s.id)} دسته\n${if(db.greenhouseBalance(s.id)>0) "بدهی به گلخانه: ${money(db.greenhouseBalance(s.id))} ریال" else if(db.greenhouseBalance(s.id)<0) "طلب از گلخانه: ${money(-db.greenhouseBalance(s.id))} ریال" else "حساب گلخانه تسویه است"}") {
                it.addView(actionButton("ویرایش") { sellerDialog(s) })
            })
        }
        root.addView(actionButton("بازگشت") { showHome() }); setScreen(root)
    }

    private fun sellerDialog(s: Seller?) {
        val box=formBox(); val name=field("نام فروشنده",s?.name?:("")); val phone=field("شماره تماس",s?.phone?:""); val share=numberField("درصد توافقی فروشنده",s?.let{db.sellerShare(it.id).toString()}?:db.getDefaultSellerShare().toString())
        box.addView(name); box.addView(phone); box.addView(share)
        AlertDialog.Builder(this).setTitle(if(s==null) "فروشنده جدید" else "ویرایش فروشنده").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val pct=share.text.toString().toDoubleOrNull(); if(name.text.isNotBlank() && pct!=null && pct in 0.0..100.0) { db.upsertSeller(s?.id,name.text.toString(),phone.text.toString(),pct); showSellers() } else info("درصد باید بین صفر تا صد باشد.")
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showDelivery() {
        val root=base("ثبت تحویل / فروش گلخانه", "تحویل گل به فروشنده به‌منزله فروش گلخانه است؛ قیمت فروش هر دسته در همین مرحله ثبت می‌شود.")
        val flowers=db.flowers(); val sellers=db.sellers(); if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا حداقل یک گل و یک فروشنده تعریف کنید.");return}
        val seller=spinner("فروشنده",sellers.map{it.name},64); val flower=spinner("نوع گل",flowers.map{it.name},64); val qty=numberField("تعداد دسته",""); val price=moneyField("قیمت فروش هر دسته (ریال)","")
        root.addView(label("فروشنده")); root.addView(seller); root.addView(label("نوع گل")); root.addView(flower); root.addView(qty); root.addView(price)
        val historyBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        fun refreshHistory(){historyBox.removeAllViews(); db.greenhouseSales(sellers[seller.selectedItemPosition].id).take(15).forEach{r->historyBox.addView(tableRow(listOf(r.date,r.flowerName,r.qty.toString(),money(r.unitPrice),money(r.total))))};if(historyBox.childCount==0)historyBox.addView(label("هنوز تحویلی ثبت نشده است."))}
        seller.setOnItemSelectedListener(simpleListener{refreshHistory()})
        root.addView(actionButton("ثبت تحویل / فروش") {
            val q=qty.text.toString().replace(",","").toIntOrNull()?:0; val p=parseMoney(price); val ss=sellers[seller.selectedItemPosition]; val f=flowers[flower.selectedItemPosition]
            if(q<=0||p<=0){info("تعداد و قیمت را صحیح وارد کنید.");return@actionButton}
            db.addDelivery(ss.id,f.id,q,p); qty.setText(""); price.setText(""); refreshHistory()
            info("تحویل / فروش گلخانه ثبت شد.\nمبلغ: ${money(q.toLong()*p)} ریال")
        })
        root.addView(label("📋 ثبت‌های اخیر این بخش")); root.addView(historyBox); refreshHistory()
        root.addView(actionButton("بازگشت"){showHome()}); setScreen(root)
    }

    private fun showSale() {
        val root=base("ثبت فروش فروشنده", "این فروش فقط فروش فروشنده به مشتری است و با فروش گلخانه/تحویل ارتباط ندارد.")
        val flowers=db.flowers(); val sellers=if(db.isSellerMode()) db.sellers().filter{it.id==db.currentSellerId()} else db.sellers()
        if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا اطلاعات پایه را وارد کنید.");return}
        val seller=spinner("فروشنده",sellers.map{it.name},64); val flower=spinner("نوع گل",flowers.map{it.name},64); val qty=numberField("تعداد دسته فروخته‌شده",""); val price=moneyField("قیمت فروش هر دسته به مشتری (ریال)","")
        val stockText=label(""); val selectedDate=Calendar.getInstance(); val dateLabel=label("تاریخ فروش: ${jalali(selectedDate)}")
        val salesBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        fun refresh(){val st=db.sellerFlowerStock(sellers[seller.selectedItemPosition].id,flowers[flower.selectedItemPosition].id);stockText.text="موجودی قابل فروش: $st دسته"}
        fun refreshSalesTable(){salesBox.removeAllViews(); val ss=sellers[seller.selectedItemPosition].id; salesBox.addView(tableHeader(listOf("تاریخ","گل","تعداد","قیمت","مبلغ"))); db.sales(ss).forEach{r->salesBox.addView(tableRow(listOf(r.date,r.flowerName,r.qty.toString(),money(r.price),money(r.qty.toLong()*r.price))))}; if(salesBox.childCount==1)salesBox.addView(label("هنوز فروشی ثبت نشده است."))}
        seller.setOnItemSelectedListener(simpleListener{refresh();refreshSalesTable()}); flower.setOnItemSelectedListener(simpleListener{refresh()}); refresh(); refreshSalesTable()
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل"));root.addView(flower);root.addView(stockText);root.addView(qty);root.addView(price);root.addView(dateLabel)
        root.addView(actionButton("📅 انتخاب تاریخ فروش"){
            val initial=Calendar.getInstance().apply{timeInMillis=selectedDate.timeInMillis}
            DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ فروش: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()
        })
        root.addView(actionButton("ثبت فروش فروشنده") {
            val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val p=parseMoney(price);val ss=sellers[seller.selectedItemPosition];val f=flowers[flower.selectedItemPosition];val stock=db.sellerFlowerStock(ss.id,f.id)
            if(q<=0||p<=0){info("تعداد و قیمت را صحیح وارد کنید.");return@actionButton};if(q>stock){info("موجودی کافی نیست. موجودی فعلی: $stock دسته");return@actionButton}
            val save={saveSale(ss.id,f.id,q,p,selectedDate.timeInMillis,qty,price,stockText){refreshSalesTable()}}
            if(p<f.minPrice){AlertDialog.Builder(this).setTitle("هشدار قیمت").setMessage("قیمت واردشده پایین‌تر از حداقل مجاز است. ثبت شود؟").setNegativeButton("لغو",null).setPositiveButton("ثبت"){_,_->save()}.show()}else save()
        })
        root.addView(label("📋 فروش‌های ثبت‌شده")); root.addView(salesBox)
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun saveSale(sellerId:Long,flowerId:Long,qty:Int,price:Long,saleDate:Long,qtyField:EditText,priceField:EditText,stockText:TextView,onSaved:(()->Unit)?=null){db.addSale(sellerId,flowerId,qty,price,saleDate);qtyField.setText("");priceField.setText("");stockText.text="موجودی قابل فروش: ${db.sellerFlowerStock(sellerId,flowerId)} دسته";onSaved?.invoke();info("فروش فروشنده ثبت شد.\nتاریخ فروش: ${jalaliDate(saleDate)}\nمبلغ: ${money(qty.toLong()*price)} ریال")}

    private fun showSalesHistory() {
        val root=base("فروش‌های ثبت‌شده من")
        val sid=db.currentSellerId()?:return
        val sales=db.sales(sid)
        if(sales.isEmpty()) root.addView(label("هنوز فروشی ثبت نشده است."))
        sales.forEach{root.addView(cardRow("${it.flowerName}  |  ${it.qty} دسته\nقیمت هر دسته: ${money(it.price)} ریال\nمبلغ کل فروش: ${money(it.qty*it.price)} ریال\nتاریخ فروش: ${it.date}\nوضعیت ارسال: ${if(it.synced) "آماده ارسال/همگام‌شده" else "در انتظار اتصال به گلخانه"}") {})}
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showReturn(){
        if(db.isSellerMode()){info("ثبت برگشت در نسخه گلخانه انجام می‌شود.");return}
        val root=base("ثبت برگشت گل","برگشت از موجودی فروشنده کم می‌شود و دلیل آن ثبت می‌گردد.");val flowers=db.flowers();val sellers=db.sellers();if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا اطلاعات پایه را وارد کنید.");return}
        val seller=spinner("فروشنده",sellers.map{it.name},64);val flower=spinner("نوع گل",flowers.map{it.name},64);val qty=numberField("تعداد دسته برگشتی","");val reason=field("علت برگشت","فروش نرفته / خراب / کیفیت / سایر")
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل"));root.addView(flower);root.addView(qty);root.addView(reason)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        fun refresh(){box.removeAllViews();box.addView(tableHeader(listOf("فروشنده","گل","تعداد","دلیل")));db.allReturns().take(20).forEach{box.addView(tableRow(listOf(it.sellerName,it.flowerName,it.qty.toString(),it.reason)))};if(box.childCount==1)box.addView(label("برگشتی ثبت نشده است."))}
        root.addView(actionButton("ثبت برگشت"){val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val ss=sellers[seller.selectedItemPosition];val f=flowers[flower.selectedItemPosition];if(q<=0||q>db.sellerFlowerStock(ss.id,f.id)){info("تعداد برگشتی بیشتر از موجودی است.");return@actionButton};db.addReturn(ss.id,f.id,q,reason.text.toString());qty.setText("");reason.setText("");refresh();info("برگشت ثبت شد.")})
        root.addView(label("📋 برگشت‌های ثبت‌شده"));root.addView(box);refresh();root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSettlement(){
        val root=base(if(db.isSellerMode()) "حساب و پرداخت به گلخانه" else "تسویه حساب فروشندگان", "در نسخه گلخانه ابتدا فروشنده را انتخاب کنید و تمام خریدهای او را ببینید.")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        if(db.isSellerMode()){
            val s=sellers.firstOrNull{it.id==db.currentSellerId()} ?: return
            addSellerAccountSection(root,s,showPaymentTable=true)
        }else{
            val sellerSpinner=spinner("انتخاب فروشنده",sellers.map{it.name},64); root.addView(label("فروشنده"));root.addView(sellerSpinner)
            val detail=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(detail)
            fun refresh(){detail.removeAllViews();addSellerAccountSection(detail,sellers[sellerSpinner.selectedItemPosition],false)}
            sellerSpinner.setOnItemSelectedListener(simpleListener{refresh()});refresh()
        }
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun addSellerAccountSection(root:LinearLayout,s:Seller,showPaymentTable:Boolean){
        val balance=db.greenhouseBalance(s.id)
        val status=if(balance>0) "بدهی به گلخانه: ${money(balance)} ریال" else if(balance<0) "طلب فروشنده از گلخانه: ${money(-balance)} ریال" else "حساب تسویه است"
        root.addView(cardText("👤 ${s.name}\n$status"))
        root.addView(label("📦 خرید/تحویل‌های ثبت‌شده از گلخانه"))
        root.addView(tableHeader(listOf("تاریخ","نوع گل","تعداد","قیمت/دسته","مبلغ")))
        val rows=db.greenhouseSales(s.id); if(rows.isEmpty())root.addView(label("خریدی ثبت نشده است.")) else rows.forEach{r->root.addView(tableRow(listOf(r.date,r.flowerName,r.qty.toString(),money(r.unitPrice),money(r.total))))}
        root.addView(cardText("جمع خرید گلخانه: ${money(db.greenhouseCharges(s.id))} ریال\nبرگشت قابل کسر: ${money(db.returnCredits(s.id))} ریال\nپرداخت به گلخانه: ${money(db.paidToGreenhouse(s.id))} ریال\n$status"))
        root.addView(actionButton("💳 ثبت پرداخت به گلخانه"){paymentDialog(s)})
        root.addView(label("📋 پرداخت‌های ثبت‌شده"));root.addView(tableHeader(listOf("تاریخ","مبلغ"))); val ps=db.payments(s.id);if(ps.isEmpty())root.addView(label("پرداختی ثبت نشده است.")) else ps.forEach{p->root.addView(tableRow(listOf(p.date,money(p.amount))))}
    }

    private fun showPaymentHistory(s:Seller){
        val root=base("تاریخچه پرداخت ${s.name}")
        val payments=db.payments(s.id)
        if(payments.isEmpty()) root.addView(label("پرداختی ثبت نشده است."))
        payments.forEachIndexed{index,p->root.addView(cardText("پرداخت ${payments.size-index}\nمبلغ: ${money(p.amount)} ریال\nتاریخ پرداخت: ${p.date}"))}
        root.addView(actionButton("بازگشت"){showSettlement()});setScreen(root)
    }

    private fun paymentDialog(s:Seller){
        val balance=db.greenhouseBalance(s.id); val box=formBox(); val amount=moneyField("مبلغ پرداختی (ریال)",if(balance>0)money(balance) else "")
        val selectedDate=Calendar.getInstance(); val dateLabel=label("تاریخ پرداخت: ${jalali(selectedDate)}")
        box.addView(amount);box.addView(dateLabel)
        box.addView(actionButton("📅 انتخاب تاریخ پرداخت"){val initial=Calendar.getInstance().apply{timeInMillis=selectedDate.timeInMillis};DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ پرداخت: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()})
        val msg=if(balance>0) "مانده بدهی به گلخانه: ${money(balance)} ریال" else if(balance<0) "طلب فروشنده از گلخانه: ${money(-balance)} ریال" else "حساب تسویه است"
        AlertDialog.Builder(this).setTitle("پرداخت ${s.name} به گلخانه").setMessage(msg).setView(box).setPositiveButton("ثبت پرداخت"){_,_->
            val a=parseMoney(amount)
            if(a<=0) info("مبلغ پرداختی باید بیشتر از صفر باشد.") else {db.addPayment(s.id,a,selectedDate.timeInMillis);info("پرداخت ثبت شد.\nتاریخ: ${jalali(selectedDate)}"){showSettlement()}}
        }.setNegativeButton("انصراف",null).show()
    }

    private fun showReports(){
        if(db.isSellerMode()){showSellerInventoryReport();return}
        val root=base("گزارش‌های گلخانه","گزارش‌ها از بخش ثبت‌ها جدا شده و همه در این قسمت قرار دارند.")
        root.addView(actionButton("👤 گزارش فروشندگان") { showGreenhouseSellerSalesReport() })
        root.addView(actionButton("🌹 گزارش فروش گلخانه") { showGreenhouseDeliveryReport() })
        root.addView(actionButton("💰 گزارش مالی و بدهی فروشندگان") { showFinancialReport() })
        root.addView(actionButton("📦 گزارش موجودی نزد فروشندگان") { showGreenhouseInventoryReport() })
        root.addView(actionButton("📋 گزارش برگشت گل") { showReturnReport() })
        root.addView(actionButton("💳 گزارش پرداخت‌ها") { showAllPaymentsHistory() })
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSellerInventoryReport(){
        val root=base("موجودی من","فقط گل‌های موجود نزد من، قیمت و مشخصات آن‌ها")
        val sid=db.currentSellerId()?:return
        root.addView(tableHeader(listOf("نام گل","موجودی","قیمت پایه","حداقل قیمت")))
        var count=0;db.flowers().forEach{f->val stock=db.sellerFlowerStock(sid,f.id);if(stock>0){count++;root.addView(tableRow(listOf(f.name,stock.toString(),money(f.basePrice),money(f.minPrice))))}}
        if(count==0)root.addView(label("در حال حاضر گل موجودی ندارید."))
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showGreenhouseDeliveryReport(){
        val root=base("گزارش فروش گلخانه","تحویل گل به فروشنده = فروش گلخانه؛ شامل تاریخ، نوع، تعداد و قیمت")
        db.sellers().forEach{s->root.addView(label("👤 ${s.name}"));root.addView(tableHeader(listOf("تاریخ","گل","تعداد","قیمت","مبلغ")));val rows=db.greenhouseSales(s.id);if(rows.isEmpty())root.addView(label("رکوردی ندارد.")) else rows.forEach{r->root.addView(tableRow(listOf(r.date,r.flowerName,r.qty.toString(),money(r.unitPrice),money(r.total))))}}
        root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showFinancialReport(){
        val root=base("گزارش مالی","بدهی، طلب، خرید گلخانه و پرداخت هر فروشنده")
        root.addView(tableHeader(listOf("فروشنده","خرید","پرداخت","مانده")))
        db.sellers().forEach{s->val b=db.greenhouseBalance(s.id);root.addView(tableRow(listOf(s.name,money(db.greenhouseCharges(s.id)),money(db.paidToGreenhouse(s.id)),if(b>0)"بدهکار ${money(b)}" else if(b<0)"طلبکار ${money(-b)}" else "تسویه")))}
        root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showGreenhouseInventoryReport(){
        val root=base("موجودی نزد فروشندگان","موجودی بر اساس تحویل منهای فروش و برگشت")
        root.addView(tableHeader(listOf("فروشنده","گل","موجودی")))
        var count=0;db.sellers().forEach{s->db.flowers().forEach{f->val st=db.sellerFlowerStock(s.id,f.id);if(st>0){count++;root.addView(tableRow(listOf(s.name,f.name,st.toString())))}}}
        if(count==0)root.addView(label("موجودی نزد فروشندگان ثبت نشده است."));root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showReturnReport(){
        val root=base("گزارش برگشت گل","فهرست برگشت‌های ثبت‌شده از فروشندگان")
        root.addView(tableHeader(listOf("فروشنده","گل","تعداد","دلیل")))
        val rows=db.allReturns();if(rows.isEmpty())root.addView(label("برگشتی ثبت نشده است.")) else rows.forEach{root.addView(tableRow(listOf(it.sellerName,it.flowerName,it.qty.toString(),it.reason)))}
        root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showGreenhouseSellerSalesReport(){
        val root=base("گزارش کامل فروش فروشندگان","هر فروش ثبت‌شده توسط فروشنده با نام فروشنده، نام گل، تعداد، قیمت و تاریخ")
        val rows=db.allSellerSalesReport()
        if(rows.isEmpty()){
            root.addView(label("هنوز هیچ فروش مشتری توسط فروشندگان ثبت نشده است."))
        }else{
            var lastSeller=""
            rows.forEach{r->
                if(r.sellerName!=lastSeller){
                    root.addView(cardText("👤 ${r.sellerName}"))
                    lastSeller=r.sellerName
                }
                root.addView(cardText("🌹 ${r.flowerName}\nتعداد: ${r.qty} دسته\nقیمت فروش هر دسته: ${money(r.unitPrice)} ریال\nمبلغ کل: ${money(r.total)} ریال\nتاریخ فروش: ${r.date}"))
            }
        }
        root.addView(actionButton("بازگشت"){showReports()})
        setScreen(root)
    }

    private fun showAllPaymentsHistory(){
        val root=base("تاریخچه همه پرداخت‌ها", "پرداخت‌ها بر اساس تاریخ پرداخت مرتب شده‌اند")
        val rows=db.allPayments()
        if(rows.isEmpty()) root.addView(label("هنوز هیچ پرداختی ثبت نشده است."))
        var lastSeller=""; rows.forEachIndexed{index,p->{if(p.sellerName!=lastSeller){root.addView(label("👤 ${p.sellerName}"));lastSeller=p.sellerName};root.addView(cardText("پرداخت ${index+1}\nمبلغ: ${money(p.amount)} ریال\nتاریخ پرداخت: ${p.date}"))}}
        root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showSettings(){
        val root=base("تنظیمات")
        if(!db.isSellerMode()){
            val def=numberField("درصد پیش‌فرض سهم فروشنده",db.getDefaultSellerShare().toString());root.addView(def);root.addView(actionButton("ذخیره درصد پیش‌فرض"){val v=def.text.toString().toDoubleOrNull();if(v!=null&&v in 0.0..100.0){db.setDefaultSellerShare(v);info("درصد پیش‌فرض ذخیره شد.")}else info("درصد باید بین صفر تا صد باشد.")})
        }
        root.addView(actionButton("🔄 تغییر نوع نسخه / فروشنده"){db.setMode(null);showModeChooser()})
        root.addView(label("تاریخ امروز: ${todayJalali()}"))
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun tableHeader(cells:List<String>):LinearLayout=tableRow(cells,true)
    private fun tableRow(cells:List<String>,header:Boolean=false):LinearLayout{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(4),dp(2),dp(4),dp(2));background=GradientDrawable().apply{cornerRadius=dp(8).toFloat();setColor(if(header) Color.rgb(63,58,70) else Color.rgb(31,29,37));setStroke(dp(1),Color.rgb(65,60,72))};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).also{it.setMargins(0,dp(1),0,dp(1))}}
        cells.forEach{value->row.addView(TextView(this).apply{text=value;textSize=if(header)14f else 13.5f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setTypeface(Typeface.DEFAULT,if(header)Typeface.BOLD else Typeface.NORMAL);setPadding(dp(4),0,dp(4),0);layoutParams=LinearLayout.LayoutParams(0,-1,1f)})};return row}
    private fun cardBackground()=
GradientDrawable().apply{cornerRadius=dp(18).toFloat();setColor(Color.rgb(35,32,42));setStroke(dp(1),Color.rgb(70,64,78))}
    private fun cardText(text:String):TextView=TextView(this).apply{textSize=16f;setTextColor(Color.WHITE);setPadding(dp(18),dp(16),dp(18),dp(16));gravity=Gravity.CENTER_VERTICAL;includeFontPadding=true;background=cardBackground();val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(9));layoutParams=lp}
    private fun cardRow(text:String, build:(LinearLayout)->Unit):LinearLayout{val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(12),dp(10),dp(12),dp(10));background=cardBackground();val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(9));layoutParams=lp};box.addView(TextView(this).apply{this.text=text;textSize=16f;setTextColor(Color.WHITE);gravity=Gravity.CENTER_VERTICAL;includeFontPadding=true;setPadding(dp(8),dp(8),dp(8),dp(12))});build(box);return box}
    private fun label(t:String)=TextView(this).apply{text=t;textSize=15f;setTextColor(Color.LTGRAY);setPadding(dp(6),dp(10),dp(6),dp(5));includeFontPadding=true}
    private fun formBox()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(12),dp(4));layoutDirection=View.LAYOUT_DIRECTION_RTL}
    private fun field(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;inputType=InputType.TYPE_CLASS_TEXT;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8))}
    private fun numberField(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8))}
    private fun moneyField(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(if(value.isBlank()) "" else value.replace(",",""));textSize=17f;inputType=InputType.TYPE_CLASS_NUMBER;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8));addTextChangedListener(object:TextWatcher{private var busy=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(e:Editable?){if(busy)return;val raw=e?.toString()?.replace(",","")?.filter{it.isDigit()}?:"";if(raw.isEmpty())return;val n=raw.toLongOrNull()?:return;val formatted=nf.format(n);if(e.toString()!=formatted){busy=true;setText(formatted);setSelection(formatted.length);busy=false}}})}
    private fun parseMoney(e:EditText):Long=e.text.toString().replace(",","").filter{it.isDigit()}.toLongOrNull()?:0L
    private fun jalaliDate(ms:Long):String{val c=Calendar.getInstance();c.timeInMillis=ms;return jalali(c)}
    private fun spinner(label:String,items:List<String>,height:Int)=Spinner(this).apply{adapter=object:ArrayAdapter<String>(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items){override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{val v=super.getView(position,convertView,parent) as TextView;v.textSize=17f;v.setTextColor(Color.WHITE);v.gravity=Gravity.CENTER_VERTICAL or Gravity.RIGHT;v.setPadding(dp(12),0,dp(12),0);return v}};contentDescription=label;layoutDirection=View.LAYOUT_DIRECTION_RTL;minimumHeight=dp(height)}
    private fun divider()=Space(this).apply{minimumHeight=dp(8)}
    private fun simpleListener(fn:()->Unit)=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){fn()}}
    private fun money(v:Long)=nf.format(v)
    private fun fmtPercent(v:Double)=String.format(Locale.US,"%.1f",v).trimEnd('0').trimEnd('.')
    private fun confirmDelete(msg:String,action:()->Unit){AlertDialog.Builder(this).setMessage(msg).setNegativeButton("انصراف",null).setPositiveButton("حذف"){_,_->action()}.show()}
    private fun info(msg:String,after:(()->Unit)?=null){AlertDialog.Builder(this).setMessage(msg).setPositiveButton("باشه"){_,_->after?.invoke()}.show()}

    data class Flower(val id:Long,val name:String,val basePrice:Long,val minPrice:Long)
    data class Seller(val id:Long,val name:String,val phone:String)
    data class SaleRow(val flowerName:String,val qty:Int,val price:Long,val date:String,val synced:Boolean)
    data class PaymentRow(val amount:Long,val date:String)
    data class PaymentHistoryRow(val sellerName:String,val amount:Long,val date:String)
    data class GreenhouseSaleRow(val flowerName:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
    data class SellerSaleReportRow(val sellerName:String,val flowerName:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
    data class ReturnReportRow(val sellerName:String,val flowerName:String,val qty:Int,val reason:String)
    data class Dash(val deliveredToday:Int,val soldToday:Int,val returnedToday:Int,val salesToday:Long,val stock:Int,val greenhouseDue:Long)

    private fun todayJalali():String = jalali(Calendar.getInstance())
    private fun jalali(c:Calendar):String {
        val gy=c.get(Calendar.YEAR); val gm=c.get(Calendar.MONTH)+1; val gd=c.get(Calendar.DAY_OF_MONTH)
        val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31)
        var days=355666 + 365*gy + ((gy+3)/4) - ((gy+99)/100) + ((gy+399)/400) + gd
        for(i in 1 until gm) days += gdm[i]
        if(gm>2 && isLeapGregorian(gy)) days++
        var jy=-1595 + 33*(days/12053); days%=12053
        jy += 4*(days/1461); days%=1461
        if(days>365){jy += (days-1)/365; days=(days-1)%365}
        val jm=if(days<186) 1 + days/31 else 7 + (days-186)/30
        val jd=1 + if(days<186) days%31 else (days-186)%30
        return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
    }
    private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)

    class GolYarDb(ctx:Context):SQLiteOpenHelper(ctx,"golyar.db",null,4){
        private val appContext = ctx.applicationContext
        override fun onCreate(db:SQLiteDatabase){
            db.execSQL("CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,base_price INTEGER NOT NULL,min_price INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,share REAL NOT NULL DEFAULT 20)")
            db.execSQL("CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER NOT NULL DEFAULT 0,created_at INTEGER)")
            db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,created_at INTEGER,sync_state TEXT DEFAULT 'PENDING')")
            db.execSQL("CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,reason TEXT,created_at INTEGER)")
            db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,created_at INTEGER,payment_date INTEGER)")
            db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT)")
            db.execSQL("INSERT INTO settings(key,value) VALUES('default_seller_share','20')")
        }
        override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){
            if(oldVersion<2){db.execSQL("ALTER TABLE sellers ADD COLUMN share REAL NOT NULL DEFAULT 20");db.execSQL("ALTER TABLE sales ADD COLUMN sync_state TEXT DEFAULT 'PENDING'");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('default_seller_share','20')")}
            if(oldVersion<3){db.execSQL("ALTER TABLE payments ADD COLUMN payment_date INTEGER");db.execSQL("UPDATE payments SET payment_date=created_at WHERE payment_date IS NULL")}
            if(oldVersion<4){db.execSQL("ALTER TABLE deliveries ADD COLUMN price INTEGER NOT NULL DEFAULT 0");db.execSQL("UPDATE deliveries SET price=COALESCE((SELECT base_price FROM flowers WHERE flowers.id=deliveries.flower_id),0) WHERE price=0")}
        }
        private fun cv(vararg p:Pair<String,Any?>)=ContentValues().also{p.forEach{(k,v)->when(v){is String->it.put(k,v);is Int->it.put(k,v);is Long->it.put(k,v);is Double->it.put(k,v);null->it.putNull(k)}}}
        fun setMode(v:String?){val sp=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE);sp.edit().putString("mode",v).apply()}
        fun getMode():String?=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE).getString("mode",null)
        fun isSellerMode()=getMode()?.startsWith("SELLER:")==true
        fun currentSellerId():Long?=getMode()?.substringAfter("SELLER:")?.toLongOrNull()
        fun upsertFlower(id:Long?,name:String,base:Long,min:Long){val v=cv("name" to name,"base_price" to base,"min_price" to min);if(id==null)writableDatabase.insert("flowers",null,v)else writableDatabase.update("flowers",v,"id=?",arrayOf(id.toString()))}
        fun upsertSeller(id:Long?,name:String,phone:String,share:Double){val v=cv("name" to name,"phone" to phone,"share" to share);if(id==null)writableDatabase.insert("sellers",null,v)else writableDatabase.update("sellers",v,"id=?",arrayOf(id.toString()))}
        fun flowers():List<Flower>{val l=mutableListOf<Flower>();q("SELECT * FROM flowers ORDER BY name"){c->l.add(Flower(c.getLong(0),c.getString(1),c.getLong(2),c.getLong(3)))};return l}
        fun sellers():List<Seller>{val l=mutableListOf<Seller>();q("SELECT * FROM sellers ORDER BY name"){c->l.add(Seller(c.getLong(0),c.getString(1),c.getString(2)?:("")))};return l}
        private fun q(sql:String,block:(android.database.Cursor)->Unit){readableDatabase.rawQuery(sql,null).use{while(it.moveToNext())block(it)}}
        fun delete(table:String,id:Long){writableDatabase.delete(table,"id=?",arrayOf(id.toString()))}
        fun addDelivery(s:Long,f:Long,q:Int,p:Long){writableDatabase.insert("deliveries",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to System.currentTimeMillis()))}
        fun addSale(s:Long,f:Long,q:Int,p:Long,saleDate:Long){writableDatabase.insert("sales",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to saleDate,"sync_state" to "PENDING"))}
        fun addReturn(s:Long,f:Long,q:Int,r:String){writableDatabase.insert("returns",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"reason" to r,"created_at" to System.currentTimeMillis()))}
        fun addPayment(s:Long,a:Long,paymentDate:Long){writableDatabase.insert("payments",null,cv("seller_id" to s,"amount" to a,"created_at" to System.currentTimeMillis(),"payment_date" to paymentDate))}
        fun sellerFlowerStock(s:Long,f:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=? AND flower_id=?),0)",arrayOf(s,f,s,f,s,f)).toInt()
        fun sellerStock(s:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=?),0)",arrayOf(s,s,s)).toInt()
        fun sellerShare(s:Long):Double=readableDatabase.rawQuery("SELECT share FROM sellers WHERE id=?",arrayOf(s.toString())).use{if(it.moveToFirst())it.getDouble(0) else getDefaultSellerShare()}
        fun getDefaultSellerShare():Double=setting("default_seller_share",20.0)
        fun setDefaultSellerShare(v:Double){writableDatabase.update("settings",cv("value" to v.toString()),"key='default_seller_share'",null)}
        fun sellerSalesTotal(s:Long):Long=one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE seller_id=?",arrayOf(s))
        fun sellerCommission(s:Long):Long=(sellerSalesTotal(s)*sellerShare(s)/100.0).toLong()
        fun paidToGreenhouse(s:Long):Long=one("SELECT COALESCE(SUM(amount),0) FROM payments WHERE seller_id=?",arrayOf(s))
        fun greenhouseCharges(s:Long):Long=one("SELECT COALESCE(SUM(qty*price),0) FROM deliveries WHERE seller_id=?",arrayOf(s))
        fun returnCredits(s:Long):Long{var total=0L;readableDatabase.rawQuery("SELECT r.flower_id,r.qty FROM returns r WHERE r.seller_id=?",arrayOf(s.toString())).use{c->while(c.moveToNext()){val f=c.getLong(0);val q=c.getInt(1);val avg=one("SELECT CASE WHEN COALESCE(SUM(qty),0)=0 THEN 0 ELSE CAST(SUM(qty*price) AS INTEGER)/SUM(qty) END FROM deliveries WHERE seller_id=? AND flower_id=?",arrayOf(s,f));total+=q*avg}};return total}
        fun greenhouseBalance(s:Long):Long=greenhouseCharges(s)-returnCredits(s)-paidToGreenhouse(s)
        fun greenhouseDue(s:Long):Long=greenhouseBalance(s)
        fun payments(s:Long):List<PaymentRow>{val l=mutableListOf<PaymentRow>();readableDatabase.rawQuery("SELECT amount,COALESCE(payment_date,created_at) FROM payments WHERE seller_id=? ORDER BY COALESCE(payment_date,created_at) DESC,id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(PaymentRow(c.getLong(0),jalaliDate(c.getLong(1))))};return l}
        fun allPayments():List<PaymentHistoryRow>{val l=mutableListOf<PaymentHistoryRow>();readableDatabase.rawQuery("SELECT s.name,p.amount,COALESCE(p.payment_date,p.created_at) FROM payments p JOIN sellers s ON s.id=p.seller_id ORDER BY s.name,COALESCE(p.payment_date,p.created_at) DESC,p.id DESC",null).use{c->while(c.moveToNext())l.add(PaymentHistoryRow(c.getString(0),c.getLong(1),jalaliDate(c.getLong(2))))};return l}
        fun dashboard(sellerId:Long?):Dash{val condition=sellerId?.let { " AND seller_id=$it" } ?: "";val todayStart=dayStart();val todayEnd=todayStart+86400000;val deliveredToday=one("SELECT COALESCE(SUM(qty),0) FROM deliveries WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val soldToday=one("SELECT COALESCE(SUM(qty),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val returnedToday=one("SELECT COALESCE(SUM(qty),0) FROM returns WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val salesToday=if(sellerId!=null)one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)) else one("SELECT COALESCE(SUM(qty*price),0) FROM deliveries WHERE created_at>=? AND created_at<?",arrayOf(todayStart,todayEnd));val stock=if(sellerId!=null)sellerStock(sellerId) else one("SELECT COALESCE(SUM(qty),0) FROM deliveries").toInt()-one("SELECT COALESCE(SUM(qty),0) FROM returns").toInt();val due=if(sellerId!=null)greenhouseBalance(sellerId) else sellers().sumOf{greenhouseBalance(it.id)};return Dash(deliveredToday,soldToday,returnedToday,salesToday,stock,due)}
        fun greenhouseSales(s:Long):List<GreenhouseSaleRow>{val l=mutableListOf<GreenhouseSaleRow>();readableDatabase.rawQuery("SELECT f.name,d.qty,d.price,d.qty*d.price,d.created_at FROM deliveries d JOIN flowers f ON f.id=d.flower_id WHERE d.seller_id=? ORDER BY d.created_at DESC,d.id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(GreenhouseSaleRow(c.getString(0),c.getInt(1),c.getLong(2),c.getLong(3),jalaliDate(c.getLong(4))))};return l}
        fun allReturns():List<ReturnReportRow>{val l=mutableListOf<ReturnReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,r.qty,r.reason FROM returns r JOIN sellers s ON s.id=r.seller_id JOIN flowers f ON f.id=r.flower_id ORDER BY r.created_at DESC,r.id DESC",null).use{c->while(c.moveToNext())l.add(ReturnReportRow(c.getString(0),c.getString(1),c.getInt(2),c.getString(3)?:("")))};return l}
        fun allSellerSalesReport():List<SellerSaleReportRow>{val l=mutableListOf<SellerSaleReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,sa.qty,sa.price,sa.qty*sa.price,sa.created_at FROM sales sa JOIN sellers s ON s.id=sa.seller_id JOIN flowers f ON f.id=sa.flower_id ORDER BY s.name,sa.created_at DESC,sa.id DESC",null).use{c->while(c.moveToNext())l.add(SellerSaleReportRow(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),c.getLong(4),jalaliDate(c.getLong(5))))};return l}
        fun sales(s:Long):List<SaleRow>{val l=mutableListOf<SaleRow>();readableDatabase.rawQuery("SELECT f.name,s.qty,s.price,s.created_at,s.sync_state FROM sales s JOIN flowers f ON f.id=s.flower_id WHERE s.seller_id=? ORDER BY s.created_at DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(SaleRow(c.getString(0),c.getInt(1),c.getLong(2),jalaliDate(c.getLong(3)),c.getString(4)!="PENDING"))};return l}
        fun flowerDelivered(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM deliveries WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun flowerSold(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM sales WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun flowerReturned(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM returns WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        private fun setting(k:String,d:Double):Double=readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0).toDoubleOrNull()?:d else d}
        private fun one(sql:String,args:Array<Any?> = emptyArray()):Long{val a=args.map{it.toString()}.toTypedArray();readableDatabase.rawQuery(sql,a).use{it.moveToFirst();return it.getLong(0)}}
        private fun dayStart():Long{val c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.timeInMillis}
        private fun jalaliDate(ms:Long):String{val c=Calendar.getInstance();c.timeInMillis=ms;val gy=c.get(Calendar.YEAR);val gm=c.get(Calendar.MONTH)+1;val gd=c.get(Calendar.DAY_OF_MONTH);val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31);var days=355666+365*gy+((gy+3)/4)-((gy+99)/100)+((gy+399)/400)+gd;for(i in 1 until gm)days+=gdm[i];if(gm>2&&isLeapGregorian(gy))days++;var jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365};val jm=if(days<186)1+days/31 else 7+(days-186)/30;val jd=1+if(days<186)days%31 else(days-186)%30;return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)}
        private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)
    }
}
