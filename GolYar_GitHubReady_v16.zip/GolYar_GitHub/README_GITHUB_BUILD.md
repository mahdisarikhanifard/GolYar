# گل‌یار — آماده Build با GitHub Actions

این نسخه برای ساخت APK با GitHub Actions آماده شده است.

## ساخت APK با گوشی
1. در GitHub یک Repository بسازید.
2. فایل‌های این پوشه را داخل Repository قرار دهید.
3. بعد از Push به شاخه `main`، بخش **Actions** را باز کنید.
4. Workflow با نام **Build GolYar APK** اجرا می‌شود.
5. پس از اتمام موفق، در صفحه اجرای Workflow بخش **Artifacts** فایل `GolYar-debug-apk` را دریافت کنید.
6. فایل داخل آن `app-debug.apk` است و برای نصب روی گوشی قابل استفاده است.

این Workflow از JDK 17 و Gradle 8.11.1 استفاده می‌کند و به Android Studio یا AndroidIDE روی گوشی نیاز ندارد.

## نکته
اتصال Firebase در این مرحله انجام نشده است. بعد از اینکه APK اولیه روی گوشی تست شد، Firebase Auth/Firestore/FCM را به پروژه اضافه می‌کنیم.
