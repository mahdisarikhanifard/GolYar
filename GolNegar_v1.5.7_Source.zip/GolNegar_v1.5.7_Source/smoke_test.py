import sqlite3, hashlib, re

con=sqlite3.connect(':memory:')
c=con.cursor()
c.executescript('''
CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,username TEXT,share REAL,remote_id TEXT UNIQUE);
CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,size TEXT,base_price INTEGER,min_price INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,seller_share_amount INTEGER,greenhouse_amount INTEGER,min_price_snapshot INTEGER,below_minimum INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,remote_id TEXT UNIQUE);
''')
# Source device: seller local id 1, flower local id 1.
c.execute("INSERT INTO sellers(name,username,share,remote_id) VALUES('علی','ali',20,'seller-A')")
c.execute("INSERT INTO flowers(name,size,base_price,min_price,remote_id) VALUES('رز','50',100000,90000,'flower-R50')")
c.execute("INSERT INTO deliveries VALUES(NULL,1,1,100,100000,'delivery-A')")
# 10 sold at 95k: seller gets 20%, greenhouse gets 80%, below minimum.
total=10*95000; seller_share=total*20//100; greenhouse=total-seller_share
c.execute("INSERT INTO sales VALUES(NULL,1,1,10,95000,?,?,?,?,?)",(seller_share,greenhouse,90000,1,'sale-A'))
c.execute("INSERT INTO returns VALUES(NULL,1,1,5,'return-A')")
c.execute("INSERT INTO payments VALUES(NULL,1,500000,'payment-A')")

# Settlement invariants.
stock=c.execute('SELECT SUM(qty) FROM deliveries WHERE seller_id=1').fetchone()[0]-c.execute('SELECT SUM(qty) FROM sales WHERE seller_id=1').fetchone()[0]-c.execute('SELECT SUM(qty) FROM returns WHERE seller_id=1').fetchone()[0]
sales_total=c.execute('SELECT SUM(qty*price) FROM sales WHERE seller_id=1').fetchone()[0]
commission=c.execute('SELECT SUM(seller_share_amount) FROM sales WHERE seller_id=1').fetchone()[0]
greenhouse_due=c.execute('SELECT SUM(greenhouse_amount) FROM sales WHERE seller_id=1').fetchone()[0]
paid=c.execute('SELECT SUM(amount) FROM payments WHERE seller_id=1').fetchone()[0]
balance=greenhouse_due-paid
assert stock==85, stock
assert sales_total==950000
assert commission==190000
assert greenhouse_due==760000
assert paid==500000
assert balance==260000
assert c.execute('SELECT COUNT(*) FROM sales WHERE below_minimum=1').fetchone()[0]==1

# Simulate a second device with different local IDs; map by stable remote IDs.
c.execute("INSERT INTO sellers(name,username,share,remote_id) VALUES('سارا','sara',30,'seller-B')")
c.execute("INSERT INTO flowers(name,size,base_price,min_price,remote_id) VALUES('رز','40',80000,70000,'flower-R40')")
# Remote record from source must resolve seller-A/flower-R50, not numeric ids.
seller_local=c.execute("SELECT id FROM sellers WHERE remote_id='seller-A'").fetchone()[0]
flower_local=c.execute("SELECT id FROM flowers WHERE remote_id='flower-R50'").fetchone()[0]
assert seller_local==1 and flower_local==1

# Ensure no plaintext Firebase password is present in source package.
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=(ROOT/'app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'Ham' not in source
assert 'admin_firebase_password' in source
assert 'AES/GCM/NoPadding' in source

print('PASS: settlement arithmetic')
print('PASS: stock arithmetic')
print('PASS: below-minimum detection')
print('PASS: stable seller/flower remote-ID mapping')
print('PASS: Firebase password is not hard-coded in source')


# v1.3.2 static integration checks
from pathlib import Path
source = Path("app/src/main/java/com/example/golyar/MainActivity.kt").read_text(encoding="utf-8")
gradle = Path("app/build.gradle.kts").read_text(encoding="utf-8")
assert 'versionName = "1.5.7"' in gradle
assert 'versionCode = 87' in gradle
assert 'whereEqualTo("seller_remote_id", sellerRemoteId)' in source
assert 'auth_uid-only query for payments' in source
assert 'queries[index].get()' in source, "seller pull must execute Firestore queries"
assert 'whereEqualTo("auth_uid", firebaseAuth.currentUser?.uid.orEmpty())' not in source, "seller payments must not use a rules-incompatible auth_uid-only query"
assert 'fun goBack()' in source
assert 'db.delete("flowers", f.id); showFlowers(); syncWithFirebaseIfOnline(false)' in source
assert 'private fun detachFromParent(view: View)' in source
assert 'detachFromParent(root)' in source
assert 'showFinancialReport' in source
assert '🧾 فروش متفرقه گلخانه' in source
assert '💰 هزینه‌های گلخانه' in source
assert 'val sellerSharePercent=db.sellerShare(s.id)' in source
assert 'val shareTotal=saleRows.sumOf{(it.total*sellerSharePercent/100.0).toLong()}' in source
assert 'sellerShareAmount' not in source[source.index('private fun showFinancialReport()'):source.index('private fun showGreenhouseInventoryReport()')]
assert 'private fun renderGreenhouseExpensesPage(title: String, subtitle: String)' in source
assert 'private fun showMiscSalesReport()' in source
assert 'private fun showGreenhouseExpensesReport()' in source
assert 'sameLogicalScreen' in source
assert 'page.post { androidx.core.view.ViewCompat.requestApplyInsets(page) }' in source
assert 'private fun showHome() {\n        screenBackStack.clear()' in source
assert 'FirebaseFirestore.getInstance(secondaryApp).collection("users").document(uid).set(data)' not in source
assert 'fs.collection("users").document(uid).set(data)' in source
assert 'لیست‌ها و گزارش‌های عملیاتی' in source
assert 'گزارش مالی جامع' in source
print("PASS: v1.3.9 navigation/sync/delete/account/report integration checks")

# v1.3.3 report coverage: miscellaneous sales and greenhouse expenses must be
# independently readable and must not depend on seller records.
c.executescript('''
CREATE TABLE misc_sales(id INTEGER PRIMARY KEY AUTOINCREMENT,buyer_name TEXT,flower_id INTEGER,qty INTEGER,price INTEGER,payment_type TEXT);
CREATE TABLE greenhouse_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,recipient TEXT,amount INTEGER,expense_type TEXT,description TEXT);
''')
c.execute("INSERT INTO misc_sales(buyer_name,flower_id,qty,price,payment_type) VALUES('مشتری مستقیم',1,3,120000,'نقدی')")
c.execute("INSERT INTO misc_sales(buyer_name,flower_id,qty,price,payment_type) VALUES('مشتری دوم',1,2,150000,'کارتخوان')")
c.execute("INSERT INTO greenhouse_payments(recipient,amount,expense_type,description) VALUES('برق','180000','آب و برق','قبض')")
c.execute("INSERT INTO greenhouse_payments(recipient,amount,expense_type,description) VALUES('تعمیرات','70000','تعمیرات','تعمیر پمپ')")
misc_total=c.execute('SELECT COALESCE(SUM(qty*price),0) FROM misc_sales').fetchone()[0]
misc_qty=c.execute('SELECT COALESCE(SUM(qty),0) FROM misc_sales').fetchone()[0]
expense_total=c.execute('SELECT COALESCE(SUM(amount),0) FROM greenhouse_payments').fetchone()[0]
assert misc_total==660000 and misc_qty==5
assert expense_total==250000
assert misc_total-expense_total==410000
print('PASS: miscellaneous sales report arithmetic')
print('PASS: greenhouse expense report arithmetic')
print('PASS: v1.3.9 reports include misc sales and greenhouse expenses')

# v1.4.5 regression checks for requested UX and payment fixes
assert 'private fun addCircularRoleSelector(root: LinearLayout)' not in source
assert 'private fun addCircularShortcutWheel(root: LinearLayout, shortcuts: List<HomeShortcut>)' in source
assert 'root.addView(sectionTitle("منوی چرخشی"))' not in source
assert 'text = subtitle' in source
assert 'رمز عبور: ${db.sellerPassword(s.id)' in source
assert 'private fun editGreenhouseUserDialog(' in source
assert 'private fun forceBlackText(view: View)' in source
assert 'Color.BLACK' in source
assert 'val currentPassword = passwordField("رمز فعلی ورود این کاربر", savedOldPassword)' in source
assert 'val newPassword = (password.tag as EditText).text.toString()' in source
assert '"name" to display' in source
assert 'private fun showPaymentHistoryImpl(s:Seller, notice:String? = null)' in source
assert 'مجموع پرداخت‌ها' in source
assert '↻ دریافت دوبارهٔ پرداخت‌ها' in source
assert 'whereEqualTo("seller_remote_id", remoteId)' in source
assert 'if (!firebaseAuth.currentUser?.email.equals(db.adminFirebaseEmail(), ignoreCase = true)) firebaseAuth.signOut()' in source
header_block = source[source.index('private fun base('):source.index('private fun actionButton(')]
assert header_block.index('text = \"نسخه ${BuildConfig.VERSION_NAME}\"') < header_block.index('text = subtitle')
print('PASS: version appears above active account name in home header')
assert 'whereEqualTo("sellerRemoteId", remoteId)' in source
assert 'adminAccountDialog()' in source and 'تغییر نام کاربری و رمز عبور مدیر' in source
assert 'permissionChecks.filterValues' in source
print('PASS: v1.5.1 compact layout, combined admin account button, staff permissions, rose icon, and seller-payment checks')

# v1.5.1 layout assertions
assert 'root.addView(sectionTitle("منوی چرخشی"))' not in source
assert 'تغییر نام کاربری و رمز عبور مدیر' in source
assert 'حذف کاربر گلخانه' in source
assert 'collection("users").document(d.id).delete()' in source
assert 'طراح و برنامه‌نویس: مهدی ساریخانی فرد' in source
assert '۰۹۱۲۱۳۹۸۸۹۳' in source
print("PASS: v1.5.1 compact home layout, combined admin account action, greenhouse profile deletion, and designer credit")

# v1.5.1 requested visual fixes
source = (Path(__file__).parent / "app/src/main/java/com/example/golyar/MainActivity.kt").read_text()
assert 'WindowCompat.setDecorFitsSystemWindows(window, false)' in source
assert 'page.addView(scroll)' in source
assert 'page.addView(nav, LinearLayout.LayoutParams(-1, dp(56)))' in source
print("PASS: v1.5.1 safe system-bar spacing")

# Retained regression checks for circular menu, readable financial lists, navigation, and seller registration sync.
assert 'private fun addCircularShortcutWheel(root: LinearLayout, shortcuts: List<HomeShortcut>)' in source
assert 'shortcuts.chunked(2).forEachIndexed' in source
assert 'tile.animate().alpha(1f).translationY(0f)' in source
assert 'setTextColor(if(header) Color.WHITE else Color.rgb(35,58,43))' in source
assert 'private fun goBack()' in source and 'screenBackStack.removeLast()' in source
assert 'private fun renderMiscSalesPage(title: String, subtitle: String)' in source
assert 'private fun renderGreenhouseExpensesPage(title: String, subtitle: String)' in source
assert 'db.upsertSeller(s?.id,n,phone.text.toString().trim(),u,finalPassword,pct)' in source
assert 'syncWithFirebaseIfOnline(false)' in source[source.index('private fun sellerDialog'):source.index('private fun showMiscSale')]
print('PASS: animated shortcut cards, financial list contrast, back navigation, expense/sales ledgers, and seller sync checks')

# v1.5.3 real UI changes requested after v1.5.1: transparent rose launcher, compact spaced radial menu, system-bar-safe title/nav/buttons.
manifest = (Path(__file__).parent / "app/src/main/AndroidManifest.xml").read_text()
assert 'android:icon="@drawable/ic_launcher_rose"' in manifest and 'android:roundIcon="@drawable/ic_launcher_rose"' in manifest
assert (Path(__file__).parent / "app/src/main/res/drawable/ic_launcher_rose.xml").exists()
assert 'WindowCompat.setDecorFitsSystemWindows(window, false)' in source
assert 'tag = "APP_BOTTOM_NAV"' in source
assert 'LinearLayout.LayoutParams(0, dp(52), 1f)' in source
print('PASS: v1.5.3 rose launcher icon, visible title, and system-bar-safe bottom navigation/back area')

# v1.5.4 regression checks: gesture, system-bar-safe layout, launcher icon
assert 'WindowCompat.setDecorFitsSystemWindows(window, false)' in source
assert 'tag = "APP_BOTTOM_NAV"' in source
assert 'screenBottomNav[root] = child' in source
assert 'page.addView(nav, LinearLayout.LayoutParams(-1, dp(56)))' in source
assert 'setPadding(dp(12), dp(18), dp(12), dp(8))' in source
manifest = (Path(__file__).parent / 'app/src/main/AndroidManifest.xml').read_text()
assert 'android:icon="@drawable/ic_launcher_rose"' in manifest and 'android:roundIcon="@drawable/ic_launcher_rose"' in manifest
assert (Path(__file__).parent / 'app/src/main/res/drawable/ic_launcher_rose.xml').exists()
print('PASS: v1.5.4 fixed bottom navigation, lowered title, and rose launcher icon')

# v1.5.7: greenhouse staff permissions must hide navigation and guard direct entry.
assert 'private fun staffHasPermission(key: String): Boolean' in source
assert 'private fun requireStaffPermission(key: String, title: String): Boolean' in source
assert 'staffHasPermission("warnings")' in source
assert 'if (staffHasPermission("sellers")) root.addView(listCard("ثبت فروشنده"' in source
assert 'if (staffHasPermission("expense")) {' in source
assert '.setPositiveButton("ذخیره تغییرات")' in source
assert 'val permissionScroll = ScrollView(this).apply { isFillViewport = false; addView(box) }' in source
assert 'private fun refreshStaffPermissionsFromCloud()' in source
assert 'Fully transparent canvas' in Path("app/src/main/res/drawable/ic_launcher_rose.xml").read_text(encoding="utf-8")
assert 'android:pathData="M0,0h108v108h-108z"' not in Path("app/src/main/res/drawable/ic_launcher_rose.xml").read_text(encoding="utf-8")
print("PASS: v1.5.7 staff permission filtering, save action visibility, cloud permission refresh, transparent rose icon")
