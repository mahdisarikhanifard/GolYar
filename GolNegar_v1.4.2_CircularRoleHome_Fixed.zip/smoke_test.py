import sqlite3, hashlib, re

con=sqlite3.connect(':memory:')
c=con.cursor()
c.executescript('''
CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,username TEXT,share REAL,remote_id TEXT UNIQUE);
CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,size TEXT,base_price INTEGER,min_price INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,seller_share_amount INTEGER,greenhouse_amount INTEGER,min_price_snapshot INTEGER,below_minimum INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,remote_id TEXT UNIQUE);
''')
# Source device: seller local id 1, flower local id 1.
c.execute("INSERT INTO sellers(name,username,share,remote_id) VALUES('علی','ali',20,'seller-A')")
c.execute("INSERT INTO flowers(name,size,base_price,min_price,remote_id) VALUES('رز','50',100000,90000,'flower-R50')")
c.execute("INSERT INTO deliveries VALUES(NULL,1,1,100,100000,'delivery-A')")
# 10 sold at 95k: seller gets 20%, greenhouse gets 80%, below minimum.
total=10*95000; seller_share=total*20//100; greenhouse=total-seller_share
c.execute("INSERT INTO sales VALUES(NULL,1,1,10,95000,?,?,?,?,?)",(seller_share,greenhouse,90000,1,'sale-A'))
c.execute("INSERT INTO returns VALUES(NULL,1,1,5,'return-A')")
c.execute("INSERT INTO payments VALUES(NULL,1,500000,'payment-A')")

# Settlement invariants.
stock=c.execute('SELECT SUM(qty) FROM deliveries WHERE seller_id=1').fetchone()[0]-c.execute('SELECT SUM(qty) FROM sales WHERE seller_id=1').fetchone()[0]-c.execute('SELECT SUM(qty) FROM returns WHERE seller_id=1').fetchone()[0]
sales_total=c.execute('SELECT SUM(qty*price) FROM sales WHERE seller_id=1').fetchone()[0]
commission=c.execute('SELECT SUM(seller_share_amount) FROM sales WHERE seller_id=1').fetchone()[0]
greenhouse_due=c.execute('SELECT SUM(greenhouse_amount) FROM sales WHERE seller_id=1').fetchone()[0]
paid=c.execute('SELECT SUM(amount) FROM payments WHERE seller_id=1').fetchone()[0]
balance=greenhouse_due-paid
assert stock==85, stock
assert sales_total==950000
assert commission==190000
assert greenhouse_due==760000
assert paid==500000
assert balance==260000
assert c.execute('SELECT COUNT(*) FROM sales WHERE below_minimum=1').fetchone()[0]==1

# Simulate a second device with different local IDs; map by stable remote IDs.
c.execute("INSERT INTO sellers(name,username,share,remote_id) VALUES('سارا','sara',30,'seller-B')")
c.execute("INSERT INTO flowers(name,size,base_price,min_price,remote_id) VALUES('رز','40',80000,70000,'flower-R40')")
# Remote record from source must resolve seller-A/flower-R50, not numeric ids.
seller_local=c.execute("SELECT id FROM sellers WHERE remote_id='seller-A'").fetchone()[0]
flower_local=c.execute("SELECT id FROM flowers WHERE remote_id='flower-R50'").fetchone()[0]
assert seller_local==1 and flower_local==1

# Ensure no plaintext Firebase password is present in source package.
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=(ROOT/'app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'Ham' not in source
assert 'admin_firebase_password' in source
assert 'AES/GCM/NoPadding' in source

print('PASS: settlement arithmetic')
print('PASS: stock arithmetic')
print('PASS: below-minimum detection')
print('PASS: stable seller/flower remote-ID mapping')
print('PASS: Firebase password is not hard-coded in source')


# v1.3.2 static integration checks
from pathlib import Path
source = Path("app/src/main/java/com/example/golyar/MainActivity.kt").read_text(encoding="utf-8")
gradle = Path("app/build.gradle.kts").read_text(encoding="utf-8")
assert 'versionName = "1.4.2"' in gradle
assert 'versionCode = 71' in gradle
assert 'whereEqualTo("seller_remote_id", sellerRemoteId)' in source
assert 'auth_uid-only query for payments' in source
assert 'queries[index].get()' in source, "seller pull must execute Firestore queries"
assert 'whereEqualTo("auth_uid", firebaseAuth.currentUser?.uid.orEmpty())' not in source, "seller payments must not use a rules-incompatible auth_uid-only query"
assert 'fun goBack()' in source
assert 'db.delete("flowers", f.id); showFlowers(); syncWithFirebaseIfOnline(false)' in source
assert 'private fun detachFromParent(view: View)' in source
assert 'detachFromParent(root)' in source
assert 'showFinancialReport' in source
assert '🧾 فروش متفرقه گلخانه' in source
assert '💰 هزینه‌های گلخانه' in source
assert 'val sellerSharePercent=db.sellerShare(s.id)' in source
assert 'val shareTotal=saleRows.sumOf{(it.total*sellerSharePercent/100.0).toLong()}' in source
assert 'sellerShareAmount' not in source[source.index('private fun showFinancialReport()'):source.index('private fun showGreenhouseInventoryReport()')]
assert 'private fun renderGreenhouseExpensesPage(title: String, subtitle: String)' in source
assert 'private fun showMiscSalesReport()' in source
assert 'private fun showGreenhouseExpensesReport()' in source
assert 'sameLogicalScreen' in source
assert 'private fun showHome() {\n        screenBackStack.clear()' in source
assert 'FirebaseFirestore.getInstance(secondaryApp).collection("users").document(uid).set(data)' not in source
assert 'fs.collection("users").document(uid).set(data)' in source
assert 'لیست‌ها و گزارش‌های عملیاتی' in source
assert 'گزارش مالی جامع' in source
print("PASS: v1.3.9 navigation/sync/delete/account/report integration checks")

# v1.3.3 report coverage: miscellaneous sales and greenhouse expenses must be
# independently readable and must not depend on seller records.
c.executescript('''
CREATE TABLE misc_sales(id INTEGER PRIMARY KEY AUTOINCREMENT,buyer_name TEXT,flower_id INTEGER,qty INTEGER,price INTEGER,payment_type TEXT);
CREATE TABLE greenhouse_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,recipient TEXT,amount INTEGER,expense_type TEXT,description TEXT);
''')
c.execute("INSERT INTO misc_sales(buyer_name,flower_id,qty,price,payment_type) VALUES('مشتری مستقیم',1,3,120000,'نقدی')")
c.execute("INSERT INTO misc_sales(buyer_name,flower_id,qty,price,payment_type) VALUES('مشتری دوم',1,2,150000,'کارتخوان')")
c.execute("INSERT INTO greenhouse_payments(recipient,amount,expense_type,description) VALUES('برق','180000','آب و برق','قبض')")
c.execute("INSERT INTO greenhouse_payments(recipient,amount,expense_type,description) VALUES('تعمیرات','70000','تعمیرات','تعمیر پمپ')")
misc_total=c.execute('SELECT COALESCE(SUM(qty*price),0) FROM misc_sales').fetchone()[0]
misc_qty=c.execute('SELECT COALESCE(SUM(qty),0) FROM misc_sales').fetchone()[0]
expense_total=c.execute('SELECT COALESCE(SUM(amount),0) FROM greenhouse_payments').fetchone()[0]
assert misc_total==660000 and misc_qty==5
assert expense_total==250000
assert misc_total-expense_total==410000
print('PASS: miscellaneous sales report arithmetic')
print('PASS: greenhouse expense report arithmetic')
print('PASS: v1.3.9 reports include misc sales and greenhouse expenses')

# v1.4.2 regression checks for the requested fixes
assert 'private fun addCircularRoleSelector(root: LinearLayout)' in source
assert 'RoleItem("گلخانه / مدیر"' in source
assert 'RoleItem("فروشنده"' in source
assert 'RoleItem("کاربر گلخانه"' in source
assert 'MotionEvent.ACTION_MOVE' in source
assert 'root.addView(sectionTitle("انتخاب حساب / تغییر نسخه"))' in source
assert 'showCircularHomeMenu' not in source
assert 'private fun createGreenhouseUserDialog()' in source
assert 'staff_invites' not in source[source.index('private fun createGreenhouseUserDialog()'):source.index('private fun sellerAccountSettings()')]
assert 'کاربر گلخانه' in source[source.index('private fun showVersionSwitcher()'):source.index('private fun showPriceWarnings()')]
assert 'if (!firebaseAuth.currentUser?.email.equals(db.adminFirebaseEmail(), ignoreCase = true)) firebaseAuth.signOut()' in source
print('PASS: v1.4.2 circular role selector, greenhouse user creation path, and account switcher checks')
