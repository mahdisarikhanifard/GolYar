package com.example.golyar

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.firestore.FirebaseFirestore
import androidx.activity.OnBackPressedCallback
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var db: GolYarDb
    private var isHomeScreen = false
    private val nf = NumberFormat.getNumberInstance(Locale.US)
    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        db = GolYarDb(this)
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (FirebaseApp.initializeApp(this) != null) {
            FirebaseAnalytics.getInstance(this).logEvent("app_open", null)
            FirebaseFirestore.getInstance().collection("golyar_meta").document("app").set(mapOf("last_open" to System.currentTimeMillis(), "version" to "18.1"))
            registerNetworkSync()
            syncWithFirebaseIfOnline(false)
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!isHomeScreen) {
                    showHome()
                } else {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("خروج از گل‌یار")
                        .setMessage("آیا قصد خروج از برنامه را دارید؟")
                        .setNegativeButton("خیر", null)
                        .setPositiveButton("بله") { _, _ -> finish() }
                        .show()
                }
            }
        })
        if (!db.isAdminSetupDone()) {
            firstGreenhouseSetup()
        } else if (db.getMode() == null) {
            showModeChooser()
        } else {
            showHome()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun base(title: String, subtitle: String? = null): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            setBackgroundColor(Color.rgb(18, 15, 23))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(dp(20), bars.top + dp(88), dp(20), bars.bottom + dp(28))
            insets
        }
        ViewCompat.requestApplyInsets(root)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(16))
        }
        header.addView(TextView(this).apply {
            text = title
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            includeFontPadding = true
            translationY = dp(18).toFloat()
        })
        root.addView(header)
        return root
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 17f
        isAllCaps = false
        gravity = Gravity.CENTER
        minHeight = dp(56)
        minimumHeight = dp(56)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.rgb(91, 88, 94))
        }
        stateListAnimator = null
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, dp(56))
        lp.setMargins(0, dp(5), 0, dp(5))
        layoutParams = lp
    }

    private fun setScreen(root: LinearLayout, home: Boolean = false) {
        isHomeScreen = home
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.rgb(18, 15, 23))
            clipToPadding = false
        }
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun showModeChooser() {
        val root = base("گل‌یار", "انتخاب نوع برنامه")
        root.addView(actionButton("🏭  نسخه گلخانه") { greenhouseLogin() })
        root.addView(actionButton("👤  نسخه فروشنده") { showSellerChooser() })
        if (db.getMode() != null) {
            root.addView(actionButton("↩️  بازگشت به صفحه اصلی") { showHome() })
        }
        setScreen(root)
    }

    private fun showSellerChooser() {
        val sellers = db.sellers(); if (sellers.isEmpty()) { info("برای ورود به نسخه فروشنده، ابتدا در نسخه گلخانه حداقل یک فروشنده تعریف کنید."); return }
        val box=formBox();val sp=spinner("انتخاب فروشنده",sellers.map{"${it.name} | ${it.phone}"},64);val user=field("نام کاربری","");val pass=field("رمز عبور","");box.addView(sp);box.addView(user);box.addView(pass)
        AlertDialog.Builder(this).setTitle("ورود به نسخه فروشنده").setView(box).setPositiveButton("ورود"){_,_->val s=sellers[sp.selectedItemPosition];if(s.username.isBlank()){if(user.text.isBlank()||pass.text.isBlank()){info("این اولین ورود فروشنده است؛ نام کاربری و رمز جدید وارد کنید.");return@setPositiveButton};db.updateSellerCredentials(s.id,user.text.toString().trim(),pass.text.toString());db.setMode("SELLER:${s.id}");showHome()}else if(db.verifySellerLogin(s.id,user.text.toString().trim(),pass.text.toString())){db.setMode("SELLER:${s.id}");showHome()}else info("نام کاربری یا رمز عبور اشتباه است.")}.setNegativeButton("انصراف",null).show()
    }

    private fun showHome() {
        isHomeScreen = true
        val root = base("گل‌یار")
        val d = db.dashboard(if (db.isSellerMode()) db.currentSellerId() else null)
        val date = todayJalali()
        root.addView(summaryCard(date, d))

        if (db.isSellerMode()) {
            root.addView(actionButton("🧾  ثبت فروش جدید") { showSale() })
            root.addView(actionButton("📦  موجودی من") { showReports() })
            root.addView(actionButton("💰  حساب و پرداخت به گلخانه") { showSettlement() })
        } else {
            root.addView(actionButton("🌹  انواع گل") { showFlowers() })
            root.addView(actionButton("👤  فروشندگان") { showSellers() })
            root.addView(actionButton("📦  ثبت تحویل / فروش گلخانه") { showDelivery() })
            root.addView(actionButton("↩️  ثبت برگشت گل") { showReturn() })
            root.addView(actionButton("💰  تسویه حساب فروشندگان") { showSettlement() })
            root.addView(actionButton("📊  گزارش‌ها") { showReports() })
        }
        if (db.lowPriceWarningCount(if (db.isSellerMode()) db.currentSellerId() else null) > 0) {
            root.addView(actionButton("⚠️  هشدارهای قیمت زیر حداقل (${db.lowPriceWarningCount(if (db.isSellerMode()) db.currentSellerId() else null)})") { showPriceWarnings() })
        }
        root.addView(actionButton("⚙️  تنظیمات") { showSettings() })
        setScreen(root, true)
    }

    private fun summaryCard(date: String, d: Dash): TextView = TextView(this).apply {
        text = if (db.isSellerMode()) { val sid=db.currentSellerId()?:0; val b=db.greenhouseBalance(sid); "امروز  |  $date\n\nفروش امروز من: ${d.soldToday} دسته\nفروش امروز من: ${money(d.salesToday)} ریال\nموجودی من: ${d.stock} دسته\n${if(b>0) "بدهی من به گلخانه: ${money(b)} ریال" else if(b<0) "طلب من از گلخانه: ${money(-b)} ریال" else "حساب گلخانه تسویه است"}" } else "امروز  |  $date\n\nتحویل / فروش گلخانه امروز: ${d.deliveredToday} دسته\nفروش گلخانه امروز: ${money(d.salesToday)} ریال\nموجودی نزد فروشندگان: ${d.stock} دسته\nمطالبات گلخانه: ${money(d.greenhouseDue)} ریال"
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(20), dp(18), dp(20), dp(18))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, dp(14))
        layoutParams = lp
    }

    private fun showFlowers() {
        val root = base("انواع گل")
        root.addView(actionButton("＋  تعریف نوع گل") { flowerDialog(null) })
        db.flowers().forEach { f ->
            root.addView(cardRow("🌹  ${f.name} | اندازه: ${f.size}\nقیمت پایه: ${money(f.basePrice)}  |  حداقل فروش: ${money(f.minPrice)}") {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                row.addView(actionButton("ویرایش") { flowerDialog(f) }, LinearLayout.LayoutParams(0, dp(56), 1f))
                row.addView(actionButton("حذف") { confirmDelete("حذف ${f.name}؟") { db.delete("flowers", f.id); showFlowers() } }, LinearLayout.LayoutParams(0, dp(56), 1f))
                it.addView(row)
            })
        }
        root.addView(actionButton("بازگشت") { showHome() })
        setScreen(root)
    }

    private fun flowerDialog(f: Flower?) {
        val box = formBox(); val name = field("نام گل", f?.name ?: ""); val size = field("اندازه گل (مثلاً ۴۰ سانتی / ۵۰ سانتی)", f?.size ?: ""); val base = moneyField("قیمت پایه هر دسته (ریال)", f?.basePrice?.toString() ?: ""); val min = moneyField("حداقل قیمت مجاز (ریال)", f?.minPrice?.toString() ?: "")
        box.addView(name); box.addView(size); box.addView(base); box.addView(min)
        AlertDialog.Builder(this).setTitle(if (f == null) "تعریف گل" else "ویرایش گل").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val n=name.text.toString().trim(); val z=size.text.toString().trim(); val b=parseMoney(base); val m=parseMoney(min)
                if(n.isNotEmpty() && z.isNotEmpty() && b>0 && m>0) db.upsertFlower(f?.id,n,z,b,m); else info("نام، اندازه و قیمت‌ها را کامل وارد کنید.")
                if(n.isNotEmpty() && z.isNotEmpty() && b>0 && m>0) showFlowers()
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showSellers() {
        val root = base("فروشندگان", "درصد سهم هر فروشنده از مبلغ فروش قابل تنظیم است")
        root.addView(actionButton("＋  تعریف فروشنده") { sellerDialog(null) })
        db.sellers().forEach { s ->
            root.addView(cardRow("👤  ${s.name}\n${s.phone}\nنام کاربری: ${s.username}\nسهم فروشنده از فروش خودش: ${fmtPercent(db.sellerShare(s.id))}%\nموجودی: ${db.sellerStock(s.id)} دسته\n${if(db.greenhouseBalance(s.id)>0) "بدهی به گلخانه: ${money(db.greenhouseBalance(s.id))} ریال" else if(db.greenhouseBalance(s.id)<0) "طلب از گلخانه: ${money(-db.greenhouseBalance(s.id))} ریال" else "حساب گلخانه تسویه است"}") {
                it.addView(actionButton("ویرایش") { sellerDialog(s) })
            })
        }
        root.addView(actionButton("بازگشت") { showHome() }); setScreen(root)
    }

    private fun sellerDialog(s: Seller?) {
        val box=formBox(); val name=field("نام فروشنده",s?.name?:""); val phone=field("شماره تماس",s?.phone?:""); val username=field("نام کاربری",s?.username?:""); val password=field("رمز عبور",""); val share=numberField("درصد توافقی فروشنده",s?.let{db.sellerShare(it.id).toString()}?:db.getDefaultSellerShare().toString())
        box.addView(name); box.addView(phone); box.addView(username); box.addView(password); box.addView(share)
        AlertDialog.Builder(this).setTitle(if(s==null) "فروشنده جدید" else "ویرایش فروشنده").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val pct=share.text.toString().toDoubleOrNull(); if(name.text.isNotBlank() && username.text.isNotBlank() && (password.text.isNotBlank() || s!=null) && pct!=null && pct in 0.0..100.0) { db.upsertSeller(s?.id,name.text.toString(),phone.text.toString(),username.text.toString().trim(),if(password.text.isBlank() && s!=null) db.sellerPassword(s.id) else password.text.toString(),pct); showSellers() } else info("درصد باید بین صفر تا صد باشد.")
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showDelivery() {
        val root=base("ثبت فروش گلخانه")
        val flowers=db.flowers(); val sellers=db.sellers()
        if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا حداقل یک گل و یک فروشنده تعریف کنید.");return}
        val seller=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64)
        val flower=spinner("نوع گل",flowers.map{"${it.name} | ${it.size}"},64)
        val qty=numberField("تعداد دسته",""); val price=moneyField("قیمت فروش هر دسته (ریال)","")
        val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}
        val dateLabel=label("تاریخ فروش گلخانه: ${jalali(selectedDate)}")
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل / اندازه"));root.addView(flower);root.addView(qty);root.addView(price);root.addView(dateLabel)
        root.addView(actionButton("📅 انتخاب تاریخ"){val initial=selectedDate.clone() as Calendar;DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ فروش گلخانه: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()})
        val historyBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val totalBox=TextView(this).apply{textSize=16f;setTextColor(Color.WHITE);setPadding(dp(12),dp(12),dp(12),dp(12))}
        fun refreshHistory(){
            historyBox.removeAllViews()
            val sid=if(seller.selectedItemPosition==0)null else sellers[seller.selectedItemPosition-1].id
            val rows=db.greenhouseSalesFiltered(sid,selectedDate.timeInMillis)
            historyBox.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","قیمت","مبلغ")))
            if(rows.isEmpty()) historyBox.addView(label("رکوردی برای این تاریخ وجود ندارد."))
            else rows.forEach{r->historyBox.addView(tableRow(listOf(r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))}
            val totals=db.greenhouseDayTotals(sid,selectedDate.timeInMillis)
            totalBox.text="جمع تعداد: ${totals.qty} دسته\nجمع فروش گلخانه: ${money(totals.total)} ریال\nجمع طلب گلخانه: ${money(maxOf(totals.balance,0L))} ریال\nجمع بدهی/طلب فروشندگان از گلخانه: ${money(maxOf(-totals.balance,0L))} ریال\nمیانگین قیمت فروش: ${money(totals.avg)} ریال"
        }
        seller.setOnItemSelectedListener(simpleListener{refreshHistory()})
        root.addView(actionButton("ثبت فروش گلخانه"){
            val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val p=parseMoney(price);val f=flowers[flower.selectedItemPosition]
            if(q<=0||p<=0){info("تعداد و قیمت را صحیح وارد کنید.");return@actionButton}
            val targets=if(seller.selectedItemPosition==0)sellers else listOf(sellers[seller.selectedItemPosition-1])
            if(targets.size>1){info("برای ثبت یک فروش باید یک فروشنده مشخص انتخاب کنید.");return@actionButton}
            val ss=targets.first()
            val save={db.addDelivery(ss.id,f.id,q,p,selectedDate.timeInMillis);qty.setText("");price.setText("");refreshHistory();info("فروش گلخانه ثبت شد.")} 
            if(p<f.minPrice) AlertDialog.Builder(this).setTitle("⚠️ هشدار قیمت").setMessage("قیمت فروش ${f.name} با اندازه ${f.size} پایین‌تر از حداقل مجاز است. ثبت شود؟").setNegativeButton("لغو",null).setPositiveButton("ثبت"){_,_->save()}.show() else save()
        })
        root.addView(label("📋 گزارش فروش در تاریخ انتخاب‌شده"));root.addView(historyBox);root.addView(totalBox);refreshHistory()
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSale() {
        val root=base("ثبت فروش جدید")
        val flowers=db.flowers(); val seller=db.sellers().firstOrNull{it.id==db.currentSellerId()} ?: return
        if(flowers.isEmpty()){info("ابتدا نوع گل را تعریف کنید.");return}
        val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64); val qty=numberField("تعداد دسته فروخته‌شده",""); val price=moneyField("قیمت فروش هر دسته به مشتری (ریال)","")
        val stockText=label(""); val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}; val dateLabel=label("تاریخ فروش: ${jalali(selectedDate)}")
        val salesBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}; val totalBox=label("")
        fun refresh(){val f=flowers[flower.selectedItemPosition];stockText.text="موجودی ${f.name} | ${f.size}: ${db.sellerFlowerStock(seller.id,f.id)} دسته"}
        fun refreshSalesTable(){salesBox.removeAllViews();salesBox.addView(tableHeader(listOf("تاریخ","گل/اندازه","تعداد","قیمت","مبلغ")));var qtyTotal=0;var total=0L;db.sales(seller.id).forEach{r->salesBox.addView(tableRow(listOf(r.date,r.flowerName,r.qty.toString(),money(r.price),money(r.qty.toLong()*r.price))));qtyTotal+=r.qty;total+=r.qty.toLong()*r.price};if(salesBox.childCount==1)salesBox.addView(label("هنوز فروشی ثبت نشده است."));val avg=if(qtyTotal==0)0 else total/qtyTotal;totalBox.text="جمع تعداد فروش: $qtyTotal دسته\nجمع مبلغ فروش: ${money(total)} ریال\nمیانگین قیمت فروش: ${money(avg.toLong())} ریال\n${sellerBalanceText(seller.id)}"}
        flower.setOnItemSelectedListener(simpleListener{refresh()});refresh();refreshSalesTable()
        root.addView(label("گل / اندازه"));root.addView(flower);root.addView(stockText);root.addView(qty);root.addView(price);root.addView(dateLabel)
        root.addView(actionButton("📅 انتخاب تاریخ فروش"){val initial=selectedDate.clone() as Calendar;DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ فروش: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()})
        root.addView(actionButton("ثبت فروش") {val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val p=parseMoney(price);val f=flowers[flower.selectedItemPosition];val stock=db.sellerFlowerStock(seller.id,f.id);if(q<=0||p<=0){info("تعداد و قیمت را صحیح وارد کنید.");return@actionButton};if(q>stock){info("موجودی کافی نیست. موجودی فعلی: $stock دسته");return@actionButton};val save={saveSale(seller.id,f.id,q,p,selectedDate.timeInMillis,qty,price,stockText){refreshSalesTable()}};if(p<f.minPrice)AlertDialog.Builder(this).setTitle("هشدار قیمت").setMessage("قیمت واردشده پایین‌تر از حداقل مجاز است. ثبت شود؟").setNegativeButton("لغو",null).setPositiveButton("ثبت"){_,_->save()}.show()else save()})
        root.addView(label("📋 فروش‌های ثبت‌شده"));root.addView(salesBox);root.addView(totalBox)
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun saveSale(sellerId:Long,flowerId:Long,qty:Int,price:Long,saleDate:Long,qtyField:EditText,priceField:EditText,stockText:TextView,onSaved:(()->Unit)?=null){db.addSale(sellerId,flowerId,qty,price,saleDate);qtyField.setText("");priceField.setText("");stockText.text="موجودی قابل فروش: ${db.sellerFlowerStock(sellerId,flowerId)} دسته";onSaved?.invoke();info("فروش فروشنده ثبت شد.\nتاریخ فروش: ${jalaliDate(saleDate)}\nمبلغ: ${money(qty.toLong()*price)} ریال")}

    private fun showSalesHistory() {
        val root=base("فروش‌های ثبت‌شده من")
        val sid=db.currentSellerId()?:return
        val sales=db.sales(sid)
        if(sales.isEmpty()) root.addView(label("هنوز فروشی ثبت نشده است."))
        sales.forEach{root.addView(cardRow("${it.flowerName} | ${it.size}  |  ${it.qty} دسته\nقیمت هر دسته: ${money(it.price)} ریال\nمبلغ کل فروش: ${money(it.qty*it.price)} ریال\nتاریخ فروش: ${it.date}\nوضعیت ارسال: ${if(it.synced) "آماده ارسال/همگام‌شده" else "در انتظار اتصال به گلخانه"}") {})}
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showReturn(){
        if(db.isSellerMode()){info("ثبت برگشت در نسخه گلخانه انجام می‌شود.");return}
        val root=base("ثبت برگشت گل","برگشت از موجودی فروشنده کم می‌شود و دلیل آن ثبت می‌گردد.");val flowers=db.flowers();val sellers=db.sellers();if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا اطلاعات پایه را وارد کنید.");return}
        val seller=spinner("فروشنده",sellers.map{it.name},64);val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64);val qty=numberField("تعداد دسته برگشتی","");val reason=field("علت برگشت","فروش نرفته / خراب / کیفیت / سایر")
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل"));root.addView(flower);root.addView(qty);root.addView(reason)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        fun refresh(){box.removeAllViews();box.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","دلیل")));db.allReturns().take(20).forEach{box.addView(tableRow(listOf(it.sellerName,"${it.flowerName} | ${it.size}",it.qty.toString(),it.reason)))};if(box.childCount==1)box.addView(label("برگشتی ثبت نشده است."))}
        root.addView(actionButton("ثبت برگشت"){val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val ss=sellers[seller.selectedItemPosition];val f=flowers[flower.selectedItemPosition];if(q<=0||q>db.sellerFlowerStock(ss.id,f.id)){info("تعداد برگشتی بیشتر از موجودی است.");return@actionButton};db.addReturn(ss.id,f.id,q,reason.text.toString());qty.setText("");reason.setText("");refresh();info("برگشت ثبت شد.")})
        root.addView(label("📋 برگشت‌های ثبت‌شده"));root.addView(box);refresh();root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSettlement(){
        val root=base(if(db.isSellerMode()) "حساب و پرداخت به گلخانه" else "تسویه حساب فروشندگان")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        if(db.isSellerMode()) addSellerAccountSection(root,sellers.firstOrNull{it.id==db.currentSellerId()}?:return,true)
        else {val sp=spinner("فروشنده",sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp);val detail=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(detail);fun refresh(){detail.removeAllViews();addSellerAccountSection(detail,sellers[sp.selectedItemPosition],false)};sp.setOnItemSelectedListener(simpleListener{refresh()});refresh()}
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun addSellerAccountSection(root:LinearLayout,s:Seller,showPaymentTable:Boolean){
        val balance=db.greenhouseBalance(s.id);val status=if(balance>0)"بدهی به گلخانه: ${money(balance)} ریال" else if(balance<0)"طلب فروشنده از گلخانه: ${money(-balance)} ریال" else "حساب گلخانه تسویه است"
        root.addView(label("📦 خریدهای ثبت‌شده از گلخانه"));root.addView(tableHeader(listOf("تاریخ","گل/اندازه","تعداد","قیمت","مبلغ")));val rows=db.greenhouseSales(s.id);if(rows.isEmpty())root.addView(label("خریدی ثبت نشده است."))else rows.forEach{r->root.addView(tableRow(listOf(r.date,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))}
        root.addView(cardText("جمع کل خرید گلخانه: ${money(db.greenhouseCharges(s.id))} ریال\nبرگشت قابل کسر: ${money(db.returnCredits(s.id))} ریال\n$status"))
        root.addView(actionButton("💳 ثبت پرداخت به گلخانه"){paymentDialog(s)})
        root.addView(label("📋 پرداخت‌های ثبت‌شده"));root.addView(tableHeader(listOf("تاریخ","مبلغ")));val ps=db.payments(s.id);var paid=0L;if(ps.isEmpty())root.addView(label("پرداختی ثبت نشده است."))else ps.forEach{p->paid+=p.amount;root.addView(tableRow(listOf(p.date,money(p.amount))))};root.addView(cardText("جمع کل پرداخت‌ها: ${money(paid)} ریال\nمانده حساب: $status"))
    }

    private fun showPaymentHistory(s:Seller){
        val root=base("تاریخچه پرداخت ${s.name}")
        val payments=db.payments(s.id)
        if(payments.isEmpty()) root.addView(label("پرداختی ثبت نشده است."))
        payments.forEachIndexed{index,p->root.addView(cardText("پرداخت ${payments.size-index}\nمبلغ: ${money(p.amount)} ریال\nتاریخ پرداخت: ${p.date}"))}
        root.addView(actionButton("بازگشت"){showSettlement()});setScreen(root)
    }

    private fun paymentDialog(s:Seller){
        val balance=db.greenhouseBalance(s.id); val box=formBox(); val amount=moneyField("مبلغ پرداختی (ریال)",if(balance>0)money(balance) else "")
        val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}; val dateLabel=label("تاریخ پرداخت: ${jalali(selectedDate)}")
        box.addView(amount);box.addView(dateLabel)
        box.addView(actionButton("📅 انتخاب تاریخ پرداخت"){val initial=Calendar.getInstance().apply{timeInMillis=selectedDate.timeInMillis};DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ پرداخت: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()})
        val msg=if(balance>0) "مانده بدهی به گلخانه: ${money(balance)} ریال" else if(balance<0) "طلب فروشنده از گلخانه: ${money(-balance)} ریال" else "حساب تسویه است"
        AlertDialog.Builder(this).setTitle("پرداخت ${s.name} به گلخانه").setMessage(msg).setView(box).setPositiveButton("ثبت پرداخت"){_,_->
            val a=parseMoney(amount)
            if(a<=0) info("مبلغ پرداختی باید بیشتر از صفر باشد.") else {db.addPayment(s.id,a,selectedDate.timeInMillis);info("پرداخت ثبت شد.\nتاریخ: ${jalali(selectedDate)}"){showSettlement()}}
        }.setNegativeButton("انصراف",null).show()
    }

    private fun showReports(){
        if(db.isSellerMode()){showSellerInventoryReport();return}
        val root=base("گزارش‌های گلخانه","گزارش‌ها از بخش ثبت‌ها جدا شده و همه در این قسمت قرار دارند.")
        root.addView(actionButton("👤 گزارش فروشندگان") { showGreenhouseSellerSalesReport() })
        root.addView(actionButton("🌹 گزارش فروش گلخانه") { showGreenhouseDeliveryReport() })
        root.addView(actionButton("💰 گزارش مالی و بدهی فروشندگان") { showFinancialReport() })
        root.addView(actionButton("📦 گزارش موجودی نزد فروشندگان") { showGreenhouseInventoryReport() })
        root.addView(actionButton("📋 گزارش برگشت گل") { showReturnReport() })
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSellerInventoryReport(){
        val root=base("موجودی من","فقط گل‌های موجود نزد من، قیمت و مشخصات آن‌ها")
        val sid=db.currentSellerId()?:return
        root.addView(tableHeader(listOf("نام گل","اندازه","موجودی","قیمت پایه","حداقل قیمت")))
        var count=0;var totalQty=0;var totalValue=0L;db.flowers().forEach{f->val stock=db.sellerFlowerStock(sid,f.id);if(stock>0){count++;totalQty+=stock;totalValue+=stock.toLong()*f.basePrice;root.addView(tableRow(listOf(f.name,f.size,stock.toString(),money(f.basePrice),money(f.minPrice))))}}
        if(count==0)root.addView(label("در حال حاضر گل موجودی ندارید."))
        root.addView(cardText("جمع کل موجودی: $totalQty دسته\nارزش تقریبی موجودی بر اساس قیمت پایه: ${money(totalValue)} ریال"))
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showGreenhouseDeliveryReport(){
        val root=base("گزارش فروش گلخانه")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("فروشنده"));root.addView(sp)
        val date=Calendar.getInstance().apply{timeInMillis=db.appDate()};val dl=label("تاریخ: ${jalali(date)}");root.addView(dl)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val sid=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1].id;val rows=db.greenhouseSalesFiltered(sid,date.timeInMillis);box.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","قیمت","مبلغ")));if(rows.isEmpty())box.addView(label("رکوردی برای این تاریخ وجود ندارد."))else rows.forEach{r->box.addView(tableRow(listOf(r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))};val t=db.greenhouseDayTotals(sid,date.timeInMillis);box.addView(cardText("جمع کل تعداد: ${t.qty} دسته\nجمع کل فروش: ${money(t.total)} ریال\nمیانگین فروش هر دسته: ${money(t.avg)} ریال\nجمع طلب گلخانه: ${money(maxOf(t.balance,0L))} ریال\nجمع بدهی/طلب فروشندگان از گلخانه: ${money(maxOf(-t.balance,0L))} ریال"))}
        sp.setOnItemSelectedListener(simpleListener{refresh()})
        root.addView(actionButton("📅 انتخاب تاریخ"){val i=date.clone() as Calendar;DatePickerDialog(this,{_,y,m,d->date.set(y,m,d,12,0,0);date.set(Calendar.MILLISECOND,0);dl.text="تاریخ: ${jalali(date)}";refresh()},i.get(Calendar.YEAR),i.get(Calendar.MONTH),i.get(Calendar.DAY_OF_MONTH)).show()})
        refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showFinancialReport(){
        val root=base("گزارش مالی فروشندگان")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("فروشنده"));root.addView(sp)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val selected=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1];val list=if(selected==null)sellers else listOf(selected);list.forEach{s->val buy=db.greenhouseCharges(s.id);val ret=db.returnCredits(s.id);val paid=db.paidToGreenhouse(s.id);val bal=db.greenhouseBalance(s.id);box.addView(cardText("👤 ${s.name}\nخرید از گلخانه: ${money(buy)} ریال\nبرگشت قابل کسر: ${money(ret)} ریال\nجمع پرداخت‌ها: ${money(paid)} ریال\n${if(bal>0)"بدهی به گلخانه: ${money(bal)} ریال"else if(bal<0)"طلب از گلخانه: ${money(-bal)} ریال"else"حساب تسویه است"}"));box.addView(label("پرداخت‌ها"));val ps=db.payments(s.id);if(ps.isEmpty())box.addView(label("پرداختی ثبت نشده است."))else ps.forEachIndexed{i,p->box.addView(tableRow(listOf("${i+1}. ${p.date}",money(p.amount))))};box.addView(label("خریدهای گلخانه"));db.greenhouseSales(s.id).forEach{r->box.addView(tableRow(listOf(r.date,"${r.flowerName} | ${r.size} | ${r.qty} دسته",money(r.total))))}}
        }
        sp.setOnItemSelectedListener(simpleListener{refresh()});refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showGreenhouseInventoryReport(){
        val root=base("موجودی نزد فروشندگان","موجودی بر اساس تحویل منهای فروش و برگشت")
        root.addView(tableHeader(listOf("فروشنده","گل/اندازه","موجودی")))
        var count=0;db.sellers().forEach{s->db.flowers().forEach{f->val st=db.sellerFlowerStock(s.id,f.id);if(st>0){count++;root.addView(tableRow(listOf(s.name,"${f.name} | ${f.size}",st.toString())))}}}
        if(count==0)root.addView(label("موجودی نزد فروشندگان ثبت نشده است."));root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showReturnReport(){
        val root=base("گزارش برگشت گل","فهرست برگشت‌های ثبت‌شده از فروشندگان")
        root.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","دلیل")))
        val rows=db.allReturns();if(rows.isEmpty())root.addView(label("برگشتی ثبت نشده است.")) else rows.forEach{root.addView(tableRow(listOf(it.sellerName,"${it.flowerName} | ${it.size}",it.qty.toString(),it.reason)))}
        root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showGreenhouseSellerSalesReport(){
        val root=base("گزارش فروشندگان")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){val s=sellers[sp.selectedItemPosition];box.removeAllViews();val purchases=db.greenhouseSales(s.id);val sales=db.sellerSalesDetailed(s.id);val totalQty=sales.sumOf{it.qty};val totalSales=sales.sumOf{it.total};val avg=if(totalQty==0)0 else totalSales/totalQty;box.addView(cardText("👤 ${s.name}\nتعداد کل گل‌های برده‌شده از گلخانه: ${purchases.sumOf{it.qty}} دسته\nارزش کل خرید از گلخانه: ${money(db.greenhouseCharges(s.id))} ریال\nتعداد کل فروش به مشتری: $totalQty دسته\nقیمت فروش کل: ${money(totalSales)} ریال\nمیانگین قیمت فروش: ${money(avg)} ریال"));box.addView(label("خرید گل از گلخانه"));box.addView(tableHeader(listOf("تاریخ","گل/اندازه","تعداد","قیمت","مبلغ")));if(purchases.isEmpty())box.addView(label("خریدی ثبت نشده است."))else purchases.forEach{r->box.addView(tableRow(listOf(r.date,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))};box.addView(label("تک‌تک فروش‌ها"));box.addView(tableHeader(listOf("تاریخ","گل/اندازه","تعداد","قیمت","مبلغ")));if(sales.isEmpty())box.addView(label("فروشی ثبت نشده است."))else sales.forEach{r->box.addView(tableRow(listOf(r.date,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))}}
        sp.setOnItemSelectedListener(simpleListener{refresh()});refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showDetailedReport(){
        val root=base("گزارش تفصیلی فروش","فیلتر بر اساس فروشنده و بازه تاریخ")
        val sellers=db.sellers(); if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val seller=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("فروشنده"));root.addView(seller)
        val from=Calendar.getInstance().apply{timeInMillis=db.appDate();set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}
        val to=Calendar.getInstance().apply{timeInMillis=db.appDate();set(Calendar.HOUR_OF_DAY,23);set(Calendar.MINUTE,59);set(Calendar.SECOND,59);set(Calendar.MILLISECOND,999)}
        val fromLabel=label("از تاریخ: ${jalali(from)}");val toLabel=label("تا تاریخ: ${jalali(to)}");root.addView(fromLabel);root.addView(actionButton("📅 انتخاب تاریخ شروع"){DatePickerDialog(this,{_,y,m,d->from.set(y,m,d,0,0,0);from.set(Calendar.MILLISECOND,0);fromLabel.text="از تاریخ: ${jalali(from)}"},from.get(Calendar.YEAR),from.get(Calendar.MONTH),from.get(Calendar.DAY_OF_MONTH)).show()});root.addView(toLabel);root.addView(actionButton("📅 انتخاب تاریخ پایان"){DatePickerDialog(this,{_,y,m,d->to.set(y,m,d,23,59,59);to.set(Calendar.MILLISECOND,999);toLabel.text="تا تاریخ: ${jalali(to)}"},to.get(Calendar.YEAR),to.get(Calendar.MONTH),to.get(Calendar.DAY_OF_MONTH)).show()})
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val sid=if(seller.selectedItemPosition==0)null else sellers[seller.selectedItemPosition-1].id;val rows=db.detailedSales(sid,from.timeInMillis,to.timeInMillis);box.addView(tableHeader(listOf("تاریخ","فروشنده","گل/اندازه","تعداد","قیمت","مبلغ")));if(rows.isEmpty())box.addView(label("رکوردی در این بازه وجود ندارد.")) else {var total=0L;rows.forEach{r->total+=r.total;box.addView(tableRow(listOf(r.date,r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.price),money(r.total))))};box.addView(cardText("جمع مبلغ فروش این فیلتر: ${money(total)} ریال"))}}
        seller.setOnItemSelectedListener(simpleListener{refresh()});root.addView(actionButton("🔎 اعمال فیلتر"){refresh()});refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showAllPaymentsHistory(){
        val root=base("تاریخچه همه پرداخت‌ها", "پرداخت‌ها بر اساس تاریخ پرداخت مرتب شده‌اند")
        val rows=db.allPayments()
        if(rows.isEmpty()) root.addView(label("هنوز هیچ پرداختی ثبت نشده است."))
        var lastSeller=""; rows.forEachIndexed{index,p->{if(p.sellerName!=lastSeller){root.addView(label("👤 ${p.sellerName}"));lastSeller=p.sellerName};root.addView(cardText("پرداخت ${index+1}\nمبلغ: ${money(p.amount)} ریال\nتاریخ پرداخت: ${p.date}"))}}
        root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showSettings(){
        val root=base("تنظیمات")
        val lastSync=db.lastFirebaseSync()
        root.addView(cardText(if(lastSync==null) "☁️ آخرین بروزرسانی موفق دیتابیس: هنوز انجام نشده" else "☁️ آخرین بروزرسانی موفق دیتابیس: ${jalaliDateTime(lastSync)}"))
        if(!db.isSellerMode()){
            val def=numberField("درصد پیش‌فرض سهم فروشنده",db.getDefaultSellerShare().toString());root.addView(def);root.addView(actionButton("ذخیره درصد پیش‌فرض"){val v=def.text.toString().toDoubleOrNull();if(v!=null&&v in 0.0..100.0){db.setDefaultSellerShare(v);info("درصد پیش‌فرض ذخیره شد.")}else info("درصد باید بین صفر تا صد باشد.")})
            root.addView(actionButton("🔐 نام کاربری و رمز گلخانه"){greenhouseCredentialsDialog()})
        } else {
            val sid=db.currentSellerId() ?: 0L
            root.addView(actionButton("🔐 تغییر نام کاربری و رمز عبور"){sellerCredentialsDialog(sid)})
        }
        val date=Calendar.getInstance().apply{timeInMillis=db.appDate()}
        val dateLabel=label("تاریخ کاری برنامه: ${jalali(date)}")
        root.addView(dateLabel)
        root.addView(actionButton("📅 تنظیم تاریخ"){
            val initial=Calendar.getInstance().apply{timeInMillis=db.appDate()}
            DatePickerDialog(this,{_,y,m,d->initial.set(y,m,d,12,0,0);initial.set(Calendar.MILLISECOND,0);db.setAppDate(initial.timeInMillis);dateLabel.text="تاریخ کاری برنامه: ${jalali(initial)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()
        })
        root.addView(actionButton("☁️ همگام‌سازی اطلاعات با Firebase"){syncWithFirebaseIfOnline(true)})
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun firebaseSyncDialog(){
        syncWithFirebaseIfOnline(true)
    }

    private fun isNetworkAvailable(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun registerNetworkSync(){
        if (networkCallback != null) return
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread { syncWithFirebaseIfOnline(false) }
            }
        }
        connectivityManager.registerDefaultNetworkCallback(networkCallback!!)
    }

    override fun onDestroy() {
        networkCallback?.let {
            runCatching { connectivityManager.unregisterNetworkCallback(it) }
        }
        networkCallback = null
        super.onDestroy()
    }

    private fun syncWithFirebaseIfOnline(showMessage: Boolean){
        if (FirebaseApp.getApps(this).isEmpty()) {
            if (showMessage) info("Firebase هنوز به پروژه متصل نشده است. فایل google-services.json پروژه Firebase را در پوشه app قرار دهید.")
            return
        }
        if (!isNetworkAvailable()) {
            if (showMessage) info("اینترنت در دسترس نیست. اطلاعات روی گوشی ذخیره می‌شوند و با برگشت اینترنت به‌صورت خودکار همگام می‌شوند.")
            return
        }
        val fs=FirebaseFirestore.getInstance()
        val data=hashMapOf<String,Any>("updated_at" to System.currentTimeMillis(),"app_date" to db.appDate(),"data" to db.firebaseSnapshot())
        fs.collection("golyar").document("local_snapshot").set(data)
            .addOnSuccessListener {
                db.setLastFirebaseSync(System.currentTimeMillis())
                if (showMessage) info("همگام‌سازی با Firebase با موفقیت انجام شد.")
            }
            .addOnFailureListener {
                if (showMessage) info("همگام‌سازی انجام نشد: ${it.message ?: "خطای نامشخص"}. اطلاعات محلی محفوظ هستند و بعداً دوباره تلاش می‌شود.")
            }
    }


    private fun firstGreenhouseSetup(){
        val box=formBox();val u=field("نام کاربری جدید گلخانه","");val p=field("رمز عبور جدید گلخانه","");val p2=field("تکرار رمز عبور","");box.addView(u);box.addView(p);box.addView(p2)
        AlertDialog.Builder(this).setTitle("اولین ورود گل‌یار").setMessage("برای شروع، نام کاربری و رمز عبور گلخانه را تعیین کنید.").setView(box).setCancelable(false).setPositiveButton("ذخیره و ادامه"){_,_->val a=u.text.toString().trim();val b=p.text.toString();if(a.isBlank()||b.isBlank()||b!=p2.text.toString()){info("نام کاربری و رمز عبور را کامل و یکسان وارد کنید."){firstGreenhouseSetup()}}else{db.setAdminCredentials(a,b);db.setAdminSetupDone();showModeChooser()}}.show()
    }

    private fun greenhouseLogin(){
        val box=formBox(); val u=field("نام کاربری گلخانه",""); val p=field("رمز عبور",""); box.addView(u);box.addView(p)
        AlertDialog.Builder(this).setTitle("ورود به نسخه گلخانه").setView(box).setPositiveButton("ورود"){_,_->
            if(db.verifyAdminLogin(u.text.toString().trim(),p.text.toString())){db.setMode("GREENHOUSE");showHome()} else info("نام کاربری یا رمز عبور اشتباه است.")
        }.setNegativeButton("انصراف",null).show()
    }

    private fun greenhouseCredentialsDialog(){
        val box=formBox();val u=field("نام کاربری گلخانه",db.adminUsername());val p=field("رمز عبور جدید","");box.addView(u);box.addView(p)
        AlertDialog.Builder(this).setTitle("حساب گلخانه").setView(box).setPositiveButton("ذخیره"){_,_->if(u.text.isNotBlank()&&p.text.isNotBlank()){db.setAdminCredentials(u.text.toString().trim(),p.text.toString());info("اطلاعات ورود گلخانه ذخیره شد.")}else info("نام کاربری و رمز عبور را کامل وارد کنید.")}.setNegativeButton("انصراف",null).show()
    }

    private fun sellerCredentialsDialog(id:Long){
        val s=db.sellers().firstOrNull{it.id==id}?:return;val box=formBox();val u=field("نام کاربری",s.username);val p=field("رمز عبور جدید","");box.addView(u);box.addView(p)
        AlertDialog.Builder(this).setTitle("اطلاعات ورود فروشنده").setView(box).setPositiveButton("ذخیره"){_,_->if(u.text.isNotBlank()&&p.text.isNotBlank()){db.updateSellerCredentials(id,u.text.toString().trim(),p.text.toString());info("اطلاعات ورود ذخیره شد.")}else info("نام کاربری و رمز عبور را کامل وارد کنید.")}.setNegativeButton("انصراف",null).show()
    }

    private fun showPriceWarnings(){
        val root=base("هشدارهای قیمت","فروش‌ها و تحویل‌هایی که با قیمتی پایین‌تر از حداقل قیمت همان گل و اندازه ثبت شده‌اند.")
        val sid=if(db.isSellerMode()) db.currentSellerId() else null
        val rows=db.priceWarnings(sid)
        if(rows.isEmpty()) root.addView(label("هشداری وجود ندارد.")) else rows.forEach{r->root.addView(cardText("⚠️ ${r.type}\n${r.sellerName}\n${r.flowerName} | اندازه: ${r.size}\nقیمت ثبت‌شده: ${money(r.price)} ریال\nحداقل مجاز: ${money(r.minPrice)} ریال\nتعداد: ${r.qty} دسته\nتاریخ: ${r.date}"))}
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun sellerBalanceText(id:Long):String { val b=db.greenhouseBalance(id); return "بدهی به گلخانه: ${money(maxOf(b,0L))} ریال\nطلب از گلخانه: ${money(maxOf(-b,0L))} ریال\nوضعیت: ${if(b==0L) "تسویه" else if(b>0) "بدهکار گلخانه" else "طلبکار از گلخانه"}" }

    private fun tableHeader(cells:List<String>):LinearLayout=tableRow(cells,true)
    private fun tableRow(cells:List<String>,header:Boolean=false):LinearLayout{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(4),dp(2),dp(4),dp(2));background=GradientDrawable().apply{cornerRadius=dp(8).toFloat();setColor(if(header) Color.rgb(63,58,70) else Color.rgb(31,29,37));setStroke(dp(1),Color.rgb(65,60,72))};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).also{it.setMargins(0,dp(1),0,dp(1))}}
        cells.forEach{value->row.addView(TextView(this).apply{text=value;textSize=if(header)14f else 13.5f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setTypeface(Typeface.DEFAULT,if(header)Typeface.BOLD else Typeface.NORMAL);setPadding(dp(4),0,dp(4),0);layoutParams=LinearLayout.LayoutParams(0,-1,1f)})};return row}
    private fun cardBackground()=
GradientDrawable().apply{cornerRadius=dp(18).toFloat();setColor(Color.rgb(35,32,42));setStroke(dp(1),Color.rgb(70,64,78))}
    private fun cardText(text:String):TextView=TextView(this).apply{textSize=16f;setTextColor(Color.WHITE);setPadding(dp(18),dp(16),dp(18),dp(16));gravity=Gravity.CENTER_VERTICAL;includeFontPadding=true;background=cardBackground();val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(9));layoutParams=lp}
    private fun cardRow(text:String, build:(LinearLayout)->Unit):LinearLayout{val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(12),dp(10),dp(12),dp(10));background=cardBackground();val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(9));layoutParams=lp};box.addView(TextView(this).apply{this.text=text;textSize=16f;setTextColor(Color.WHITE);gravity=Gravity.CENTER_VERTICAL;includeFontPadding=true;setPadding(dp(8),dp(8),dp(8),dp(12))});build(box);return box}
    private fun label(t:String)=TextView(this).apply{text=t;textSize=15f;setTextColor(Color.LTGRAY);setPadding(dp(6),dp(10),dp(6),dp(5));includeFontPadding=true}
    private fun formBox()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(12),dp(4));layoutDirection=View.LAYOUT_DIRECTION_RTL}
    private fun field(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;inputType=InputType.TYPE_CLASS_TEXT;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8))}
    private fun numberField(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8))}
    private fun moneyField(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(if(value.isBlank()) "" else value.replace(",",""));textSize=17f;inputType=InputType.TYPE_CLASS_NUMBER;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8));addTextChangedListener(object:TextWatcher{private var busy=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(e:Editable?){if(busy)return;val raw=e?.toString()?.replace(",","")?.filter{it.isDigit()}?:"";if(raw.isEmpty())return;val n=raw.toLongOrNull()?:return;val formatted=nf.format(n);if(e.toString()!=formatted){busy=true;setText(formatted);setSelection(formatted.length);busy=false}}})}
    private fun parseMoney(e:EditText):Long=e.text.toString().replace(",","").filter{it.isDigit()}.toLongOrNull()?:0L
    private fun jalaliDateTime(ms:Long):String{
        val c=Calendar.getInstance().apply{timeInMillis=ms}
        return "${jalaliDate(ms)} ${"%02d:%02d".format(Locale.US,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE))}"
    }

    private fun jalaliDate(ms:Long):String{val c=Calendar.getInstance();c.timeInMillis=ms;return jalali(c)}
    private fun spinner(label:String,items:List<String>,height:Int)=Spinner(this).apply{adapter=object:ArrayAdapter<String>(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items){override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{val v=super.getView(position,convertView,parent) as TextView;v.textSize=17f;v.setTextColor(Color.WHITE);v.gravity=Gravity.CENTER_VERTICAL or Gravity.RIGHT;v.setPadding(dp(12),0,dp(12),0);return v}};contentDescription=label;layoutDirection=View.LAYOUT_DIRECTION_RTL;minimumHeight=dp(height)}
    private fun divider()=Space(this).apply{minimumHeight=dp(8)}
    private fun simpleListener(fn:()->Unit)=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){fn()}}
    private fun money(v:Long)=nf.format(v)
    private fun fmtPercent(v:Double)=String.format(Locale.US,"%.1f",v).trimEnd('0').trimEnd('.')
    private fun confirmDelete(msg:String,action:()->Unit){AlertDialog.Builder(this).setMessage(msg).setNegativeButton("انصراف",null).setPositiveButton("حذف"){_,_->action()}.show()}
    private fun info(msg:String,after:(()->Unit)?=null){AlertDialog.Builder(this).setMessage(msg).setPositiveButton("باشه"){_,_->after?.invoke()}.show()}

    data class Flower(val id:Long,val name:String,val size:String,val basePrice:Long,val minPrice:Long)
    data class Seller(val id:Long,val name:String,val phone:String,val username:String)
    data class SaleRow(val flowerName:String,val size:String,val qty:Int,val price:Long,val date:String,val synced:Boolean)
    data class PaymentRow(val amount:Long,val date:String)
    data class PaymentHistoryRow(val sellerName:String,val amount:Long,val date:String)
    data class GreenhouseSaleRow(val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
    data class SellerSaleReportRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
    data class ReturnReportRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val reason:String)
    data class Dash(val deliveredToday:Int,val soldToday:Int,val returnedToday:Int,val salesToday:Long,val stock:Int,val greenhouseDue:Long)

    private fun todayJalali():String = jalali(Calendar.getInstance().apply{timeInMillis=db.appDate()})
    private fun jalali(c:Calendar):String {
        val gy=c.get(Calendar.YEAR); val gm=c.get(Calendar.MONTH)+1; val gd=c.get(Calendar.DAY_OF_MONTH)
        val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31)
        var days=355666 + 365*gy + ((gy+3)/4) - ((gy+99)/100) + ((gy+399)/400) + gd
        for(i in 1 until gm) days += gdm[i]
        if(gm>2 && isLeapGregorian(gy)) days++
        var jy=-1595 + 33*(days/12053); days%=12053
        jy += 4*(days/1461); days%=1461
        if(days>365){jy += (days-1)/365; days=(days-1)%365}
        val jm=if(days<186) 1 + days/31 else 7 + (days-186)/30
        val jd=1 + if(days<186) days%31 else (days-186)%30
        return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
    }
    private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)

    class GolYarDb(ctx:Context):SQLiteOpenHelper(ctx,"golyar.db",null,6){
        private val appContext = ctx.applicationContext
        override fun onCreate(db:SQLiteDatabase){
            db.execSQL("CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,size TEXT NOT NULL,base_price INTEGER NOT NULL,min_price INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,username TEXT NOT NULL DEFAULT '',password TEXT NOT NULL DEFAULT '',share REAL NOT NULL DEFAULT 20)")
            db.execSQL("CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER NOT NULL DEFAULT 0,created_at INTEGER)")
            db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,created_at INTEGER,sync_state TEXT DEFAULT 'PENDING')")
            db.execSQL("CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,reason TEXT,created_at INTEGER)")
            db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,created_at INTEGER,payment_date INTEGER)")
            db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT)")
            db.execSQL("INSERT INTO settings(key,value) VALUES('default_seller_share','20')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('admin_username','admin')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('admin_password','1234')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('app_date',System.currentTimeMillis().toString())")
            db.execSQL("INSERT INTO settings(key,value) VALUES('admin_setup_done','0')")
        }
        override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){
            if(oldVersion<2){db.execSQL("ALTER TABLE sellers ADD COLUMN share REAL NOT NULL DEFAULT 20");db.execSQL("ALTER TABLE sales ADD COLUMN sync_state TEXT DEFAULT 'PENDING'");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('default_seller_share','20')")}
            if(oldVersion<3){db.execSQL("ALTER TABLE payments ADD COLUMN payment_date INTEGER");db.execSQL("UPDATE payments SET payment_date=created_at WHERE payment_date IS NULL")}
            if(oldVersion<4){db.execSQL("ALTER TABLE deliveries ADD COLUMN price INTEGER NOT NULL DEFAULT 0");db.execSQL("UPDATE deliveries SET price=COALESCE((SELECT base_price FROM flowers WHERE flowers.id=deliveries.flower_id),0) WHERE price=0")}
            if(oldVersion<5){db.execSQL("ALTER TABLE flowers ADD COLUMN size TEXT NOT NULL DEFAULT 'استاندارد'");db.execSQL("ALTER TABLE sellers ADD COLUMN username TEXT NOT NULL DEFAULT ''");db.execSQL("ALTER TABLE sellers ADD COLUMN password TEXT NOT NULL DEFAULT ''");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_username','admin')");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_password','1234')");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('app_date',?)",arrayOf(System.currentTimeMillis().toString()))}
            if(oldVersion<6){db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_setup_done','0')")}
        }
        private fun cv(vararg p:Pair<String,Any?>)=ContentValues().also{p.forEach{(k,v)->when(v){is String->it.put(k,v);is Int->it.put(k,v);is Long->it.put(k,v);is Double->it.put(k,v);null->it.putNull(k)}}}
        fun setMode(v:String?){val sp=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE);sp.edit().putString("mode",v).apply()}
        fun getMode():String?=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE).getString("mode",null)
        fun isSellerMode()=getMode()?.startsWith("SELLER:")==true
        fun currentSellerId():Long?=getMode()?.substringAfter("SELLER:")?.toLongOrNull()
        fun upsertFlower(id:Long?,name:String,size:String,base:Long,min:Long){val v=cv("name" to name,"size" to size,"base_price" to base,"min_price" to min);if(id==null)writableDatabase.insert("flowers",null,v)else writableDatabase.update("flowers",v,"id=?",arrayOf(id.toString()))}
        fun upsertSeller(id:Long?,name:String,phone:String,username:String,password:String,share:Double){val v=cv("name" to name,"phone" to phone,"username" to username,"password" to password,"share" to share);if(id==null)writableDatabase.insert("sellers",null,v)else writableDatabase.update("sellers",v,"id=?",arrayOf(id.toString()))}
        fun flowers():List<Flower>{val l=mutableListOf<Flower>();q("SELECT id,name,size,base_price,min_price FROM flowers ORDER BY name,size"){c->l.add(Flower(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getLong(4)))};return l}
        fun sellers():List<Seller>{val l=mutableListOf<Seller>();q("SELECT id,name,phone,username FROM sellers ORDER BY name"){c->l.add(Seller(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:""))};return l}
        private fun q(sql:String,block:(android.database.Cursor)->Unit){readableDatabase.rawQuery(sql,null).use{while(it.moveToNext())block(it)}}
        fun delete(table:String,id:Long){writableDatabase.delete(table,"id=?",arrayOf(id.toString()))}
        fun addDelivery(s:Long,f:Long,q:Int,p:Long,createdAt:Long=appDate()){writableDatabase.insert("deliveries",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to createdAt))}
        fun addSale(s:Long,f:Long,q:Int,p:Long,saleDate:Long){writableDatabase.insert("sales",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to saleDate,"sync_state" to "PENDING"))}
        fun addReturn(s:Long,f:Long,q:Int,r:String){writableDatabase.insert("returns",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"reason" to r,"created_at" to appDate()))}
        fun addPayment(s:Long,a:Long,paymentDate:Long){writableDatabase.insert("payments",null,cv("seller_id" to s,"amount" to a,"created_at" to appDate(),"payment_date" to paymentDate))}
        fun sellerFlowerStock(s:Long,f:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=? AND flower_id=?),0)",arrayOf(s,f,s,f,s,f)).toInt()
        fun sellerStock(s:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=?),0)",arrayOf(s,s,s)).toInt()
        fun sellerShare(s:Long):Double=readableDatabase.rawQuery("SELECT share FROM sellers WHERE id=?",arrayOf(s.toString())).use{if(it.moveToFirst())it.getDouble(0) else getDefaultSellerShare()}
        fun getDefaultSellerShare():Double=setting("default_seller_share",20.0)
        fun setDefaultSellerShare(v:Double){writableDatabase.update("settings",cv("value" to v.toString()),"key='default_seller_share'",null)}
        fun sellerSalesTotal(s:Long):Long=one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE seller_id=?",arrayOf(s))
        fun sellerCommission(s:Long):Long=(sellerSalesTotal(s)*sellerShare(s)/100.0).toLong()
        fun paidToGreenhouse(s:Long):Long=one("SELECT COALESCE(SUM(amount),0) FROM payments WHERE seller_id=?",arrayOf(s))
        fun greenhouseCharges(s:Long):Long=one("SELECT COALESCE(SUM(qty*price),0) FROM deliveries WHERE seller_id=?",arrayOf(s))
        fun returnCredits(s:Long):Long{var total=0L;readableDatabase.rawQuery("SELECT r.flower_id,r.qty FROM returns r WHERE r.seller_id=?",arrayOf(s.toString())).use{c->while(c.moveToNext()){val f=c.getLong(0);val q=c.getInt(1);val avg=one("SELECT CASE WHEN COALESCE(SUM(qty),0)=0 THEN 0 ELSE CAST(SUM(qty*price) AS INTEGER)/SUM(qty) END FROM deliveries WHERE seller_id=? AND flower_id=?",arrayOf(s,f));total+=q*avg}};return total}
        fun greenhouseBalance(s:Long):Long=greenhouseCharges(s)-returnCredits(s)-paidToGreenhouse(s)
        fun greenhouseDue(s:Long):Long=greenhouseBalance(s)
        fun payments(s:Long):List<PaymentRow>{val l=mutableListOf<PaymentRow>();readableDatabase.rawQuery("SELECT amount,COALESCE(payment_date,created_at) FROM payments WHERE seller_id=? ORDER BY COALESCE(payment_date,created_at) DESC,id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(PaymentRow(c.getLong(0),jalaliDate(c.getLong(1))))};return l}
        fun allPayments():List<PaymentHistoryRow>{val l=mutableListOf<PaymentHistoryRow>();readableDatabase.rawQuery("SELECT s.name,p.amount,COALESCE(p.payment_date,p.created_at) FROM payments p JOIN sellers s ON s.id=p.seller_id ORDER BY s.name,COALESCE(p.payment_date,p.created_at) DESC,p.id DESC",null).use{c->while(c.moveToNext())l.add(PaymentHistoryRow(c.getString(0),c.getLong(1),jalaliDate(c.getLong(2))))};return l}
        fun dashboard(sellerId:Long?):Dash{val condition=sellerId?.let { " AND seller_id=$it" } ?: "";val todayStart=dayStart();val todayEnd=todayStart+86400000;val deliveredToday=one("SELECT COALESCE(SUM(qty),0) FROM deliveries WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val soldToday=one("SELECT COALESCE(SUM(qty),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val returnedToday=one("SELECT COALESCE(SUM(qty),0) FROM returns WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val salesToday=if(sellerId!=null)one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)) else one("SELECT COALESCE(SUM(qty*price),0) FROM deliveries WHERE created_at>=? AND created_at<?",arrayOf(todayStart,todayEnd));val stock=if(sellerId!=null)sellerStock(sellerId) else one("SELECT COALESCE(SUM(qty),0) FROM deliveries").toInt()-one("SELECT COALESCE(SUM(qty),0) FROM returns").toInt();val due=if(sellerId!=null)greenhouseBalance(sellerId) else sellers().sumOf{greenhouseBalance(it.id)};return Dash(deliveredToday,soldToday,returnedToday,salesToday,stock,due)}
        fun greenhouseSales(s:Long):List<GreenhouseSaleRow>{val l=mutableListOf<GreenhouseSaleRow>();readableDatabase.rawQuery("SELECT f.name,f.size,d.qty,d.price,d.qty*d.price,d.created_at FROM deliveries d JOIN flowers f ON f.id=d.flower_id WHERE d.seller_id=? ORDER BY d.created_at DESC,d.id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(GreenhouseSaleRow(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),c.getLong(4),jalaliDate(c.getLong(5))))};return l}
        fun allReturns():List<ReturnReportRow>{val l=mutableListOf<ReturnReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,r.qty,r.reason FROM returns r JOIN sellers s ON s.id=r.seller_id JOIN flowers f ON f.id=r.flower_id ORDER BY r.created_at DESC,r.id DESC",null).use{c->while(c.moveToNext())l.add(ReturnReportRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(4)?:""))};return l}
        fun allSellerSalesReport():List<SellerSaleReportRow>{val l=mutableListOf<SellerSaleReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,sa.qty,sa.price,sa.qty*sa.price,sa.created_at FROM sales sa JOIN sellers s ON s.id=sa.seller_id JOIN flowers f ON f.id=sa.flower_id ORDER BY s.name,sa.created_at DESC,sa.id DESC",null).use{c->while(c.moveToNext())l.add(SellerSaleReportRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getLong(4),c.getLong(5),jalaliDate(c.getLong(6))))};return l}
        fun sales(s:Long):List<SaleRow>{val l=mutableListOf<SaleRow>();readableDatabase.rawQuery("SELECT f.name,f.size,s.qty,s.price,s.created_at,s.sync_state FROM sales s JOIN flowers f ON f.id=s.flower_id WHERE s.seller_id=? ORDER BY s.created_at DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(SaleRow(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),jalaliDate(c.getLong(4)),c.getString(5)!="PENDING"))};return l}
        data class DayTotals(val qty:Int,val total:Long,val avg:Long,val balance:Long)
        fun greenhouseSalesFiltered(sellerId:Long?,dateMs:Long):List<DetailedGreenhouseRow>{val c=Calendar.getInstance().apply{timeInMillis=dateMs;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)};val from=c.timeInMillis;val to=from+86400000;val where=if(sellerId==null)"" else " AND d.seller_id=$sellerId";val l=mutableListOf<DetailedGreenhouseRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,d.qty,d.price,d.qty*d.price,d.created_at FROM deliveries d JOIN sellers s ON s.id=d.seller_id JOIN flowers f ON f.id=d.flower_id WHERE d.created_at>=? AND d.created_at<?$where ORDER BY s.name,d.created_at DESC,d.id DESC",arrayOf(from.toString(),to.toString())).use{curs->while(curs.moveToNext())l.add(DetailedGreenhouseRow(curs.getString(0),curs.getString(1),curs.getString(2),curs.getInt(3),curs.getLong(4),curs.getLong(5),jalaliDate(curs.getLong(6))))};return l}
        fun greenhouseDayTotals(sellerId:Long?,dateMs:Long):DayTotals{val c=Calendar.getInstance().apply{timeInMillis=dateMs;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)};val from=c.timeInMillis;val to=from+86400000;val where=if(sellerId==null)"" else " AND d.seller_id=$sellerId";val q=one("SELECT COALESCE(SUM(qty),0) FROM deliveries d WHERE d.created_at>=? AND d.created_at<?$where",arrayOf(from,to));val total=one("SELECT COALESCE(SUM(qty*price),0) FROM deliveries d WHERE d.created_at>=? AND d.created_at<?$where",arrayOf(from,to));val avg=if(q==0L)0 else total/q;val bal=if(sellerId==null)sellers().sumOf{greenhouseBalance(it.id)} else greenhouseBalance(sellerId);return DayTotals(q.toInt(),total,avg,bal)}
        data class SellerSaleDetail(val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
        fun sellerSalesDetailed(s:Long):List<SellerSaleDetail>{val l=mutableListOf<SellerSaleDetail>();readableDatabase.rawQuery("SELECT f.name,f.size,sa.qty,sa.price,sa.qty*sa.price,sa.created_at FROM sales sa JOIN flowers f ON f.id=sa.flower_id WHERE sa.seller_id=? ORDER BY sa.created_at DESC,sa.id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(SellerSaleDetail(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),c.getLong(4),jalaliDate(c.getLong(5))))};return l}
        data class DetailedGreenhouseRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)

        fun firebaseSnapshot():Map<String,Any>{
            fun rows(sql:String, mapper:(android.database.Cursor)->Map<String,Any?>):List<Map<String,Any?>>{val out=mutableListOf<Map<String,Any?>>();readableDatabase.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(mapper(c))};return out}
            return mapOf(
                "flowers" to rows("SELECT id,name,size,base_price,min_price FROM flowers"){mapOf("id" to it.getLong(0),"name" to it.getString(1),"size" to it.getString(2),"base_price" to it.getLong(3),"min_price" to it.getLong(4))},
                "sellers" to rows("SELECT id,name,phone,username,share FROM sellers"){mapOf("id" to it.getLong(0),"name" to it.getString(1),"phone" to (it.getString(2)?:("")),"username" to it.getString(3),"share" to it.getDouble(4))},
                "deliveries" to rows("SELECT seller_id,flower_id,qty,price,created_at FROM deliveries"){mapOf("seller_id" to it.getLong(0),"flower_id" to it.getLong(1),"qty" to it.getInt(2),"price" to it.getLong(3),"created_at" to it.getLong(4))},
                "sales" to rows("SELECT seller_id,flower_id,qty,price,created_at,sync_state FROM sales"){mapOf("seller_id" to it.getLong(0),"flower_id" to it.getLong(1),"qty" to it.getInt(2),"price" to it.getLong(3),"created_at" to it.getLong(4),"sync_state" to it.getString(5))},
                "returns" to rows("SELECT seller_id,flower_id,qty,reason,created_at FROM returns"){mapOf("seller_id" to it.getLong(0),"flower_id" to it.getLong(1),"qty" to it.getInt(2),"reason" to it.getString(3),"created_at" to it.getLong(4))},
                "payments" to rows("SELECT seller_id,amount,created_at,payment_date FROM payments"){mapOf("seller_id" to it.getLong(0),"amount" to it.getLong(1),"created_at" to it.getLong(2),"payment_date" to (it.getLong(3)))}
            )
        }

        fun flowerDelivered(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM deliveries WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun flowerSold(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM sales WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun flowerReturned(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM returns WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun sellerPassword(id:Long):String=readableDatabase.rawQuery("SELECT password FROM sellers WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getString(0)?:"" else ""}
        fun verifySellerLogin(id:Long,u:String,p:String):Boolean=readableDatabase.rawQuery("SELECT 1 FROM sellers WHERE id=? AND username=? AND password=?",arrayOf(id.toString(),u,p)).use{it.moveToFirst()}
        fun adminUsername():String=settingText("admin_username","admin")
        fun setAdminCredentials(u:String,p:String){setSettingText("admin_username",u);setSettingText("admin_password",p)}
        fun isAdminSetupDone():Boolean=settingText("admin_setup_done","0")=="1"
        fun setAdminSetupDone(){setSettingText("admin_setup_done","1")}
        fun verifyAdminLogin(u:String,p:String):Boolean=u==adminUsername()&&p==settingText("admin_password","1234")
        fun updateSellerCredentials(id:Long,u:String,p:String){writableDatabase.update("sellers",cv("username" to u,"password" to p),"id=?",arrayOf(id.toString()))}
        fun appDate():Long=settingText("app_date",System.currentTimeMillis().toString()).toLongOrNull()?:System.currentTimeMillis()
        fun setAppDate(ms:Long)=setSettingText("app_date",ms.toString())
        fun lastFirebaseSync():Long?=settingText("last_firebase_sync","").toLongOrNull()
        fun setLastFirebaseSync(ms:Long)=setSettingText("last_firebase_sync",ms.toString())
        private fun settingText(k:String,d:String):String=readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0)?:d else d}
        private fun setSettingText(k:String,v:String){writableDatabase.insertWithOnConflict("settings",null,cv("key" to k,"value" to v),SQLiteDatabase.CONFLICT_REPLACE)}
        data class DetailedSaleRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val price:Long,val total:Long,val date:String)
        fun detailedSales(sellerId:Long?,from:Long,to:Long):List<DetailedSaleRow>{val l=mutableListOf<DetailedSaleRow>();val extra=if(sellerId==null)"" else " AND sa.seller_id=$sellerId";readableDatabase.rawQuery("SELECT s.name,f.name,f.size,sa.qty,sa.price,sa.qty*sa.price,sa.created_at FROM sales sa JOIN sellers s ON s.id=sa.seller_id JOIN flowers f ON f.id=sa.flower_id WHERE sa.created_at>=? AND sa.created_at<=?$extra ORDER BY sa.created_at DESC,sa.id DESC",arrayOf(from.toString(),to.toString())).use{c->while(c.moveToNext())l.add(DetailedSaleRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getLong(4),c.getLong(5),jalaliDate(c.getLong(6))))};return l}
        data class PriceWarning(val type:String,val sellerName:String,val flowerName:String,val size:String,val qty:Int,val price:Long,val minPrice:Long,val date:String)
        fun lowPriceWarningCount(sellerId:Long?):Int{val where=if(sellerId==null)"" else " AND d.seller_id=$sellerId";return one("SELECT COUNT(*) FROM deliveries d JOIN flowers f ON f.id=d.flower_id WHERE d.price<f.min_price$where").toInt()+one("SELECT COUNT(*) FROM sales s JOIN flowers f ON f.id=s.flower_id WHERE s.price<f.min_price${if(sellerId==null)"" else " AND s.seller_id=$sellerId"}").toInt()}
        fun priceWarnings(sellerId:Long?):List<PriceWarning>{val l=mutableListOf<PriceWarning>();val dWhere=if(sellerId==null)"" else " AND d.seller_id=$sellerId";readableDatabase.rawQuery("SELECT 'تحویل گلخانه',s.name,f.name,f.size,d.qty,d.price,f.min_price,d.created_at FROM deliveries d JOIN sellers s ON s.id=d.seller_id JOIN flowers f ON f.id=d.flower_id WHERE d.price<f.min_price$dWhere ORDER BY d.created_at DESC",null).use{c->while(c.moveToNext())l.add(PriceWarning(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),c.getLong(5),c.getLong(6),jalaliDate(c.getLong(7))))};val sWhere=if(sellerId==null)"" else " AND sa.seller_id=$sellerId";readableDatabase.rawQuery("SELECT 'فروش فروشنده',s.name,f.name,f.size,sa.qty,sa.price,f.min_price,sa.created_at FROM sales sa JOIN sellers s ON s.id=sa.seller_id JOIN flowers f ON f.id=sa.flower_id WHERE sa.price<f.min_price$sWhere ORDER BY sa.created_at DESC",null).use{c->while(c.moveToNext())l.add(PriceWarning(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),c.getLong(5),c.getLong(6),jalaliDate(c.getLong(7))))};return l}

        private fun setting(k:String,d:Double):Double=readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0).toDoubleOrNull()?:d else d}
        private fun one(sql:String,args:Array<Any?> = emptyArray()):Long{val a=args.map{it.toString()}.toTypedArray();readableDatabase.rawQuery(sql,a).use{it.moveToFirst();return it.getLong(0)}}
        private fun dayStart():Long{val c=Calendar.getInstance();c.timeInMillis=appDate();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.timeInMillis}
        private fun jalaliDateTime(ms:Long):String{
            val c=Calendar.getInstance().apply{timeInMillis=ms}
            return "${jalaliDate(ms)} ${"%02d:%02d".format(Locale.US,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE))}"
        }
        private fun jalaliDate(ms:Long):String{val c=Calendar.getInstance();c.timeInMillis=ms;val gy=c.get(Calendar.YEAR);val gm=c.get(Calendar.MONTH)+1;val gd=c.get(Calendar.DAY_OF_MONTH);val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31);var days=355666+365*gy+((gy+3)/4)-((gy+99)/100)+((gy+399)/400)+gd;for(i in 1 until gm)days+=gdm[i];if(gm>2&&isLeapGregorian(gy))days++;var jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365};val jm=if(days<186)1+days/31 else 7+(days-186)/30;val jd=1+if(days<186)days%31 else(days-186)%30;return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)}
        private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)
    }
}
