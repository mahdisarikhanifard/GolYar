import sqlite3, hashlib, re

con=sqlite3.connect(':memory:')
c=con.cursor()
c.executescript('''
CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,username TEXT,share REAL,remote_id TEXT UNIQUE);
CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,size TEXT,base_price INTEGER,min_price INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,seller_share_amount INTEGER,greenhouse_amount INTEGER,min_price_snapshot INTEGER,below_minimum INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,remote_id TEXT UNIQUE);
''')
# Source device: seller local id 1, flower local id 1.
c.execute("INSERT INTO sellers(name,username,share,remote_id) VALUES('علی','ali',20,'seller-A')")
c.execute("INSERT INTO flowers(name,size,base_price,min_price,remote_id) VALUES('رز','50',100000,90000,'flower-R50')")
c.execute("INSERT INTO deliveries VALUES(NULL,1,1,100,100000,'delivery-A')")
# 10 sold at 95k: seller gets 20%, greenhouse gets 80%, below minimum.
total=10*95000; seller_share=total*20//100; greenhouse=total-seller_share
c.execute("INSERT INTO sales VALUES(NULL,1,1,10,95000,?,?,?,?,?)",(seller_share,greenhouse,90000,1,'sale-A'))
c.execute("INSERT INTO returns VALUES(NULL,1,1,5,'return-A')")
c.execute("INSERT INTO payments VALUES(NULL,1,500000,'payment-A')")

# Settlement invariants.
stock=c.execute('SELECT SUM(qty) FROM deliveries WHERE seller_id=1').fetchone()[0]-c.execute('SELECT SUM(qty) FROM sales WHERE seller_id=1').fetchone()[0]-c.execute('SELECT SUM(qty) FROM returns WHERE seller_id=1').fetchone()[0]
sales_total=c.execute('SELECT SUM(qty*price) FROM sales WHERE seller_id=1').fetchone()[0]
commission=c.execute('SELECT SUM(seller_share_amount) FROM sales WHERE seller_id=1').fetchone()[0]
greenhouse_due=c.execute('SELECT SUM(greenhouse_amount) FROM sales WHERE seller_id=1').fetchone()[0]
paid=c.execute('SELECT SUM(amount) FROM payments WHERE seller_id=1').fetchone()[0]
balance=greenhouse_due-paid
assert stock==85, stock
assert sales_total==950000
assert commission==190000
assert greenhouse_due==760000
assert paid==500000
assert balance==260000
assert c.execute('SELECT COUNT(*) FROM sales WHERE below_minimum=1').fetchone()[0]==1

# Simulate a second device with different local IDs; map by stable remote IDs.
c.execute("INSERT INTO sellers(name,username,share,remote_id) VALUES('سارا','sara',30,'seller-B')")
c.execute("INSERT INTO flowers(name,size,base_price,min_price,remote_id) VALUES('رز','40',80000,70000,'flower-R40')")
# Remote record from source must resolve seller-A/flower-R50, not numeric ids.
seller_local=c.execute("SELECT id FROM sellers WHERE remote_id='seller-A'").fetchone()[0]
flower_local=c.execute("SELECT id FROM flowers WHERE remote_id='flower-R50'").fetchone()[0]
assert seller_local==1 and flower_local==1

# Ensure no plaintext Firebase password is present in source package.
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=(ROOT/'app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'Ham' not in source
assert 'admin_firebase_password' in source
assert 'AES/GCM/NoPadding' in source

print('PASS: settlement arithmetic')
print('PASS: stock arithmetic')
print('PASS: below-minimum detection')
print('PASS: stable seller/flower remote-ID mapping')
print('PASS: Firebase password is not hard-coded in source')


# v1.3.2 static integration checks
from pathlib import Path
source = Path("app/src/main/java/com/example/golyar/MainActivity.kt").read_text(encoding="utf-8")
gradle = Path("app/build.gradle.kts").read_text(encoding="utf-8")
assert 'versionName = "1.8.42"' in gradle
assert 'versionCode = 144' in gradle
assert 'whereEqualTo("seller_remote_id", sellerRemoteId)' in source
assert 'auth_uid-only query for payments' in source
assert 'queries[index].get()' in source, "seller pull must execute Firestore queries"
assert 'whereEqualTo("auth_uid", firebaseAuth.currentUser?.uid.orEmpty())' not in source, "seller payments must not use a rules-incompatible auth_uid-only query"
assert 'fun goBack()' in source
assert 'db.delete("flowers", f.id); showFlowers(); syncWithFirebaseIfOnline(false)' in source
assert 'private fun detachFromParent(view: View)' in source
assert 'detachFromParent(root)' in source
assert 'showFinancialReport' in source
assert '🧾 فروش متفرقه گلخانه' in source
assert '💰 هزینه‌های گلخانه' in source
assert 'val sellerSharePercent=db.sellerShare(s.id)' in source
assert 'val shareTotal=saleRows.sumOf{(it.total*sellerSharePercent/100.0).toLong()}' in source
assert 'sellerShareAmount' not in source[source.index('private fun showFinancialReport()'):source.index('private fun showGreenhouseInventoryReport()')]
assert 'private fun renderGreenhouseExpensesPage(title: String, subtitle: String)' in source
assert 'private fun showMiscSalesReport()' in source
assert 'private fun showGreenhouseExpensesReport()' in source
assert 'sameLogicalScreen' in source
assert 'page.post { androidx.core.view.ViewCompat.requestApplyInsets(page) }' in source
assert 'private fun showHome() {\n        screenBackStack.clear()' in source
assert 'FirebaseFirestore.getInstance(secondaryApp).collection("users").document(uid).set(data)' not in source
assert 'fs.collection("users").document(uid).set(data)' in source
assert 'تحویل، فروش و برگشتی‌ها' in source
assert 'گزارش مالی جامع' in source
print("PASS: v1.3.9 navigation/sync/delete/account/report integration checks")

# v1.3.3 report coverage: miscellaneous sales and greenhouse expenses must be
# independently readable and must not depend on seller records.
c.executescript('''
CREATE TABLE misc_sales(id INTEGER PRIMARY KEY AUTOINCREMENT,buyer_name TEXT,flower_id INTEGER,qty INTEGER,price INTEGER,payment_type TEXT);
CREATE TABLE greenhouse_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,recipient TEXT,amount INTEGER,expense_type TEXT,description TEXT);
''')
c.execute("INSERT INTO misc_sales(buyer_name,flower_id,qty,price,payment_type) VALUES('مشتری مستقیم',1,3,120000,'نقدی')")
c.execute("INSERT INTO misc_sales(buyer_name,flower_id,qty,price,payment_type) VALUES('مشتری دوم',1,2,150000,'کارتخوان')")
c.execute("INSERT INTO greenhouse_payments(recipient,amount,expense_type,description) VALUES('برق','180000','آب و برق','قبض')")
c.execute("INSERT INTO greenhouse_payments(recipient,amount,expense_type,description) VALUES('تعمیرات','70000','تعمیرات','تعمیر پمپ')")
misc_total=c.execute('SELECT COALESCE(SUM(qty*price),0) FROM misc_sales').fetchone()[0]
misc_qty=c.execute('SELECT COALESCE(SUM(qty),0) FROM misc_sales').fetchone()[0]
expense_total=c.execute('SELECT COALESCE(SUM(amount),0) FROM greenhouse_payments').fetchone()[0]
assert misc_total==660000 and misc_qty==5
assert expense_total==250000
assert misc_total-expense_total==410000
print('PASS: miscellaneous sales report arithmetic')
print('PASS: greenhouse expense report arithmetic')
print('PASS: v1.3.9 reports include misc sales and greenhouse expenses')

# v1.4.5 regression checks for requested UX and payment fixes
assert 'private fun addCircularRoleSelector(root: LinearLayout)' not in source
assert 'private fun addCircularShortcutWheel(root: LinearLayout, shortcuts: List<HomeShortcut>)' in source
assert 'root.addView(sectionTitle("منوی چرخشی"))' not in source
assert 'text = subtitle' in source
assert 'رمز عبور: ${db.sellerPassword(s.id)' in source
assert 'private fun editGreenhouseUserDialog(' in source
assert 'private fun forceBlackText(view: View)' in source
assert 'Color.BLACK' in source
assert 'val currentPassword = passwordField("رمز فعلی ورود این کاربر", savedOldPassword)' in source
assert 'val newPassword = (password.tag as EditText).text.toString()' in source
assert '"name" to display' in source
assert 'private fun showPaymentHistoryImpl(s:Seller, notice:String? = null)' in source
assert 'مجموع پرداخت‌ها' in source
assert '↻ دریافت دوبارهٔ پرداخت‌ها' in source
assert 'whereEqualTo("seller_remote_id", remoteId)' in source
assert 'if (!firebaseAuth.currentUser?.email.equals(db.adminFirebaseEmail(), ignoreCase = true)) firebaseAuth.signOut()' in source
header_block = source[source.index('private fun base('):source.index('private fun actionButton(')]
assert header_block.index('text = \"نسخه ${BuildConfig.VERSION_NAME}\"') < header_block.index('text = subtitle')
print('PASS: version appears above active account name in home header')
assert 'whereEqualTo("sellerRemoteId", remoteId)' in source
assert 'adminAccountDialog()' in source and 'تغییر نام کاربری و رمز عبور مدیر' in source
assert 'permissionChecks.filterValues' in source
print('PASS: v1.5.1 compact layout, combined admin account button, staff permissions, rose icon, and seller-payment checks')

# v1.5.1 layout assertions
assert 'root.addView(sectionTitle("منوی چرخشی"))' not in source
assert 'تغییر نام کاربری و رمز عبور مدیر' in source
assert 'حذف کاربر گلخانه' in source
assert 'collection("users").document(d.id).delete()' in source
assert 'طراح و برنامه‌نویس: مهدی ساریخانی فرد' in source
assert '۰۹۱۲۱۳۹۸۸۹۳' in source
print("PASS: v1.5.1 compact home layout, combined admin account action, greenhouse profile deletion, and designer credit")

# v1.5.1 requested visual fixes
source = (Path(__file__).parent / "app/src/main/java/com/example/golyar/MainActivity.kt").read_text()
assert 'WindowCompat.setDecorFitsSystemWindows(window, false)' in source
assert 'page.addView(scroll)' in source
assert 'page.addView(nav, LinearLayout.LayoutParams(-1, dp(56)))' in source
print("PASS: v1.5.1 safe system-bar spacing")

# Retained regression checks for circular menu, readable financial lists, navigation, and seller registration sync.
assert 'private fun addCircularShortcutWheel(root: LinearLayout, shortcuts: List<HomeShortcut>)' in source
assert 'shortcuts.chunked(2).forEachIndexed' in source
assert 'tile.animate().alpha(1f).translationY(0f)' in source
assert 'setTextColor(if(header) Color.WHITE else palette().text)' in source
assert 'private fun goBack()' in source and 'screenBackStack.removeLast()' in source
assert 'private fun renderMiscSalesPage(title: String, subtitle: String)' in source
assert 'private fun renderGreenhouseExpensesPage(title: String, subtitle: String)' in source
assert 'db.upsertSeller(s?.id,n,phone.text.toString().trim(),u,finalPassword,pct)' in source
assert 'syncWithFirebaseIfOnline(false)' in source[source.index('private fun sellerDialog'):source.index('private fun showMiscSale')]
print('PASS: animated shortcut cards, financial list contrast, back navigation, expense/sales ledgers, and seller sync checks')

# v1.5.3 real UI changes requested after v1.5.1: transparent rose launcher, compact spaced radial menu, system-bar-safe title/nav/buttons.
manifest = (Path(__file__).parent / "app/src/main/AndroidManifest.xml").read_text()
assert 'android:icon="@drawable/ic_launcher_rose"' in manifest and 'android:roundIcon="@drawable/ic_launcher_rose"' in manifest
assert (Path(__file__).parent / "app/src/main/res/drawable/ic_launcher_rose.xml").exists()
assert 'WindowCompat.setDecorFitsSystemWindows(window, false)' in source
assert 'tag = "APP_BOTTOM_NAV"' in source
assert 'LinearLayout.LayoutParams(0, dp(52), 1f)' in source
print('PASS: v1.5.3 rose launcher icon, visible title, and system-bar-safe bottom navigation/back area')

# v1.5.4 regression checks: gesture, system-bar-safe layout, launcher icon
assert 'WindowCompat.setDecorFitsSystemWindows(window, false)' in source
assert 'tag = "APP_BOTTOM_NAV"' in source
assert 'screenBottomNav[root] = child' in source
assert 'page.addView(nav, LinearLayout.LayoutParams(-1, dp(56)))' in source
assert 'setPadding(dp(12), dp(18), dp(12), dp(8))' in source
manifest = (Path(__file__).parent / 'app/src/main/AndroidManifest.xml').read_text()
assert 'android:icon="@drawable/ic_launcher_rose"' in manifest and 'android:roundIcon="@drawable/ic_launcher_rose"' in manifest
assert (Path(__file__).parent / 'app/src/main/res/drawable/ic_launcher_rose.xml').exists()
print('PASS: v1.5.4 fixed bottom navigation, lowered title, and rose launcher icon')

# v1.5.8: greenhouse staff permissions must hide navigation and guard direct entry.
assert 'private fun staffHasPermission(key: String): Boolean' in source
assert 'private fun requireStaffPermission(key: String, title: String): Boolean' in source
assert 'staffHasPermission("warnings")' in source
assert 'if (staffHasPermission("sellers")) root.addView(listCard("ثبت فروشنده"' in source
assert 'if (staffHasPermission("expense")) {' in source
assert '.setPositiveButton("ذخیره تغییرات")' in source
assert 'val permissionScroll = ScrollView(this).apply {' in source and 'Reserve a permanent footer area for the dialog action buttons' in source
assert 'private fun refreshStaffPermissionsFromCloud()' in source
assert 'Fully transparent canvas' in Path("app/src/main/res/drawable/ic_launcher_rose.xml").read_text(encoding="utf-8")
assert 'android:pathData="M0,0h108v108h-108z"' not in Path("app/src/main/res/drawable/ic_launcher_rose.xml").read_text(encoding="utf-8")
print("PASS: v1.5.8 staff permission filtering, save action visibility, cloud permission refresh, transparent rose icon")


# v1.5.9 database deletion and diagnostics regression checks
assert '"expense_types","greenhouse_daily_reports")' in source[source.index('private fun deleteOperationalFirebaseData'):source.index('private fun showPettyCashPeople')]
assert 'deleteOperationalFirebaseData(true)' in source
assert 'حذف کامل از گوشی و Firebase' in source
assert 'fun clearLastSyncMetadata()' in source
assert 'انواع هزینه: ${count("expense_types")}' in source
assert 'داده‌های باقی‌مانده در Firebase' in source or 'ممکن است بعداً دوباره همگام شوند' in source
assert 'destructiveDeleteInProgress' in source
print('PASS: v1.5.9 complete local/cloud deletion, expense-type coverage, and database diagnostics')


# v1.6.0: automatically resume the previous greenhouse staff session securely.
assert 'private fun resumeLastStaffSessionOrChooseMode()' in source
assert 'secureCredentials.get("last_staff_username")' in source
assert 'secureCredentials.get("last_staff_password")' in source
assert 'resumeLastStaffSessionOrChooseMode()' in source[source.index('private fun startEntryFlow'):source.index('private fun showModeChooser')]
assert 'db.setMode("GREENHOUSE:STAFF:$uid")' in source
assert 'secureCredentials.put("staff_firebase_$uid", password)' in source
assert 'golnegar_staff_permissions' in source
print('PASS: v1.6.0 securely restores the previous greenhouse staff session without prompting for credentials')

# v1.6.1 full-cleanup regression checks: preserve current admin profile, delete all other profiles, clear non-admin credentials.
assert 'fun deleteOtherUserProfiles()' in source
assert 'snap.documents.filter { it.id != preservedAdminUid }' in source
assert 'fs.collection("users").get()' in source
assert 'secureCredentials.removeByPrefixes(listOf("staff_", "last_staff_", "seller_firebase_"))' in source
assert 'حساب مدیر و تنظیمات اتصال حفظ شدند' in source
assert 'هویت‌های Firebase Authentication به دلیل محدودیت امنیتی حذف فیزیکی نشده‌اند' in source
assert 'users (پروفایل کاربران غیرمدیر)' in source
print("PASS: v1.6.1 full cleanup removes non-admin user profiles and local staff/seller credentials while preserving admin")


# v1.7.1 monthly financial close and archive regressions
assert 'fun closeCompletedFinancialMonths(): List<String>' in source
assert 'CREATE TABLE financial_month_archives' in source
assert 'private fun archiveMonth(month: String)' in source
assert 'fun financialArchives(): List<Pair<String, String>>' in source
assert 'fun saveCloudFinancialArchive(month: String, json: String)' in source
assert 'showFinancialArchives()' in source
assert 'financial_month_archives' in Path('firestore.rules').read_text(encoding='utf-8')
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'seller_balances' in source and 'sumBeforeMonth' in source
assert 'private fun <T> currentMonthRows(rows: List<T>' in source
assert 'return currentMonthRows(l){it.date}' in source
assert 'data class ReturnReportRow' in source and 'r.created_at' in source
print('PASS: v1.7.1 monthly close, read-only financial archives, carry-forward balance snapshots, and cloud archive rules')


# v1.7.2: petty-cash access/contrast and seller-specific monthly archive UI.
assert '👛 مدیریت صندوق تنخواه' in source
assert 'private fun showPettyCashPeople()' in source
assert '✏️ ویرایش نام تنخواه' in source
assert 'private fun showSellerFinancialArchives(sellerId: Long)' in source
assert 'private fun showSellerFinancialArchiveDetail(sellerId: Long, month: String, json: String)' in source
assert 'row.optLong("seller_id", -1L) == sellerId' in source
assert 'آرشیو ماه‌های مالی من' in source
assert 'versionName = "1.8.42"' in gradle and 'versionCode = 144' in gradle
workflow = Path('.github/workflows/build.yml').read_text(encoding='utf-8')
assert 'GolNegar_v1.8.42_Source_Final.zip' in workflow
assert 'GolNegar-v1.8.42-debug.apk' in workflow
print('PASS: v1.7.3 petty-cash settings/edit access and seller-specific monthly archives')

# v1.7.3 petty-cash edit integration checks
assert '✏️ ویرایش نام تنخواه' in source
assert 'fun updatePettyCashPerson(id:Long,name:String)' in source
assert 'db.updatePettyCashPerson(person.id, newName)' in source
print("PASS: petty-cash name editing is wired to local database and Firebase sync")

# v1.7.4 theme customization integration checks
assert 'private fun showThemeSettings()' in source
assert 'private fun showAccentColorDialog()' in source
assert 'theme_${themeScope()}' in source
assert 'accent_${themeScope()}' in source
assert 'ظاهر و رنگ‌بندی' in source
assert 'باغ رز' in source and 'آبی اقیانوسی' in source and 'فیروزه‌ای' in source
assert 'private fun themeGradient()' in source and 'private fun themeCardBackground()' in source
assert 'mixColor(custom, Color.WHITE, 0.27f)' in source
assert 'setTextColor(Color.WHITE)' in source
assert 'GradientDrawable.Orientation.TL_BR' in source
print('PASS: v1.7.5 stronger theme gradients, custom accent propagation, and role-specific preferences')

# v1.7.6 category navigation checks
assert 'تحویل، فروش و برگشتی‌ها' in source
assert 'تحلیل فروش و موجودی' in source
assert 'امور مالی و صندوق' in source
assert 'showReportCategory' in source
assert 'showAdminSettingsCategory' in source
print("PASS: v1.7.6 settings and reports category navigation")


# v1.7.7 petty-cash accounting rules and consistent premium card layout.
assert 'fun pettyCashStats(id:Long):Triple<Long,Long,Int>' in source
assert 'fun archivePettyCashPerson(id:Long)' in source
assert 'مانده صندوق: ${money(balance)} ریال' in source
assert 'تعداد گردش‌ها: $count' in source
assert 'مانده غیرصفر دارد قابل حذف یا بایگانی نیست' in source
assert 'بایگانی صندوق با حفظ سوابق' in source
assert 'if (balance != 0L)' in source
assert 'background = themeCardBackground()' in source[source.index('private fun base('):source.index('private fun actionButton(')]
assert 'setStroke(dp(1), mixColor(palette().primary, palette().surface, 0.62f))' in source
assert 'hp.setMargins(0, 0, 0, dp(10))' in source
print('PASS: v1.7.7 petty-cash balance/movement deletion safeguards and framed screen UI')

# v1.7.8 delivery totals contrast and seller settings duplicate version action regression.
assert 'val totalBox=TextView(this).apply{textSize=16f;setTextColor(Color.DKGRAY);setPadding(dp(12),dp(12),dp(12),dp(12))}' in source
seller_settings = source[source.index('private fun showSettings()'):source.index('private fun showAdminSettingsCategory(')]
assert '"برنامه و آرشیو مالی"' in seller_settings
archive_section = seller_settings[seller_settings.index('"📅 برنامه و آرشیو مالی"'):seller_settings.index('} else if (db.isStaffMode())')]
assert 'Triple("تغییر نسخه"' not in archive_section
assert 'Triple("تغییر نسخه"' in seller_settings[seller_settings.index('"📅 تاریخ و نسخه برنامه"'):]
print('PASS: v1.7.8 delivery totals contrast and removal of duplicate seller version-switch action')

# v1.7.9 daily greenhouse report and temperature dashboard.
assert 'fun showGreenhouseDailyReport(' in source
assert 'fun showGreenhouseDailyReportHistory()' in source
assert 'CREATE TABLE greenhouse_daily_reports' in source
assert 'greenhouse_daily_reports' in Path('firestore.rules').read_text(encoding='utf-8')
assert 'دمای روز گلخانه' not in source
assert 'greenhouse_daily_reports' in Path('firestore.rules').read_text(encoding='utf-8')
print('PASS: v1.7.9 daily greenhouse report, duplicate temperature card removed, and cloud sync rules')

# v1.8.2 press-and-hold speech and Safashahr weather regression checks
assert "if (!sellerMode) addSafashahrWeatherCard(root)" in source
assert "api.open-meteo.com/v1/forecast" in source
assert "latitude=30.6167&longitude=53.1958" in source
assert "relative_humidity_2m" in source
assert "پیش‌بینی ساعتی" in source
assert "clockView" in source and "textSize = 21f" in source
assert "دستیار صوتی گزارش" in source and "ACTION_RECOGNIZE_SPEECH" in source
assert "حداقل دمای امروز (°C) — پیشنهادی آنلاین، قابل تغییر" in source
assert "clockView" in source and "textSize = 21f" in source
assert "دستیار صوتی گزارش" in source and "ACTION_RECOGNIZE_SPEECH" in source
assert "حداقل دمای امروز (°C) — پیشنهادی آنلاین، قابل تغییر" in source
assert "versionName = \"1.8.42\"" in gradle
assert "versionCode = 144" in gradle
assert "android.permission.RECORD_AUDIO" in Path("app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
assert "MotionEvent.ACTION_DOWN" in source and "MotionEvent.ACTION_UP" in source
assert "stopListening()" in source and "EXTRA_BIASING_STRINGS" in source
print("PASS: v1.8.2 press-and-hold voice capture, Persian speech biasing, and weather regression")

# v1.8.8 voice quantity filling and recognizer recovery regression checks
assert 'extractSpokenQuantity(spoken)' in source
assert 'dailyReportSpeechTargetIndex = index' in source
assert 'ERROR_SERVER_DISCONNECTED' in source
assert 'ERROR_RECOGNIZER_BUSY' in source
assert '(کد ۱۱)' in source
print('PASS: v1.8.8 numeric quantity extraction, focused-field targeting, and speech service error recovery')

# v1.8.8 smart archive search coverage
source = Path("app/src/main/java/com/example/golyar/MainActivity.kt").read_text(encoding="utf-8")
assert 'private fun showSmartArchiveSearch' in source
assert 'fun smartSearchRecords()' in source
assert 'جستجوی هوشمند آرشیو' in source
assert 'normalizeSmartSearch' in source
assert 'financialArchives().forEach' in source
assert 'گزارش روزانه گلخانه' in source
print('PASS: v1.8.8 smart Persian archive search, structured totals, history and access-filter integration')

# v1.8.8 saved search and backup persistence checks
main_activity = (ROOT / "app/src/main/java/com/example/golyar/MainActivity.kt").read_text(encoding="utf-8")
assert 'ذخیره این نتیجه و جزئیات' in main_activity
assert 'showSavedSmartSearches()' in main_activity
assert 'buildCompleteBackupJson()' in main_activity
assert 'saved_smart_searches' in main_activity
assert 'automaticBackupOnExit()' in main_activity
assert 'financial_month_archives' in main_activity
print("PASS: v1.8.8 saved smart-search results, complete backups, monthly archives, and version-change backup checks")


# v1.8.8 smart query planner regression checks
source = Path("app/src/main/java/com/example/golyar/MainActivity.kt").read_text(encoding="utf-8")
assert '"30days"' in source and '"yesterday"' in source and '"today"' in source
assert 'numericTerms.any' in source and 'kotlin.math.round(wordTerms.size * 0.6)' in source
assert 'RankedSmartRecord' in source and 'normalized.contains("بیشترین")' in source
assert 'if (categoryIntent.isNotEmpty() && !categoryMatch) return@mapNotNull null' in source
assert 'replace("هزینههای", "هزینه")' in source
print('PASS: v1.8.8 local query planner, date windows, numeric filters, relevance ranking, and category isolation')


# v1.8.18 hybrid AI integration checks
source = Path("app/src/main/java/com/example/golyar/MainActivity.kt").read_text(encoding="utf-8")
assert 'private fun showHybridAiAssistant(prefill: String = "")' in source
assert 'private fun showAiProviderSettings' in source
assert 'private fun askAiForPlan' in source
assert 'requestCode == 8111' in source and 'دستیار صوتی' in source
assert 'private fun analyzeRequestOffline' in source and 'sumOf { it.amount }' in source
assert 'requestedCategories.isNotEmpty() && validCategories.isEmpty()' in source
assert 'records = records.filter { it.category != "آرشیو مالی" }' in source
assert 'private fun callAiChat' in source
assert 'secureCredentials.put("ai_api_key", newKey)' in source
assert 'https://' in source and 'Authorization", "Bearer $apiKey' in source
assert 'دریافت توضیح هوشمند؟' in source
assert 'matching_records' in source
assert 'runOnlineFallback(question, output' in source
assert 'val examples = listOf("فروش امروز چقدر بود؟"' not in source
assert 'val examples = listOf("هزینه‌های ماه جاری"' not in source
assert 'private fun showSmartArchiveSearch(prefill: String = "") {\n        // One screen only' in source
assert 'showSmartArchiveSearch()' in source
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 144' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.18 hybrid AI provider settings, encrypted key storage, local query execution, encrypted key storage, local query execution, and online fallback')


# v1.8.18 simplified smart search and Groq default provider
source = Path("app/src/main/java/com/example/golyar/MainActivity.kt").read_text(encoding="utf-8")
assert 'private fun showSmartArchiveSearch(prefill: String = "")' in source
assert 'private fun showSmartArchiveSearchOffline(prefill: String = "")' in source
assert 'showHybridAiAssistant(prefill)' in source
assert 'https://api.groq.com/openai/v1/chat/completions' in source
assert 'openai/gpt-oss-120b' in source
assert 'آزمایش اتصال ناموفق بود' in source and 'اتصال موفق است' in source
assert 'secureCredentials.put("ai_api_key", newKey)' in source
print("PASS: v1.8.18 simplified search, Groq defaults, in-app connection test, and encrypted user-entered key")

# v1.8.18 streamlined assistant UI and flower catalogue fallback checks
source = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'actionButton("🎙️ دستیار صوتی")' in source
assert 'actionButton("🔎 جستجو")' in source
assert 'actionButton("⚙️ تنظیمات")' in source
assert 'گزارش جستجوی هوشمند' in source
assert '"تعریف گل"' in source and 'base_price' in source
assert 'runOnlineFallback(question, output' in source
assert 'asksMostExpensiveFlower' not in source
print('PASS: v1.8.18 compact assistant UI, modal report, searchable flower catalogue, and online fallback')

# v1.8.18 regression checks: never leave online fallback blank; deterministic local search
source = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'if (!aiConfigured()) {\n            showOnlineMessage("جستجوی آنلاین شروع نشد:' in source
assert 'private fun simpleLocalSearch(question: String' in source
assert 'simpleLocalSearch(question, records)' in source
assert 'SELECT id,name,size,base_price,min_price,active FROM flowers", null' in source
assert 'نتیجه تحلیل آفلاین' in source
print('PASS: v1.8.18 deterministic local fallback, full flower catalogue lookup, and visible online configuration/error states')

# v1.8.18 Word export regression checks
main_activity = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'ذخیره Word' in main_activity
assert 'ACTION_CREATE_DOCUMENT' in main_activity
assert 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' in main_activity
assert 'createWordDocument' in main_activity and 'word/document.xml' in main_activity
assert 'requestCode == 8112' in main_activity
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 144' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.18 smart search report export as a real DOCX Word file using Android document picker')


# v1.8.18: visible online response/error handling and suppress unrelated daily reports.
main_activity = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'if (answer.isBlank()) {' in main_activity and 'finish_reason=length' in main_activity
assert 'private fun questionAsksDailyGreenhouse(question: String): Boolean' in main_activity
assert 'val searchableRecords = if (questionAsksDailyGreenhouse(question)) records else records.filter { it.category != "گزارش روزانه گلخانه" }' in main_activity
assert 'val records = if (questionAsksDailyGreenhouse(q)) allRecords else allRecords.filter { it.category != "گزارش روزانه گلخانه" }' in main_activity
assert 'val onlineBox = LinearLayout(this)' in main_activity
assert 'دریافت پاسخ آنلاین ناموفق بود:' in main_activity
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 144' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.18 visible online output/errors and exclusion of unrelated daily greenhouse reports')


# v1.8.18: deterministic local answer for seller-count questions.
main_activity = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'private fun questionAsksSellerCount(question: String): Boolean' not in main_activity
assert 'private fun analyzeRequestOffline(question: String, allRecords: List<SmartSearchRecord>): OfflineAnalysis?' in main_activity
assert '"فروشنده" to listOf("فروشنده", "فروشندگان", "بدهکار", "بدهکاران", "حساب فروشنده")' in main_activity
assert 'One canonical row per active seller makes generic count/list analysis possible.' in main_activity
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 144' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.18 seller-count questions are answered deterministically from local seller database')


# v1.8.30 general offline-first assistant: generic intents, online consent fallback, and seller records.
source = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'private fun analyzeRequestOffline(question: String, allRecords: List<SmartSearchRecord>): OfflineAnalysis?' in source
assert 'private fun runOfflineFirstAssistant(question: String, output: LinearLayout)' in source
assert 'syncSharedAiConfig { ready ->' in source and 'runOfflineFirstAssistant(q, output)' in source
assert 'asksCount -> {' in source and 'asksSum -> {' in source and 'asksMax -> {' in source and 'asksMin -> {' in source and 'asksList -> {' in source
assert 'One canonical row per active seller makes generic count/list analysis possible.' in source
assert 'local_category_statistics' in source
assert 'تا ۸۰ رکورد' in source
assert 'تأیید و ادامه' in source
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 144' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.30 general offline-first analysis and consent-gated online fallback')
# v1.8.30: avoid token-starved Groq connection test and automatic consent-gated online fallback.
main = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert ')), 256)' in main and 'reasoning_effort", "low"' in main
assert 'finish_reason=length' in main and 'سرویس HTTP موفق داد اما متن پاسخ خالی است' in main
assert 'Automatically hand off after a low-confidence local result' in main
assert 'runOnlineFallback(question, output, false)' in main
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.30 larger Groq connection-test budget, blank-response diagnostics, and automatic consent-gated online fallback')



# v1.8.30 online assistant data handoff and credential exclusion regressions
assert 'val definedFlowers = if (asksFlower && includeLocalRecords && mayReadFlowerCatalogue)' in source
assert 'distinct_defined_flower_names' in source and 'defined_flower_size_entries' in source
assert 'همه گل‌های تعریف‌شده همراه وضعیت فعال/غیرفعال' in source
assert 'private fun redactAiSensitiveText(value: String)' in source
assert 'رمزهای عبور، توکن‌های ورود و کلیدهای API ارسال نمی‌شوند' in source
assert 'listOf("فروشنده", "فروشندگان", "فروش", "گل", "دسته گل", "نوع گل"' in source
print('PASS: v1.8.30 online assistant receives live flower catalogue and category counts')
print('PASS: v1.8.30 credential redaction and explicit data-transfer consent')

# v1.8.30 regression: online flower analysis sends all defined rows, including inactive definitions, and diagnoses permission/empty-data cases.
assert 'fun definedFlowers():List<Flower> = readFlowerCatalogue(false)' in source
assert '"status", if (f.active) "active" else "inactive"' in source
assert 'defined_flower_rows_sent' in source and 'catalogue_permission_granted' in source
assert 'اطلاعات گل‌ها ارسال نشد' in source and 'هیچ گل تعریف‌شده‌ای ندارد' in source
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 144' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.30 sends all defined flower records, reports active status, and diagnoses empty/permission-blocked catalogues')


# v1.8.30 greenhouse daily report usability, EC persistence, and humidity auto-fill regressions
assert 'private fun showDailyChemicalEntry(title: String, target: EditText, preferenceKey: String)' in source
assert 'daily_report_chemical_catalog' in source and 'setAdapter(ArrayAdapter' in source
assert '＋ افزودن کود با انتخاب از فهرست' in source and '＋ افزودن سم یا محلول با انتخاب از فهرست' in source
assert 'relative_humidity_2m' in source and 'رطوبت نسبی بیرون (%) — خودکار از هواشناسی' in source
assert 'برای ثبت رطوبت واقعی داخل گلخانه به حسگر رطوبت متصل نیاز است' in source
assert 'EC آب آبیاری (mS/cm یا dS/m)' in source
assert 'SQLiteOpenHelper(ctx,"golyar.db",null,18)' in source
assert 'if(oldVersion<16) db.execSQL("ALTER TABLE greenhouse_daily_reports ADD COLUMN ec_water TEXT")' in source
assert '"ec_water" to values["ec_water"].orEmpty()' in source
assert '"ec_water" to str("ec_water")' in source
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 144' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.30 reusable fertilizer/pesticide suggestions, automatic outdoor humidity, EC water field, local persistence, and sync integration')

# v1.8.30 configurable greenhouse contamination map regression checks
main_source = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'private fun showContaminationMap()' in main_source
assert 'private fun showContaminationEntry(' in main_source
assert 'private fun showContaminationSummary(' in main_source
assert 'contam_greenhouses' in main_source and 'contam_records' in main_source
assert 'عرض پیش‌فرض هر دهنه: ۸٫۲۰ متر' in main_source
assert 'بیماری قارچی' in main_source and 'آفت حشره‌ای' in main_source and 'ثبت بازدید سالم' in main_source
assert 'مدیریت نقشه آلودگی گلخانه' in main_source
print('PASS: v1.8.30 configurable greenhouse schematic and contamination map checks')

# v1.8.30: daily bouquet terminology, color legend, Word map/report export, and editable chemical catalogue
source = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'بازدیدنشده' in source and 'legendItems.chunked(3)' in source
assert 'fun mapTable(line: String)' in source and '<w:tbl>' in source and 'E7F3EE' in source
assert 'خلاصه ثبت روزانه' in source
assert 'saveContaminationMapWord' in source and '📝 ذخیره نقشه رنگی در فایل Word' in source
assert 'خروجی کامل گزارش روزانه در Word' in source and 'buildDailyReportWordText' in source
assert 'نقشه آلودگی در گزارش روزانه' not in source
assert 'footerReference' in source and 'NUMPAGES' in source and 'PAGE ' in source
assert '<w:keepNext/>' in source
assert 'گل‌های انتخاب‌شده از فهرست' in source
assert 'showEditChemicalCatalog' in source and 'ویرایش فهرست نام کودها' in source and 'ویرایش فهرست نام سم‌ها و محلول‌ها' in source
assert 'تعداد دسته گل تولیدشده/برداشت‌شده' in source and 'تعداد دسته گل ضایعاتی' in source
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.30 improved contamination-map layout, professional styled Word tables, daily report UX, editable chemical catalogue, and bouquet quantities')

# v1.8.30 detailed bouquet production records: per-type quantities/specifications persist and export.
source = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'showDailyBouquetProduction(reportDate)' in source
assert 'bouquets_json' in source and 'saveDailyBouquets' in source
assert 'bouquetTotalQuantity' in source
assert 'جزئیات دسته گل‌های تولیدی' in source
assert 'تعداد شاخه در هر دسته' in source and 'نوع بسته‌بندی' in source
assert 'bouquets_json' in source[source.index('fun dailyReport(date:String)'):source.index('fun dailyReportDates()')]
assert 'bouquets_json' in source[source.index('fun saveDailyBouquets'):source.index('private fun q(')]
assert 'versionName = "1.8.42"' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionCode = 144' in Path('app/build.gradle.kts').read_text(encoding='utf-8')
print('PASS: v1.8.30 per-type bouquet production page, derived total, local persistence, sync payload, and report export')

# v1.8.42: registered-flower picker and schema-driven universal search coverage.
assert 'انتخاب یک یا چند نوع گل ثبت‌شده' in source
assert 'flower_ids' in source and 'flower_names' in source
assert 'db.flowers()' in source[source.index('private fun editBouquet'):source.index('private fun showDailyChemicalEntry')]
assert 'Schema-driven catch-all index' in source
assert 'SELECT name FROM sqlite_master WHERE type=\'table\'' in source
assert 'نمایه خودکار همه جدول‌ها' in source
assert 'password|passwd|secret|token|credential|private_key|firebase_key|api_key' in source
print('PASS: registered flower multi-select is wired into bouquet records')
print('PASS: schema-driven search covers future tables and columns while excluding credentials')


# v1.8.42: production is emitted as a real Word table; contamination maps are appended to daily output.
assert 'تولیدجدول_سرستون|' in source
assert 'تولیدجدول_ردیف|' in source
assert 'private fun buildDailyContaminationMapAppendix()' in source
assert 'out.append(buildDailyContaminationMapAppendix())' in source
assert 'fun productionTable(lines: List<String>)' in source and 'body.append(productionTable(tableLines).orEmpty())' in source
assert 'root.addView(actionButton("🗺️ مدیریت نقشه آلودگی گلخانه") { showContaminationMap() })' in source
assert 'نقشه آلودگی گلخانه' not in source[source.index('private fun showReportsHub'):source.index('private fun showReportCategory')] if 'private fun showReportsHub' in source and 'private fun showReportCategory' in source else True
print('PASS: daily report includes production table and contamination maps; map management is inside daily report')

# v1.8.42 daily-report and contamination-map regressions
assert '"__WORD_PAGE_BREAK__\\nتولید دسته گل و ضایعات' in source
assert '"\\n__WORD_PAGE_BREAK__\\nنقشه آلودگی گلخانه‌ها' in source
assert 'fun productionTable(lines: List<String>)' in source
assert '<w:bidiVisual/>' in source
assert 'آخرین ثبت هر نوع جداگانه نگهداری می‌شود' in source
assert 'contaminationTypeEmoji' in source
assert 'سوابق نقشه آلودگی' in source
assert 'val exportValues = linkedMapOf(' in source
assert 'db.saveDailyReport(reportDate, exportValues)' in source
print('PASS: v1.8.42 Word RTL/page-break/production-table integration')
print('PASS: v1.8.42 contamination type colors and multi-type cell history')
print('PASS: v1.8.42 save-current-daily-report-before-Word-export')
print('PASS: v1.8.42 contamination observations indexed for local smart search')

# v1.8.42: report ordering, reliable non-destructive save, schema repair, and Persian Word RTL.
source = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
report_fn = source[source.index('private fun buildDailyReportWordText'):source.index('private fun bouquetTotalQuantity')]
assert report_fn.index('مشکلات و توضیحات') < report_fn.index('__WORD_PAGE_BREAK__\\nتولید دسته گل و ضایعات')
assert 'database.update("greenhouse_daily_reports", v, "report_date=?"' in source
assert 'database.insert("greenhouse_daily_reports", null, v)' in source
assert 'CONFLICT_REPLACE' not in source[source.index('fun saveDailyReport(date:String'):source.index('fun saveDailyBouquets')]
assert 'ensureDailyReportSchema(database)' in source and 'PRAGMA table_info(greenhouse_daily_reports)' in source
assert 'val savedValues = db.dailyReport(reportDate)' in source
assert 'val missingFields = fieldsToVerify.filter' in source
assert 'w:lang' in source and 'fa-IR' in source
assert '<w:rtl/></w:rPr>' in source and '<w:bidi/>' in source
print('PASS: v1.8.42 problems/notes precede dedicated production page')
print('PASS: v1.8.42 non-destructive transactional daily report upsert and read-back verification')
print('PASS: v1.8.42 database schema repair for EC and bouquet fields')
print('PASS: v1.8.42 Persian language metadata and explicit RTL direction in Word')


# v1.8.42: auto-save daily report and bouquet rows; mother-page back navigation.
activity = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'ذخیره‌سازی خودکار فعال است' in activity
assert 'field.addTextChangedListener(object : TextWatcher' in activity
assert 'ذخیره جزئیات تولید' not in activity
assert 'هر مورد بلافاصله پس از ثبت، ویرایش یا حذف در پایگاه داده ذخیره می‌شود.' in activity
assert 'pendingAutoSave?.let { autoSaveHandler.removeCallbacks(it) }' in activity
assert activity.index('root.addView(sectionTitle("⚠️ مشکلات و توضیحات"))') < activity.index('root.addView(sectionTitle("🌹 تولید و وضعیت محصول"))')
print('PASS: v1.8.42 daily report fields auto-save after editing and before Word export')
print('PASS: v1.8.42 bouquet rows save immediately on add/edit/delete; duplicate save button removed')
print('PASS: v1.8.42 report issues/notes precede production section')
print('PASS: v1.8.42 explicit home back buttons route to home')

# v1.8.42: one report date at top; each greenhouse map begins on its own page and map rows are width-limited.
source = Path('app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'val cleanQuestion = if (question.startsWith("گزارش روزانه گلخانه ")) "گزارش روزانه گلخانه" else question' in source
assert 'if (reportHasDatedTitle) "گل نگار — $cleanQuestion\\n\\n$report"' in source
assert 'matches.chunked(7)' in source
assert 'latinDigits(value: String)' in source
assert 'پیش‌نمایش گزارش روزانه' in source
assert '━━━━━━━━━━━━━━━━━━━━' in source
assert 'if (mapGreenhouseCount > 0) body.append' in source
print('PASS: v1.8.42 single date heading and per-greenhouse page layout')

# v1.8.42: shared admin AI settings and seller home weather card removal.
assert 'document("ai_assistant")' in source
assert 'private fun syncSharedAiConfig' in source
assert 'if (isAiSettingsAdmin())' in source
assert 'if (!sellerMode) addSafashahrWeatherCard(root)' in source
print('PASS: v1.8.42 shared admin assistant settings and seller weather-card removal')
