# گل‌یار — مدیریت فروش گلخانه

نسخه 0.2 با تمرکز بر حسابداری فروشنده، تسویه، تاریخ شمسی، موجودی مبتنی بر تراکنش و تفکیک رابط گلخانه/فروشنده.

## نکات نسخه 0.2
- سهم توافقی هر فروشنده به‌صورت مستقل ثبت می‌شود.
- فروشنده سهم خود را نگه می‌دارد و مانده را به گلخانه پرداخت می‌کند.
- مبلغ و تاریخ هر پرداخت به گلخانه ثبت می‌شود و تاریخچه پرداخت وجود دارد.
- فروش در تاریخ واقعی ثبت می‌شود؛ فروش دسته‌هایی که چند روز بعد از تحویل انجام می‌شوند از موجودی کم شده و در گزارش همان روز فروش محاسبه می‌شوند.
- تاریخ شمسی امروز در صفحه اصلی و صفحات عملیاتی نمایش داده می‌شود.
- رابط نسخه گلخانه و نسخه فروشنده تفکیک شده است؛ در نسخه فروشنده فقط اطلاعات همان فروشنده نمایش داده می‌شود.
- گزینه‌ها و کنترل‌ها بزرگ‌تر شده‌اند و رابط کارت‌محور و RTL شده است.
- برای اتصال آنلاین، فروش‌ها با وضعیت همگام‌سازی محلی نگهداری می‌شوند و در مرحله بعد Firebase Auth/Firestore/FCM اضافه خواهد شد.

ساخت APK از طریق GitHub Actions انجام می‌شود.

## نسخه 17 — اصلاحات پس از v16
- اندازه گل به عنوان مشخصه مستقل هر نوع گل اضافه شده و در قیمت‌گذاری، تحویل، فروش، برگشت، موجودی و گزارش‌ها نمایش داده می‌شود.
- هشدار قیمت زیر حداقل مجاز برای تحویل/فروش گلخانه و فروش فروشنده فعال شده است و هشدارها از صفحه اصلی قابل مشاهده‌اند.
- ورود نسخه گلخانه با نام کاربری/رمز عبور و ورود فروشنده با حساب اختصاصی انجام می‌شود.
- تنظیم تاریخ کاری برنامه اضافه شده و تاریخ پیش‌فرض ثبت‌ها از آن استفاده می‌کند.
- تنظیم نام کاربری و رمز عبور گلخانه و فروشنده اضافه شده است.
- گزارش تفصیلی با فیلتر فروشنده و بازه تاریخ و جمع مبلغ اضافه شده است.
- گزارش مالی شامل جمع خرید، جمع پرداخت و خالص بدهی/طلب است.
- دکمه «گزارش پرداخت‌ها» از منوی گزارش‌ها حذف شده است.
- قابلیت تغییر عکس پس‌زمینه اضافه نشده است.


## نسخه 17.1 - اصلاح خطاهای Build
- رفع خطای unresolved reference برای نام کاربری و رمز عبور در فرم فروشنده.
- اصلاح خواندن username از جدول فروشندگان.
- اصلاح ساخت ReturnReportRow با ستون اندازه گل و دلیل برگشت.
- در ویرایش فروشنده، اگر رمز جدید خالی باشد رمز قبلی حفظ می‌شود.


## نسخه 18.4
- اندازه گل در تعریف گل، تحویل/فروش گلخانه، فروش فروشنده، برگشت، موجودی و گزارش‌ها
- پایین‌تر رفتن عنوان گل‌یار در تمام صفحات و حذف زیرعنوان‌های بالای صفحات
- ورود گلخانه و فروشنده با نام کاربری و رمز عبور
- اولین اجرای برنامه: تعیین نام کاربری و رمز جدید گلخانه؛ اولین ورود فروشنده بدون حساب قبلی نیز درخواست ساخت نام کاربری و رمز می‌کند
- تنظیم و تغییر تاریخ کاری برنامه
- حذف دکمه تغییر نسخه فروشنده و حذف گزارش پرداخت‌ها
- گزارش فروش گلخانه با فیلتر تاریخ و فروشنده/همه فروشندگان و جمع تعداد، مبلغ، میانگین و وضعیت طلب/بدهی
- گزارش فروشندگان شامل خرید از گلخانه، تک‌تک فروش‌ها، تعداد کل و میانگین قیمت فروش
- گزارش مالی تفصیلی هر فروشنده و پرداخت‌های ثبت‌شده
- جمع کل خریدها و پرداخت‌ها در حساب فروشنده
- Firebase-ready: Firebase Authentication، Firebase Analytics و Firestore اضافه شده‌اند و در صورت وجود google-services.json، ثبت بازشدن برنامه و متادیتای نسخه انجام می‌شود.

### نسخه 18.4 — آفلاین و همگام‌سازی خودکار
- اطلاعات عملیاتی روی SQLite دستگاه در حالت آفلاین ذخیره می‌شوند.
- پس از برگشت اینترنت، همگام‌سازی Firebase به‌صورت خودکار انجام می‌شود.
- آخرین زمان همگام‌سازی موفق در تنظیمات نمایش داده می‌شود.
- در صورت خطای همگام‌سازی، اطلاعات محلی حفظ می‌شوند و تلاش بعدی با اتصال شبکه انجام خواهد شد.

### اتصال Firebase
برای اتصال پروژه به پروژه Firebase واقعی، فایل `app/google-services.json` مربوط به همان Android applicationId (`com.example.golyar`) باید در پروژه قرار گیرد و پلاگین Google Services در مرحله اتصال نهایی فعال شود. این فایل را نباید داخل ZIP بدون تأیید پروژه Firebase قرار داد.


## Firebase architecture (v19.2 working version)

The Android client now uses Firebase Authentication when Firebase is configured and keeps the existing local SQLite database as the offline source of truth. Firestore sync is normalized into top-level collections: `flowers`, `sellers`, `deliveries`, `sales`, `returns`, `payments`, and `settings`. Seller clients synchronize only their sales/returns; greenhouse/admin clients synchronize all business collections.

Before testing against the real Firebase project, keep `app/google-services.json` for Android package `com.example.golyar`, enable Email/Password Authentication, and deploy `firestore.rules` only after the Firebase project settings are verified. Keep Realtime Database locked; this version does not use it. The greenhouse/admin Firebase email is stored separately from the local greenhouse username and defaults to `msf@asia.com`, matching the current `settings/admin_bootstrap` document. The existing Firebase Authentication password must match the password entered for the local greenhouse login. Seller accounts continue to use the synthetic email derived from each seller username; on first seller login, the app creates the seller `users/{uid}` profile only when the matching seller record exists in Firestore.

Do not put a production `google-services.json` into a public repository unless that is acceptable for your Firebase project.
