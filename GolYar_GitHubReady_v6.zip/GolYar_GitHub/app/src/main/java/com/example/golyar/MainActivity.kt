package com.example.golyar

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var db: GolYarDb
    private val nf = NumberFormat.getNumberInstance(Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = GolYarDb(this)
        if (db.getMode() == null) showModeChooser() else showHome()
    }

    private fun base(title: String, subtitle: String? = null): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 28)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 8, 4, 18)
        }
        header.addView(TextView(this).apply {
            text = title
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        if (subtitle != null) header.addView(TextView(this).apply {
            text = subtitle
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 0)
        })
        root.addView(header)
        return root
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 17f
        isAllCaps = false
        minHeight = 62
        setPadding(18, 8, 18, 8)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, 62)
        lp.setMargins(0, 7, 0, 7)
        layoutParams = lp
    }

    private fun setScreen(root: LinearLayout) {
        val scroll = ScrollView(this).apply { isFillViewport = true }
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun showModeChooser() {
        val root = base("گل‌یار", "انتخاب نوع برنامه")
        root.addView(TextView(this).apply {
            text = "نسخه مورد استفاده را انتخاب کنید. این انتخاب بعداً از تنظیمات قابل تغییر است."
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(12, 12, 12, 24)
            setTextColor(Color.WHITE)
        })
        root.addView(actionButton("🏭  نسخه گلخانه",) { db.setMode("GREENHOUSE"); showHome() })
        root.addView(actionButton("👤  نسخه فروشنده") { showSellerChooser() })
        setScreen(root)
    }

    private fun showSellerChooser() {
        val sellers = db.sellers()
        if (sellers.isEmpty()) {
            info("برای ورود به نسخه فروشنده، ابتدا در نسخه گلخانه حداقل یک فروشنده تعریف کنید.")
            return
        }
        val names = sellers.map { "${it.name}  |  ${it.phone}" }
        val box = formBox()
        box.addView(spinner("انتخاب فروشنده", names, 60))
        AlertDialog.Builder(this).setTitle("ورود به نسخه فروشنده").setView(box)
            .setPositiveButton("ورود") { _, _ ->
                val sp = box.getChildAt(0) as Spinner
                db.setMode("SELLER:${sellers[sp.selectedItemPosition].id}")
                showHome()
            }.setNegativeButton("انصراف", null).show()
    }

    private fun showHome() {
        val root = base("گل‌یار", if (db.isSellerMode()) "نسخه فروشنده" else "مدیریت گلخانه")
        val d = db.dashboard(if (db.isSellerMode()) db.currentSellerId() else null)
        val date = todayJalali()
        root.addView(summaryCard(date, d))

        if (db.isSellerMode()) {
            root.addView(actionButton("🧾  ثبت فروش جدید") { showSale() })
            root.addView(actionButton("📦  موجودی من") { showReports() })
            root.addView(actionButton("💰  حساب و پرداخت به گلخانه") { showSettlement() })
            root.addView(actionButton("📋  فروش‌های ثبت‌شده من") { showSalesHistory() })
        } else {
            root.addView(actionButton("🌹  انواع گل") { showFlowers() })
            root.addView(actionButton("👤  فروشندگان") { showSellers() })
            root.addView(actionButton("📦  ثبت تحویل گل") { showDelivery() })
            root.addView(actionButton("🧾  ثبت فروش") { showSale() })
            root.addView(actionButton("↩️  ثبت برگشت گل") { showReturn() })
            root.addView(actionButton("💰  تسویه حساب فروشندگان") { showSettlement() })
            root.addView(actionButton("📊  موجودی و گزارش‌ها") { showReports() })
        }
        root.addView(actionButton("⚙️  تنظیمات") { showSettings() })
        setScreen(root)
    }

    private fun summaryCard(date: String, d: Dash): TextView = TextView(this).apply {
        text = "امروز  |  $date\n\nتحویل امروز: ${d.deliveredToday} دسته     فروش امروز: ${d.soldToday} دسته\nفروش امروز: ${money(d.salesToday)} تومان\n\nموجودی نزد فروشندگان: ${d.stock} دسته\nمطالبات گلخانه: ${money(d.greenhouseDue)} تومان"
        textSize = 16f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(20, 22, 20, 22)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, 14)
        layoutParams = lp
    }

    private fun showFlowers() {
        val root = base("انواع گل")
        root.addView(actionButton("＋  تعریف نوع گل") { flowerDialog(null) })
        db.flowers().forEach { f ->
            root.addView(cardRow("🌹  ${f.name}\nقیمت پایه: ${money(f.basePrice)}  |  حداقل فروش: ${money(f.minPrice)}") {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                row.addView(actionButton("ویرایش") { flowerDialog(f) }, LinearLayout.LayoutParams(0, 62, 1f))
                row.addView(actionButton("حذف") { confirmDelete("حذف ${f.name}؟") { db.delete("flowers", f.id); showFlowers() } }, LinearLayout.LayoutParams(0, 62, 1f))
                it.addView(row)
            })
        }
        root.addView(actionButton("بازگشت") { showHome() })
        setScreen(root)
    }

    private fun flowerDialog(f: Flower?) {
        val box = formBox(); val name = field("نام گل", f?.name ?: ""); val base = numberField("قیمت پایه هر دسته", f?.basePrice?.toString() ?: ""); val min = numberField("حداقل قیمت مجاز", f?.minPrice?.toString() ?: "")
        box.addView(name); box.addView(base); box.addView(min)
        AlertDialog.Builder(this).setTitle(if (f == null) "تعریف گل" else "ویرایش گل").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val n=name.text.toString().trim(); val b=base.text.toString().toLongOrNull()?:0; val m=min.text.toString().toLongOrNull()?:0
                if(n.isNotEmpty()) db.upsertFlower(f?.id,n,b,m); showFlowers()
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showSellers() {
        val root = base("فروشندگان", "درصد سهم هر فروشنده از مبلغ فروش قابل تنظیم است")
        root.addView(actionButton("＋  تعریف فروشنده") { sellerDialog(null) })
        db.sellers().forEach { s ->
            root.addView(cardRow("👤  ${s.name}\n${s.phone}\nسهم فروشنده: ${fmtPercent(db.sellerShare(s.id))}%\nموجودی: ${db.sellerStock(s.id)} دسته\nبدهی به گلخانه: ${money(db.greenhouseDue(s.id))} تومان") {
                it.addView(actionButton("ویرایش") { sellerDialog(s) })
            })
        }
        root.addView(actionButton("بازگشت") { showHome() }); setScreen(root)
    }

    private fun sellerDialog(s: Seller?) {
        val box=formBox(); val name=field("نام فروشنده",s?.name?:("")); val phone=field("شماره تماس",s?.phone?:""); val share=numberField("درصد توافقی فروشنده",s?.let{db.sellerShare(it.id).toString()}?:db.getDefaultSellerShare().toString())
        box.addView(name); box.addView(phone); box.addView(share)
        AlertDialog.Builder(this).setTitle(if(s==null) "فروشنده جدید" else "ویرایش فروشنده").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val pct=share.text.toString().toDoubleOrNull(); if(name.text.isNotBlank() && pct!=null && pct in 0.0..100.0) { db.upsertSeller(s?.id,name.text.toString(),phone.text.toString(),pct); showSellers() } else info("درصد باید بین صفر تا صد باشد.")
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showDelivery() {
        val root=base("ثبت تحویل گل", "تاریخ تحویل: ${todayJalali()}")
        val flowers=db.flowers(); val sellers=db.sellers(); if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا حداقل یک گل و یک فروشنده تعریف کنید.");return}
        val seller=spinner("فروشنده",sellers.map{it.name},60); val flower=spinner("نوع گل",flowers.map{it.name},60); val qty=numberField("تعداد دسته","")
        root.addView(label("فروشنده")); root.addView(seller); root.addView(label("نوع گل")); root.addView(flower); root.addView(qty)
        root.addView(actionButton("ثبت تحویل") { val q=qty.text.toString().toIntOrNull()?:0; if(q<=0){info("تعداد نامعتبر است.");return@actionButton}; db.addDelivery(sellers[seller.selectedItemPosition].id,flowers[flower.selectedItemPosition].id,q); info("تحویل ثبت شد."){showHome()} })
        root.addView(actionButton("بازگشت"){showHome()}); setScreen(root)
    }

    private fun showSale() {
        val root=base("ثبت فروش", "فروش بر اساس تاریخ واقعی فروش ثبت می‌شود؛ بنابراین فروش دسته‌های تحویل‌شده در روزهای قبل نیز به‌درستی محاسبه خواهد شد.")
        val flowers=db.flowers(); val sellers=if(db.isSellerMode()) db.sellers().filter{it.id==db.currentSellerId()} else db.sellers()
        if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا اطلاعات پایه را وارد کنید.");return}
        val seller=spinner("فروشنده",sellers.map{it.name},60); val flower=spinner("نوع گل",flowers.map{it.name},60); val qty=numberField("تعداد دسته فروخته‌شده",""); val price=numberField("قیمت فروش هر دسته (تومان)","")
        val stockText=label("")
        fun refresh(){val st=db.sellerFlowerStock(sellers[seller.selectedItemPosition].id,flowers[flower.selectedItemPosition].id);stockText.text="موجودی قابل فروش: $st دسته"}
        seller.setOnItemSelectedListener(simpleListener{refresh()}); flower.setOnItemSelectedListener(simpleListener{refresh()}); refresh()
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل"));root.addView(flower);root.addView(stockText);root.addView(qty);root.addView(price)
        root.addView(actionButton("ثبت فروش") {
            val q=qty.text.toString().toIntOrNull()?:0;val p=price.text.toString().toLongOrNull()?:0;val s=sellers[seller.selectedItemPosition];val f=flowers[flower.selectedItemPosition];val stock=db.sellerFlowerStock(s.id,f.id)
            if(q<=0||p<=0){info("تعداد و قیمت را صحیح وارد کنید.");return@actionButton};if(q>stock){info("موجودی کافی نیست. موجودی فعلی: $stock دسته");return@actionButton}
            if(p<f.minPrice){AlertDialog.Builder(this).setTitle("هشدار قیمت").setMessage("قیمت واردشده پایین‌تر از حداقل مجاز است. ثبت شود؟").setNegativeButton("لغو",null).setPositiveButton("ثبت"){_,_->saveSale(s.id,f.id,q,p)}.show()}else saveSale(s.id,f.id,q,p)
        })
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun saveSale(sellerId:Long,flowerId:Long,qty:Int,price:Long){db.addSale(sellerId,flowerId,qty,price);info("فروش ثبت شد.\nتاریخ فروش: ${todayJalali()}\n\nدر نسخه آنلاین، این رکورد برای گلخانه ارسال خواهد شد."){showHome()}}

    private fun showSalesHistory() {
        val root=base("فروش‌های ثبت‌شده من")
        val sid=db.currentSellerId()?:return
        val sales=db.sales(sid)
        if(sales.isEmpty()) root.addView(label("هنوز فروشی ثبت نشده است."))
        sales.forEach{root.addView(cardRow("${it.flowerName}  |  ${it.qty} دسته\nمبلغ فروش: ${money(it.qty*it.price)} تومان\nتاریخ فروش: ${it.date}\nوضعیت ارسال: ${if(it.synced) "آماده ارسال/همگام‌شده" else "در انتظار اتصال به گلخانه"}") {})}
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showReturn(){
        if(db.isSellerMode()){info("ثبت برگشت در نسخه گلخانه انجام می‌شود.");return}
        val root=base("ثبت برگشت گل","برگشت از موجودی فروشنده کم می‌شود و دلیل آن ثبت می‌گردد.");val flowers=db.flowers();val sellers=db.sellers();if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا اطلاعات پایه را وارد کنید.");return}
        val seller=spinner("فروشنده",sellers.map{it.name},60);val flower=spinner("نوع گل",flowers.map{it.name},60);val qty=numberField("تعداد دسته برگشتی","");val reason=field("علت برگشت","فروش نرفته / خراب / کیفیت / سایر")
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل"));root.addView(flower);root.addView(qty);root.addView(reason)
        root.addView(actionButton("ثبت برگشت"){val q=qty.text.toString().toIntOrNull()?:0;val s=sellers[seller.selectedItemPosition];val f=flowers[flower.selectedItemPosition];if(q<=0||q>db.sellerFlowerStock(s.id,f.id)){info("تعداد برگشتی بیشتر از موجودی است.");return@actionButton};db.addReturn(s.id,f.id,q,reason.text.toString());info("برگشت ثبت شد."){showHome()}});root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSettlement(){
        val root=base("تسویه حساب", "فروشنده درصد توافقی خود را نگه می‌دارد و مابقی فروش را به گلخانه پرداخت می‌کند.")
        val sellers=if(db.isSellerMode()) db.sellers().filter{it.id==db.currentSellerId()} else db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        sellers.forEach{s->val payments=db.payments(s.id);val paymentText=if(payments.isEmpty())"هنوز پرداختی ثبت نشده" else "آخرین پرداخت: ${money(payments.first().amount)} تومان در تاریخ ${payments.first().date}";root.addView(cardRow("👤 ${s.name}\nکل فروش: ${money(db.sellerSalesTotal(s.id))} تومان\nسهم فروشنده (${fmtPercent(db.sellerShare(s.id))}%): ${money(db.sellerCommission(s.id))} تومان\nمبلغ پرداخت‌شده به گلخانه: ${money(db.paidToGreenhouse(s.id))} تومان\nمانده بدهی به گلخانه: ${money(db.greenhouseDue(s.id))} تومان\n$paymentText"){add->add.addView(actionButton("ثبت پرداخت به گلخانه"){paymentDialog(s)});if(payments.isNotEmpty())add.addView(actionButton("مشاهده تاریخچه پرداخت"){showPaymentHistory(s)})})}
        root.addView(label("تاریخ امروز: ${todayJalali()}"));root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showPaymentHistory(s:Seller){
        val root=base("تاریخچه پرداخت ${s.name}")
        val payments=db.payments(s.id)
        if(payments.isEmpty()) root.addView(label("پرداختی ثبت نشده است."))
        payments.forEachIndexed{index,p->root.addView(cardText("پرداخت ${payments.size-index}\nمبلغ: ${money(p.amount)} تومان\nتاریخ پرداخت: ${p.date}"))}
        root.addView(actionButton("بازگشت"){showSettlement()});setScreen(root)
    }

    private fun paymentDialog(s:Seller){val due=db.greenhouseDue(s.id);val box=formBox();val amount=numberField("مبلغ پرداختی",if(due>0)due.toString() else "");box.addView(amount);AlertDialog.Builder(this).setTitle("پرداخت ${s.name} به گلخانه").setMessage("تاریخ پرداخت: ${todayJalali()}\nمانده بدهی: ${money(due)} تومان").setView(box).setPositiveButton("ثبت پرداخت"){_,_->val a=amount.text.toString().toLongOrNull()?:0;if(a<=0||a>due){info("مبلغ پرداختی باید بیشتر از صفر و حداکثر برابر مانده بدهی باشد.")}else{db.addPayment(s.id,a);info("پرداخت ثبت شد.\nتاریخ: ${todayJalali()}") {showSettlement()}}}.setNegativeButton("انصراف",null).show()}

    private fun showReports(){
        val root=base("موجودی و گزارش‌ها", "گزارش‌ها بر اساس تراکنش‌های واقعی محاسبه می‌شوند")
        val sid=if(db.isSellerMode()) db.currentSellerId() else null;val d=db.dashboard(sid)
        root.addView(cardText("📊 خلاصه\nتحویل امروز: ${d.deliveredToday} دسته\nفروش امروز: ${d.soldToday} دسته\nبرگشت امروز: ${d.returnedToday} دسته\nفروش امروز: ${money(d.salesToday)} تومان\n\nموجودی: ${d.stock} دسته\nمطالبات گلخانه: ${money(d.greenhouseDue)} تومان"))
        root.addView(label("موجودی تفکیکی"))
        if(sid!=null){db.flowers().forEach{f->root.addView(label("${f.name}: ${db.sellerFlowerStock(sid,f.id)} دسته"))}}else db.sellers().forEach{s->root.addView(cardText("${s.name}\nموجودی: ${db.sellerStock(s.id)} دسته\nبدهی به گلخانه: ${money(db.greenhouseDue(s.id))} تومان"))}
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSettings(){
        val root=base("تنظیمات")
        if(!db.isSellerMode()){
            val def=numberField("درصد پیش‌فرض سهم فروشنده",db.getDefaultSellerShare().toString());root.addView(def);root.addView(actionButton("ذخیره درصد پیش‌فرض"){val v=def.text.toString().toDoubleOrNull();if(v!=null&&v in 0.0..100.0){db.setDefaultSellerShare(v);info("درصد پیش‌فرض ذخیره شد.")}else info("درصد باید بین صفر تا صد باشد.")})
        }
        root.addView(actionButton("🔄 تغییر نوع نسخه / فروشنده"){db.setMode(null);showModeChooser()})
        root.addView(label("تاریخ امروز: ${todayJalali()}"))
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun cardBackground()=GradientDrawable().apply{cornerRadius=24f;setColor(Color.rgb(35,32,42));setStroke(1,Color.rgb(70,64,78))}
    private fun cardText(text:String):TextView=TextView(this).apply{textSize=16f;setTextColor(Color.WHITE);setPadding(20,18,20,18);background=cardBackground();val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,10);layoutParams=lp}
    private fun cardRow(text:String, build:(LinearLayout)->Unit):LinearLayout{val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(14,12,14,12);background=cardBackground();val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,10);layoutParams=lp};box.addView(TextView(this).apply{this.text=text;textSize=16f;setTextColor(Color.WHITE);setPadding(8,8,8,12)});build(box);return box}
    private fun label(t:String)=TextView(this).apply{text=t;textSize=15f;setTextColor(Color.LTGRAY);setPadding(6,12,6,5)}
    private fun formBox()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,4,12,4);layoutDirection=View.LAYOUT_DIRECTION_RTL}
    private fun field(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;inputType=InputType.TYPE_CLASS_TEXT;minHeight=58;setPadding(12,8,12,8)}
    private fun numberField(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;minHeight=58;setPadding(12,8,12,8)}
    private fun spinner(label:String,items:List<String>,height:Int)=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items);contentDescription=label;layoutDirection=View.LAYOUT_DIRECTION_RTL;minimumHeight=height}
    private fun divider()=Space(this).apply{minimumHeight=8}
    private fun simpleListener(fn:()->Unit)=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){fn()}}
    private fun money(v:Long)=nf.format(v)
    private fun fmtPercent(v:Double)=String.format(Locale.US,"%.1f",v).trimEnd('0').trimEnd('.')
    private fun confirmDelete(msg:String,action:()->Unit){AlertDialog.Builder(this).setMessage(msg).setNegativeButton("انصراف",null).setPositiveButton("حذف"){_,_->action()}.show()}
    private fun info(msg:String,after:(()->Unit)?=null){AlertDialog.Builder(this).setMessage(msg).setPositiveButton("باشه"){_,_->after?.invoke()}.show()}

    data class Flower(val id:Long,val name:String,val basePrice:Long,val minPrice:Long)
    data class Seller(val id:Long,val name:String,val phone:String)
    data class SaleRow(val flowerName:String,val qty:Int,val price:Long,val date:String,val synced:Boolean)
    data class PaymentRow(val amount:Long,val date:String)
    data class Dash(val deliveredToday:Int,val soldToday:Int,val returnedToday:Int,val salesToday:Long,val stock:Int,val greenhouseDue:Long)

    private fun todayJalali():String = jalali(Calendar.getInstance())
    private fun jalali(c:Calendar):String {
        val gy=c.get(Calendar.YEAR); val gm=c.get(Calendar.MONTH)+1; val gd=c.get(Calendar.DAY_OF_MONTH)
        val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31)
        var days=355666 + 365*gy + ((gy+3)/4) - ((gy+99)/100) + ((gy+399)/400) + gd
        for(i in 1 until gm) days += gdm[i]
        if(gm>2 && isLeapGregorian(gy)) days++
        var jy=-1595 + 33*(days/12053); days%=12053
        jy += 4*(days/1461); days%=1461
        if(days>365){jy += (days-1)/365; days=(days-1)%365}
        val jm=if(days<186) 1 + days/31 else 7 + (days-186)/30
        val jd=1 + if(days<186) days%31 else (days-186)%30
        return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
    }
    private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)

    class GolYarDb(ctx:Context):SQLiteOpenHelper(ctx,"golyar.db",null,2){
        private val appContext = ctx.applicationContext
        override fun onCreate(db:SQLiteDatabase){
            db.execSQL("CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,base_price INTEGER NOT NULL,min_price INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,share REAL NOT NULL DEFAULT 20)")
            db.execSQL("CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,created_at INTEGER)")
            db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,created_at INTEGER,sync_state TEXT DEFAULT 'PENDING')")
            db.execSQL("CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,reason TEXT,created_at INTEGER)")
            db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,created_at INTEGER)")
            db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT)")
            db.execSQL("INSERT INTO settings(key,value) VALUES('default_seller_share','20')")
        }
        override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){if(oldVersion<2){db.execSQL("ALTER TABLE sellers ADD COLUMN share REAL NOT NULL DEFAULT 20");db.execSQL("ALTER TABLE sales ADD COLUMN sync_state TEXT DEFAULT 'PENDING'");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('default_seller_share','20')")}}
        private fun cv(vararg p:Pair<String,Any?>)=ContentValues().also{p.forEach{(k,v)->when(v){is String->it.put(k,v);is Int->it.put(k,v);is Long->it.put(k,v);is Double->it.put(k,v);null->it.putNull(k)}}}
        fun setMode(v:String?){val sp=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE);sp.edit().putString("mode",v).apply()}
        fun getMode():String?=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE).getString("mode",null)
        fun isSellerMode()=getMode()?.startsWith("SELLER:")==true
        fun currentSellerId():Long?=getMode()?.substringAfter("SELLER:")?.toLongOrNull()
        fun upsertFlower(id:Long?,name:String,base:Long,min:Long){val v=cv("name" to name,"base_price" to base,"min_price" to min);if(id==null)writableDatabase.insert("flowers",null,v)else writableDatabase.update("flowers",v,"id=?",arrayOf(id.toString()))}
        fun upsertSeller(id:Long?,name:String,phone:String,share:Double){val v=cv("name" to name,"phone" to phone,"share" to share);if(id==null)writableDatabase.insert("sellers",null,v)else writableDatabase.update("sellers",v,"id=?",arrayOf(id.toString()))}
        fun flowers():List<Flower>{val l=mutableListOf<Flower>();q("SELECT * FROM flowers ORDER BY name"){c->l.add(Flower(c.getLong(0),c.getString(1),c.getLong(2),c.getLong(3)))};return l}
        fun sellers():List<Seller>{val l=mutableListOf<Seller>();q("SELECT * FROM sellers ORDER BY name"){c->l.add(Seller(c.getLong(0),c.getString(1),c.getString(2)?:("")))};return l}
        private fun q(sql:String,block:(android.database.Cursor)->Unit){readableDatabase.rawQuery(sql,null).use{while(it.moveToNext())block(it)}}
        fun delete(table:String,id:Long){writableDatabase.delete(table,"id=?",arrayOf(id.toString()))}
        fun addDelivery(s:Long,f:Long,q:Int){writableDatabase.insert("deliveries",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"created_at" to System.currentTimeMillis()))}
        fun addSale(s:Long,f:Long,q:Int,p:Long){writableDatabase.insert("sales",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to System.currentTimeMillis(),"sync_state" to "PENDING"))}
        fun addReturn(s:Long,f:Long,q:Int,r:String){writableDatabase.insert("returns",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"reason" to r,"created_at" to System.currentTimeMillis()))}
        fun addPayment(s:Long,a:Long){writableDatabase.insert("payments",null,cv("seller_id" to s,"amount" to a,"created_at" to System.currentTimeMillis()))}
        fun sellerFlowerStock(s:Long,f:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=? AND flower_id=?),0)",arrayOf(s,f,s,f,s,f)).toInt()
        fun sellerStock(s:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=?),0)",arrayOf(s,s,s)).toInt()
        fun sellerShare(s:Long):Double=readableDatabase.rawQuery("SELECT share FROM sellers WHERE id=?",arrayOf(s.toString())).use{if(it.moveToFirst())it.getDouble(0) else getDefaultSellerShare()}
        fun getDefaultSellerShare():Double=setting("default_seller_share",20.0)
        fun setDefaultSellerShare(v:Double){writableDatabase.update("settings",cv("value" to v.toString()),"key='default_seller_share'",null)}
        fun sellerSalesTotal(s:Long):Long=one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE seller_id=?",arrayOf(s))
        fun sellerCommission(s:Long):Long=(sellerSalesTotal(s)*sellerShare(s)/100.0).toLong()
        fun paidToGreenhouse(s:Long):Long=one("SELECT COALESCE(SUM(amount),0) FROM payments WHERE seller_id=?",arrayOf(s))
        fun payments(s:Long):List<PaymentRow>{val l=mutableListOf<PaymentRow>();readableDatabase.rawQuery("SELECT amount,created_at FROM payments WHERE seller_id=? ORDER BY created_at DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(PaymentRow(c.getLong(0),jalaliDate(c.getLong(1))))};return l}
        fun greenhouseDue(s:Long):Long=(sellerSalesTotal(s)-sellerCommission(s)-paidToGreenhouse(s)).coerceAtLeast(0)
        fun dashboard(sellerId:Long?):Dash{val condition=sellerId?.let{" AND seller_id=$it"}?:"";val todayStart=dayStart();val todayEnd=todayStart+86400000;val deliveredToday=one("SELECT COALESCE(SUM(qty),0) FROM deliveries WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val soldToday=one("SELECT COALESCE(SUM(qty),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val returnedToday=one("SELECT COALESCE(SUM(qty),0) FROM returns WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val salesToday=one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd));val stock=if(sellerId!=null)sellerStock(sellerId) else one("SELECT COALESCE(SUM(qty),0) FROM deliveries").toInt()-one("SELECT COALESCE(SUM(qty),0) FROM sales").toInt()-one("SELECT COALESCE(SUM(qty),0) FROM returns").toInt();val due=if(sellerId!=null)greenhouseDue(sellerId) else sellers().sumOf{greenhouseDue(it.id)};return Dash(deliveredToday,soldToday,returnedToday,salesToday,stock,due)}
        fun sales(s:Long):List<SaleRow>{val l=mutableListOf<SaleRow>();readableDatabase.rawQuery("SELECT f.name,s.qty,s.price,s.created_at,s.sync_state FROM sales s JOIN flowers f ON f.id=s.flower_id WHERE s.seller_id=? ORDER BY s.created_at DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(SaleRow(c.getString(0),c.getInt(1),c.getLong(2),jalaliDate(c.getLong(3)),c.getString(4)!="PENDING"))};return l}
        private fun setting(k:String,d:Double):Double=readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0).toDoubleOrNull()?:d else d}
        private fun one(sql:String,args:Array<Any?> = emptyArray()):Long{val a=args.map{it.toString()}.toTypedArray();readableDatabase.rawQuery(sql,a).use{it.moveToFirst();return it.getLong(0)}}
        private fun dayStart():Long{val c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.timeInMillis}
        private fun jalaliDate(ms:Long):String{val c=Calendar.getInstance();c.timeInMillis=ms;val gy=c.get(Calendar.YEAR);val gm=c.get(Calendar.MONTH)+1;val gd=c.get(Calendar.DAY_OF_MONTH);val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31);var days=355666+365*gy+((gy+3)/4)-((gy+99)/100)+((gy+399)/400)+gd;for(i in 1 until gm)days+=gdm[i];if(gm>2&&isLeapGregorian(gy))days++;var jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365};val jm=if(days<186)1+days/31 else 7+(days-186)/30;val jd=1+if(days<186)days%31 else(days-186)%30;return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)}
        private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)
    }
}
