Gol Negar v25.27 - Stage 1

This stage focuses only on account/session/settings foundations:
- First greenhouse setup collects local admin username/password and Firebase email/password once.
- Subsequent launches open directly to Home without login prompts.
- Firebase Auth session/secure encrypted credential restore is silent.
- Offline launch remains usable.
- Admin settings: username/password changes, password visibility, Firebase connection test, manual sync, database connection reset.
- Seller settings: username/password change with password visibility; Firebase account is updated when the active session permits it.
- No logout feature.
