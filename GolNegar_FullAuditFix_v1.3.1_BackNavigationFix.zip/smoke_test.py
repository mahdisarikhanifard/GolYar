import sqlite3, hashlib, re

con=sqlite3.connect(':memory:')
c=con.cursor()
c.executescript('''
CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,username TEXT,share REAL,remote_id TEXT UNIQUE);
CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,size TEXT,base_price INTEGER,min_price INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,seller_share_amount INTEGER,greenhouse_amount INTEGER,min_price_snapshot INTEGER,below_minimum INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,remote_id TEXT UNIQUE);
CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,remote_id TEXT UNIQUE);
''')
# Source device: seller local id 1, flower local id 1.
c.execute("INSERT INTO sellers(name,username,share,remote_id) VALUES('علی','ali',20,'seller-A')")
c.execute("INSERT INTO flowers(name,size,base_price,min_price,remote_id) VALUES('رز','50',100000,90000,'flower-R50')")
c.execute("INSERT INTO deliveries VALUES(NULL,1,1,100,100000,'delivery-A')")
# 10 sold at 95k: seller gets 20%, greenhouse gets 80%, below minimum.
total=10*95000; seller_share=total*20//100; greenhouse=total-seller_share
c.execute("INSERT INTO sales VALUES(NULL,1,1,10,95000,?,?,?,?,?)",(seller_share,greenhouse,90000,1,'sale-A'))
c.execute("INSERT INTO returns VALUES(NULL,1,1,5,'return-A')")
c.execute("INSERT INTO payments VALUES(NULL,1,500000,'payment-A')")

# Settlement invariants.
stock=c.execute('SELECT SUM(qty) FROM deliveries WHERE seller_id=1').fetchone()[0]-c.execute('SELECT SUM(qty) FROM sales WHERE seller_id=1').fetchone()[0]-c.execute('SELECT SUM(qty) FROM returns WHERE seller_id=1').fetchone()[0]
sales_total=c.execute('SELECT SUM(qty*price) FROM sales WHERE seller_id=1').fetchone()[0]
commission=c.execute('SELECT SUM(seller_share_amount) FROM sales WHERE seller_id=1').fetchone()[0]
greenhouse_due=c.execute('SELECT SUM(greenhouse_amount) FROM sales WHERE seller_id=1').fetchone()[0]
paid=c.execute('SELECT SUM(amount) FROM payments WHERE seller_id=1').fetchone()[0]
balance=greenhouse_due-paid
assert stock==85, stock
assert sales_total==950000
assert commission==190000
assert greenhouse_due==760000
assert paid==500000
assert balance==260000
assert c.execute('SELECT COUNT(*) FROM sales WHERE below_minimum=1').fetchone()[0]==1

# Simulate a second device with different local IDs; map by stable remote IDs.
c.execute("INSERT INTO sellers(name,username,share,remote_id) VALUES('سارا','sara',30,'seller-B')")
c.execute("INSERT INTO flowers(name,size,base_price,min_price,remote_id) VALUES('رز','40',80000,70000,'flower-R40')")
# Remote record from source must resolve seller-A/flower-R50, not numeric ids.
seller_local=c.execute("SELECT id FROM sellers WHERE remote_id='seller-A'").fetchone()[0]
flower_local=c.execute("SELECT id FROM flowers WHERE remote_id='flower-R50'").fetchone()[0]
assert seller_local==1 and flower_local==1

# Ensure no plaintext Firebase password is present in source package.
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=(ROOT/'app/src/main/java/com/example/golyar/MainActivity.kt').read_text(encoding='utf-8')
assert 'Ham' not in source
assert 'admin_firebase_password' in source
assert 'AES/GCM/NoPadding' in source

print('PASS: settlement arithmetic')
print('PASS: stock arithmetic')
print('PASS: below-minimum detection')
print('PASS: stable seller/flower remote-ID mapping')
print('PASS: Firebase password is not hard-coded in source')


# v1.3.1 static integration checks
from pathlib import Path
source = Path("app/src/main/java/com/example/golyar/MainActivity.kt").read_text(encoding="utf-8")
gradle = Path("app/build.gradle.kts").read_text(encoding="utf-8")
assert 'versionName = "1.3.1"' in gradle
assert 'versionCode = 61' in gradle
assert 'whereEqualTo("auth_uid", firebaseAuth.currentUser?.uid.orEmpty())' in source
payment_branch = source[source.index('name == "payments"'):source.index('} else if (sellerId != null && sellerId > 0L)')]
assert '.get()' in payment_branch, "payments pull must execute Firestore query"
assert 'fun goBack()' in source
assert 'db.delete("flowers", f.id); showFlowers(); syncWithFirebaseIfOnline(false)' in source
assert 'private fun showHome() {\n        screenBackStack.clear()' in source
assert 'private fun detachFromParent(view: View)' in source
assert 'detachFromParent(root)' in source
print("PASS: v1.3.1 navigation/sync/delete integration checks")
