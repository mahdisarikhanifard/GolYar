Gol Negar v1.1.10 — Build & Sync Hardening

Based on v1.1.9 Deep Sync Fix. This release keeps the seller bootstrap/deep-sync fixes, keeps below-minimum-price sales registrable with a warning, keeps the version number beside the app name, and hardens the GitHub build so the exact source archive is validated before Gradle runs. The source also keeps the sectionTitle helper in MainActivity, avoiding the earlier unresolved-reference build failure.
