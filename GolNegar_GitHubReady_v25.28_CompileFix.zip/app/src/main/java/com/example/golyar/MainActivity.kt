package com.example.golyar

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Context
import android.util.Base64
import android.net.ConnectivityManager
import android.net.Network
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestore
import androidx.activity.OnBackPressedCallback
import java.text.NumberFormat
import kotlin.math.abs
import java.util.Calendar
import java.util.Locale
import java.util.UUID
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.SecretKey

private class SecureCredentialStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("golnegar_secure_credentials", Context.MODE_PRIVATE)
    private val alias = "GolNegarCredentialKey"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(alias, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
            alias,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return generator.generateKey()
    }

    fun put(name: String, value: String) {
        if (value.isEmpty()) return
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val data = Base64.encodeToString(cipher.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        prefs.edit().putString(name + "_iv", iv).putString(name + "_data", data).apply()
    }

    fun remove(name: String) {
        prefs.edit().remove(name + "_iv").remove(name + "_data").apply()
    }

    fun get(name: String): String? {
        return try {
            val iv = prefs.getString(name + "_iv", null) ?: return null
            val data = prefs.getString(name + "_data", null) ?: return null
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
            String(cipher.doFinal(Base64.decode(data, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var db: GolYarDb
    private lateinit var secureCredentials: SecureCredentialStore
    private var isHomeScreen = false
    private val nf = NumberFormat.getNumberInstance(Locale.US)
    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var syncInProgress = false
    private var syncStatusTapCount = 0
    private val syncStatusTapHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val resetSyncStatusTapCount = Runnable { syncStatusTapCount = 0 }
    private val autoSyncHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val autoSyncRunnable = object : Runnable {
        override fun run() {
            if (!isFinishing && FirebaseApp.getApps(this@MainActivity).isNotEmpty() && firebaseSignedIn() && isNetworkAvailable()) {
                syncWithFirebaseIfOnline(false)
            }
            autoSyncHandler.postDelayed(this, 60_000L)
        }
    }

    private val firebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    private fun firebaseEmail(username: String, role: String): String {
        if (role == "ADMIN") return db.adminFirebaseEmail()
        val clean = username.trim().lowercase(Locale.US).replace(Regex("[^a-z0-9._-]"), "_")
        return "$clean@golyar.app"
    }

    private fun firebaseSignInOrCreate(username: String, password: String, role: String, sellerId: Long?, onDone: (Boolean) -> Unit) {
        if (username.isBlank() || password.length < 6) { onDone(false); return }
        val email = firebaseEmail(username, role)
        firebaseAuth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                if (role == "SELLER" && sellerId != null) secureCredentials.put("seller_firebase_$sellerId", password)
                ensureFirebaseUserDoc(result.user, role, sellerId, onDone)
            }
            .addOnFailureListener { onDone(false) }
    }

    private fun firebaseAdminLogin(onDone: (Boolean) -> Unit) {
        val email = db.adminFirebaseEmail()
        if (email.isBlank()) { onDone(false); return }

        val current = firebaseAuth.currentUser
        if (current?.email?.equals(email, ignoreCase = true) == true) {
            ensureFirebaseUserDoc(current, "ADMIN", null, onDone)
            return
        }

        // First try the encrypted credential saved after a successful Firebase login.
        // If it is not available, try the greenhouse login password once. This keeps
        // the common case completely silent without hard-coding a password in the APK.
        val candidates = linkedSetOf<String>()
        secureCredentials.get("admin_firebase_password")?.takeIf { it.length >= 6 }?.let { candidates.add(it) }
        db.adminLocalPassword()?.takeIf { it.length >= 6 }?.let { candidates.add(it) }

        fun tryCandidate(index: Int) {
            if (index >= candidates.size) {
                showFirebaseAdminPasswordDialog(email, onDone)
                return
            }
            val password = candidates.elementAt(index)
            firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    secureCredentials.put("admin_firebase_password", password)
                    ensureFirebaseUserDoc(result.user, "ADMIN", null, onDone)
                }
                .addOnFailureListener { error ->
                    // IMPORTANT: Never create a new Firebase user just because
                    // sign-in failed. A wrong password, disabled account, network
                    // error, etc. must NOT trigger account creation.
                    // Creation is allowed only when Firebase explicitly says that
                    // this email/user does not exist.
                    val authError = error as? FirebaseAuthException
                    val code = authError?.errorCode.orEmpty()
                    if (code == "ERROR_USER_NOT_FOUND") {
                        firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnSuccessListener { result ->
                                secureCredentials.put("admin_firebase_password", password)
                                ensureFirebaseUserDoc(result.user, "ADMIN", null, onDone)
                            }
                            .addOnFailureListener { createError ->
                                val createCode = (createError as? FirebaseAuthException)?.errorCode.orEmpty()
                                if (createCode == "ERROR_EMAIL_ALREADY_IN_USE") {
                                    // The account appeared between the lookup and
                                    // create request. Ask for the existing Firebase
                                    // password instead of trying to create another user.
                                    showFirebaseAdminPasswordDialog(email, onDone)
                                } else {
                                    tryCandidate(index + 1)
                                }
                            }
                    } else {
                        // Existing account / wrong credentials: try the next saved
                        // credential, then ask explicitly. Never auto-create here.
                        tryCandidate(index + 1)
                    }
                }
        }
        tryCandidate(0)
    }

    private fun showFirebaseAdminPasswordDialog(email: String, onDone: (Boolean) -> Unit) {
        val box = formBox()
        val emailField = field("ایمیل Firebase", email)
        emailField.isEnabled = false
        val passwordField = field("رمز عبور Firebase", "")
        passwordField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(emailField)
        box.addView(passwordField)

        AlertDialog.Builder(this)
            .setTitle("اتصال حساب گلخانه به Firebase")
            .setMessage("این رمز پس از ورود موفق، به‌صورت رمزگذاری‌شده در همین گوشی ذخیره می‌شود و در ورودهای بعدی دوباره پرسیده نمی‌شود.")
            .setView(box)
            .setPositiveButton("اتصال") { _, _ ->
                val firebasePassword = passwordField.text.toString()
                if (firebasePassword.length < 6) {
                    info("رمز عبور Firebase باید حداقل ۶ کاراکتر باشد.")
                    onDone(false)
                    return@setPositiveButton
                }
                firebaseAuth.signInWithEmailAndPassword(email, firebasePassword)
                    .addOnSuccessListener { result ->
                        secureCredentials.put("admin_firebase_password", firebasePassword)
                        ensureFirebaseUserDoc(result.user, "ADMIN", null, onDone)
                    }
                    .addOnFailureListener { error ->
                        info("ورود به حساب Firebase انجام نشد: ${error.localizedMessage ?: "ایمیل یا رمز عبور Firebase صحیح نیست."}")
                        onDone(false)
                    }
            }
            .setNegativeButton("انصراف") { _, _ -> onDone(false) }
            .show()
    }

    private fun provisionSellerFirebaseAccounts(onDone: (Boolean, String?) -> Unit) {
        val sellers = db.sellers()
        if (sellers.isEmpty()) { onDone(true, null); return }
        val primaryApp = FirebaseApp.getInstance()
        val secondaryName = "golyarSellerProvision"
        val secondaryApp = try {
            FirebaseApp.getInstance(secondaryName)
        } catch (_: Exception) {
            FirebaseApp.initializeApp(this, primaryApp.options, secondaryName)
        }
        if (secondaryApp == null) { onDone(false, "راه‌اندازی اتصال Firebase برای ساخت حساب فروشندگان انجام نشد."); return }
        val secondaryAuth = FirebaseAuth.getInstance(secondaryApp)
        val fs = FirebaseFirestore.getInstance()

        fun next(index: Int) {
            if (index >= sellers.size) {
                runCatching { secondaryAuth.signOut() }
                onDone(true, null)
                return
            }
            val seller = sellers[index]
            val username = seller.username.trim()
            val password = db.sellerPassword(seller.id)
            if (username.isBlank()) { onDone(false, "فروشنده «${seller.name}» نام کاربری ندارد."); return }
            if (password.length < 6) { onDone(false, "رمز عبور فروشنده «${seller.name}» باید حداقل ۶ کاراکتر باشد."); return }
            val clean = username.lowercase(Locale.US).replace(Regex("[^a-z0-9._-]"), "_")
            val email = "$clean@golyar.app"

            secondaryAuth.signOut()
            secondaryAuth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid
                    if (uid == null) { onDone(false, "حساب Firebase فروشنده «${seller.name}» ساخته نشد."); return@addOnSuccessListener }
                    val data = hashMapOf<String, Any>("role" to "SELLER", "username" to username, "firebase_email" to email, "seller_id" to seller.id, "seller_remote_id" to db.sellerRemoteId(seller.id), "updated_at" to System.currentTimeMillis())
                    fs.collection("users").document(uid).set(data)
                        .addOnSuccessListener { next(index + 1) }
                        .addOnFailureListener { e -> onDone(false, "ثبت پروفایل Firebase فروشنده «${seller.name}» انجام نشد: ${e.localizedMessage ?: e.message}") }
                }
                .addOnFailureListener { createError ->
                    // If the account already exists, verify the local seller password against it.
                    secondaryAuth.signInWithEmailAndPassword(email, password)
                        .addOnSuccessListener { result ->
                            val uid = result.user?.uid
                            if (uid == null) { onDone(false, "حساب Firebase فروشنده «${seller.name}» قابل شناسایی نیست."); return@addOnSuccessListener }
                            val data = hashMapOf<String, Any>("role" to "SELLER", "username" to username, "firebase_email" to email, "seller_id" to seller.id, "seller_remote_id" to db.sellerRemoteId(seller.id), "updated_at" to System.currentTimeMillis())
                            fs.collection("users").document(uid).set(data)
                                .addOnSuccessListener { next(index + 1) }
                                .addOnFailureListener { e -> onDone(false, "ثبت پروفایل Firebase فروشنده «${seller.name}» انجام نشد: ${e.localizedMessage ?: e.message}") }
                        }
                        .addOnFailureListener { signInError ->
                            onDone(false, "حساب Firebase فروشنده «${seller.name}» وجود دارد ولی رمز ثبت‌شده با Firebase مطابقت ندارد. از Authentication برای Reset password استفاده کنید.")
                        }
                }
        }
        next(0)
    }

    private fun ensureFirebaseUserDoc(user: FirebaseUser?, role: String, sellerId: Long?, onDone: (Boolean) -> Unit) {
        if (user == null) { onDone(false); return }

        // The admin account has already been authenticated by Firebase and its
        // users/{uid} profile is provisioned in Firestore. Do not perform a
        // second Firestore read/write during login; this avoids a false login
        // failure caused by Firestore rules while the authenticated session is valid.
        if (role == "ADMIN" &&
            user.email?.equals(db.adminFirebaseEmail(), ignoreCase = true) == true) {
            onDone(true)
            return
        }

        val data = hashMapOf<String, Any>(
            "role" to role,
            "username" to db.sellerUsername(sellerId ?: -1L),
            "firebase_email" to user.email.orEmpty(),
            "updated_at" to System.currentTimeMillis()
        )
        if (sellerId != null) { data["seller_id"] = sellerId; data["seller_remote_id"] = db.sellerRemoteId(sellerId) }
        val userRef = FirebaseFirestore.getInstance().collection("users").document(user.uid)
        userRef.get()
            .addOnSuccessListener { snap ->
                if (snap.exists()) {
                    onDone(true)
                } else {
                    userRef.set(data)
                        .addOnSuccessListener { onDone(true) }
                        .addOnFailureListener { error ->
                            info("ثبت پروفایل Firebase انجام نشد: ${error.localizedMessage ?: error.message ?: "خطای نامشخص"}")
                            onDone(false)
                        }
                }
            }
            .addOnFailureListener { error ->
                info("بررسی پروفایل Firebase انجام نشد: ${error.localizedMessage ?: error.message ?: "خطای نامشخص"}")
                onDone(false)
            }
    }

    private fun restoreFirebaseSessionIfNeeded() {
        if (FirebaseApp.getApps(this).isEmpty() || firebaseAuth.currentUser != null) return
        if (!isNetworkAvailable()) return
        if (db.isSellerMode()) {
            val sid = db.currentSellerId() ?: return
            val username = db.sellerUsername(sid)
            val password = secureCredentials.get("seller_firebase_$sid") ?: db.sellerPassword(sid)
            if (username.isBlank() || password.length < 6) return
            firebaseAuth.signInWithEmailAndPassword(firebaseEmail(username, "SELLER"), password)
                .addOnSuccessListener { secureCredentials.put("seller_firebase_$sid", password); syncWithFirebaseIfOnline(false) }
        } else if (db.isAdminSetupDone()) {
            val password = secureCredentials.get("admin_firebase_password") ?: return
            val email = db.adminFirebaseEmail()
            if (email.isBlank() || password.length < 6) return
            firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { secureCredentials.put("admin_firebase_password", password); syncWithFirebaseIfOnline(false) }
        }
    }

    private fun firebaseSignedIn(): Boolean {
        val user = firebaseAuth.currentUser ?: return false
        return if (db.isSellerMode()) {
            val sid = db.currentSellerId() ?: return false
            val username = db.sellerUsername(sid)
            user.email?.equals(firebaseEmail(username, "SELLER"), ignoreCase = true) == true
        } else if (db.isAdminSetupDone()) {
            user.email?.equals(db.adminFirebaseEmail(), ignoreCase = true) == true
        } else false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        db = GolYarDb(this)
        db.repairSellerActiveState()
        secureCredentials = SecureCredentialStore(this)
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (FirebaseApp.initializeApp(this) != null) {
            FirebaseAnalytics.getInstance(this).logEvent("app_open", null)
            registerNetworkSync()
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!isHomeScreen) {
                    showHome()
                } else {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("خروج از گل نگار")
                        .setMessage("آیا قصد خروج از برنامه را دارید؟")
                        .setNegativeButton("خیر", null)
                        .setPositiveButton("بله") { _, _ -> finish() }
                        .show()
                }
            }
        })
        // Every launch starts with Firebase-ready authentication flow.
        // A saved local mode never bypasses login; existing users get the
        // normal username/password screen, while a fresh installation can
        // explicitly create an account only after Firebase reports that the
        // account does not exist.
        startEntryFlow()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun base(title: String, subtitle: String? = null): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            setBackgroundColor(Color.rgb(247, 249, 247))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(dp(18), bars.top + dp(40), dp(18), bars.bottom + dp(24))
            insets
        }
        ViewCompat.requestApplyInsets(root)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(16))
        }
        header.addView(TextView(this).apply {
            text = title
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(28, 55, 39))
            includeFontPadding = false
            minHeight = dp(44)
        })
        root.addView(header)
        return root
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 16f
        isAllCaps = false
        gravity = Gravity.CENTER
        minHeight = dp(56)
        minimumHeight = dp(56)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setTextColor(Color.rgb(28, 55, 39))
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(Color.WHITE)
            setStroke(dp(1), Color.rgb(215, 226, 218))
        }
        stateListAnimator = null
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, dp(56))
        lp.setMargins(0, dp(4), 0, dp(4))
        layoutParams = lp
    }

    private fun metricCard(title:String, value:String, icon:String):LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; layoutDirection=View.LAYOUT_DIRECTION_RTL
        setPadding(dp(10),dp(12),dp(10),dp(12))
        background=GradientDrawable().apply{cornerRadius=dp(16).toFloat();setColor(Color.WHITE);setStroke(dp(1),Color.rgb(218,228,220))}
        addView(TextView(this@MainActivity).apply{text=icon;textSize=20f;gravity=Gravity.CENTER})
        addView(TextView(this@MainActivity).apply{text=value;textSize=18f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(28,55,39));gravity=Gravity.CENTER;setPadding(0,dp(5),0,dp(2))})
        addView(TextView(this@MainActivity).apply{text=title;textSize=12f;setTextColor(Color.rgb(95,105,98));gravity=Gravity.CENTER})
    }

    private fun setScreen(root: LinearLayout, home: Boolean = false) {
        isHomeScreen = home
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.rgb(247, 249, 247))
            clipToPadding = false
        }
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun startEntryFlow() {
        val savedMode = db.getMode()
        // One-time setup only. After setup there is deliberately no login screen.
        // Firebase Auth persists its authenticated session across app restarts; if
        // Android/Firebase needs a new session, the encrypted credential is used
        // silently. Offline use never blocks access to local data.
        if (savedMode?.startsWith("SELLER:") == true && db.currentSellerId() != null) {
            showHome()
            restoreFirebaseSessionIfNeeded()
            return
        }
        if (savedMode == "GREENHOUSE" && db.isAdminSetupDone()) {
            showHome()
            restoreFirebaseSessionIfNeeded()
            return
        }
        if (db.isAdminSetupDone()) {
            db.setMode("GREENHOUSE")
            showHome()
            restoreFirebaseSessionIfNeeded()
            return
        }
        showModeChooser()
    }

    private fun showModeChooser() {
        val root = base("گل نگار", "مدیریت هوشمند فروش و حساب گلخانه")
        root.addView(heroCard("گلخانه", "نسخه گلخانه برای مدیریت کامل" , "🏭") { greenhouseLogin() })
        root.addView(heroCard("فروشنده", "نسخه فروشنده برای ثبت سریع فروش", "👤") { showSellerChooser() })
        if (db.getMode() != null) root.addView(outlineAction("ادامه با حساب فعلی") { showHome() })
        setScreen(root)
    }

    private fun showSellerChooser() {
        val box = formBox()
        val user = field("نام کاربری فروشنده", "")
        val pass = field("رمز عبور", "")
        pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(user)
        box.addView(pass)

        AlertDialog.Builder(this)
            .setTitle("ورود فروشنده")
            .setMessage("حساب فروشنده باید قبلاً توسط گلخانه در Firebase ایجاد شده باشد.")
            .setView(box)
            .setPositiveButton("ورود") { _, _ ->
                val username = user.text.toString().trim()
                val password = pass.text.toString()
                if (username.isBlank() || password.length < 6) {
                    info("نام کاربری و رمز عبور را کامل وارد کنید.") { showSellerChooser() }
                    return@setPositiveButton
                }

                val email = firebaseEmail(username, "SELLER")
                firebaseAuth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener { result ->
                        val uid = result.user?.uid
                        if (uid == null) {
                            info("حساب فروشنده در Firebase قابل شناسایی نیست.")
                            return@addOnSuccessListener
                        }

                        // The users/{uid} document is the authoritative identity for a seller.
                        // Do not make login depend on the optional sellers/{seller_id} document:
                        // that document can be absent on a newly provisioned account and older
                        // Firestore Rules may deny its read. We can still establish the local
                        // seller identity from users/{uid}, then pull the seller's transactions.
                        FirebaseFirestore.getInstance().collection("users").document(uid).get()
                            .addOnSuccessListener { snap ->
                                val sellerId = snap.getLong("seller_id")
                                val role = snap.getString("role")
                                if (role != "SELLER" || sellerId == null || sellerId <= 0L) {
                                    info("این حساب Firebase به یک فروشنده معتبر متصل نیست.")
                                    return@addOnSuccessListener
                                }

                                val firebaseSellerName = snap.getString("name")?.trim().orEmpty()
                                val firebaseUsername = snap.getString("username")?.trim().takeUnless { it.isNullOrBlank() } ?: username

                                // Ensure the local seller row exists BEFORE sync. This is the
                                // critical bootstrap step on a fresh seller phone.
                                val localSeller = db.sellerById(sellerId)
                                if (localSeller == null) {
                                    db.upsertSeller(
                                        sellerId,
                                        firebaseSellerName.ifBlank { firebaseUsername },
                                        "",
                                        firebaseUsername,
                                        "",
                                        20.0
                                    )
                                }

                                // Best-effort enrichment from sellers/{seller_id}. Login must not
                                // fail if this optional document is missing/temporarily denied.
                                FirebaseFirestore.getInstance().collection("sellers")
                                    .document(sellerId.toString()).get()
                                    .addOnSuccessListener { sellerSnap ->
                                        if (sellerSnap.exists()) {
                                            db.importFirebaseRecord("sellers", sellerSnap.id, sellerSnap.data ?: emptyMap())
                                        }
                                        completeSellerLoginAfterIdentity(sellerId, password)
                                    }
                                    .addOnFailureListener {
                                        completeSellerLoginAfterIdentity(sellerId, password)
                                    }
                            }
                            .addOnFailureListener { e ->
                                info("دریافت مشخصات حساب فروشنده از Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای دسترسی یا اتصال"}")
                            }
                    }
                    .addOnFailureListener { error ->
                        val code = (error as? FirebaseAuthException)?.errorCode.orEmpty()
                        if (code == "ERROR_USER_NOT_FOUND") {
                            info("این حساب فروشنده در Firebase وجود ندارد. حساب فروشنده باید ابتدا از نسخه گلخانه ایجاد و فعال شود.")
                        } else {
                            info("نام کاربری یا رمز عبور فروشنده صحیح نیست.")
                        }
                    }
            }
            .setNegativeButton("بازگشت") { _, _ -> showModeChooser() }
            .show()
    }

    private fun completeSellerLoginAfterIdentity(sellerId: Long, password: String) {
        db.setMode("SELLER:$sellerId")
        secureCredentials.put("seller_firebase_$sellerId", password)

        // IMPORTANT: sellers is deliberately NOT pulled again here. The seller identity has
        // already been bootstrapped locally and the sellers collection is not needed to obtain
        // the seller's inventory. Pull only collections whose Rules authorize seller_id.
        syncWithFirebaseIfOnline(false) { ok ->
            runOnUiThread {
                if (ok) {
                    showHome()
                } else {
                    info("ورود فروشنده انجام شد، اما دریافت اطلاعات تراکنش‌ها از Firebase کامل نشد. پیام خطای مجموعه مشکل‌دار را بررسی کنید.")
                }
            }
        }
    }

    private fun showHome() {
        val sellerMode = db.isSellerMode()
        val sid = if (sellerMode) db.currentSellerId() else null
        val seller = sid?.let { id -> db.sellers().firstOrNull { it.id == id } }
        val d = db.dashboard(sid)
        val root = base("گل نگار", if (sellerMode) seller?.name ?: "فروشنده" else "داشبورد گلخانه")

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(10))
        }
        top.addView(TextView(this).apply {
            text = todayJalali()
            textSize = 14f
            setTextColor(Color.rgb(86, 99, 91))
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
        })
        top.addView(notificationButton(db.lowPriceWarningCount(sid)) { showPriceWarnings() })
        root.addView(top)

        val syncText = when {
            !isNetworkAvailable() -> "آفلاین • اطلاعات روی گوشی ذخیره می‌شود"
            !firebaseSignedIn() -> "اینترنت برقرار است • نشست Firebase برقرار نیست"
            db.lastFirebaseSync() != null -> "همگام‌سازی موفق: ${jalaliDateTime(db.lastFirebaseSync()!!)}"
            else -> "اتصال Firebase برقرار است • اولین همگام‌سازی انجام نشده"
        }
        root.addView(syncStatusCard(syncText))

        if (sellerMode) {
            root.addView(sectionTitle("عملیات اصلی"))
            root.addView(iconGrid(listOf(
                Triple("ثبت فروش", "🧾") { showSale() },
                Triple("پرداخت به گلخانه", "💳") { showSettlement() },
                Triple("موجودی من", "📦") { showSellerInventoryReport() },
                Triple("گزارش من", "📊") { showSellerReportsNew() },
                Triple("برگشتی", "↩️") { showSellerReturnsAndSales() },
                Triple("تنظیمات", "⚙️") { showSettings() }
            )))
            root.addView(sectionTitle("وضعیت مالی"))
            root.addView(financialCard(
                listOf(
                    "فروش ماه جاری" to money(db.sellerSalesTotal(sid ?: 0)),
                    "سهم فروشنده" to money(db.sellerCommission(sid ?: 0)),
                    "پرداخت به گلخانه" to money(db.paidToGreenhouse(sid ?: 0)),
                    "مانده حساب" to money(abs(db.greenhouseBalance(sid ?: 0)))
                ),
                if (d.greenhouseDue == 0L) "تسویه" else if (d.greenhouseDue > 0) "بدهکار گلخانه" else "طلبکار از گلخانه"
            ))
        } else {
            root.addView(sectionTitle("عملیات سریع"))
            root.addView(iconGrid(listOf(
                Triple("ثبت گل", "🌹") { flowerDialog(null) },
                Triple("فروشندگان", "👥") { showSellers() },
                Triple("تحویل گل", "📦") { showDelivery() },
                Triple("فروش متفرقه", "🧾") { showMiscSale() },
                Triple("برگشتی", "↩️") { showReturn() },
                Triple("پرداخت‌ها", "💳") { showAllPaymentsHistory() }
            )))
            root.addView(sectionTitle("نمای کلی امروز"))
            root.addView(financialCard(listOf(
                "فروش امروز" to money(d.salesToday),
                "تحویل امروز" to "${d.deliveredToday} دسته",
                "برگشتی امروز" to "${d.returnedToday} دسته",
                "موجودی نزد فروشندگان" to "${d.stock} دسته"
            ), "مطالبات فروشندگان: ${money(d.greenhouseDue)}"))
            root.addView(sectionTitle("هشدارها"))
            root.addView(alertCard("فروش زیر حداقل قیمت", "${db.lowPriceWarningCount(null)} مورد", db.lowPriceWarningCount(null) > 0) { showPriceWarnings() })
            root.addView(alertCard("وضعیت همگام‌سازی", if (isNetworkAvailable()) "اتصال برقرار است" else "آفلاین", !isNetworkAvailable()) { syncWithFirebaseIfOnline(true) })
        }
        addBottomNavigation(root, "خانه")
        setScreen(root, true)
    }

    private fun showSellerReportsNew() {
        val sid = db.currentSellerId() ?: return
        val root = base("گزارش من", "فروش، موجودی و حساب فروشنده")
        root.addView(financialCard(listOf(
            "کل فروش" to money(db.sellerSalesTotal(sid)),
            "سهم فروشنده" to money(db.sellerCommission(sid)),
            "پرداخت به گلخانه" to money(db.paidToGreenhouse(sid)),
            "موجودی" to "${db.sellerStock(sid)} دسته"
        ), sellerBalanceText(sid).replace("\n", " • ")))
        root.addView(sectionTitle("دسترسی به گزارش‌ها"))
        root.addView(listCard("فروش‌های من", "ریز فروش‌ها، اندازه، تعداد و مبلغ") { showSalesHistory() })
        root.addView(listCard("پرداخت‌های من", "تاریخ و مبالغ پرداختی") { showPaymentHistory(db.sellers().firstOrNull { it.id == sid } ?: return@listCard) })
        root.addView(listCard("موجودی من", "موجودی تفکیک‌شده بر اساس گل و اندازه") { showSellerInventoryReport() })
        root.addView(listCard("حساب و تسویه", "بدهی، طلب و پرداخت‌ها") { showSettlement() })
        addBottomNavigation(root, "گزارش‌ها")
        setScreen(root)
    }

    private fun addBottomNavigation(root: LinearLayout, selected: String) {
        root.addView(Space(this).apply { minimumHeight = dp(18) })
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = cardBackground()
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
        listOf("خانه" to "⌂", "ثبت‌ها" to "＋", "لیست‌ها" to "☷", "گزارش‌ها" to "▤", "تنظیمات" to "⚙").forEach { (title, icon) ->
            val b = TextView(this).apply {
                text = "$icon\n$title"
                textSize = if (title == selected) 12.5f else 11.5f
                typeface = if (title == selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                gravity = Gravity.CENTER
                setTextColor(if (title == selected) Color.rgb(53, 107, 70) else Color.rgb(92, 104, 96))
                setPadding(dp(2), dp(5), dp(2), dp(5))
                layoutParams = LinearLayout.LayoutParams(0, dp(62), 1f)
                setOnClickListener {
                    when (title) {
                        "خانه" -> showHome()
                        "ثبت‌ها" -> showRegistrations()
                        "لیست‌ها" -> showLists()
                        "گزارش‌ها" -> showReportsHub()
                        "تنظیمات" -> showSettings()
                    }
                }
            }
            nav.addView(b)
        }
        root.addView(nav)
    }

    private fun showRegistrations() {
        val root = base("ثبت‌ها", "هر عملیات را از اینجا ثبت کنید")
        if (db.isSellerMode()) {
            root.addView(listCard("ثبت سریع فروش", "گل ← اندازه ← تعداد و قیمت ← تأیید") { showSale() })
            root.addView(listCard("پرداخت به گلخانه", "مبلغ، روش پرداخت و مانده حساب") { showSettlement() })
            root.addView(listCard("برگشت گل", "ثبت برگشتی‌های فروشنده") { showSellerReturnsAndSales() })
        } else {
            root.addView(listCard("ثبت نوع گل", "نام، اندازه، قیمت مرجع و حداقل قیمت") { flowerDialog(null) })
            root.addView(listCard("ثبت فروشنده", "مشخصات و حساب ورود فروشنده") { sellerDialog(null) })
            root.addView(listCard("تحویل گل", "فروشنده، گل، اندازه، تعداد و قیمت مرجع") { showDelivery() })
            root.addView(listCard("ثبت فروش متفرقه", "فروش مستقیم گلخانه به اشخاص مختلف") { showMiscSale() })
            root.addView(listCard("ثبت برگشتی", "گل، اندازه، تعداد و علت") { showReturn() })
            root.addView(listCard("ثبت پرداختی گلخانه", "پرداخت‌های انجام‌شده توسط گلخانه") { showGreenhousePayment() })
        }
        addBottomNavigation(root, "ثبت‌ها")
        setScreen(root)
    }

    private fun showLists() {
        val root = base("لیست‌ها", "جست‌وجو و مشاهده اطلاعات ثبت‌شده")
        if (db.isSellerMode()) {
            root.addView(listCard("فروش‌های من", "تاریخ، گل، اندازه، تعداد و مبلغ") { showSalesHistory() })
            root.addView(listCard("موجودی من", "موجودی هر گل و اندازه") { showSellerInventoryReport() })
            root.addView(listCard("پرداخت‌های من", "تاریخچه پرداخت‌ها") { showPaymentHistory(db.sellers().firstOrNull { it.id == db.currentSellerId() } ?: return@listCard) })
            root.addView(listCard("برگشتی‌ها", "تاریخچه برگشت گل") { showSellerReturnsAndSales() })
        } else {
            root.addView(listCard("گل‌ها", "تمام گل‌ها و اندازه‌ها") { showFlowers() })
            root.addView(listCard("فروشندگان", "موجودی، فروش و حساب هر فروشنده") { showSellers() })
            root.addView(listCard("تحویل‌ها", "تحویل‌های ثبت‌شده") { showGreenhouseDeliveryReport() })
            root.addView(listCard("فروش‌های فروشندگان", "فروش‌ها به تفکیک فروشنده و گل") { showGreenhouseSellerSalesReport() })
            root.addView(listCard("فروش‌های متفرقه", "فروش مستقیم به خریداران") { showMiscSalesHistory() })
            root.addView(listCard("برگشتی‌ها", "تمام برگشتی‌ها") { showReturnReport() })
            root.addView(listCard("پرداختی‌های گلخانه", "پرداخت‌های انجام‌شده توسط گلخانه") { showGreenhousePaymentsHistory() })
            root.addView(listCard("پرداخت‌های فروشندگان", "پرداخت فروشندگان به گلخانه") { showAllPaymentsHistory() })
        }
        addBottomNavigation(root, "لیست‌ها")
        setScreen(root)
    }

    private fun showReportsHub() {
        val root = base("گزارش‌ها", "گزارش‌های فروش، مالی و موجودی")
        if (db.isSellerMode()) {
            root.addView(listCard("گزارش فروش", "فروش روزانه و جزئیات فروش") { showSalesHistory() })
            root.addView(listCard("گزارش مالی", "سهم، پرداخت و مانده حساب") { showSellerReportsNew() })
            root.addView(listCard("گزارش موجودی", "موجودی بر اساس گل و اندازه") { showSellerInventoryReport() })
        } else {
            root.addView(listCard("گزارش فروش", "روزانه، ماهانه، گل، اندازه و فروشنده") { showReports() })
            root.addView(listCard("گزارش مالی", "بدهی، طلب، پرداخت، سهم فروشنده و گلخانه") { showFinancialReport() })
            root.addView(listCard("گزارش موجودی", "موجودی گلخانه و موجودی نزد فروشندگان") { showGreenhouseInventoryReport() })
            root.addView(listCard("گزارش برگشتی", "گل، اندازه، تعداد و علت") { showReturnReport() })
            root.addView(listCard("گزارش هشدار قیمت", "فروش‌های زیر حداقل قیمت و فروشنده") { showPriceWarnings() })
        }
        addBottomNavigation(root, "گزارش‌ها")
        setScreen(root)
    }

    private fun heroCard(title: String, subtitle: String, icon: String, action: () -> Unit): LinearLayout {
        val box = cardContainer()
        box.addView(TextView(this).apply { text = icon; textSize = 34f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(2)) })
        box.addView(TextView(this).apply { text = title; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.rgb(35,58,43)) })
        box.addView(TextView(this).apply { text = subtitle; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.rgb(92,104,96)); setPadding(dp(8), dp(4), dp(8), dp(12)) })
        box.setOnClickListener { action() }
        return box
    }

    private fun iconGrid(items: List<Triple<String, String, () -> Unit>>): LinearLayout {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        items.chunked(3).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            rowItems.forEach { (title, icon, action) ->
                val card = cardContainer().apply { gravity = Gravity.CENTER; setPadding(dp(5), dp(10), dp(5), dp(8)); setOnClickListener { action() } }
                card.addView(TextView(this).apply { text = icon; textSize = 28f; gravity = Gravity.CENTER })
                card.addView(TextView(this).apply { text = title; textSize = 12.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(Color.rgb(35,58,43)); setPadding(0, dp(5), 0, 0) })
                val lp = LinearLayout.LayoutParams(0, dp(108), 1f); lp.setMargins(dp(3), dp(3), dp(3), dp(3)); row.addView(card, lp)
            }
            repeat(3 - rowItems.size) { row.addView(Space(this), LinearLayout.LayoutParams(0, dp(108), 1f)) }
            grid.addView(row)
        }
        return grid
    }

    private fun cardContainer(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        background = cardBackground()
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(5), 0, dp(8)); layoutParams = lp
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }

    private fun listCard(title: String, subtitle: String, action: () -> Unit): LinearLayout {
        val box = cardContainer().apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setOnClickListener { action() } }
        box.addView(TextView(this).apply { text = "›"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.rgb(53,107,70)); layoutParams = LinearLayout.LayoutParams(dp(32), dp(58)) })
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; layoutParams = LinearLayout.LayoutParams(0, dp(66), 1f) }
        textBox.addView(TextView(this).apply { text = title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(35,58,43)) })
        textBox.addView(TextView(this).apply { text = subtitle; textSize = 12.5f; setTextColor(Color.rgb(92,104,96)); setPadding(0, dp(4), 0, 0) })
        box.addView(textBox)
        return box
    }

    private fun outlineAction(title: String, action: () -> Unit): Button = Button(this).apply {
        text = title; isAllCaps = false; textSize = 15f; setOnClickListener { action() }; layoutDirection = View.LAYOUT_DIRECTION_RTL
        background = cardBackground(); setTextColor(Color.rgb(53,107,70)); minHeight = dp(54)
        layoutParams = LinearLayout.LayoutParams(-1, dp(56)).also { it.setMargins(0, dp(5), 0, dp(8)) }
    }

    private fun notificationButton(count: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = if (count > 0) "🔔 $count" else "🔔"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.rgb(53,107,70)); background = cardBackground(); setPadding(dp(10), 0, dp(10), 0); setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(dp(82), dp(40))
    }

    private fun statusCard(text: String): TextView = TextView(this).apply {
        this.text = "●  $text"; textSize = 12.5f; setTextColor(Color.rgb(74, 98, 80)); gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT; background = cardBackground(); setPadding(dp(14), 0, dp(14), 0); layoutParams = LinearLayout.LayoutParams(-1, dp(48)).also { it.setMargins(0, dp(4), 0, dp(8)) }
    }

    private fun syncStatusCard(text: String): TextView = statusCard(text).apply {
        isClickable = true
        setOnClickListener {
            syncStatusTapHandler.removeCallbacks(resetSyncStatusTapCount)
            syncStatusTapCount++
            if (syncStatusTapCount >= 5) {
                syncStatusTapCount = 0
                info("درخواست همگام‌سازی دستی ارسال شد.")
                syncWithFirebaseIfOnline(true)
            } else {
                syncStatusTapHandler.postDelayed(resetSyncStatusTapCount, 1800L)
            }
        }
    }

    private fun financialCard(items: List<Pair<String, String>>, footer: String): LinearLayout {
        val box = cardContainer()
        items.forEach { (k, v) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(6)) }
            row.addView(TextView(this).apply { text = k; textSize = 13f; setTextColor(Color.rgb(92,104,96)); layoutParams = LinearLayout.LayoutParams(0, dp(34), 1f) })
            row.addView(TextView(this).apply { text = v; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(35,58,43)); gravity = Gravity.LEFT; layoutParams = LinearLayout.LayoutParams(dp(150), dp(34)) })
            box.addView(row)
        }
        box.addView(TextView(this).apply { text = footer; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(53,107,70)); gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), dp(4)) })
        return box
    }

    private fun alertCard(title: String, value: String, attention: Boolean, action: () -> Unit): LinearLayout {
        val box = listCard(title, value, action)
        if (attention) box.setBackgroundColor(Color.rgb(255, 248, 235))
        return box
    }

    private fun showFlowers() {
        val root = base("انواع گل")
        root.addView(actionButton("＋  تعریف نوع گل") { flowerDialog(null) })
        db.flowers().forEach { f ->
            root.addView(cardRow("🌹  ${f.name} | اندازه: ${f.size}\nقیمت پایه: ${money(f.basePrice)}  |  حداقل فروش: ${money(f.minPrice)}") {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                row.addView(actionButton("ویرایش") { flowerDialog(f) }, LinearLayout.LayoutParams(0, dp(56), 1f))
                row.addView(actionButton("حذف") { confirmDelete("حذف ${f.name}؟") { db.delete("flowers", f.id); showFlowers() } }, LinearLayout.LayoutParams(0, dp(56), 1f))
                it.addView(row)
            })
        }
        root.addView(actionButton("بازگشت") { showHome() })
        setScreen(root)
    }

    private fun flowerDialog(f: Flower?) {
        val box = formBox(); val name = field("نام گل", f?.name ?: ""); val size = field("اندازه گل (مثلاً ۴۰ سانتی / ۵۰ سانتی)", f?.size ?: ""); val base = moneyField("قیمت پایه هر دسته (ریال)", f?.basePrice?.toString() ?: ""); val min = moneyField("حداقل قیمت مجاز (ریال)", f?.minPrice?.toString() ?: "")
        box.addView(name); box.addView(size); box.addView(base); box.addView(min)
        AlertDialog.Builder(this).setTitle(if (f == null) "تعریف گل" else "ویرایش گل").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val n=name.text.toString().trim(); val z=size.text.toString().trim(); val b=parseMoney(base); val m=parseMoney(min)
                if(n.isNotEmpty() && z.isNotEmpty() && b>0 && m>0) db.upsertFlower(f?.id,n,z,b,m); else info("نام، اندازه و قیمت‌ها را کامل وارد کنید.")
                if(n.isNotEmpty() && z.isNotEmpty() && b>0 && m>0) { showFlowers(); syncWithFirebaseIfOnline(false) }
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showSellers() {
        val root = base("فروشندگان", "درصد سهم هر فروشنده از مبلغ فروش قابل تنظیم است")
        root.addView(actionButton("＋  تعریف فروشنده") { sellerDialog(null) })
        db.sellers().forEach { s ->
            root.addView(cardRow("👤  ${s.name}\n${s.phone}\nنام کاربری: ${s.username}\nسهم فروشنده از فروش خودش: ${fmtPercent(db.sellerShare(s.id))}%") {
                it.addView(actionButton("ویرایش") { sellerDialog(s) })
                it.addView(actionButton("حذف فروشنده") { confirmDelete("فروشنده «${s.name}» حذف شود؟ اگر سابقه مالی داشته باشد، برای حفظ سوابق مالی غیرفعال می‌شود.") { db.deleteSeller(s.id); showSellers(); syncWithFirebaseIfOnline(false) } })
            })
        }
        root.addView(actionButton("بازگشت") { showHome() }); setScreen(root)
    }

    private fun sellerDialog(s: Seller?) {
        val box=formBox(); val name=field("نام فروشنده",s?.name?:""); val phone=field("شماره تماس",s?.phone?:""); val username=field("نام کاربری",s?.username?:"")
        val currentPassword = s?.let { db.sellerPassword(it.id) } ?: ""
        val password=field(if(s==null) "رمز عبور" else "رمز عبور فعلی",currentPassword)
        password.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val showPassword = CheckBox(this).apply { text="نمایش رمز عبور"; isChecked=false }
        showPassword.setOnCheckedChangeListener { _, checked ->
            password.inputType = if(checked) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            password.setSelection(password.text.length)
        }
        val share=numberField("درصد توافقی فروشنده",s?.let{db.sellerShare(it.id).toString()}?:db.getDefaultSellerShare().toString())
        box.addView(name); box.addView(phone); box.addView(username); box.addView(password); box.addView(showPassword); box.addView(share)
        AlertDialog.Builder(this).setTitle(if(s==null) "فروشنده جدید" else "ویرایش فروشنده").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val pct=share.text.toString().toDoubleOrNull(); if(name.text.isNotBlank() && username.text.isNotBlank() && (password.text.isNotBlank() || s!=null) && pct!=null && pct in 0.0..100.0) { db.upsertSeller(s?.id,name.text.toString(),phone.text.toString(),username.text.toString().trim(),if(password.text.isBlank() && s!=null) db.sellerPassword(s.id) else password.text.toString(),pct); showSellers(); syncWithFirebaseIfOnline(false) } else info("درصد باید بین صفر تا صد باشد.")
            }.setNegativeButton("انصراف",null).show()
    }

    private fun showMiscSale() {
        if (db.isSellerMode()) { info("ثبت فروش متفرقه فقط در نسخه گلخانه انجام می‌شود."); return }
        val root=base("ثبت فروش متفرقه گلخانه","فروش مستقیم گل به اشخاص مختلف؛ این فروش به حساب فروشندگان وارد نمی‌شود.")
        val flowers=db.flowers(); if(flowers.isEmpty()){info("ابتدا حداقل یک نوع گل تعریف کنید.");return}
        val buyer=field("نام خریدار","")
        val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64)
        val qty=numberField("تعداد دسته","1")
        val price=moneyField("قیمت فروش هر دسته (ریال)","")
        val payment=spinner("نوع دریافتی",listOf("نقدی","کارتخوان","کارت به کارت","واریز بانکی","چک","سایر"),64)
        val cashPeople=db.pettyCashPeople(); val cashSpinner=spinner("دریافت توسط تنخواه",cashPeople.map{it.name},64)
        val cashLabel=label("دریافت توسط تنخواه")
        if(!db.isSellerMode()){
            root.addView(actionButton("👛 تعریف صندوق تنخواه"){showPettyCashPeople()})
        }
        val date=Calendar.getInstance().apply{timeInMillis=db.appDate()}; val dateLabel=label("تاریخ فروش: ${jalali(date)}")
        root.addView(label("نام خریدار"));root.addView(buyer);root.addView(label("نوع گل / اندازه"));root.addView(flower);root.addView(qty);root.addView(price);root.addView(label("نوع دریافتی"));root.addView(payment)
        if(cashPeople.isNotEmpty()){root.addView(cashLabel);root.addView(cashSpinner)} else root.addView(cardText("برای فروش نقدی ابتدا در تنظیمات، صندوق تنخواه را تعریف کنید."))
        root.addView(dateLabel);root.addView(actionButton("📅 انتخاب تاریخ فروش"){DatePickerDialog(this,{_,y,m,d->date.set(y,m,d,12,0,0);date.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ فروش: ${jalali(date)}"},date.get(Calendar.YEAR),date.get(Calendar.MONTH),date.get(Calendar.DAY_OF_MONTH)).show()})
        root.addView(actionButton("ثبت فروش متفرقه"){val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val p=parseMoney(price);if(buyer.text.toString().trim().isBlank()){info("نام خریدار را وارد کنید.");return@actionButton};if(q<=0||p<=0){info("تعداد و قیمت فروش را صحیح وارد کنید.");return@actionButton};if(payment.selectedItemPosition==0&&cashPeople.isEmpty()){info("برای دریافتی نقدی ابتدا صندوق تنخواه را تعریف کنید.");return@actionButton};val petty=if(payment.selectedItemPosition==0) cashPeople[cashSpinner.selectedItemPosition].id else null;db.addMiscSale(buyer.text.toString().trim(),flowers[flower.selectedItemPosition].id,q,p,payment.selectedItem.toString(),petty,date.timeInMillis);buyer.setText("");qty.setText("1");price.setText("");info("فروش متفرقه ثبت شد.");syncWithFirebaseIfOnline(false)})
        root.addView(actionButton("بازگشت"){showRegistrations()});setScreen(root)
    }

    private fun showMiscSalesHistory(){
        val root=base("فروش‌های متفرقه","فروش‌های مستقیم گلخانه به خریداران")
        val rows=db.miscSales();if(rows.isEmpty())root.addView(label("فروش متفرقه‌ای ثبت نشده است."))
        var total=0L;rows.forEachIndexed{idx,r->total+=r.total;root.addView(cardText("${idx+1}. ${r.buyerName}\n${r.flowerName} | ${r.size} | ${r.qty} دسته\nمبلغ: ${money(r.total)} ریال\nدریافتی: ${r.paymentType}${r.pettyCashName?.let{" | تنخواه: $it"}?:("")}\nتاریخ: ${r.date}"))}
        if(rows.isNotEmpty())root.addView(cardText("جمع فروش متفرقه: ${money(total)} ریال"));root.addView(actionButton("بازگشت"){showLists()});setScreen(root)
    }

    private fun showGreenhousePayment(){
        if(db.isSellerMode()){info("ثبت پرداختی گلخانه فقط در نسخه گلخانه انجام می‌شود.");return}
        val box=formBox();val recipient=field("پرداخت به / گیرنده","");val amount=moneyField("مبلغ پرداختی (ریال),","" );val method=spinner("نوع پرداخت",listOf("نقدی","کارتخوان","کارت به کارت","واریز بانکی","چک","سایر"),64);val people=db.pettyCashPeople();val petty=spinner("پرداخت نقدی از تنخواه",people.map{it.name},64);val desc=field("شرح پرداخت","");val date=Calendar.getInstance().apply{timeInMillis=db.appDate()};val dl=label("تاریخ پرداختی: ${jalali(date)}")
        box.addView(recipient);box.addView(amount);box.addView(label("نوع پرداخت"));box.addView(method);if(people.isNotEmpty()){box.addView(label("پرداخت نقدی از تنخواه"));box.addView(petty)}else box.addView(cardText("برای پرداخت نقدی ابتدا صندوق تنخواه را تعریف کنید."));box.addView(desc);box.addView(dl);box.addView(actionButton("📅 انتخاب تاریخ"){DatePickerDialog(this,{_,y,m,d->date.set(y,m,d,12,0,0);date.set(Calendar.MILLISECOND,0);dl.text="تاریخ پرداختی: ${jalali(date)}"},date.get(Calendar.YEAR),date.get(Calendar.MONTH),date.get(Calendar.DAY_OF_MONTH)).show()})
        AlertDialog.Builder(this).setTitle("ثبت پرداختی گلخانه").setView(box).setPositiveButton("ثبت"){_,_->val a=parseMoney(amount);if(recipient.text.toString().trim().isBlank()||a<=0){info("گیرنده و مبلغ را کامل وارد کنید.");return@setPositiveButton};if(method.selectedItemPosition==0&&people.isEmpty()){info("برای پرداخت نقدی ابتدا صندوق تنخواه را تعریف کنید.");return@setPositiveButton};val pid=if(method.selectedItemPosition==0)people[petty.selectedItemPosition].id else null;db.addGreenhousePayment(recipient.text.toString().trim(),a,method.selectedItem.toString(),pid,desc.text.toString().trim(),date.timeInMillis);info("پرداختی گلخانه ثبت شد.");syncWithFirebaseIfOnline(false)}.setNegativeButton("انصراف",null).show()
    }

    private fun showGreenhousePaymentsHistory(){
        val root=base("پرداختی‌های گلخانه","پرداخت‌های انجام‌شده توسط گلخانه، جدا از پرداخت فروشندگان")
        val rows=db.greenhousePayments();if(rows.isEmpty())root.addView(label("پرداختی ثبت نشده است."));var total=0L;rows.forEachIndexed{idx,r->total+=r.amount;root.addView(cardText("${idx+1}. ${r.recipient}\nمبلغ: ${money(r.amount)} ریال\nنوع پرداخت: ${r.paymentType}${r.pettyCashName?.let{" | تنخواه: $it"}?:("")}\n${r.description.ifBlank{"بدون شرح"}}\n${r.date}"))};if(rows.isNotEmpty())root.addView(cardText("جمع پرداختی‌های گلخانه: ${money(total)} ریال"));root.addView(actionButton("بازگشت"){showLists()});setScreen(root)
    }

    private fun showDelivery() {
        val root=base("تحویل امانی به فروشنده","تحویل گل تا زمان فروش، امانت نزد فروشنده است و بدهی ایجاد نمی‌کند.")
        val flowers=db.flowers(); val sellers=db.sellers()
        if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا حداقل یک گل و یک فروشنده تعریف کنید.");return}
        val seller=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64)
        val flower=spinner("نوع گل",flowers.map{"${it.name} | ${it.size}"},64)
        val qty=numberField("تعداد دسته",""); val price=moneyField("قیمت مرجع هر دسته (ریال)","")
        val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}
        val dateLabel=label("تاریخ تحویل امانی: ${jalali(selectedDate)}")
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل / اندازه"));root.addView(flower);root.addView(qty);root.addView(price);root.addView(dateLabel)
        root.addView(actionButton("📅 انتخاب تاریخ"){val initial=selectedDate.clone() as Calendar;DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ تحویل امانی: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()})
        val historyBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val totalBox=TextView(this).apply{textSize=16f;setTextColor(Color.WHITE);setPadding(dp(12),dp(12),dp(12),dp(12))}
        fun refreshHistory(){
            historyBox.removeAllViews()
            val sid=if(seller.selectedItemPosition==0)null else sellers[seller.selectedItemPosition-1].id
            val rows=db.greenhouseSalesFiltered(sid,selectedDate.timeInMillis)
            historyBox.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","قیمت","مبلغ")))
            if(rows.isEmpty()) historyBox.addView(label("رکوردی برای این تاریخ وجود ندارد."))
            else rows.forEach{r->historyBox.addView(tableRow(listOf(r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))}
            val totals=db.greenhouseDayTotals(sid,selectedDate.timeInMillis)
            totalBox.text="جمع تعداد: ${totals.qty} دسته\nجمع فروش گلخانه: ${money(totals.total)} ریال\nجمع طلب گلخانه: ${money(maxOf(totals.balance,0L))} ریال\nجمع بدهی/طلب فروشندگان از گلخانه: ${money(maxOf(-totals.balance,0L))} ریال\nمیانگین قیمت فروش: ${money(totals.avg)} ریال"
        }
        seller.setOnItemSelectedListener(simpleListener{refreshHistory()})
        root.addView(actionButton("ثبت تحویل امانی"){
            val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val p=parseMoney(price);val f=flowers[flower.selectedItemPosition]
            if(q<=0||p<=0){info("تعداد و قیمت را صحیح وارد کنید.");return@actionButton}
            val targets=if(seller.selectedItemPosition==0)sellers else listOf(sellers[seller.selectedItemPosition-1])
            if(targets.size>1){info("برای ثبت یک فروش باید یک فروشنده مشخص انتخاب کنید.");return@actionButton}
            val ss=targets[0]
            db.addDelivery(ss.id,f.id,q,p,selectedDate.timeInMillis)
            qty.setText("");price.setText("");refreshHistory()
            info("تحویل امانی ثبت شد؛ تا زمان فروش، برای فروشنده بدهی ایجاد نمی‌شود.")
            syncWithFirebaseIfOnline(false)
        })
        root.addView(label("📋 تحویل‌های امانی در تاریخ انتخاب‌شده"));root.addView(historyBox);root.addView(totalBox);refreshHistory()
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSale() {
        if (db.isSellerMode() && isNetworkAvailable() && firebaseSignedIn()) {
            val loading=base("ثبت فروش جدید")
            loading.addView(cardText("در حال بروزرسانی فهرست گل‌ها و اندازه‌ها…"))
            setScreen(loading)
            syncWithFirebaseIfOnline(false) { runOnUiThread { renderSalePage() } }
            return
        }
        renderSalePage()
    }

    private fun renderSalePage() {
        val root=base("ثبت فروش جدید")
        val flowers=db.flowers(); val sellerId=db.currentSellerId(); val seller=db.sellerById(sellerId ?: -1L) ?: run { info("اطلاعات حساب فروشنده پیدا نشد. لطفاً یک‌بار از حساب خارج و دوباره وارد شوید."); return }
        if(flowers.isEmpty()){info("ابتدا نوع گل را تعریف کنید.");return}
        val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64); val qty=numberField("تعداد دسته فروخته‌شده",""); val price=moneyField("قیمت فروش هر دسته به مشتری (ریال)","")
        val stockText=label(""); val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}; val dateLabel=label("تاریخ فروش: ${jalali(selectedDate)}")
        val salesBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}; val totalBox=label("")
        fun refresh(){val f=flowers[flower.selectedItemPosition];stockText.text="موجودی امانی ${f.name} | ${f.size}: ${db.sellerFlowerStock(seller.id,f.id)} دسته";if(price.text.toString().isBlank()) price.setText(money(f.basePrice))}
        fun refreshSalesTable(){
            salesBox.removeAllViews()
            val rows=db.sellerSalesDetailed(seller.id).take(5)
            var total=0L; var commissionTotal=0L; var qtyTotal=0
            rows.forEach{r->total+=r.total; commissionTotal+=(r.total*db.sellerShare(seller.id)/100.0).toLong(); qtyTotal+=r.qty}
            if(rows.isEmpty()) {
                salesBox.addView(cardText("هیچ فروش جدیدی ثبت نشده است.\nپس از ثبت فروش، خلاصه آن در همین بخش نمایش داده می‌شود."))
            } else {
                salesBox.addView(cardText("📊 ${rows.size} فروش اخیر\nمجموع فروش: ${money(total)} ریال\nمجموع سهم فروشنده: ${money(commissionTotal)} ریال"))
                rows.forEach{r->
                    val part=(r.total*db.sellerShare(seller.id)/100.0).toLong()
                    salesBox.addView(cardRow("${r.flowerName} | ${r.size}\n${r.qty} دسته × ${money(r.unitPrice)} ریال\nفروش: ${money(r.total)} ریال | سهم فروشنده: ${money(part)} ریال\n${r.date}") {})
                }
            }
            val avg=if(qtyTotal==0)0 else total/qtyTotal
            totalBox.text="جمع ۵ فروش اخیر: $qtyTotal دسته\nمیانگین قیمت: ${money(avg)} ریال\n${sellerBalanceText(seller.id)}"
        }
        flower.setOnItemSelectedListener(simpleListener{refresh()});refresh();refreshSalesTable()
        root.addView(label("گل / اندازه"));root.addView(flower);root.addView(stockText);root.addView(qty);root.addView(price);root.addView(dateLabel)
        root.addView(actionButton("📅 انتخاب تاریخ فروش"){val initial=selectedDate.clone() as Calendar;DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ فروش: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()})
        root.addView(actionButton("ثبت فروش") {val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val p=parseMoney(price);val f=flowers[flower.selectedItemPosition];val stock=db.sellerFlowerStock(seller.id,f.id);if(q<=0||p<=0){info("تعداد و قیمت را صحیح وارد کنید.");return@actionButton};if(q>stock){info("موجودی کافی نیست. موجودی فعلی: $stock دسته");return@actionButton};val save={saveSale(seller.id,f.id,q,p,selectedDate.timeInMillis,qty,price,stockText){refreshSalesTable()}};if(p<f.minPrice)AlertDialog.Builder(this).setTitle("هشدار قیمت").setMessage("قیمت واردشده پایین‌تر از حداقل مجاز است. ثبت شود؟").setNegativeButton("لغو",null).setPositiveButton("ثبت"){_,_->save()}.show()else save()})
        root.addView(label("📋 خلاصه فروش‌های اخیر"));root.addView(salesBox);root.addView(totalBox)
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun saveSale(sellerId:Long,flowerId:Long,qty:Int,price:Long,saleDate:Long,qtyField:EditText,priceField:EditText,stockText:TextView,onSaved:(()->Unit)?=null){db.addSale(sellerId,flowerId,qty,price,saleDate);qtyField.setText("");priceField.setText("");stockText.text="موجودی قابل فروش: ${db.sellerFlowerStock(sellerId,flowerId)} دسته";onSaved?.invoke();info("فروش فروشنده ثبت شد.\nتاریخ فروش: ${jalaliDate(saleDate)}\nمبلغ: ${money(qty.toLong()*price)} ریال");syncWithFirebaseIfOnline(false)}

    private fun showSellerReturnsAndSales() {
        if (db.isSellerMode() && isNetworkAvailable() && firebaseSignedIn()) {
            val loading=base("برگشت کالا / مشاهده فروش‌ها")
            loading.addView(cardText("در حال بروزرسانی اطلاعات…"))
            setScreen(loading)
            syncWithFirebaseIfOnline(false) { runOnUiThread { renderSellerReturnsAndSales() } }
            return
        }
        renderSellerReturnsAndSales()
    }

    private fun renderSellerReturnsAndSales() {
        val root=base("برگشت کالا / مشاهده فروش‌ها","فروش‌های اخیر و برگشت‌های ثبت‌شده شما")
        val sid=db.currentSellerId()?:return
        root.addView(label("🧾 فروش‌های اخیر"))
        val sales=db.sellerSalesDetailed(sid).take(10)
        if(sales.isEmpty()) root.addView(label("هنوز فروشی ثبت نشده است."))
        else sales.forEach{r->root.addView(cardRow("${r.flowerName} | ${r.size} | ${r.qty} دسته\nقیمت هر دسته: ${money(r.unitPrice)} ریال\nمبلغ کل: ${money(r.total)} ریال\n${r.date}") {})}

        root.addView(sectionTitle("↩️ ثبت برگشت کالا"))
        val flowers=db.flowers()
        if(flowers.isEmpty()) root.addView(label("نوع گلی برای برگشت وجود ندارد."))
        else {
            val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64)
            val qty=numberField("تعداد دسته برگشتی","")
            val reason=field("علت برگشت","فروش نرفته / خراب / کیفیت / سایر")
            val stockLabel=label("")
            fun refreshStock(){val f=flowers[flower.selectedItemPosition];stockLabel.text="موجودی فعلی: ${db.sellerFlowerStock(sid,f.id)} دسته"}
            flower.setOnItemSelectedListener(simpleListener{refreshStock()})
            root.addView(label("نوع گل / اندازه"));root.addView(flower);root.addView(stockLabel);root.addView(qty);root.addView(reason)
            root.addView(actionButton("ثبت برگشت کالا"){
                val f=flowers[flower.selectedItemPosition]
                val q=qty.text.toString().replace(",","").toIntOrNull()?:0
                val stock=db.sellerFlowerStock(sid,f.id)
                if(q<=0){info("تعداد برگشتی را وارد کنید.");return@actionButton}
                if(q>stock){info("تعداد برگشتی بیشتر از موجودی است. موجودی فعلی: $stock دسته");return@actionButton}
                db.addReturn(sid,f.id,q,reason.text.toString().trim().ifBlank{"سایر"})
                qty.setText("");reason.setText("");refreshStock();info("برگشت کالا ثبت شد.");syncWithFirebaseIfOnline(false)
            })
            refreshStock()
        }

        root.addView(label("📋 آخرین برگشت‌ها"))
        val returns=db.returnsForSeller(sid).take(10)
        if(returns.isEmpty()) root.addView(label("برگشتی ثبت نشده است."))
        else returns.forEach{r->root.addView(cardRow("${r.flowerName} | ${r.size} | ${r.qty} دسته\nعلت: ${r.reason}") {})}
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSalesHistory() {
        val root=base("فروش‌های ثبت‌شده من")
        val sid=db.currentSellerId()?:return
        val sales=db.sales(sid)
        if(sales.isEmpty()) root.addView(label("هنوز فروشی ثبت نشده است."))
        sales.forEach{root.addView(cardRow("${it.flowerName} | ${it.size}  |  ${it.qty} دسته\nقیمت هر دسته: ${money(it.price)} ریال\nمبلغ کل فروش: ${money(it.qty*it.price)} ریال\nتاریخ فروش: ${it.date}\nوضعیت ارسال: ${if(it.synced) "آماده ارسال/همگام‌شده" else "در انتظار اتصال به گلخانه"}") {})}
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showReturn(){
        if(db.isSellerMode()){info("ثبت برگشت در نسخه گلخانه انجام می‌شود.");return}
        val root=base("ثبت برگشت گل","برگشت از موجودی فروشنده کم می‌شود و دلیل آن ثبت می‌گردد.");val flowers=db.flowers();val sellers=db.sellers();if(flowers.isEmpty()||sellers.isEmpty()){info("ابتدا اطلاعات پایه را وارد کنید.");return}
        val seller=spinner("فروشنده",sellers.map{it.name},64);val flower=spinner("نوع گل / اندازه",flowers.map{"${it.name} | ${it.size}"},64);val qty=numberField("تعداد دسته برگشتی","");val reason=field("علت برگشت","فروش نرفته / خراب / کیفیت / سایر")
        root.addView(label("فروشنده"));root.addView(seller);root.addView(label("نوع گل"));root.addView(flower);root.addView(qty);root.addView(reason)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        fun refresh(){box.removeAllViews();box.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","دلیل")));db.allReturns().take(20).forEach{box.addView(tableRow(listOf(it.sellerName,"${it.flowerName} | ${it.size}",it.qty.toString(),it.reason)))};if(box.childCount==1)box.addView(label("برگشتی ثبت نشده است."))}
        root.addView(actionButton("ثبت برگشت"){val q=qty.text.toString().replace(",","").toIntOrNull()?:0;val ss=sellers[seller.selectedItemPosition];val f=flowers[flower.selectedItemPosition];if(q<=0||q>db.sellerFlowerStock(ss.id,f.id)){info("تعداد برگشتی بیشتر از موجودی است.");return@actionButton};db.addReturn(ss.id,f.id,q,reason.text.toString());qty.setText("");reason.setText("");refresh();info("برگشت ثبت شد.");syncWithFirebaseIfOnline(false)})
        root.addView(label("📋 برگشت‌های ثبت‌شده"));root.addView(box);refresh();root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSettlement(){
        if(db.isSellerMode()) {
            val seller=db.sellerById(db.currentSellerId() ?: -1L)
            if(seller==null){
                info("اطلاعات حساب فروشنده پیدا نشد. لطفاً یک‌بار از حساب خارج و دوباره وارد شوید.")
                return
            }
            showSellerGreenhousePaymentPage(seller)
            return
        }
        val root=base("تسویه حساب فروشندگان")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        else {
            val sp=spinner("فروشنده",sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp)
            val detail=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(detail)
            fun refresh(){detail.removeAllViews();addSellerAccountSection(detail,sellers[sp.selectedItemPosition],false)}
            sp.setOnItemSelectedListener(simpleListener{refresh()});refresh()
        }
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSellerGreenhousePaymentPage(s:Seller){
        val root=base("پرداخت به گلخانه","ثبت سریع، شفاف و قابل پیگیری")
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        root.addView(content)

        fun refreshPage(){
            content.removeAllViews()
            val balance=db.greenhouseBalance(s.id)
            val salesTotal=db.sellerSalesTotal(s.id)
            val share=db.sellerCommission(s.id)
            val paid=db.paidToGreenhouse(s.id)

            content.addView(cardText("👤 ${s.name}\nحساب اختصاصی فروشنده"))
            content.addView(financialCard(listOf(
                "فروش کل" to money(salesTotal),
                "سهم فروشنده" to money(share),
                "پرداخت‌های قبلی" to money(paid)
            ),"مبالغ به ریال"))

            val status=when{
                balance>0L -> "بدهکار به گلخانه • ${money(balance)} ریال"
                balance<0L -> "طلبکار از گلخانه • ${money(-balance)} ریال"
                else -> "تسویه کامل • مانده صفر"
            }
            content.addView(statusCard("وضعیت حساب: $status"))
            content.addView(sectionTitle("ثبت پرداخت جدید"))

            val amount=moneyField("مبلغ پرداختی (ریال)",if(balance>0L) money(balance) else "")
            val method=spinner("روش پرداخت",listOf("نقدی","کارتخوان","کارت به کارت","واریز بانکی","چک","سایر"),64)
            val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}
            val dateLabel=label("تاریخ پرداخت: ${jalali(selectedDate)}")
            val remaining=label("")

            fun updateRemaining(){
                val a=parseMoney(amount)
                val after=balance-a
                remaining.text=when{
                    a<=0L -> "مانده فعلی: ${if(balance>0) money(balance)+" ریال بدهی" else if(balance<0) money(-balance)+" ریال طلب" else "تسویه"}"
                    after>0L -> "بعد از پرداخت: ${money(after)} ریال بدهی"
                    after<0L -> "بعد از پرداخت: ${money(-after)} ریال طلب از گلخانه"
                    else -> "بعد از پرداخت: تسویه کامل"
                }
            }
            updateRemaining()

            content.addView(label("مبلغ"));content.addView(amount)
            content.addView(label("روش پرداخت"));content.addView(method)
            content.addView(dateLabel)
            content.addView(actionButton("📅 انتخاب تاریخ"){DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ پرداخت: ${jalali(selectedDate)}"},selectedDate.get(Calendar.YEAR),selectedDate.get(Calendar.MONTH),selectedDate.get(Calendar.DAY_OF_MONTH)).show()})
            content.addView(remaining)
            amount.addTextChangedListener(object:TextWatcher{
                override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
                override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){}
                override fun afterTextChanged(e:Editable?){updateRemaining()}
            })

            content.addView(actionButton("✓ ثبت پرداخت"){ 
                val a=parseMoney(amount)
                if(a<=0L){info("مبلغ پرداختی را وارد کنید.");return@actionButton}
                val type=method.selectedItem?.toString().orEmpty().ifBlank{"سایر"}
                db.addPayment(s.id,a,selectedDate.timeInMillis,type)
                syncWithFirebaseIfOnline(false)
                info("پرداخت ${money(a)} ریال با موفقیت ثبت شد."){refreshPage()}
            })

            content.addView(sectionTitle("آخرین پرداخت‌ها"))
            val history=db.payments(s.id).take(10)
            if(history.isEmpty()) content.addView(cardText("هنوز پرداختی ثبت نشده است."))
            else history.forEachIndexed{index,p->
                content.addView(cardText("پرداخت ${index+1}\n${money(p.amount)} ریال • ${p.paymentType}\nتاریخ: ${p.date}"))
            }
        }

        refreshPage()
        root.addView(actionButton("بازگشت به خانه"){showHome()})
        setScreen(root)
    }

    private fun addSellerAccountSection(root:LinearLayout,s:Seller,showPaymentTable:Boolean){
        // Settlement is calculated from the accounting tables directly. No UI field
        // depends on a previous screen having been opened.
        val stock=db.sellerStock(s.id)
        val salesTotal=db.sellerSalesTotal(s.id)
        val sharePercent=db.sellerShare(s.id)
        val sellerShareAmount=db.sellerCommission(s.id)
        val greenhouseDue=db.sellerNetDue(s.id)
        val paid=db.paidToGreenhouse(s.id)
        val balance=db.greenhouseBalance(s.id)

        val status = when {
            balance > 0L -> "باقی‌مانده بدهی فروشنده به گلخانه: ${money(balance)} ریال"
            balance < 0L -> "طلب فروشنده از گلخانه: ${money(-balance)} ریال"
            else -> "حساب این فروشنده کاملاً تسویه است."
        }
        if(showPaymentTable){
            root.addView(cardText("فروشنده: ${s.name}\nمجموع فروش: ${money(salesTotal)} ریال\nسهم فروشنده: ${money(sellerShareAmount)} ریال\nپرداخت به گلخانه: ${money(paid)} ریال\n$status"))
            root.addView(actionButton("💳 ثبت پرداخت به گلخانه"){paymentDialog(s)})
        } else {
            root.addView(cardText("👤 فروشنده: ${s.name}\nموجودی امانی: ${stock} دسته"))
            root.addView(cardText("💵 مجموع فروش: ${money(salesTotal)} ریال\nسهم فروشنده (${fmtPercent(sharePercent)}٪): ${money(sellerShareAmount)} ریال\nخالص سهم گلخانه: ${money(greenhouseDue)} ریال"))
            root.addView(cardText("💳 مجموع پرداخت به گلخانه: ${money(paid)} ریال"))
            root.addView(cardText("📊 وضعیت نهایی حساب\n$status"))
        }
        root.addView(label("📋 آخرین فروش‌ها"))
        val sales=db.sellerSalesDetailed(s.id).take(8)
        if(sales.isEmpty()) root.addView(label("هنوز فروشی برای این فروشنده ثبت نشده است."))
        else sales.forEach{r->
            val sellerPart=(r.total*sharePercent/100.0).toLong()
            root.addView(cardText("${r.flowerName} | ${r.size}\n${r.qty} دسته × ${money(r.unitPrice)} ریال = ${money(r.total)} ریال\nسهم فروشنده: ${money(sellerPart)} ریال\n${r.date}"))
        }

        root.addView(label("📋 آخرین پرداخت‌ها"))
        val ps=db.payments(s.id).take(8)
        if(ps.isEmpty()) root.addView(label("پرداختی برای این فروشنده ثبت نشده است."))
        else ps.forEach{p->root.addView(cardText("${money(p.amount)} ریال\nروش پرداخت: ${p.paymentType}\n${p.date}"))}
    }

    private fun showPaymentHistory(s:Seller){
        val root=base("تاریخچه پرداخت ${s.name}")
        val payments=db.payments(s.id)
        if(payments.isEmpty()) root.addView(label("پرداختی ثبت نشده است."))
        payments.forEachIndexed{index,p->root.addView(cardText("پرداخت ${payments.size-index}\nمبلغ: ${money(p.amount)} ریال\nتاریخ پرداخت: ${p.date}"))}
        root.addView(actionButton("بازگشت"){showSettlement()});setScreen(root)
    }

    private fun paymentDialog(s:Seller){
        val balance=db.greenhouseBalance(s.id)
        val box=formBox()
        val amount=moneyField("مبلغ پرداختی (ریال)",if(balance>0)money(balance) else "")
        val method=spinner("روش پرداخت",listOf("نقدی","کارتخوان","کارت به کارت","واریز بانکی","چک","سایر"),64)
        val selectedDate=Calendar.getInstance().apply{timeInMillis=db.appDate()}
        val dateLabel=label("تاریخ پرداخت: ${jalali(selectedDate)}")
        val balanceLabel=label(if(balance>0) "بدهی فعلی به گلخانه: ${money(balance)} ریال" else if(balance<0) "طلب فعلی فروشنده از گلخانه: ${money(-balance)} ریال" else "حساب فعلاً تسویه است")
        box.addView(balanceLabel);box.addView(amount);box.addView(label("روش پرداخت"));box.addView(method);box.addView(dateLabel)
        box.addView(actionButton("📅 انتخاب تاریخ پرداخت"){
            val initial=Calendar.getInstance().apply{timeInMillis=selectedDate.timeInMillis}
            DatePickerDialog(this,{_,y,m,d->selectedDate.set(y,m,d,12,0,0);selectedDate.set(Calendar.MILLISECOND,0);dateLabel.text="تاریخ پرداخت: ${jalali(selectedDate)}"},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH)).show()
        })
        AlertDialog.Builder(this).setTitle("پرداخت به گلخانه — ${s.name}").setView(box).setPositiveButton("ثبت پرداخت"){_,_->
            val a=parseMoney(amount)
            if(a<=0) info("مبلغ پرداختی باید بیشتر از صفر باشد.") else {
                db.addPayment(s.id,a,selectedDate.timeInMillis,method.selectedItem.toString())
                val newBalance=db.greenhouseBalance(s.id)
                val result=if(newBalance>0) "باقی‌مانده بدهی: ${money(newBalance)} ریال" else if(newBalance<0) "طلب فروشنده از گلخانه: ${money(-newBalance)} ریال" else "حساب تسویه شد"
                info("پرداخت ${money(a)} ریال ثبت شد.\nروش پرداخت: ${method.selectedItem}\n$result"){showSettlement()}
                syncWithFirebaseIfOnline(false)
            }
        }.setNegativeButton("انصراف",null).show()
    }

    private fun showReports(){
        if(db.isSellerMode()){showSellerInventoryReport();return}
        val root=base("گزارش‌های گلخانه","گزارش‌ها از بخش ثبت‌ها جدا شده و همه در این قسمت قرار دارند.")
        root.addView(actionButton("👤 گزارش فروشندگان") { showGreenhouseSellerSalesReport() })
        root.addView(actionButton("🌹 گزارش فروش گلخانه") { showGreenhouseDeliveryReport() })
        root.addView(actionButton("💰 گزارش مالی و بدهی فروشندگان") { showFinancialReport() })
        root.addView(actionButton("📦 گزارش موجودی نزد فروشندگان") { showGreenhouseInventoryReport() })
        root.addView(actionButton("📋 گزارش برگشت گل") { showReturnReport() })
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showSellerInventoryReport(){
        val root=base("موجودی امانی من","فقط گل‌های موجود نزد من، قیمت و مشخصات آن‌ها")
        val sid=db.currentSellerId()?:return
        root.addView(tableHeader(listOf("نام گل","اندازه","موجودی","قیمت پایه","حداقل قیمت")))
        var count=0;var totalQty=0;var totalValue=0L;db.flowers().forEach{f->val stock=db.sellerFlowerStock(sid,f.id);if(stock>0){count++;totalQty+=stock;totalValue+=stock.toLong()*f.basePrice;root.addView(tableRow(listOf(f.name,f.size,stock.toString(),money(f.basePrice),money(f.minPrice))))}}
        if(count==0)root.addView(label("در حال حاضر گل موجودی ندارید."))
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showGreenhouseDeliveryReport(){
        val root=base("گزارش تحویل‌های امانی","این گزارش بدهی فروشنده را نشان نمی‌دهد؛ فقط تحویل‌های امانی را ثبت می‌کند.")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("فروشنده"));root.addView(sp)
        val date=Calendar.getInstance().apply{timeInMillis=db.appDate()};val dl=label("تاریخ: ${jalali(date)}");root.addView(dl)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val sid=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1].id;val rows=db.greenhouseSalesFiltered(sid,date.timeInMillis);box.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","قیمت مرجع","ارزش مرجع")));if(rows.isEmpty())box.addView(label("رکوردی برای این تاریخ وجود ندارد."))else {var qty=0;var total=0L;rows.forEach{r->qty+=r.qty;total+=r.total;box.addView(tableRow(listOf(r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))};val avg=if(qty==0)0 else total/qty;box.addView(tableRow(listOf("جمع کل","",qty.toString(),money(avg),money(total)),true))}}
        sp.setOnItemSelectedListener(simpleListener{refresh()})
        root.addView(actionButton("📅 انتخاب تاریخ"){val i=date.clone() as Calendar;DatePickerDialog(this,{_,y,m,d->date.set(y,m,d,12,0,0);date.set(Calendar.MILLISECOND,0);dl.text="تاریخ: ${jalali(date)}";refresh()},i.get(Calendar.YEAR),i.get(Calendar.MONTH),i.get(Calendar.DAY_OF_MONTH)).show()})
        refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showFinancialReport(){
        val root=base("گزارش مالی فروشندگان")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("فروشنده"));root.addView(sp)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){
            box.removeAllViews()
            val selected=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1]
            val list=if(selected==null)sellers else listOf(selected)
            list.forEach{s->
                box.addView(label("👤 ${s.name}"))
                box.addView(label("📋 پرداخت‌ها"))
                box.addView(tableHeader(listOf("تاریخ","مبلغ")))
                val ps=db.payments(s.id);var paid=0L
                if(ps.isEmpty()) box.addView(label("پرداختی ثبت نشده است.")) else ps.forEach{p->paid+=p.amount;box.addView(tableRow(listOf(p.date,money(p.amount))))}
                box.addView(tableRow(listOf("جمع کل",money(paid)),true))
                box.addView(label("📦 خریدهای گلخانه"))
                box.addView(tableHeader(listOf("تاریخ","گل/اندازه","تعداد","قیمت","مبلغ")))
                val buys=db.greenhouseSales(s.id);var qty=0;var total=0L
                if(buys.isEmpty()) box.addView(label("تحویل امانی ثبت نشده است.")) else buys.forEach{r->qty+=r.qty;total+=r.total;box.addView(tableRow(listOf(r.date,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))}
                val avg=if(qty==0)0 else total/qty
                box.addView(tableRow(listOf("جمع کل","",qty.toString(),money(avg),money(total)),true))
                val saleRows=db.sellerSalesDetailed(s.id);var saleTotal=0L;var shareTotal=0L;saleRows.forEach{r->saleTotal+=r.total;shareTotal+=(r.total*db.sellerShare(s.id)/100.0).toLong()}
                box.addView(label("سهم سود فروشنده: ${fmtPercent(db.sellerShare(s.id))}% | جمع مبلغ فروش: ${money(saleTotal)} ریال | جمع سهم سود فروشنده: ${money(shareTotal)} ریال | مانده حساب پس از سهم فروشنده: ${money(db.greenhouseBalance(s.id))} ریال"))
            }
        }
        sp.setOnItemSelectedListener(simpleListener{refresh()});refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showGreenhouseInventoryReport(){
        val root=base("موجودی امانی فروشندگان","گل‌های تحویلی تا زمان فروش، امانی هستند و بدهی ایجاد نمی‌کنند.")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val selected=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1];val list=if(selected==null)sellers else listOf(selected);box.addView(tableHeader(listOf("فروشنده","گل/اندازه","موجودی")));var totalQty=0;var count=0;list.forEach{s->db.flowers().forEach{f->val st=db.sellerFlowerStock(s.id,f.id);if(st>0){count++;totalQty+=st;box.addView(tableRow(listOf(s.name,"${f.name} | ${f.size}",st.toString())))}}};if(count==0)box.addView(label("موجودی نزد فروشندگان ثبت نشده است."));box.addView(tableRow(listOf("جمع کل","",totalQty.toString()),true))}
        sp.setOnItemSelectedListener(simpleListener{refresh()});refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showReturnReport(){
        val root=base("گزارش برگشت گل","با انتخاب هر فروشنده یا همه فروشندگان، برگشت‌های ثبت‌شده نمایش داده می‌شود.")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val sid=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1].id;val rows=if(sid==null)db.allReturns() else db.returnsForSeller(sid);box.addView(tableHeader(listOf("فروشنده","گل/اندازه","تعداد","دلیل")));var qty=0;if(rows.isEmpty())box.addView(label("برگشتی ثبت نشده است."))else rows.forEach{r->qty+=r.qty;box.addView(tableRow(listOf(r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),r.reason)))};box.addView(tableRow(listOf("جمع کل","",qty.toString(),""),true))}
        sp.setOnItemSelectedListener(simpleListener{refresh()});refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showGreenhouseSellerSalesReport(){
        val root=base("گزارش فروشندگان")
        val sellers=db.sellers();if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val sp=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("انتخاب فروشنده"));root.addView(sp)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){
            box.removeAllViews()
            val selected=if(sp.selectedItemPosition==0)null else sellers[sp.selectedItemPosition-1]
            val list=if(selected==null)sellers else listOf(selected)
            list.forEach{s->
                box.addView(label("👤 ${s.name}"))
                box.addView(label("📦 خرید گل از گلخانه"))
                box.addView(tableHeader(listOf("تاریخ","گل/اندازه","تعداد","قیمت","مبلغ")))
                val purchases=db.greenhouseSales(s.id);var pq=0;var pt=0L
                if(purchases.isEmpty())box.addView(label("خریدی ثبت نشده است."))else purchases.forEach{r->pq+=r.qty;pt+=r.total;box.addView(tableRow(listOf(r.date,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total))))}
                val pavg=if(pq==0)0 else pt/pq;box.addView(tableRow(listOf("جمع کل","",pq.toString(),money(pavg),money(pt)),true))
                box.addView(label("🧾 تک‌تک فروش‌ها"))
                box.addView(tableHeader(listOf("تاریخ","گل/اندازه","تعداد","قیمت","مبلغ","سهم فروشنده")))
                val sales=db.sellerSalesDetailed(s.id);var sq=0;var st=0L;var sc=0L
                if(sales.isEmpty())box.addView(label("فروشی ثبت نشده است."))else sales.forEach{r->val share=(r.total*db.sellerShare(s.id)/100.0).toLong();sq+=r.qty;st+=r.total;sc+=share;box.addView(tableRow(listOf(r.date,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.unitPrice),money(r.total),money(share))))}
                val savg=if(sq==0)0 else st/sq;box.addView(tableRow(listOf("جمع کل","",sq.toString(),money(savg),money(st),money(sc)),true));box.addView(label("جمع سهم سود فروشنده: ${money(sc)} ریال"))
            }
        }
        sp.setOnItemSelectedListener(simpleListener{refresh()});refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showDetailedReport(){
        val root=base("گزارش تفصیلی فروش","فیلتر بر اساس فروشنده و بازه تاریخ")
        val sellers=db.sellers(); if(sellers.isEmpty()){info("فروشنده‌ای ثبت نشده است.");return}
        val seller=spinner("فروشنده",listOf("همه فروشندگان")+sellers.map{it.name},64);root.addView(label("فروشنده"));root.addView(seller)
        val from=Calendar.getInstance().apply{timeInMillis=db.appDate();set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}
        val to=Calendar.getInstance().apply{timeInMillis=db.appDate();set(Calendar.HOUR_OF_DAY,23);set(Calendar.MINUTE,59);set(Calendar.SECOND,59);set(Calendar.MILLISECOND,999)}
        val fromLabel=label("از تاریخ: ${jalali(from)}");val toLabel=label("تا تاریخ: ${jalali(to)}");root.addView(fromLabel);root.addView(actionButton("📅 انتخاب تاریخ شروع"){DatePickerDialog(this,{_,y,m,d->from.set(y,m,d,0,0,0);from.set(Calendar.MILLISECOND,0);fromLabel.text="از تاریخ: ${jalali(from)}"},from.get(Calendar.YEAR),from.get(Calendar.MONTH),from.get(Calendar.DAY_OF_MONTH)).show()});root.addView(toLabel);root.addView(actionButton("📅 انتخاب تاریخ پایان"){DatePickerDialog(this,{_,y,m,d->to.set(y,m,d,23,59,59);to.set(Calendar.MILLISECOND,999);toLabel.text="تا تاریخ: ${jalali(to)}"},to.get(Calendar.YEAR),to.get(Calendar.MONTH),to.get(Calendar.DAY_OF_MONTH)).show()})
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};root.addView(box)
        fun refresh(){box.removeAllViews();val sid=if(seller.selectedItemPosition==0)null else sellers[seller.selectedItemPosition-1].id;val rows=db.detailedSales(sid,from.timeInMillis,to.timeInMillis);box.addView(tableHeader(listOf("تاریخ","فروشنده","گل/اندازه","تعداد","قیمت","مبلغ","سهم فروشنده")));if(rows.isEmpty())box.addView(label("رکوردی در این بازه وجود ندارد.")) else {var total=0L;var commission=0L;rows.forEach{r->val share=r.sellerShareAmount;total+=r.total;commission+=share;box.addView(tableRow(listOf(r.date,r.sellerName,"${r.flowerName} | ${r.size}",r.qty.toString(),money(r.price),money(r.total),money(share))))};box.addView(tableRow(listOf("جمع کل","","","","",money(total),money(commission)),true));box.addView(cardText("جمع مبلغ فروش این فیلتر: ${money(total)} ریال\nجمع سهم سود فروشنده: ${money(commission)} ریال"))}}
        seller.setOnItemSelectedListener(simpleListener{refresh()});root.addView(actionButton("🔎 اعمال فیلتر"){refresh()});refresh();root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showAllPaymentsHistory(){
        val root=base("تاریخچه همه پرداخت‌ها", "پرداخت‌ها بر اساس تاریخ پرداخت مرتب شده‌اند")
        val rows=db.allPayments()
        if(rows.isEmpty()) root.addView(label("هنوز هیچ پرداختی ثبت نشده است."))
        var lastSeller=""; rows.forEachIndexed{index,p->{if(p.sellerName!=lastSeller){root.addView(label("👤 ${p.sellerName}"));lastSeller=p.sellerName};root.addView(cardText("پرداخت ${index+1}\nمبلغ: ${money(p.amount)} ریال\nروش پرداخت: ${p.paymentType}\nتاریخ پرداخت: ${p.date}"))}}
        root.addView(actionButton("بازگشت"){showReports()});setScreen(root)
    }

    private fun showPettyCashPeople(){
        val root=base("صندوق تنخواه","افرادی که دریافت/پرداخت نقدی از تنخواه به نام آنها ثبت می‌شود.")
        val people=db.pettyCashPeople();if(people.isEmpty())root.addView(label("هنوز شخصی برای تنخواه تعریف نشده است."));people.forEach{root.addView(cardText("👛 ${it.name}"))}
        root.addView(actionButton("＋ افزودن شخص به تنخواه"){val f=field("نام شخص","");AlertDialog.Builder(this).setTitle("شخص تنخواه").setView(f).setPositiveButton("ثبت"){_,_->if(f.text.toString().trim().isNotBlank()){db.addPettyCashPerson(f.text.toString());showPettyCashPeople();syncWithFirebaseIfOnline(false)}}.setNegativeButton("انصراف",null).show()})
        root.addView(actionButton("بازگشت"){showSettings()});setScreen(root)
    }

    private fun greenhouseCredentialsDialog(){ showAdminSettings() }

    private fun sellerCredentialsDialog(sid:Long){
        if(db.currentSellerId()!=sid) return
        sellerAccountSettings()
    }

    private fun firebaseSyncDialog(){
        syncWithFirebaseIfOnline(true)
    }

    private fun isNetworkAvailable(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun registerNetworkSync(){
        if (networkCallback != null) return
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread { syncWithFirebaseIfOnline(false) }
            }
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            connectivityManager.registerDefaultNetworkCallback(networkCallback!!)
        }
    }

    override fun onResume() {
        super.onResume()
        autoSyncHandler.removeCallbacks(autoSyncRunnable)
        autoSyncHandler.post(autoSyncRunnable)
        if (FirebaseApp.getApps(this).isNotEmpty() && firebaseSignedIn() && isNetworkAvailable()) {
            syncWithFirebaseIfOnline(false)
        }
    }

    override fun onPause() {
        autoSyncHandler.removeCallbacks(autoSyncRunnable)
        super.onPause()
    }

    override fun onDestroy() {
        networkCallback?.let {
            runCatching { connectivityManager.unregisterNetworkCallback(it) }
        }
        networkCallback = null
        super.onDestroy()
    }

    private fun syncWithFirebaseIfOnline(showMessage: Boolean, onDone: (Boolean) -> Unit = {}){
        if (syncInProgress) { onDone(false); return }
        if (FirebaseApp.getApps(this).isEmpty()) { if (showMessage) info("Firebase به برنامه متصل نشده است."); onDone(false); return }
        if (!firebaseSignedIn()) {
            if (showMessage && !db.isSellerMode()) {
                firebaseAdminLogin { ok ->
                    if (ok) syncWithFirebaseIfOnline(true, onDone)
                    else onDone(false)
                }
            } else {
                onDone(false)
            }
            return
        }
        if (!isNetworkAvailable()) { if (showMessage) info("اینترنت در دسترس نیست؛ اطلاعات هنگام اتصال دوباره خودکار همگام می‌شوند."); onDone(false); return }

        syncInProgress = true
        val fs = FirebaseFirestore.getInstance()
        val admin = !db.isSellerMode()
        db.ensureRemoteIds()
        val localFirebase = db.firebaseCollections()
        val collections: List<Pair<String, List<Map<String, Any?>>>> =
            if (admin) localFirebase.entries.map { it.key to it.value }
            else {
                val sid = db.currentSellerId()
                listOf(
                    "sales" to localFirebase["sales"].orEmpty().filter { (it["seller_id"] as? Number)?.toLong() == sid || it["seller_remote_id"]?.toString() == db.sellerRemoteId(sid ?: -1L) },
                    "returns" to localFirebase["returns"].orEmpty().filter { (it["seller_id"] as? Number)?.toLong() == sid || it["seller_remote_id"]?.toString() == db.sellerRemoteId(sid ?: -1L) },
                    "payments" to localFirebase["payments"].orEmpty().filter { (it["seller_id"] as? Number)?.toLong() == sid || it["seller_remote_id"]?.toString() == db.sellerRemoteId(sid ?: -1L) }
                )
            }

        fun finish(ok: Boolean, message: String? = null) {
            syncInProgress = false
            if (ok) db.setLastFirebaseSync(System.currentTimeMillis())
            onDone(ok)
            if (showMessage && message != null) info(message)
            if (ok && isHomeScreen) runOnUiThread { showHome() }
        }

        fun pullCollection(name: String, sellerId: Long?, done: (Boolean) -> Unit) {
            fun importSnapshot(snap: com.google.firebase.firestore.QuerySnapshot) {
                snap.documents.forEach { d ->
                    val m = d.data ?: return@forEach
                    db.importFirebaseRecord(name, d.id, m)
                }
            }
            if (name == "sellers" && sellerId != null) {
                // Seller documents are mirrored under the numeric local seller_id.
                // This matches the existing Firestore Rules exactly:
                // sellers/{id} is readable when id == userDoc().seller_id.
                // It also avoids a collection query that older Rules cannot authorize.
                fs.collection(name).document(sellerId.toString()).get()
                    .addOnSuccessListener { snap ->
                        if (snap.exists()) {
                            db.importFirebaseRecord(name, snap.id, snap.data ?: emptyMap())
                            done(true)
                        } else {
                            if (showMessage) info("اطلاعات فروشنده در Firebase پیدا نشد. ابتدا از نسخه گلخانه یک‌بار همگام‌سازی کنید.")
                            done(false)
                        }
                    }
                    .addOnFailureListener { e ->
                        if (showMessage) info("دریافت اطلاعات فروشنده از Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای دسترسی یا اتصال"}")
                        done(false)
                    }
            } else if (sellerId != null) {
                // Seller reads must use the seller_id query. Firestore security rules
                // can prove that this query belongs to the signed-in seller. A query
                // based only on seller_remote_id cannot be authorized by the current
                // rules because that field is not part of users/{uid}.
                fs.collection(name).whereEqualTo("seller_id", sellerId)
                    .get()
                    .addOnSuccessListener { snap ->
                        importSnapshot(snap)
                        done(true)
                    }
                    .addOnFailureListener { e ->
                        if (showMessage) info("دریافت «$name» از Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}")
                        done(false)
                    }
            } else {
                fs.collection(name).get()
                    .addOnSuccessListener { snap -> importSnapshot(snap); done(true) }
                    .addOnFailureListener { e ->
                        if (showMessage) info("دریافت «$name» از Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}")
                        done(false)
                    }
            }
        }

        fun pullAll(done: (Boolean) -> Unit) {
            val names = if (admin) listOf("flowers", "sellers", "deliveries", "sales", "returns", "payments", "misc_sales", "greenhouse_payments", "petty_cash_people", "settings") else listOf("flowers", "deliveries", "sales", "returns", "payments", "settings")
            val sid = db.currentSellerId()
            var allOk = true
            fun next(i: Int) {
                if (i >= names.size) { done(allOk); return }
                val name = names[i]
                val filter = if (!admin && name != "flowers" && name != "sellers" && name != "settings") sid else null
                pullCollection(name, filter) { ok -> allOk = allOk && ok; next(i + 1) }
            }
            next(0)
        }

        fun writeCollection(index: Int, afterWrite: () -> Unit) {
            if (index >= collections.size) { afterWrite(); return }
            val entry = collections[index]
            val batch = fs.batch()
            entry.second.forEach { row ->
                val docId = row["remote_id"]?.toString()?.takeIf { it.isNotBlank() }
                    ?: return@forEach
                val data = HashMap<String, Any>()
                row.forEach { (k, v) ->
                    if (v != null && k != "id") data[k] = v
                }
                data["updated_at"] = System.currentTimeMillis()
                if (!admin && (entry.first == "sales" || entry.first == "returns" || entry.first == "payments")) {
                    data["auth_uid"] = firebaseAuth.currentUser!!.uid
                }
                batch.set(fs.collection(entry.first).document(docId), data, com.google.firebase.firestore.SetOptions.merge())
                // Keep a seller document mirrored under seller_id so seller devices
                // can read it using the existing Firestore Rules without a broad query.
                if (admin && entry.first == "sellers") {
                    val sid = row["seller_id"]?.toString()?.toLongOrNull()
                    if (sid != null && sid > 0L) {
                        batch.set(
                            fs.collection("sellers").document(sid.toString()),
                            data,
                            com.google.firebase.firestore.SetOptions.merge()
                        )
                    }
                }
            }
            batch.commit()
                .addOnSuccessListener { writeCollection(index + 1, afterWrite) }
                .addOnFailureListener { e ->
                    finish(false, "همگام‌سازی «${entry.first}» انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}")
                }
        }

        // Local pending changes are written first. Then the same Firebase snapshot is
        // pulled back so the local database also receives records created on another device.
        writeCollection(0) {
            if (admin) {
                provisionSellerFirebaseAccounts { ok, error ->
                    pullAll { pullOk ->
                        if (!pullOk) finish(false, "اطلاعات به Firebase ارسال شد، اما دریافت کامل اطلاعات مشترک انجام نشد.")
                        else if (!ok) finish(true, error ?: "اطلاعات اصلی همگام شد، اما ساخت حساب Firebase یکی از فروشندگان کامل نشد.")
                        else finish(true, "همگام‌سازی گلخانه با Firebase با موفقیت انجام شد.")
                    }
                }
            } else {
                pullAll { ok -> finish(ok, if (ok) "همگام‌سازی فروشنده با Firebase با موفقیت انجام شد." else "بخشی از اطلاعات فروشنده از Firebase دریافت نشد.") }
            }
        }
    }

    private fun firstGreenhouseSetup(){
        val box=formBox()
        val u=field("نام کاربری مدیر","admin")
        val p=field("رمز عبور مدیر","")
        val p2=field("تکرار رمز عبور","")
        val email=field("ایمیل حساب Firebase",db.adminFirebaseEmail())
        val fp=field("رمز عبور Firebase","")
        p.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        p2.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        fp.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(u);box.addView(p);box.addView(p2);box.addView(email);box.addView(fp)
        AlertDialog.Builder(this)
            .setTitle("راه‌اندازی اولیه گل نگار")
            .setMessage("نام کاربری و رمز مدیر و همچنین اطلاعات حساب Firebase فقط یک‌بار وارد می‌شوند. پس از اتصال موفق، دفعات بعد برنامه بدون نمایش صفحه ورود باز می‌شود.")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("اتصال و شروع") { _, _ ->
                val a=u.text.toString().trim(); val b=p.text.toString(); val b2=p2.text.toString()
                val em=email.text.toString().trim(); val fpass=fp.text.toString()
                if(a.isBlank()||b.length<6||b!=b2||!android.util.Patterns.EMAIL_ADDRESS.matcher(em).matches()||fpass.length<6){
                    info("نام کاربری را وارد کنید، رمز مدیر را حداقل ۶ کاراکتر انتخاب کنید و ایمیل و رمز Firebase را کامل وارد کنید."){firstGreenhouseSetup()}
                    return@setPositiveButton
                }
                db.setAdminCredentials(a,b)
                db.setAdminFirebaseEmail(em)
                firebaseAuth.signInWithEmailAndPassword(em,fpass)
                    .addOnSuccessListener { result ->
                        secureCredentials.put("admin_firebase_password",fpass)
                        db.setAdminSetupDone(); db.setMode("GREENHOUSE")
                        ensureFirebaseUserDoc(result.user,"ADMIN",null){ ok ->
                            runOnUiThread { if(ok){ syncWithFirebaseIfOnline(false); showHome() } else info("اتصال Firebase برقرار شد، اما ثبت حساب مدیر کامل نشد.") }
                        }
                    }
                    .addOnFailureListener { err ->
                        val code=(err as? FirebaseAuthException)?.errorCode.orEmpty()
                        if(code=="ERROR_USER_NOT_FOUND" || code=="ERROR_EMAIL_NOT_FOUND"){
                            AlertDialog.Builder(this)
                                .setTitle("حساب Firebase پیدا نشد")
                                .setMessage("برای این ایمیل حساب Firebase وجود ندارد. آیا حساب جدید ساخته شود؟")
                                .setNegativeButton("لغو",null)
                                .setPositiveButton("ساخت حساب"){_,_->
                                    firebaseAuth.createUserWithEmailAndPassword(em,fpass)
                                        .addOnSuccessListener { result ->
                                            secureCredentials.put("admin_firebase_password",fpass); db.setAdminSetupDone(); db.setMode("GREENHOUSE")
                                            ensureFirebaseUserDoc(result.user,"ADMIN",null){ ok -> runOnUiThread { if(ok){syncWithFirebaseIfOnline(false);showHome()} else info("حساب ساخته شد، اما ثبت پروفایل مدیر کامل نشد.") } }
                                        }
                                        .addOnFailureListener { e -> info("ساخت حساب Firebase انجام نشد: ${e.localizedMessage ?: e.message ?: "خطای نامشخص"}") }
                                }.show()
                        } else {
                            info("اتصال Firebase انجام نشد: ${err.localizedMessage ?: err.message ?: "ایمیل یا رمز Firebase صحیح نیست."}"){firstGreenhouseSetup()}
                        }
                    }
            }.show()
    }

    private fun greenhouseLogin(){
        if(db.isAdminSetupDone()){
            showHome(); restoreFirebaseSessionIfNeeded(); return
        }
        firstGreenhouseSetup()
    }

    private fun passwordField(label:String, value:String, revealLabel:String = "نمایش رمز"): LinearLayout {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
        val e=field(label,value)
        e.inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val show=CheckBox(this).apply{text="👁 $revealLabel";isChecked=false}
        show.setOnCheckedChangeListener { _, checked ->
            e.inputType=if(checked) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            e.setSelection(e.text.length)
        }
        box.addView(e);box.addView(show)
        box.tag=e
        return box
    }

    private fun showAdminSettings(){
        val root=base("تنظیمات مدیر")
        root.addView(sectionTitle("حساب مدیر"))
        root.addView(actionButton("✏️ تغییر نام کاربری"){adminUsernameDialog()})
        root.addView(actionButton("🔐 تغییر رمز عبور"){adminPasswordDialog()})
        root.addView(actionButton("👁 نمایش اطلاعات حساب"){
            val box=formBox();box.addView(label("نام کاربری: ${db.adminUsername()}"));box.addView(label("رمز عبور: ${db.adminLocalPassword().ifBlank{"ثبت نشده"}}"));setScreen(base("اطلاعات حساب").apply{addView(box);addView(actionButton("بازگشت"){showAdminSettings()})})
        })
        root.addView(sectionTitle("اتصال به دیتابیس"))
        root.addView(label(if(firebaseSignedIn()) "🟢 اتصال Firebase برقرار است" else "🔴 اتصال Firebase برقرار نیست"))
        root.addView(label("حساب Firebase: ${db.adminFirebaseEmail()}"))
        root.addView(actionButton("🔌 آزمایش اتصال"){testDatabaseConnection()})
        root.addView(actionButton("🔄 همگام‌سازی اکنون"){syncWithFirebaseIfOnline(true)})
        root.addView(actionButton("⚙️ تنظیم مجدد اتصال دیتابیس"){resetDatabaseConnectionDialog()})
        root.addView(sectionTitle("سایر تنظیمات مدیر"))
        root.addView(actionButton("👛 تعریف صندوق تنخواه"){showPettyCashPeople()})
        root.addView(actionButton("📅 تنظیم تاریخ"){showSettings()})
        root.addView(actionButton("بازگشت"){showSettings()})
        setScreen(root)
    }

    private fun adminUsernameDialog(){
        val f=field("نام کاربری جدید",db.adminUsername())
        AlertDialog.Builder(this).setTitle("تغییر نام کاربری مدیر").setView(f).setPositiveButton("ذخیره"){_,_->val v=f.text.toString().trim();if(v.isBlank())info("نام کاربری نمی‌تواند خالی باشد.")else{db.setSettingText("admin_username",v);info("نام کاربری مدیر تغییر کرد.")}}.setNegativeButton("انصراف",null).show()
    }

    private fun adminPasswordDialog(){
        val box=formBox();val old=passwordField("رمز فعلی","");val np=passwordField("رمز جدید","");val cp=passwordField("تکرار رمز جدید","");box.addView(old);box.addView(np);box.addView(cp)
        AlertDialog.Builder(this).setTitle("تغییر رمز عبور مدیر").setView(box).setPositiveButton("ذخیره"){_,_->
            val o=(old.tag as EditText).text.toString();val n=(np.tag as EditText).text.toString();val c=(cp.tag as EditText).text.toString()
            if(o!=db.adminLocalPassword())info("رمز فعلی صحیح نیست.") else if(n.length<6||n!=c)info("رمز جدید باید حداقل ۶ کاراکتر و با تکرار آن یکسان باشد.") else{db.setSettingText("admin_password",n);info("رمز مدیر تغییر کرد. اتصال Firebase بدون تغییر باقی می‌ماند.")}
        }.setNegativeButton("انصراف",null).show()
    }

    private fun testDatabaseConnection(){
        if(!isNetworkAvailable()){info("اینترنت در دسترس نیست. برنامه آفلاین کار می‌کند و بعداً دوباره تلاش می‌کند.");return}
        if(!firebaseSignedIn()){restoreFirebaseSessionIfNeeded();info("در حال برقراری اتصال با حساب ذخیره‌شده هستیم. چند لحظه بعد وضعیت را بررسی کنید.");return}
        FirebaseFirestore.getInstance().collection("settings").document("app").get().addOnSuccessListener{info("🟢 اتصال به دیتابیس برقرار است و دسترسی خواندن تأیید شد.")}.addOnFailureListener{e->info("🔴 اتصال برقرار نشد: ${e.localizedMessage ?: e.message ?: "خطای دسترسی"}")}
    }

    private fun resetDatabaseConnectionDialog(){
        val box=formBox();val em=field("ایمیل Firebase",db.adminFirebaseEmail());val p=passwordField("رمز Firebase","");box.addView(em);box.addView(p)
        AlertDialog.Builder(this).setTitle("تنظیم مجدد اتصال دیتابیس").setMessage("این گزینه فقط برای زمانی است که حساب یا رمز Firebase تغییر کرده یا اتصال ذخیره‌شده قابل بازیابی نیست.").setView(box).setPositiveButton("اتصال مجدد"){_,_->
            val email=em.text.toString().trim();val pass=(p.tag as EditText).text.toString()
            if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()||pass.length<6){info("ایمیل و رمز Firebase را صحیح وارد کنید.");return@setPositiveButton}
            firebaseAuth.signInWithEmailAndPassword(email,pass).addOnSuccessListener{r->db.setAdminFirebaseEmail(email);secureCredentials.put("admin_firebase_password",pass);info("🟢 اتصال دیتابیس با موفقیت تنظیم شد.");syncWithFirebaseIfOnline(false)}.addOnFailureListener{e->info("اتصال مجدد انجام نشد: ${e.localizedMessage ?: e.message ?: "ایمیل یا رمز صحیح نیست."}")}
        }.setNegativeButton("انصراف",null).show()
    }

    private fun sellerAccountSettings(){
        val sid=db.currentSellerId()?:return;val s=db.sellers().firstOrNull{it.id==sid}?:return
        val box=formBox();val u=field("نام کاربری",s.username);val p=passwordField("رمز عبور",db.sellerPassword(sid));box.addView(u);box.addView(p)
        AlertDialog.Builder(this).setTitle("حساب فروشنده").setView(box).setPositiveButton("ذخیره"){_,_->
            val newU=u.text.toString().trim();val newP=(p.tag as EditText).text.toString();if(newU.isBlank()||newP.length<6){info("نام کاربری و رمز عبور را کامل وارد کنید.");return@setPositiveButton}
            val oldU=s.username;val oldP=db.sellerPassword(sid);val current=firebaseAuth.currentUser
            fun saveLocal(){db.updateSellerCredentials(sid,newU,newP);secureCredentials.put("seller_firebase_$sid",newP);info("اطلاعات حساب فروشنده تغییر کرد.")}
            if(current!=null&&current.email?.equals(firebaseEmail(oldU,"SELLER"),true)==true){
                val emailChanged=newU!=oldU;val passwordChanged=newP!=oldP
                fun afterEmail(){if(passwordChanged)current.updatePassword(newP).addOnSuccessListener{saveLocal()}.addOnFailureListener{info("رمز Firebase تغییر نکرد: ${it.localizedMessage ?: it.message ?: "نیاز به احراز مجدد دارد."}")}else saveLocal()}
                if(emailChanged)current.updateEmail(firebaseEmail(newU,"SELLER")).addOnSuccessListener{afterEmail()}.addOnFailureListener{info("نام کاربری Firebase تغییر نکرد: ${it.localizedMessage ?: it.message ?: "نیاز به احراز مجدد دارد."}")} else afterEmail()
            } else saveLocal()
        }.setNegativeButton("انصراف",null).show()
    }

    private fun showSettings(){
        val root=base("تنظیمات")
        if(!db.isSellerMode()){
            root.addView(actionButton("👤 مدیریت مدیر"){showAdminSettings()})
        } else {
            root.addView(actionButton("👤 حساب کاربری فروشنده"){sellerAccountSettings()})
        }
        root.addView(sectionTitle("اتصال و همگام‌سازی"))
        root.addView(label(if(firebaseSignedIn()) "🟢 اتصال فعال" else "🟡 اتصال در انتظار / آفلاین"))
        root.addView(actionButton("🔌 آزمایش اتصال"){testDatabaseConnection()})
        root.addView(actionButton("🔄 همگام‌سازی اکنون"){syncWithFirebaseIfOnline(true)})
        if(!db.isSellerMode()) root.addView(actionButton("⚙️ تنظیمات کامل مدیر"){showAdminSettings()})
        val date=Calendar.getInstance().apply{timeInMillis=db.appDate()};val dateLabel=label("تاریخ کاری برنامه: ${jalali(date)}");root.addView(dateLabel)
        root.addView(actionButton("📅 تنظیم تاریخ"){showAdminSettings()})
        root.addView(label("نسخه برنامه: ${BuildConfig.VERSION_NAME}"))
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun showPriceWarnings(){
        val root=base("هشدارهای قیمت","فروش‌هایی که با قیمتی پایین‌تر از حداقل قیمت همان گل و اندازه ثبت شده‌اند.")
        val sid=if(db.isSellerMode()) db.currentSellerId() else null
        val rows=db.priceWarnings(sid)
        if(rows.isEmpty()) root.addView(label("هشداری وجود ندارد. فروشی زیر قیمت حداقل ثبت نشده است.")) else {
            var lastSeller=""
            rows.sortedWith(compareBy<GolYarDb.PriceWarning>{it.sellerName}.thenByDescending{it.createdAt}).forEach{r->
                if(!db.isSellerMode() && r.sellerName!=lastSeller){lastSeller=r.sellerName;root.addView(label("👤 فروشنده: ${r.sellerName}"))}
                val diff=r.minPrice-r.price
                root.addView(cardText("⚠️ ${r.type}\n${if(db.isSellerMode()) "فروشنده: ${r.sellerName}\n" else ""}${r.flowerName} | اندازه: ${r.size}\nقیمت ثبت‌شده: ${money(r.price)} ریال\nحداقل مجاز: ${money(r.minPrice)} ریال\nمیزان کمتر از حداقل: ${money(diff)} ریال\nتعداد: ${r.qty} دسته\nتاریخ: ${r.date}"))
            }
        }
        root.addView(actionButton("بازگشت"){showHome()});setScreen(root)
    }

    private fun sellerBalanceText(id:Long):String { val b=db.greenhouseBalance(id); return "بدهی به گلخانه: ${money(maxOf(b,0L))} ریال\nطلب از گلخانه: ${money(maxOf(-b,0L))} ریال\nوضعیت: ${if(b==0L) "تسویه" else if(b>0) "بدهکار گلخانه" else "طلبکار از گلخانه"}" }

    private fun tableHeader(cells:List<String>):LinearLayout=tableRow(cells,true)
    private fun tableRow(cells:List<String>,header:Boolean=false):LinearLayout{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(4),dp(2),dp(4),dp(2));background=GradientDrawable().apply{cornerRadius=dp(8).toFloat();setColor(if(header) Color.rgb(53,107,70) else Color.WHITE);setStroke(dp(1),Color.rgb(218,228,220))};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).also{it.setMargins(0,dp(1),0,dp(1))}}
        cells.forEach{value->row.addView(TextView(this).apply{text=value;textSize=if(header)14f else 13.5f;setTextColor(if(header) Color.WHITE else Color.rgb(35,58,43));gravity=Gravity.CENTER;setTypeface(Typeface.DEFAULT,if(header)Typeface.BOLD else Typeface.NORMAL);setPadding(dp(4),0,dp(4),0);layoutParams=LinearLayout.LayoutParams(0,-1,1f)})};return row}
    private fun cardBackground()=
GradientDrawable().apply{cornerRadius=dp(18).toFloat();setColor(Color.WHITE);setStroke(dp(1),Color.rgb(218,228,220))}
    private fun cardText(text:String):TextView=TextView(this).apply{textSize=16f;setTextColor(Color.rgb(35,58,43));setPadding(dp(18),dp(16),dp(18),dp(16));gravity=Gravity.CENTER_VERTICAL;includeFontPadding=true;background=cardBackground();val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(9));layoutParams=lp}
    private fun cardRow(text:String, build:(LinearLayout)->Unit):LinearLayout{val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(12),dp(10),dp(12),dp(10));background=cardBackground();val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(9));layoutParams=lp};box.addView(TextView(this).apply{this.text=text;textSize=16f;setTextColor(Color.rgb(35,58,43));gravity=Gravity.CENTER_VERTICAL;includeFontPadding=true;setPadding(dp(8),dp(8),dp(8),dp(12))});build(box);return box}
    private fun sectionTitle(t:String)=TextView(this).apply {
        text=t
        textSize=17f
        typeface=Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(35,58,43))
        gravity=Gravity.RIGHT
        setPadding(dp(6),dp(14),dp(6),dp(6))
        includeFontPadding=true
    }

    private fun label(t:String)=TextView(this).apply{text=t;textSize=15f;setTextColor(Color.rgb(92,104,96));setPadding(dp(6),dp(10),dp(6),dp(5));includeFontPadding=true}
    private fun formBox()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(12),dp(4));layoutDirection=View.LAYOUT_DIRECTION_RTL}
    private fun field(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;setTextColor(Color.rgb(35,58,43));setHintTextColor(Color.rgb(100,112,104));inputType=InputType.TYPE_CLASS_TEXT;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8))}
    private fun numberField(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(value);textSize=17f;setTextColor(Color.rgb(35,58,43));setHintTextColor(Color.rgb(100,112,104));inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8))}
    private fun moneyField(hint:String,value:String)=EditText(this).apply{this.hint=hint;setText(if(value.isBlank()) "" else value.replace(",",""));textSize=17f;setTextColor(Color.rgb(35,58,43));setHintTextColor(Color.rgb(100,112,104));inputType=InputType.TYPE_CLASS_NUMBER;minHeight=dp(58);setPadding(dp(12),dp(8),dp(12),dp(8));addTextChangedListener(object:TextWatcher{private var busy=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(e:Editable?){if(busy)return;val raw=e?.toString()?.replace(",","")?.filter{it.isDigit()}?:"";if(raw.isEmpty())return;val n=raw.toLongOrNull()?:return;val formatted=nf.format(n);if(e.toString()!=formatted){busy=true;setText(formatted);setSelection(formatted.length);busy=false}}})}
    private fun parseMoney(e:EditText):Long=e.text.toString().replace(",","").filter{it.isDigit()}.toLongOrNull()?:0L
    private fun jalaliDateTime(ms:Long):String{
        val c=Calendar.getInstance().apply{timeInMillis=ms}
        return "${jalaliDate(ms)} ${"%02d:%02d".format(Locale.US,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE))}"
    }

    private fun jalaliDate(ms:Long):String{val c=Calendar.getInstance();c.timeInMillis=ms;return jalali(c)}
    private fun spinner(label:String,items:List<String>,height:Int)=Spinner(this).apply{
        adapter=object:ArrayAdapter<String>(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items){
            private fun style(v:View):View{
                val t=v as TextView
                t.textSize=17f
                t.setTextColor(Color.rgb(35,58,43))
                t.setBackgroundColor(Color.WHITE)
                t.gravity=Gravity.CENTER_VERTICAL or Gravity.RIGHT
                t.setPadding(dp(12),dp(8),dp(12),dp(8))
                return t
            }
            override fun getView(position:Int,convertView:View?,parent:ViewGroup):View=style(super.getView(position,convertView,parent))
            override fun getDropDownView(position:Int,convertView:View?,parent:ViewGroup):View=style(super.getDropDownView(position,convertView,parent))
        }
        contentDescription=label;layoutDirection=View.LAYOUT_DIRECTION_RTL;minimumHeight=dp(height)
    }
    private fun divider()=Space(this).apply{minimumHeight=dp(8)}
    private fun simpleListener(fn:()->Unit)=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){fn()}}
    private fun money(v:Long)=nf.format(v)
    private fun fmtPercent(v:Double)=String.format(Locale.US,"%.1f",v).trimEnd('0').trimEnd('.')
    private fun confirmDelete(msg:String,action:()->Unit){AlertDialog.Builder(this).setMessage(msg).setNegativeButton("انصراف",null).setPositiveButton("حذف"){_,_->action()}.show()}
    private fun info(msg:String,after:(()->Unit)?=null){AlertDialog.Builder(this).setMessage(msg).setPositiveButton("باشه"){_,_->after?.invoke()}.show()}

    data class Flower(val id:Long,val name:String,val size:String,val basePrice:Long,val minPrice:Long)
    data class Seller(val id:Long,val name:String,val phone:String,val username:String)
    data class SaleRow(val flowerName:String,val size:String,val qty:Int,val price:Long,val date:String,val synced:Boolean)
    data class PaymentRow(val amount:Long,val paymentType:String,val date:String)
    data class PaymentHistoryRow(val sellerName:String,val amount:Long,val paymentType:String,val date:String)
    data class PettyCashPerson(val id:Long,val name:String)
    data class MiscSaleRow(val buyerName:String,val flowerName:String,val size:String,val qty:Int,val total:Long,val paymentType:String,val pettyCashName:String?,val date:String)
    data class GreenhousePaymentRow(val recipient:String,val amount:Long,val paymentType:String,val pettyCashName:String?,val description:String,val date:String)
    data class GreenhouseSaleRow(val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
    data class SellerSaleReportRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
    data class ReturnReportRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val reason:String)
    data class Dash(val deliveredToday:Int,val soldToday:Int,val returnedToday:Int,val salesToday:Long,val stock:Int,val greenhouseDue:Long)

    private fun todayJalali():String = jalali(Calendar.getInstance().apply{timeInMillis=db.appDate()})
    private fun jalali(c:Calendar):String {
        val gy=c.get(Calendar.YEAR); val gm=c.get(Calendar.MONTH)+1; val gd=c.get(Calendar.DAY_OF_MONTH)
        val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31)
        var days=355666 + 365*gy + ((gy+3)/4) - ((gy+99)/100) + ((gy+399)/400) + gd
        for(i in 1 until gm) days += gdm[i]
        if(gm>2 && isLeapGregorian(gy)) days++
        var jy=-1595 + 33*(days/12053); days%=12053
        jy += 4*(days/1461); days%=1461
        if(days>365){jy += (days-1)/365; days=(days-1)%365}
        val jm=if(days<186) 1 + days/31 else 7 + (days-186)/30
        val jd=1 + if(days<186) days%31 else (days-186)%30
        return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
    }
    private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)

    class GolYarDb(ctx:Context):SQLiteOpenHelper(ctx,"golyar.db",null,11){
        private val appContext = ctx.applicationContext
        override fun onCreate(db:SQLiteDatabase){
            db.execSQL("CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,size TEXT NOT NULL,base_price INTEGER NOT NULL,min_price INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,username TEXT NOT NULL DEFAULT '',password TEXT NOT NULL DEFAULT '',share REAL NOT NULL DEFAULT 20,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER NOT NULL DEFAULT 0,created_at INTEGER,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,created_at INTEGER,sync_state TEXT DEFAULT 'PENDING',remote_id TEXT UNIQUE,seller_share_percent REAL NOT NULL DEFAULT 20,seller_share_amount INTEGER NOT NULL DEFAULT 0,greenhouse_amount INTEGER NOT NULL DEFAULT 0,min_price_snapshot INTEGER NOT NULL DEFAULT 0,below_minimum INTEGER NOT NULL DEFAULT 0)")
            db.execSQL("CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,reason TEXT,created_at INTEGER,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,created_at INTEGER,payment_date INTEGER,payment_type TEXT NOT NULL DEFAULT 'نامشخص',remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE petty_cash_people(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE misc_sales(id INTEGER PRIMARY KEY AUTOINCREMENT,buyer_name TEXT NOT NULL,flower_id INTEGER,qty INTEGER NOT NULL,price INTEGER NOT NULL,payment_type TEXT NOT NULL,petty_cash_id INTEGER,created_at INTEGER,sale_date INTEGER,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE greenhouse_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,recipient TEXT NOT NULL,amount INTEGER NOT NULL,payment_type TEXT NOT NULL,petty_cash_id INTEGER,description TEXT,created_at INTEGER,payment_date INTEGER,remote_id TEXT UNIQUE)")
            db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT)")
            db.execSQL("INSERT INTO settings(key,value) VALUES('default_seller_share','20')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('admin_username','admin')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('admin_password','1234')")
            db.execSQL("INSERT INTO settings(key,value) VALUES('app_date',?)",arrayOf(System.currentTimeMillis().toString()))
            db.execSQL("INSERT INTO settings(key,value) VALUES('admin_setup_done','0')")
        }
        override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){
            if(oldVersion<2){db.execSQL("ALTER TABLE sellers ADD COLUMN share REAL NOT NULL DEFAULT 20");db.execSQL("ALTER TABLE sales ADD COLUMN sync_state TEXT DEFAULT 'PENDING'");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('default_seller_share','20')")}
            if(oldVersion<3){db.execSQL("ALTER TABLE payments ADD COLUMN payment_date INTEGER");db.execSQL("UPDATE payments SET payment_date=created_at WHERE payment_date IS NULL")}
            if(oldVersion<4){db.execSQL("ALTER TABLE deliveries ADD COLUMN price INTEGER NOT NULL DEFAULT 0");db.execSQL("UPDATE deliveries SET price=COALESCE((SELECT base_price FROM flowers WHERE flowers.id=deliveries.flower_id),0) WHERE price=0")}
            if(oldVersion<5){db.execSQL("ALTER TABLE flowers ADD COLUMN size TEXT NOT NULL DEFAULT 'استاندارد'");db.execSQL("ALTER TABLE sellers ADD COLUMN username TEXT NOT NULL DEFAULT ''");db.execSQL("ALTER TABLE sellers ADD COLUMN password TEXT NOT NULL DEFAULT ''");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_username','admin')");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_password','1234')");db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('app_date',?)",arrayOf(System.currentTimeMillis().toString()))}
            if(oldVersion<6){db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('admin_setup_done','0')")}
            if(oldVersion<7){
                db.execSQL("ALTER TABLE flowers ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE sellers ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE deliveries ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE sales ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE returns ADD COLUMN remote_id TEXT")
                db.execSQL("ALTER TABLE payments ADD COLUMN remote_id TEXT")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_flowers_remote ON flowers(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_sellers_remote ON sellers(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_deliveries_remote ON deliveries(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_remote ON sales(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_returns_remote ON returns(remote_id)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_remote ON payments(remote_id)")
            }
            if(oldVersion<9){
                db.execSQL("ALTER TABLE sellers ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
                db.execSQL("CREATE TABLE IF NOT EXISTS petty_cash_people(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,remote_id TEXT UNIQUE)")
                db.execSQL("CREATE TABLE IF NOT EXISTS misc_sales(id INTEGER PRIMARY KEY AUTOINCREMENT,buyer_name TEXT NOT NULL,flower_id INTEGER,qty INTEGER NOT NULL,price INTEGER NOT NULL,payment_type TEXT NOT NULL,petty_cash_id INTEGER,created_at INTEGER,sale_date INTEGER,remote_id TEXT UNIQUE)")
                db.execSQL("CREATE TABLE IF NOT EXISTS greenhouse_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,recipient TEXT NOT NULL,amount INTEGER NOT NULL,payment_type TEXT NOT NULL,petty_cash_id INTEGER,description TEXT,created_at INTEGER,payment_date INTEGER,remote_id TEXT UNIQUE)")
            }
            if(oldVersion<10){
                db.execSQL("ALTER TABLE flowers ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
            }
            if(oldVersion<11){
                db.execSQL("ALTER TABLE payments ADD COLUMN payment_type TEXT NOT NULL DEFAULT 'نامشخص'")
            }
            if(oldVersion<8){
                db.execSQL("ALTER TABLE sales ADD COLUMN seller_share_percent REAL NOT NULL DEFAULT 20")
                db.execSQL("ALTER TABLE sales ADD COLUMN seller_share_amount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE sales ADD COLUMN greenhouse_amount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE sales ADD COLUMN min_price_snapshot INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE sales ADD COLUMN below_minimum INTEGER NOT NULL DEFAULT 0")
                db.execSQL("UPDATE sales SET seller_share_percent=COALESCE((SELECT share FROM sellers WHERE sellers.id=sales.seller_id),20), min_price_snapshot=COALESCE((SELECT min_price FROM flowers WHERE flowers.id=sales.flower_id),0), seller_share_amount=CAST((qty*price)*COALESCE((SELECT share FROM sellers WHERE sellers.id=sales.seller_id),20)/100 AS INTEGER), greenhouse_amount=(qty*price)-CAST((qty*price)*COALESCE((SELECT share FROM sellers WHERE sellers.id=sales.seller_id),20)/100 AS INTEGER), below_minimum=CASE WHEN price<COALESCE((SELECT min_price FROM flowers WHERE flowers.id=sales.flower_id),0) THEN 1 ELSE 0 END")
            }
        }
        private fun cv(vararg p:Pair<String,Any?>)=ContentValues().also{p.forEach{(k,v)->when(v){is String->it.put(k,v);is Int->it.put(k,v);is Long->it.put(k,v);is Double->it.put(k,v);null->it.putNull(k)}}}
        fun setMode(v:String?){val sp=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE);sp.edit().putString("mode",v).apply()}
        fun getMode():String?=appContext.getSharedPreferences("golyar",Context.MODE_PRIVATE).getString("mode",null)
        fun isSellerMode()=getMode()?.startsWith("SELLER:")==true
        fun currentSellerId():Long?=getMode()?.substringAfter("SELLER:")?.toLongOrNull()
        fun upsertFlower(id:Long?,name:String,size:String,base:Long,min:Long){if(id==null){val newId=writableDatabase.insert("flowers",null,cv("name" to name,"size" to size,"base_price" to base,"min_price" to min));if(newId>0)writableDatabase.update("flowers",cv("remote_id" to newId.toString()),"id=?",arrayOf(newId.toString()))}else{writableDatabase.update("flowers",cv("name" to name,"size" to size,"base_price" to base,"min_price" to min),"id=?",arrayOf(id.toString()));writableDatabase.execSQL("UPDATE flowers SET remote_id=COALESCE(remote_id,?) WHERE id=?",arrayOf(id.toString(),id))}}
        fun upsertSeller(id:Long?,name:String,phone:String,username:String,password:String,share:Double){if(id==null){val newId=writableDatabase.insert("sellers",null,cv("name" to name,"phone" to phone,"username" to username,"password" to password,"share" to share));if(newId>0)writableDatabase.update("sellers",cv("remote_id" to newId.toString()),"id=?",arrayOf(newId.toString()))}else{writableDatabase.update("sellers",cv("name" to name,"phone" to phone,"username" to username,"password" to password,"share" to share),"id=?",arrayOf(id.toString()));writableDatabase.execSQL("UPDATE sellers SET remote_id=COALESCE(remote_id,?) WHERE id=?",arrayOf(id.toString(),id))}}
        fun flowers():List<Flower>{val l=mutableListOf<Flower>();q("SELECT id,name,size,base_price,min_price FROM flowers WHERE COALESCE(active,1)=1 ORDER BY name,size"){c->l.add(Flower(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getLong(4)))};return l}
        fun sellers():List<Seller>{val l=mutableListOf<Seller>();q("SELECT id,name,phone,username FROM sellers WHERE COALESCE(active,1)=1 ORDER BY name"){c->l.add(Seller(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:""))};return l}
        fun sellerById(id:Long):Seller?=readableDatabase.rawQuery("SELECT id,name,phone,username FROM sellers WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst())Seller(c.getLong(0),c.getString(1),c.getString(2)?:"",c.getString(3)?:"") else null}
        fun sellerUsername(id:Long):String=readableDatabase.rawQuery("SELECT username FROM sellers WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getString(0)?:"" else ""}

        fun repairSellerActiveState(){
            val d=writableDatabase
            val activeCount=d.rawQuery("SELECT COUNT(*) FROM sellers WHERE COALESCE(active,1)=1",null).use{if(it.moveToFirst())it.getInt(0) else 0}
            val totalCount=d.rawQuery("SELECT COUNT(*) FROM sellers",null).use{if(it.moveToFirst())it.getInt(0) else 0}
            // Do not reactivate inactive sellers. They are deletion/disable tombstones.
            // Legacy records without the column already default to active=1.

        }

        fun ensureRemoteIds(){
            val db=writableDatabase
            db.execSQL("UPDATE flowers SET remote_id=COALESCE(NULLIF(remote_id,''),CAST(id AS TEXT)) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE sellers SET remote_id=COALESCE(NULLIF(remote_id,''),CAST(id AS TEXT)) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE deliveries SET remote_id=COALESCE(NULLIF(remote_id,''),'delivery_'||seller_id||'_'||id) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE sales SET remote_id=COALESCE(NULLIF(remote_id,''),'sale_'||seller_id||'_'||id) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE returns SET remote_id=COALESCE(NULLIF(remote_id,''),'return_'||seller_id||'_'||id) WHERE remote_id IS NULL OR remote_id='' ")
            db.execSQL("UPDATE payments SET remote_id=COALESCE(NULLIF(remote_id,''),'payment_'||seller_id||'_'||id) WHERE remote_id IS NULL OR remote_id='' ")
        }

        fun sellerRemoteId(s:Long):String = readableDatabase.rawQuery("SELECT COALESCE(remote_id,'') FROM sellers WHERE id=?", arrayOf(s.toString())).use { if (it.moveToFirst()) it.getString(0) ?: "" else "" }
        fun flowerRemoteId(f:Long):String = readableDatabase.rawQuery("SELECT COALESCE(remote_id,'') FROM flowers WHERE id=?", arrayOf(f.toString())).use { if (it.moveToFirst()) it.getString(0) ?: "" else "" }

        fun firebaseCollections():Map<String,List<Map<String,Any?>>> {
            fun rows(sql:String, mapper:(android.database.Cursor)->Map<String,Any?>):List<Map<String,Any?>>{
                val out=mutableListOf<Map<String,Any?>>(); readableDatabase.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(mapper(c))}; return out
            }
            return linkedMapOf(
                "flowers" to rows("SELECT id,remote_id,name,size,base_price,min_price,active FROM flowers"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"name" to it.getString(2),"size" to it.getString(3),"base_price" to it.getLong(4),"min_price" to it.getLong(5),"active" to it.getInt(6))},
                "sellers" to rows("SELECT id,remote_id,name,phone,username,share,COALESCE(active,1) FROM sellers"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(0),"name" to it.getString(2),"phone" to (it.getString(3)?:""),"username" to it.getString(4),"firebase_email" to ((it.getString(4) ?: "").trim().lowercase(Locale.US).replace(Regex("[^a-z0-9._-]"), "_") + "@golyar.app"),"share" to it.getDouble(5),"active" to it.getInt(6))},
                "deliveries" to rows("SELECT d.id,d.remote_id,d.seller_id,d.flower_id,d.qty,d.price,d.created_at,s.remote_id,f.remote_id FROM deliveries d LEFT JOIN sellers s ON s.id=d.seller_id LEFT JOIN flowers f ON f.id=d.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(7)?:""),"flower_remote_id" to (it.getString(8)?:""),"qty" to it.getInt(4),"price" to it.getLong(5),"created_at" to it.getLong(6))},
                "sales" to rows("SELECT sa.id,sa.remote_id,sa.seller_id,sa.flower_id,sa.qty,sa.price,sa.created_at,sa.sync_state,sa.seller_share_percent,sa.seller_share_amount,sa.greenhouse_amount,sa.min_price_snapshot,sa.below_minimum,s.remote_id,f.remote_id FROM sales sa LEFT JOIN sellers s ON s.id=sa.seller_id LEFT JOIN flowers f ON f.id=sa.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(13)?:""),"flower_remote_id" to (it.getString(14)?:""),"qty" to it.getInt(4),"price" to it.getLong(5),"created_at" to it.getLong(6),"sync_state" to it.getString(7),"seller_share_percent" to it.getDouble(8),"seller_share_amount" to it.getLong(9),"greenhouse_amount" to it.getLong(10),"min_price_snapshot" to it.getLong(11),"below_minimum" to it.getInt(12))},
                "returns" to rows("SELECT r.id,r.remote_id,r.seller_id,r.flower_id,r.qty,r.reason,r.created_at,s.remote_id,f.remote_id FROM returns r LEFT JOIN sellers s ON s.id=r.seller_id LEFT JOIN flowers f ON f.id=r.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(7)?:""),"flower_remote_id" to (it.getString(8)?:""),"qty" to it.getInt(4),"reason" to it.getString(5),"created_at" to it.getLong(6))},
                "payments" to rows("SELECT p.id,p.remote_id,p.seller_id,p.amount,p.created_at,p.payment_date,COALESCE(p.payment_type,'نامشخص'),s.remote_id FROM payments p LEFT JOIN sellers s ON s.id=p.seller_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"seller_remote_id" to (it.getString(7)?:""),"amount" to it.getLong(3),"created_at" to it.getLong(4),"payment_date" to it.getLong(5),"payment_type" to (it.getString(6)?:"نامشخص"))},
                "misc_sales" to rows("SELECT m.id,m.remote_id,m.buyer_name,m.flower_id,m.qty,m.price,m.payment_type,m.petty_cash_id,m.created_at,m.sale_date,f.remote_id FROM misc_sales m LEFT JOIN flowers f ON f.id=m.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"buyer_name" to it.getString(2),"flower_id" to it.getLong(3),"flower_remote_id" to (it.getString(10)?:""),"qty" to it.getInt(4),"price" to it.getLong(5),"payment_type" to it.getString(6),"petty_cash_id" to it.getLong(7),"created_at" to it.getLong(8),"sale_date" to it.getLong(9))},
                "greenhouse_payments" to rows("SELECT id,remote_id,recipient,amount,payment_type,petty_cash_id,description,created_at,payment_date FROM greenhouse_payments"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"recipient" to it.getString(2),"amount" to it.getLong(3),"payment_type" to it.getString(4),"petty_cash_id" to it.getLong(5),"description" to it.getString(6),"created_at" to it.getLong(7),"payment_date" to it.getLong(8))},
                "petty_cash_people" to rows("SELECT id,remote_id,name,active FROM petty_cash_people"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"name" to it.getString(2),"active" to it.getInt(3))},
                "settings" to listOf(mapOf("id" to "app", "remote_id" to "app", "app_date" to appDate(), "default_seller_share" to getDefaultSellerShare(), "admin_username" to adminUsername(), "admin_firebase_email" to adminFirebaseEmail()))
            )
        }

        private fun q(sql:String,block:(android.database.Cursor)->Unit){readableDatabase.rawQuery(sql,null).use{while(it.moveToNext())block(it)}}
        fun delete(table:String,id:Long){ if(table=="flowers") writableDatabase.update("flowers",cv("active" to 0),"id=?",arrayOf(id.toString())) else writableDatabase.delete(table,"id=?",arrayOf(id.toString())) }
        fun addDelivery(s:Long,f:Long,q:Int,p:Long,createdAt:Long=appDate()){val id=writableDatabase.insert("deliveries",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to createdAt));if(id>0)writableDatabase.update("deliveries",cv("remote_id" to "delivery_${UUID.randomUUID()}"),"id=?",arrayOf(id.toString()))}
        fun addSale(s:Long,f:Long,q:Int,p:Long,saleDate:Long){
            val share=sellerShare(s); val total=q.toLong()*p; val sellerAmount=(total*share/100.0).toLong(); val greenhouseAmount=total-sellerAmount
            val min=readableDatabase.rawQuery("SELECT min_price FROM flowers WHERE id=?",arrayOf(f.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
            val below=if(min>0 && p<min)1 else 0
            val id=writableDatabase.insert("sales",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to saleDate,"sync_state" to "PENDING","seller_share_percent" to share,"seller_share_amount" to sellerAmount,"greenhouse_amount" to greenhouseAmount,"min_price_snapshot" to min,"below_minimum" to below))
            if(id>0)writableDatabase.update("sales",cv("remote_id" to "sale_${UUID.randomUUID()}"),"id=?",arrayOf(id.toString()))
        }
        fun addReturn(s:Long,f:Long,q:Int,r:String){val id=writableDatabase.insert("returns",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"reason" to r,"created_at" to appDate()));if(id>0)writableDatabase.update("returns",cv("remote_id" to "return_${UUID.randomUUID()}"),"id=?",arrayOf(id.toString()))}
        fun addPayment(s:Long,a:Long,paymentDate:Long,paymentType:String="نامشخص"){val id=writableDatabase.insert("payments",null,cv("seller_id" to s,"amount" to a,"created_at" to appDate(),"payment_date" to paymentDate,"payment_type" to paymentType));if(id>0)writableDatabase.update("payments",cv("remote_id" to "payment_${UUID.randomUUID()}"),"id=?",arrayOf(id.toString()))}
        fun sellerFlowerStock(s:Long,f:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=? AND flower_id=?),0)",arrayOf(s,f,s,f,s,f)).toInt()
        fun sellerStock(s:Long):Int=one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=?),0)",arrayOf(s,s,s)).toInt()
        fun sellerShare(s:Long):Double=readableDatabase.rawQuery("SELECT share FROM sellers WHERE id=?",arrayOf(s.toString())).use{if(it.moveToFirst())it.getDouble(0) else getDefaultSellerShare()}
        fun getDefaultSellerShare():Double=setting("default_seller_share",20.0)
        fun setDefaultSellerShare(v:Double){writableDatabase.update("settings",cv("value" to v.toString()),"key='default_seller_share'",null)}
        fun sellerSalesTotal(s:Long):Long=one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE seller_id=?",arrayOf(s))
        fun sellerCommission(s:Long):Long=one("SELECT COALESCE(SUM(seller_share_amount),0) FROM sales WHERE seller_id=?",arrayOf(s))
        fun sellerNetDue(s:Long):Long=one("SELECT COALESCE(SUM(greenhouse_amount),0) FROM sales WHERE seller_id=?",arrayOf(s))
        fun paidToGreenhouse(s:Long):Long=one("SELECT COALESCE(SUM(amount),0) FROM payments WHERE seller_id=?",arrayOf(s))
        // Deliveries are consignments: they never create a seller debt.
        fun greenhouseCharges(s:Long):Long=sellerNetDue(s)
        fun returnCredits(s:Long):Long=0L
        fun greenhouseBalance(s:Long):Long=greenhouseCharges(s)-paidToGreenhouse(s)
        fun greenhouseDue(s:Long):Long=greenhouseBalance(s)
        fun payments(s:Long):List<PaymentRow>{val l=mutableListOf<PaymentRow>();readableDatabase.rawQuery("SELECT amount,COALESCE(payment_type,'نامشخص'),COALESCE(payment_date,created_at) FROM payments WHERE seller_id=? ORDER BY COALESCE(payment_date,created_at) DESC,id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(PaymentRow(c.getLong(0),c.getString(1),jalaliDate(c.getLong(2))))};return l}
        fun allPayments():List<PaymentHistoryRow>{val l=mutableListOf<PaymentHistoryRow>();readableDatabase.rawQuery("SELECT s.name,p.amount,COALESCE(p.payment_type,'نامشخص'),COALESCE(p.payment_date,p.created_at) FROM payments p JOIN sellers s ON s.id=p.seller_id ORDER BY s.name,COALESCE(p.payment_date,p.created_at) DESC,p.id DESC",null).use{c->while(c.moveToNext())l.add(PaymentHistoryRow(c.getString(0),c.getLong(1),c.getString(2),jalaliDate(c.getLong(3))))};return l}
        fun dashboard(sellerId:Long?):Dash{val condition=sellerId?.let { " AND seller_id=$it" } ?: "";val todayStart=dayStart();val todayEnd=todayStart+86400000;val deliveredToday=one("SELECT COALESCE(SUM(qty),0) FROM deliveries WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val soldToday=one("SELECT COALESCE(SUM(qty),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val returnedToday=one("SELECT COALESCE(SUM(qty),0) FROM returns WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)).toInt();val salesToday=if(sellerId!=null)one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE created_at>=? AND created_at<?$condition",arrayOf(todayStart,todayEnd)) else one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE created_at>=? AND created_at<?",arrayOf(todayStart,todayEnd));val stock=if(sellerId!=null)sellerStock(sellerId) else one("SELECT COALESCE(SUM(qty),0) FROM deliveries").toInt()-one("SELECT COALESCE(SUM(qty),0) FROM sales").toInt()-one("SELECT COALESCE(SUM(qty),0) FROM returns").toInt();val due=if(sellerId!=null)greenhouseBalance(sellerId) else sellers().sumOf{greenhouseBalance(it.id)};return Dash(deliveredToday,soldToday,returnedToday,salesToday,stock,due)}
        fun greenhouseSales(s:Long):List<GreenhouseSaleRow>{val l=mutableListOf<GreenhouseSaleRow>();readableDatabase.rawQuery("SELECT f.name,f.size,d.qty,d.price,d.qty*d.price,d.created_at FROM deliveries d JOIN flowers f ON f.id=d.flower_id WHERE d.seller_id=? ORDER BY d.created_at DESC,d.id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(GreenhouseSaleRow(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),c.getLong(4),jalaliDate(c.getLong(5))))};return l}
        fun allReturns():List<ReturnReportRow>{val l=mutableListOf<ReturnReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,r.qty,r.reason FROM returns r JOIN sellers s ON s.id=r.seller_id JOIN flowers f ON f.id=r.flower_id ORDER BY r.created_at DESC,r.id DESC",null).use{c->while(c.moveToNext())l.add(ReturnReportRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(4)?:""))};return l}
        fun returnsForSeller(s:Long):List<ReturnReportRow>{val l=mutableListOf<ReturnReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,r.qty,r.reason FROM returns r JOIN sellers s ON s.id=r.seller_id JOIN flowers f ON f.id=r.flower_id WHERE r.seller_id=? ORDER BY r.created_at DESC,r.id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(ReturnReportRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(4)?:""))};return l}
        fun allSellerSalesReport():List<SellerSaleReportRow>{val l=mutableListOf<SellerSaleReportRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,sa.qty,sa.price,sa.qty*sa.price,sa.created_at FROM sales sa JOIN sellers s ON s.id=sa.seller_id JOIN flowers f ON f.id=sa.flower_id ORDER BY s.name,sa.created_at DESC,sa.id DESC",null).use{c->while(c.moveToNext())l.add(SellerSaleReportRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getLong(4),c.getLong(5),jalaliDate(c.getLong(6))))};return l}
        fun sales(s:Long):List<SaleRow>{val l=mutableListOf<SaleRow>();readableDatabase.rawQuery("SELECT f.name,f.size,s.qty,s.price,s.created_at,s.sync_state FROM sales s JOIN flowers f ON f.id=s.flower_id WHERE s.seller_id=? ORDER BY s.created_at DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(SaleRow(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),jalaliDate(c.getLong(4)),c.getString(5)!="PENDING"))};return l}
        data class DayTotals(val qty:Int,val total:Long,val avg:Long,val balance:Long)
        fun greenhouseSalesFiltered(sellerId:Long?,dateMs:Long):List<DetailedGreenhouseRow>{val c=Calendar.getInstance().apply{timeInMillis=dateMs;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)};val from=c.timeInMillis;val to=from+86400000;val where=if(sellerId==null)"" else " AND d.seller_id=$sellerId";val l=mutableListOf<DetailedGreenhouseRow>();readableDatabase.rawQuery("SELECT s.name,f.name,f.size,d.qty,d.price,d.qty*d.price,d.created_at FROM deliveries d JOIN sellers s ON s.id=d.seller_id JOIN flowers f ON f.id=d.flower_id WHERE d.created_at>=? AND d.created_at<?$where ORDER BY s.name,d.created_at DESC,d.id DESC",arrayOf(from.toString(),to.toString())).use{curs->while(curs.moveToNext())l.add(DetailedGreenhouseRow(curs.getString(0),curs.getString(1),curs.getString(2),curs.getInt(3),curs.getLong(4),curs.getLong(5),jalaliDate(curs.getLong(6))))};return l}
        fun greenhouseDayTotals(sellerId:Long?,dateMs:Long):DayTotals{val c=Calendar.getInstance().apply{timeInMillis=dateMs;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)};val from=c.timeInMillis;val to=from+86400000;val where=if(sellerId==null)"" else " AND d.seller_id=$sellerId";val q=one("SELECT COALESCE(SUM(qty),0) FROM deliveries d WHERE d.created_at>=? AND d.created_at<?$where",arrayOf(from,to));val total=one("SELECT COALESCE(SUM(qty*price),0) FROM deliveries d WHERE d.created_at>=? AND d.created_at<?$where",arrayOf(from,to));val avg=if(q==0L)0 else total/q;val bal=if(sellerId==null)sellers().sumOf{greenhouseBalance(it.id)} else greenhouseBalance(sellerId);return DayTotals(q.toInt(),total,avg,bal)}
        data class SellerSaleDetail(val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)
        fun sellerSalesDetailed(s:Long):List<SellerSaleDetail>{val l=mutableListOf<SellerSaleDetail>();readableDatabase.rawQuery("SELECT COALESCE(f.name,'گل حذف‌شده'),COALESCE(f.size,''),sa.qty,sa.price,sa.qty*sa.price,sa.created_at FROM sales sa LEFT JOIN flowers f ON f.id=sa.flower_id WHERE sa.seller_id=? ORDER BY sa.created_at DESC,sa.id DESC",arrayOf(s.toString())).use{c->while(c.moveToNext())l.add(SellerSaleDetail(c.getString(0),c.getString(1),c.getInt(2),c.getLong(3),c.getLong(4),jalaliDate(c.getLong(5))))};return l}
        data class DetailedGreenhouseRow(val sellerName:String,val flowerName:String,val size:String,val qty:Int,val unitPrice:Long,val total:Long,val date:String)

        fun firebaseSnapshot():Map<String,Any>{
            ensureRemoteIds()
            fun rows(sql:String, mapper:(android.database.Cursor)->Map<String,Any?>):List<Map<String,Any?>>{val out=mutableListOf<Map<String,Any?>>();readableDatabase.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(mapper(c))};return out}
            return mapOf(
                "flowers" to rows("SELECT id,remote_id,name,size,base_price,min_price,active FROM flowers"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"name" to it.getString(2),"size" to it.getString(3),"base_price" to it.getLong(4),"min_price" to it.getLong(5),"active" to it.getInt(6))},
                "sellers" to rows("SELECT id,remote_id,name,phone,username,share,COALESCE(active,1) FROM sellers"){mapOf("id" to it.getLong(0),"seller_id" to it.getLong(0),"remote_id" to it.getString(1),"name" to it.getString(2),"phone" to (it.getString(3)?:""),"username" to it.getString(4),"share" to it.getDouble(5),"active" to it.getInt(6))},
                "deliveries" to rows("SELECT d.id,d.remote_id,d.seller_id,d.flower_id,d.qty,d.price,d.created_at,s.remote_id,f.remote_id FROM deliveries d LEFT JOIN sellers s ON s.id=d.seller_id LEFT JOIN flowers f ON f.id=d.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(7)?:("")),"flower_remote_id" to (it.getString(8)?:("")),"qty" to it.getInt(4),"price" to it.getLong(5),"created_at" to it.getLong(6))},
                "sales" to rows("SELECT sa.id,sa.remote_id,sa.seller_id,sa.flower_id,sa.qty,sa.price,sa.created_at,sa.sync_state,sa.seller_share_percent,sa.seller_share_amount,sa.greenhouse_amount,sa.min_price_snapshot,sa.below_minimum,s.remote_id,f.remote_id FROM sales sa LEFT JOIN sellers s ON s.id=sa.seller_id LEFT JOIN flowers f ON f.id=sa.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(13)?:("")),"flower_remote_id" to (it.getString(14)?:("")),"qty" to it.getInt(4),"price" to it.getLong(5),"created_at" to it.getLong(6),"sync_state" to it.getString(7),"seller_share_percent" to it.getDouble(8),"seller_share_amount" to it.getLong(9),"greenhouse_amount" to it.getLong(10),"min_price_snapshot" to it.getLong(11),"below_minimum" to it.getInt(12))},
                "returns" to rows("SELECT r.id,r.remote_id,r.seller_id,r.flower_id,r.qty,r.reason,r.created_at,s.remote_id,f.remote_id FROM returns r LEFT JOIN sellers s ON s.id=r.seller_id LEFT JOIN flowers f ON f.id=r.flower_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"flower_id" to it.getLong(3),"seller_remote_id" to (it.getString(7)?:("")),"flower_remote_id" to (it.getString(8)?:("")),"qty" to it.getInt(4),"reason" to it.getString(5),"created_at" to it.getLong(6))},
                "payments" to rows("SELECT p.id,p.remote_id,p.seller_id,p.amount,p.created_at,p.payment_date,COALESCE(p.payment_type,'نامشخص'),s.remote_id FROM payments p LEFT JOIN sellers s ON s.id=p.seller_id"){mapOf("id" to it.getLong(0),"remote_id" to it.getString(1),"seller_id" to it.getLong(2),"seller_remote_id" to (it.getString(6)?:("")),"amount" to it.getLong(3),"created_at" to it.getLong(4),"payment_date" to it.getLong(5),"payment_type" to (it.getString(6)?:"نامشخص"))}
            )
        }

        fun importFirebaseRecord(collection:String,docId:String,m:Map<String,Any>) {
            fun str(k:String)=m[k]?.toString() ?: ""
            fun lng(k:String)=when(val v=m[k]){is Number->v.toLong();else->v?.toString()?.toLongOrNull()?:0L}
            fun int(k:String)=if(m.containsKey(k)) lng(k).toInt() else 1
            val remoteId=str("remote_id").ifBlank { docId }

            fun findSeller():Long {
                val stable=str("seller_remote_id")
                if (stable.isNotBlank()) {
                    val byRemote=readableDatabase.rawQuery("SELECT id FROM sellers WHERE remote_id=?",arrayOf(stable)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byRemote>0) return byRemote
                }
                val legacy=lng("seller_id")
                if(legacy>0){
                    val byId=readableDatabase.rawQuery("SELECT id FROM sellers WHERE id=?",arrayOf(legacy.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byId>0) return byId
                    val byRemote=readableDatabase.rawQuery("SELECT id FROM sellers WHERE remote_id=?",arrayOf(legacy.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byRemote>0) return byRemote
                }
                return 0L
            }
            fun findFlower():Long {
                val stable=str("flower_remote_id")
                if (stable.isNotBlank()) {
                    val byRemote=readableDatabase.rawQuery("SELECT id FROM flowers WHERE remote_id=?",arrayOf(stable)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byRemote>0) return byRemote
                }
                val legacy=lng("flower_id")
                if(legacy>0){
                    val byId=readableDatabase.rawQuery("SELECT id FROM flowers WHERE id=?",arrayOf(legacy.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byId>0) return byId
                    val byRemote=readableDatabase.rawQuery("SELECT id FROM flowers WHERE remote_id=?",arrayOf(legacy.toString())).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(byRemote>0) return byRemote
                }
                val name=str("flower_name"); val size=str("flower_size")
                if(name.isNotBlank() && size.isNotBlank()) {
                    return readableDatabase.rawQuery("SELECT id FROM flowers WHERE name=? AND size=? ORDER BY id LIMIT 1",arrayOf(name,size)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                }
                return 0L
            }

            when(collection){
                "flowers" -> {
                    val localId=lng("id")
                    val remoteActive=(if(m.containsKey("active")) int("active") else 1).coerceIn(0,1)
                    var existing=readableDatabase.rawQuery("SELECT id FROM flowers WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(existing==0L) existing=readableDatabase.rawQuery("SELECT id FROM flowers WHERE name=? AND size=? ORDER BY id LIMIT 1",arrayOf(str("name"),str("size"))).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(existing>0){
                        val localActive=readableDatabase.rawQuery("SELECT COALESCE(active,1) FROM flowers WHERE id=?",arrayOf(existing.toString())).use{if(it.moveToFirst())it.getInt(0) else 1}
                        val finalActive=if(localActive==0) 0 else remoteActive
                        val values=cv("name" to str("name"),"size" to str("size"),"base_price" to lng("base_price"),"min_price" to lng("min_price"),"active" to finalActive,"remote_id" to remoteId)
                        writableDatabase.update("flowers",values,"id=?",arrayOf(existing.toString()))
                    } else {
                        val idExists=localId>0 && readableDatabase.rawQuery("SELECT 1 FROM flowers WHERE id=?",arrayOf(localId.toString())).use{it.moveToFirst()}
                        writableDatabase.insert("flowers",null,if(localId>0 && !idExists) cv("id" to localId,"name" to str("name"),"size" to str("size"),"base_price" to lng("base_price"),"min_price" to lng("min_price"),"active" to remoteActive,"remote_id" to remoteId) else cv("name" to str("name"),"size" to str("size"),"base_price" to lng("base_price"),"min_price" to lng("min_price"),"active" to remoteActive,"remote_id" to remoteId))
                    }
                }
                "sellers" -> {
                    val share=(m["share"] as? Number)?.toDouble() ?: 20.0
                    val active=(if(m.containsKey("active")) int("active") else 1).coerceIn(0,1)
                    var existing=readableDatabase.rawQuery("SELECT id FROM sellers WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(existing==0L && str("username").isNotBlank()) existing=readableDatabase.rawQuery("SELECT id FROM sellers WHERE username=? ORDER BY id LIMIT 1",arrayOf(str("username"))).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    if(existing>0){
                        // A locally deleted/disabled seller is a tombstone. Never let an
                        // older Firebase document recreate it as active.
                        val localActive=readableDatabase.rawQuery("SELECT COALESCE(active,1) FROM sellers WHERE id=?",arrayOf(existing.toString())).use{if(it.moveToFirst())it.getInt(0) else 1}
                        val finalActive=if(localActive==0) 0 else active
                        val values=cv("name" to str("name"),"phone" to str("phone"),"username" to str("username"),"share" to share,"active" to finalActive,"remote_id" to remoteId)
                        writableDatabase.update("sellers",values,"id=?",arrayOf(existing.toString()))
                    } else {
                        val localId=lng("id"); val idExists=localId>0 && readableDatabase.rawQuery("SELECT 1 FROM sellers WHERE id=?",arrayOf(localId.toString())).use{it.moveToFirst()}
                        writableDatabase.insert("sellers",null,if(localId>0 && !idExists) cv("id" to localId,"name" to str("name"),"phone" to str("phone"),"username" to str("username"),"password" to "","share" to share,"active" to active,"remote_id" to remoteId) else cv("name" to str("name"),"phone" to str("phone"),"username" to str("username"),"password" to "","share" to share,"active" to active,"remote_id" to remoteId))
                    }
                }
                "deliveries","sales","returns","payments" -> {
                    val table=collection
                    var existing=readableDatabase.rawQuery("SELECT id FROM $table WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    val sellerId=findSeller()
                    val flowerId=if(collection=="payments")0L else findFlower()
                    if(sellerId<=0L || (collection!="payments" && flowerId<=0L)) return
                    val values=when(collection){
                        "deliveries"->cv("seller_id" to sellerId,"flower_id" to flowerId,"qty" to int("qty"),"price" to lng("price"),"created_at" to lng("created_at"),"remote_id" to remoteId)
                        "sales"->cv("seller_id" to sellerId,"flower_id" to flowerId,"qty" to int("qty"),"price" to lng("price"),"created_at" to lng("created_at"),"sync_state" to "SYNCED","seller_share_percent" to ((m["seller_share_percent"] as? Number)?.toDouble() ?: 20.0),"seller_share_amount" to lng("seller_share_amount"),"greenhouse_amount" to lng("greenhouse_amount"),"min_price_snapshot" to lng("min_price_snapshot"),"below_minimum" to int("below_minimum"),"remote_id" to remoteId)
                        "returns"->cv("seller_id" to sellerId,"flower_id" to flowerId,"qty" to int("qty"),"reason" to str("reason"),"created_at" to lng("created_at"),"remote_id" to remoteId)
                        else->cv("seller_id" to sellerId,"amount" to lng("amount"),"created_at" to lng("created_at"),"payment_date" to lng("payment_date"),"payment_type" to str("payment_type").ifBlank { "نامشخص" },"remote_id" to remoteId)
                    }
                    if(existing>0) writableDatabase.update(table,values,"id=?",arrayOf(existing.toString())) else writableDatabase.insert(table,null,values)
                }
                "petty_cash_people" -> {
                    val existing=readableDatabase.rawQuery("SELECT id FROM petty_cash_people WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}
                    val values=cv("name" to str("name"),"active" to int("active"),"remote_id" to remoteId)
                    if(existing>0) writableDatabase.update("petty_cash_people",values,"id=?",arrayOf(existing.toString())) else writableDatabase.insert("petty_cash_people",null,values)
                }
                "misc_sales" -> {
                    val existing=readableDatabase.rawQuery("SELECT id FROM misc_sales WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}; val flowerId=findFlower(); val values=cv("buyer_name" to str("buyer_name"),"flower_id" to flowerId,"qty" to int("qty"),"price" to lng("price"),"payment_type" to str("payment_type"),"petty_cash_id" to lng("petty_cash_id"),"created_at" to lng("created_at"),"sale_date" to lng("sale_date"),"remote_id" to remoteId); if(existing>0) writableDatabase.update("misc_sales",values,"id=?",arrayOf(existing.toString())) else writableDatabase.insert("misc_sales",null,values)
                }
                "greenhouse_payments" -> {
                    val existing=readableDatabase.rawQuery("SELECT id FROM greenhouse_payments WHERE remote_id=?",arrayOf(remoteId)).use{if(it.moveToFirst())it.getLong(0) else 0L}; val values=cv("recipient" to str("recipient"),"amount" to lng("amount"),"payment_type" to str("payment_type"),"petty_cash_id" to lng("petty_cash_id"),"description" to str("description"),"created_at" to lng("created_at"),"payment_date" to lng("payment_date"),"remote_id" to remoteId); if(existing>0) writableDatabase.update("greenhouse_payments",values,"id=?",arrayOf(existing.toString())) else writableDatabase.insert("greenhouse_payments",null,values)
                }
                "settings" -> {
                    if (str("id") == "app" || remoteId == "app") {
                        if (m.containsKey("app_date")) setAppDate(lng("app_date"))
                        if (m.containsKey("default_seller_share")) setDefaultSellerShare((m["default_seller_share"] as? Number)?.toDouble() ?: getDefaultSellerShare())
                    }
                }
            }
        }

        fun flowerDelivered(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM deliveries WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun flowerSold(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM sales WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun flowerReturned(s:Long,f:Long):Int=one("SELECT COALESCE(SUM(qty),0) FROM returns WHERE seller_id=? AND flower_id=?",arrayOf(s,f)).toInt()
        fun deleteSeller(id:Long){
            // Soft-delete every seller. This preserves history and prevents the next Firebase
            // pull from recreating a physically deleted seller.
            writableDatabase.update("sellers",cv("active" to 0),"id=?",arrayOf(id.toString()))
        }
        fun pettyCashPeople():List<PettyCashPerson>{val l=mutableListOf<PettyCashPerson>();readableDatabase.rawQuery("SELECT id,name FROM petty_cash_people WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())l.add(PettyCashPerson(c.getLong(0),c.getString(1)))};return l}
        fun addPettyCashPerson(name:String){writableDatabase.insert("petty_cash_people",null,cv("name" to name.trim(),"active" to 1,"remote_id" to "petty_${UUID.randomUUID()}"))}
        fun addMiscSale(buyer:String,flowerId:Long,qty:Int,price:Long,paymentType:String,pettyCashId:Long?,saleDate:Long){writableDatabase.insert("misc_sales",null,cv("buyer_name" to buyer,"flower_id" to flowerId,"qty" to qty,"price" to price,"payment_type" to paymentType,"petty_cash_id" to pettyCashId,"created_at" to appDate(),"sale_date" to saleDate,"remote_id" to "misc_${UUID.randomUUID()}"))}
        fun miscSales():List<MiscSaleRow>{val l=mutableListOf<MiscSaleRow>();readableDatabase.rawQuery("SELECT m.buyer_name,COALESCE(f.name,'گل حذف‌شده'),COALESCE(f.size,''),m.qty,m.qty*m.price,m.payment_type,p.name,COALESCE(m.sale_date,m.created_at) FROM misc_sales m LEFT JOIN flowers f ON f.id=m.flower_id LEFT JOIN petty_cash_people p ON p.id=m.petty_cash_id ORDER BY COALESCE(m.sale_date,m.created_at) DESC,m.id DESC",null).use{c->while(c.moveToNext())l.add(MiscSaleRow(c.getString(0),c.getString(1),c.getString(2),c.getInt(3),c.getLong(4),c.getString(5),c.getString(6),jalaliDate(c.getLong(7))))};return l}
        fun addGreenhousePayment(recipient:String,amount:Long,paymentType:String,pettyCashId:Long?,description:String,paymentDate:Long){writableDatabase.insert("greenhouse_payments",null,cv("recipient" to recipient,"amount" to amount,"payment_type" to paymentType,"petty_cash_id" to pettyCashId,"description" to description,"created_at" to appDate(),"payment_date" to paymentDate,"remote_id" to "ghpay_${UUID.randomUUID()}"))}
        fun greenhousePayments():List<GreenhousePaymentRow>{val l=mutableListOf<GreenhousePaymentRow>();readableDatabase.rawQuery("SELECT g.recipient,g.amount,g.payment_type,p.name,COALESCE(g.description,''),COALESCE(g.payment_date,g.created_at) FROM greenhouse_payments g LEFT JOIN petty_cash_people p ON p.id=g.petty_cash_id ORDER BY COALESCE(g.payment_date,g.created_at) DESC,g.id DESC",null).use{c->while(c.moveToNext())l.add(GreenhousePaymentRow(c.getString(0),c.getLong(1),c.getString(2),c.getString(3),c.getString(4),jalaliDate(c.getLong(5))))};return l}
        fun sellerPassword(id:Long):String=readableDatabase.rawQuery("SELECT password FROM sellers WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getString(0)?:"" else ""}
        fun verifySellerLogin(id:Long,u:String,p:String):Boolean=readableDatabase.rawQuery("SELECT 1 FROM sellers WHERE id=? AND username=? AND password=?",arrayOf(id.toString(),u,p)).use{it.moveToFirst()}
        fun verifySellerLogin(u:String,p:String):Long?=readableDatabase.rawQuery("SELECT id FROM sellers WHERE username=? AND password=? AND username<>'' AND password<>'' AND COALESCE(active,1)=1 ORDER BY id LIMIT 1",arrayOf(u,p)).use{if(it.moveToFirst())it.getLong(0) else null}
        fun adminUsername():String=settingText("admin_username","admin")
        fun adminFirebaseEmail():String=settingText("admin_firebase_email","msf@asia.com")
        fun setAdminFirebaseEmail(email:String)=setSettingText("admin_firebase_email",email.trim())
        fun setAdminCredentials(u:String,p:String){setSettingText("admin_username",u);setSettingText("admin_password",p)}
        fun adminLocalPassword():String=settingText("admin_password","")
        fun isAdminSetupDone():Boolean=settingText("admin_setup_done","0")=="1"
        fun setAdminSetupDone(){setSettingText("admin_setup_done","1")}
        fun verifyAdminLogin(u:String,p:String):Boolean=u==adminUsername()&&p==settingText("admin_password","1234")
        fun updateSellerCredentials(id:Long,u:String,p:String){writableDatabase.update("sellers",cv("username" to u,"password" to p),"id=?",arrayOf(id.toString()))}
        fun appDate():Long=settingText("app_date",System.currentTimeMillis().toString()).toLongOrNull()?:System.currentTimeMillis()
        fun setAppDate(ms:Long)=setSettingText("app_date",ms.toString())
        fun lastFirebaseSync():Long?=settingText("last_firebase_sync","").toLongOrNull()
        fun setLastFirebaseSync(ms:Long)=setSettingText("last_firebase_sync",ms.toString())
        private fun settingText(k:String,d:String):String=readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0)?:d else d}
        fun setSettingText(k:String,v:String){writableDatabase.insertWithOnConflict("settings",null,cv("key" to k,"value" to v),SQLiteDatabase.CONFLICT_REPLACE)}
        data class DetailedSaleRow(val sellerId:Long,val sellerName:String,val flowerName:String,val size:String,val qty:Int,val price:Long,val total:Long,val sellerShareAmount:Long,val date:String)
        fun detailedSales(sellerId:Long?,from:Long,to:Long):List<DetailedSaleRow>{val l=mutableListOf<DetailedSaleRow>();val extra=if(sellerId==null)"" else " AND sa.seller_id=$sellerId";readableDatabase.rawQuery("SELECT s.id,s.name,f.name,f.size,sa.qty,sa.price,sa.qty*sa.price,sa.seller_share_amount,sa.created_at FROM sales sa JOIN sellers s ON s.id=sa.seller_id JOIN flowers f ON f.id=sa.flower_id WHERE sa.created_at>=? AND sa.created_at<=?$extra ORDER BY sa.created_at DESC,sa.id DESC",arrayOf(from.toString(),to.toString())).use{c->while(c.moveToNext())l.add(DetailedSaleRow(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),c.getLong(5),c.getLong(6),c.getLong(7),jalaliDate(c.getLong(8))))};return l}
        data class PriceWarning(val type:String,val sellerName:String,val flowerName:String,val size:String,val qty:Int,val price:Long,val minPrice:Long,val date:String,val createdAt:Long)
        fun lowPriceWarningCount(sellerId:Long?):Int=priceWarnings(sellerId).size
        fun priceWarnings(sellerId:Long?):List<PriceWarning>{
            val l=mutableListOf<PriceWarning>()
            readableDatabase.rawQuery("SELECT 'فروش فروشنده',COALESCE(s.name,'فروشنده حذف‌شده'),COALESCE(f.name,'گل حذف‌شده'),COALESCE(f.size,''),sa.qty,sa.price,sa.min_price_snapshot,sa.created_at,sa.seller_id FROM sales sa LEFT JOIN sellers s ON s.id=sa.seller_id LEFT JOIN flowers f ON f.id=sa.flower_id WHERE sa.below_minimum=1 ORDER BY sa.created_at DESC,sa.id DESC",null).use{c->
                while(c.moveToNext()){
                    val seller=c.getLong(8); val price=c.getLong(5); val min=c.getLong(6)
                    if(min>0L && price<min && (sellerId==null || sellerId==seller)){
                        val ts=c.getLong(7); l.add(PriceWarning(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),price,min,jalaliDate(ts),ts))
                    }
                }
            }
            return l
        }

        private fun setting(k:String,d:Double):Double=readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?",arrayOf(k)).use{if(it.moveToFirst())it.getString(0).toDoubleOrNull()?:d else d}
        private fun one(sql:String,args:Array<Any?> = emptyArray()):Long{val a=args.map{it.toString()}.toTypedArray();readableDatabase.rawQuery(sql,a).use{it.moveToFirst();return it.getLong(0)}}
        private fun dayStart():Long{val c=Calendar.getInstance();c.timeInMillis=appDate();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.timeInMillis}
        private fun jalaliDateTime(ms:Long):String{
            val c=Calendar.getInstance().apply{timeInMillis=ms}
            return "${jalaliDate(ms)} ${"%02d:%02d".format(Locale.US,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE))}"
        }
        private fun jalaliDate(ms:Long):String{val c=Calendar.getInstance();c.timeInMillis=ms;val gy=c.get(Calendar.YEAR);val gm=c.get(Calendar.MONTH)+1;val gd=c.get(Calendar.DAY_OF_MONTH);val gdm=intArrayOf(0,31,28,31,30,31,30,31,31,30,31,30,31);var days=355666+365*gy+((gy+3)/4)-((gy+99)/100)+((gy+399)/400)+gd;for(i in 1 until gm)days+=gdm[i];if(gm>2&&isLeapGregorian(gy))days++;var jy=-1595+33*(days/12053);days%=12053;jy+=4*(days/1461);days%=1461;if(days>365){jy+=(days-1)/365;days=(days-1)%365};val jm=if(days<186)1+days/31 else 7+(days-186)/30;val jd=1+if(days<186)days%31 else(days-186)%30;return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)}
        private fun isLeapGregorian(y:Int)=y%400==0||(y%4==0&&y%100!=0)
    }
}
