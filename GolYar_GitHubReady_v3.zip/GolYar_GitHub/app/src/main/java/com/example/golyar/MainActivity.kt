package com.example.golyar

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var db: GolYarDb
    private lateinit var content: LinearLayout
    private val nf = NumberFormat.getNumberInstance(Locale.US)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = GolYarDb(this)
        showHome()
    }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
        }
        val bar = TextView(this).apply {
            text = title
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(8, 10, 8, 20)
        }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        return root
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 16f
        isAllCaps = false
        setOnClickListener { action() }
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun setScreen(root: LinearLayout) {
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun showHome() {
        val root = base("گل‌یار | مدیریت گلخانه")
        val summary = db.dashboard()
        val card = TextView(this).apply {
            text = "امروز\nتحویل: ${summary.delivered} دسته    فروش: ${summary.sold} دسته\nفروش ثبت‌شده: ${money(summary.salesAmount)} تومان\nمانده موجودی نزد فروشندگان: ${summary.stock} دسته"
            textSize = 17f
            setPadding(22, 20, 22, 20)
            gravity = Gravity.CENTER
        }
        root.addView(card)
        root.addView(button("🌹 انواع گل", ::showFlowers))
        root.addView(button("👤 فروشندگان", ::showSellers))
        root.addView(button("📦 ثبت تحویل گل", ::showDelivery))
        root.addView(button("🧾 ثبت فروش", ::showSale))
        root.addView(button("↩️ ثبت برگشت گل", ::showReturn))
        root.addView(button("💰 تسویه حساب", ::showSettlement))
        root.addView(button("📊 موجودی و گزارش‌ها", ::showReports))
        root.addView(button("⚙️ تنظیمات سهم گلخانه", ::showSettings))
        setScreen(root)
    }

    private fun showFlowers() {
        val root = base("انواع گل")
        root.addView(button("+ تعریف نوع گل") { flowerDialog(null) })
        db.flowers().forEach { f ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            val t = TextView(this).apply { text = "${f.name} | حداقل: ${money(f.minPrice)} | پایه: ${money(f.basePrice)}"; textSize = 16f; setPadding(8, 18, 8, 18) }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("ویرایش") { flowerDialog(f) })
            row.addView(button("حذف") { confirmDelete("حذف ${f.name}؟") { db.delete("flowers", f.id); showFlowers() } })
            root.addView(row)
            root.addView(divider())
        }
        root.addView(button("بازگشت") { showHome() })
        setScreen(root)
    }

    private fun flowerDialog(f: Flower?) {
        val box = formBox()
        val name = field("نام گل", f?.name ?: "")
        val base = field("قیمت پایه هر دسته", f?.basePrice?.toString() ?: "")
        val min = field("حداقل قیمت مجاز", f?.minPrice?.toString() ?: "")
        box.addView(name); box.addView(base); box.addView(min)
        AlertDialog.Builder(this).setTitle(if (f == null) "تعریف گل" else "ویرایش گل").setView(box)
            .setPositiveButton("ذخیره") { _, _ ->
                val n = name.text.toString().trim(); val b = base.text.toString().toLongOrNull() ?: 0; val m = min.text.toString().toLongOrNull() ?: 0
                if (n.isNotEmpty()) db.upsertFlower(f?.id, n, b, m)
                showFlowers()
            }.setNegativeButton("انصراف", null).show()
    }

    private fun showSellers() {
        val root = base("فروشندگان")
        root.addView(button("+ تعریف فروشنده") { sellerDialog(null) })
        db.sellers().forEach { s ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            val stock = db.sellerStock(s.id)
            val t = TextView(this).apply { text = "${s.name} | ${s.phone}\nموجودی: $stock دسته"; textSize = 16f; setPadding(8, 18, 8, 18) }
            row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("ویرایش") { sellerDialog(s) })
            root.addView(row); root.addView(divider())
        }
        root.addView(button("بازگشت") { showHome() }); setScreen(root)
    }

    private fun sellerDialog(s: Seller?) {
        val box = formBox(); val name = field("نام فروشنده", s?.name ?: ""); val phone = field("شماره تماس", s?.phone ?: "")
        box.addView(name); box.addView(phone)
        AlertDialog.Builder(this).setTitle(if (s == null) "فروشنده جدید" else "ویرایش فروشنده").setView(box)
            .setPositiveButton("ذخیره") { _, _ -> if (name.text.isNotBlank()) db.upsertSeller(s?.id, name.text.toString(), phone.text.toString()); showSellers() }
            .setNegativeButton("انصراف", null).show()
    }

    private fun showDelivery() {
        val root = base("ثبت تحویل گل")
        val flowers = db.flowers(); val sellers = db.sellers()
        if (flowers.isEmpty() || sellers.isEmpty()) { info("ابتدا حداقل یک گل و یک فروشنده تعریف کنید."); return }
        val seller = spinner("فروشنده", sellers.map { it.name }); val flower = spinner("نوع گل", flowers.map { it.name }); val qty = field("تعداد دسته", "")
        root.addView(seller); root.addView(flower); root.addView(qty); root.addView(button("ثبت تحویل") {
            val q = qty.text.toString().toIntOrNull() ?: 0
            if (q <= 0) { info("تعداد نامعتبر است."); return@button }
            db.addDelivery(sellers[seller.selectedItemPosition].id, flowers[flower.selectedItemPosition].id, q)
            info("تحویل ثبت شد.") { showHome() }
        }); root.addView(button("بازگشت") { showHome() }); setScreen(root)
    }

    private fun showSale() {
        val root = base("ثبت فروش")
        val flowers = db.flowers(); val sellers = db.sellers()
        if (flowers.isEmpty() || sellers.isEmpty()) { info("ابتدا گل و فروشنده تعریف کنید."); return }
        val seller = spinner("فروشنده", sellers.map { it.name }); val flower = spinner("نوع گل", flowers.map { it.name }); val qty = field("تعداد دسته", ""); val price = field("قیمت هر دسته (تومان)", "")
        val stockText = TextView(this).apply { textSize = 15f; setPadding(0, 12, 0, 12) }
        fun refreshStock() { stockText.text = "موجودی فروشنده: ${db.sellerFlowerStock(sellers[seller.selectedItemPosition].id, flowers[flower.selectedItemPosition].id)} دسته" }
        seller.setOnItemSelectedListener(simpleListener { refreshStock() }); flower.setOnItemSelectedListener(simpleListener { refreshStock() }); refreshStock()
        root.addView(seller); root.addView(flower); root.addView(stockText); root.addView(qty); root.addView(price)
        root.addView(button("ثبت فروش") {
            val q = qty.text.toString().toIntOrNull() ?: 0; val p = price.text.toString().toLongOrNull() ?: 0
            val s = sellers[seller.selectedItemPosition]; val f = flowers[flower.selectedItemPosition]; val stock = db.sellerFlowerStock(s.id, f.id)
            if (q <= 0 || p <= 0) { info("تعداد و قیمت را صحیح وارد کنید."); return@button }
            if (q > stock) { info("موجودی کافی نیست. موجودی فعلی: $stock دسته"); return@button }
            if (p < f.minPrice) {
                AlertDialog.Builder(this).setTitle("هشدار قیمت").setMessage("قیمت واردشده پایین‌تر از حداقل مجاز (${money(f.minPrice)} تومان) است. ثبت شود؟")
                    .setNegativeButton("لغو", null).setPositiveButton("ثبت") { _, _ -> saveSale(s.id, f.id, q, p) }.show()
            } else saveSale(s.id, f.id, q, p)
        })
        root.addView(button("بازگشت") { showHome() }); setScreen(root)
    }

    private fun saveSale(sellerId: Long, flowerId: Long, qty: Int, price: Long) { db.addSale(sellerId, flowerId, qty, price); info("فروش ثبت شد.") { showHome() } }

    private fun showReturn() {
        val root = base("ثبت برگشت گل")
        val flowers = db.flowers(); val sellers = db.sellers()
        if (flowers.isEmpty() || sellers.isEmpty()) { info("ابتدا اطلاعات پایه را وارد کنید."); return }
        val seller = spinner("فروشنده", sellers.map { it.name }); val flower = spinner("نوع گل", flowers.map { it.name }); val qty = field("تعداد دسته برگشتی", ""); val reason = field("علت برگشت", "فروش نرفته / خراب / کیفیت / سایر")
        root.addView(seller); root.addView(flower); root.addView(qty); root.addView(reason)
        root.addView(button("ثبت برگشت") {
            val q = qty.text.toString().toIntOrNull() ?: 0; val s = sellers[seller.selectedItemPosition]; val f = flowers[flower.selectedItemPosition]
            if (q <= 0 || q > db.sellerFlowerStock(s.id, f.id)) { info("تعداد برگشتی بیشتر از موجودی است."); return@button }
            db.addReturn(s.id, f.id, q, reason.text.toString()); info("برگشت ثبت شد.") { showHome() }
        }); root.addView(button("بازگشت") { showHome() }); setScreen(root)
    }

    private fun showSettlement() {
        val root = base("تسویه حساب")
        val sellers = db.sellers(); if (sellers.isEmpty()) { info("فروشنده‌ای ثبت نشده است."); return }
        sellers.forEach { s ->
            val due = db.sellerDue(s.id); val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            row.addView(TextView(this).apply { text = "${s.name}\nسهم فروشنده از فروش: ${money(due)} تومان"; textSize = 16f; setPadding(8, 15, 8, 15) }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(button("پرداخت") { paymentDialog(s) }); root.addView(row); root.addView(divider())
        }
        root.addView(button("بازگشت") { showHome() }); setScreen(root)
    }

    private fun paymentDialog(s: Seller) {
        val box = formBox(); val amount = field("مبلغ پرداختی", ""); box.addView(amount)
        AlertDialog.Builder(this).setTitle("پرداخت به ${s.name}").setView(box).setPositiveButton("ثبت") { _, _ -> val a = amount.text.toString().toLongOrNull() ?: 0; if (a > 0) db.addPayment(s.id, a); showSettlement() }.setNegativeButton("انصراف", null).show()
    }

    private fun showReports() {
        val root = base("موجودی و گزارش‌ها")
        val d = db.dashboard()
        root.addView(TextView(this).apply { text = "خلاصه کل\n\nتحویل: ${d.delivered} دسته\nفروش: ${d.sold} دسته\nبرگشت: ${d.returned} دسته\nمبلغ فروش: ${money(d.salesAmount)} تومان\nموجودی نزد فروشندگان: ${d.stock} دسته"; textSize = 18f; setPadding(8, 8, 8, 25) })
        root.addView(TextView(this).apply { text = "موجودی تفکیکی فروشندگان"; textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, 10, 0, 12) })
        db.sellers().forEach { s -> root.addView(TextView(this).apply { text = "${s.name}: ${db.sellerStock(s.id)} دسته | بدهی تسویه: ${money(db.sellerDue(s.id))} تومان"; textSize = 16f; setPadding(0, 8, 0, 8) }) }
        root.addView(button("بازگشت") { showHome() }); setScreen(root)
    }

    private fun showSettings() {
        val root = base("تنظیمات")
        val current = db.getShare()
        val share = field("درصد سهم گلخانه از فروش", current.toString())
        root.addView(TextView(this).apply { text = "در مدل فعلی، سهم فروشنده = 100٪ - سهم گلخانه است."; textSize = 15f; setPadding(0, 0, 0, 15) })
        root.addView(share)
        root.addView(button("ذخیره سهم") { val v = share.text.toString().toDoubleOrNull(); if (v != null && v in 0.0..100.0) { db.setShare(v); info("تنظیمات ذخیره شد.") } else info("درصد باید بین صفر تا صد باشد.") })
        root.addView(button("بازگشت") { showHome() }); setScreen(root)
    }

    private fun formBox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 4, 12, 4); layoutDirection = View.LAYOUT_DIRECTION_RTL }
    private fun field(hint: String, value: String): EditText = EditText(this).apply { this.hint = hint; setText(value); inputType = android.text.InputType.TYPE_CLASS_TEXT; setPadding(8, 10, 8, 10) }
    private fun spinner(label: String, items: List<String>): Spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items); contentDescription = label; layoutDirection = View.LAYOUT_DIRECTION_RTL }
    private fun divider() = Space(this).apply { minimumHeight = 4 }
    private fun simpleListener(fn: () -> Unit) = object : AdapterView.OnItemSelectedListener { override fun onNothingSelected(p: AdapterView<*>?) {}; override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { fn() } }
    private fun money(v: Long) = nf.format(v)
    private fun confirmDelete(msg: String, action: () -> Unit) { AlertDialog.Builder(this).setMessage(msg).setNegativeButton("انصراف", null).setPositiveButton("حذف") { _, _ -> action() }.show() }
    private fun info(msg: String, after: (() -> Unit)? = null) { AlertDialog.Builder(this).setMessage(msg).setPositiveButton("باشه") { _, _ -> after?.invoke() }.show() }

    data class Flower(val id: Long, val name: String, val basePrice: Long, val minPrice: Long)
    data class Seller(val id: Long, val name: String, val phone: String)
    data class Dash(val delivered: Int, val sold: Int, val returned: Int, val salesAmount: Long, val stock: Int)

    class GolYarDb(ctx: Context) : SQLiteOpenHelper(ctx, "golyar.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE flowers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,base_price INTEGER NOT NULL,min_price INTEGER NOT NULL)")
            db.execSQL("CREATE TABLE sellers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT)")
            db.execSQL("CREATE TABLE deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,created_at INTEGER)")
            db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,price INTEGER,created_at INTEGER)")
            db.execSQL("CREATE TABLE returns(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,flower_id INTEGER,qty INTEGER,reason TEXT,created_at INTEGER)")
            db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,amount INTEGER,created_at INTEGER)")
            db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT)")
            db.execSQL("INSERT INTO settings(key,value) VALUES('greenhouse_share','80')")
        }
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
        private fun cv(vararg p: Pair<String, Any?>): ContentValues = ContentValues().also { p.forEach { (k,v) -> when(v){is String->it.put(k,v);is Int->it.put(k,v);is Long->it.put(k,v);is Double->it.put(k,v);null->it.putNull(k)} } }
        fun upsertFlower(id: Long?, name: String, base: Long, min: Long) { val v=cv("name" to name,"base_price" to base,"min_price" to min); if(id==null) writableDatabase.insert("flowers",null,v) else writableDatabase.update("flowers",v,"id=?",arrayOf(id.toString())) }
        fun upsertSeller(id: Long?, name: String, phone: String) { val v=cv("name" to name,"phone" to phone); if(id==null) writableDatabase.insert("sellers",null,v) else writableDatabase.update("sellers",v,"id=?",arrayOf(id.toString())) }
        fun flowers(): List<Flower> { val list=mutableListOf<Flower>(); q("SELECT * FROM flowers ORDER BY name"){ c -> list.add(Flower(c.getLong(0),c.getString(1),c.getLong(2),c.getLong(3))) }; return list }
        fun sellers(): List<Seller> { val list=mutableListOf<Seller>(); q("SELECT * FROM sellers ORDER BY name"){ c -> list.add(Seller(c.getLong(0),c.getString(1),c.getString(2))) }; return list }
        private fun q(sql:String, block:(android.database.Cursor)->Unit){ readableDatabase.rawQuery(sql,null).use{while(it.moveToNext()) block(it)} }
        fun delete(table:String,id:Long){writableDatabase.delete(table,"id=?",arrayOf(id.toString()))}
        fun addDelivery(s:Long,f:Long,q:Int){writableDatabase.insert("deliveries",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"created_at" to System.currentTimeMillis()))}
        fun addSale(s:Long,f:Long,q:Int,p:Long){writableDatabase.insert("sales",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"price" to p,"created_at" to System.currentTimeMillis()))}
        fun addReturn(s:Long,f:Long,q:Int,r:String){writableDatabase.insert("returns",null,cv("seller_id" to s,"flower_id" to f,"qty" to q,"reason" to r,"created_at" to System.currentTimeMillis()))}
        fun addPayment(s:Long,a:Long){writableDatabase.insert("payments",null,cv("seller_id" to s,"amount" to a,"created_at" to System.currentTimeMillis()))}
        fun sellerFlowerStock(s:Long,f:Long):Int { return one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=? AND flower_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=? AND flower_id=?),0)",arrayOf(s,f,s,f,s,f)).toInt() }
        fun sellerStock(s:Long):Int = one("SELECT COALESCE((SELECT SUM(qty) FROM deliveries WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM sales WHERE seller_id=?),0)-COALESCE((SELECT SUM(qty) FROM returns WHERE seller_id=?),0)",arrayOf(s,s,s)).toInt()
        fun sellerDue(s:Long):Long { val total=one("SELECT COALESCE(SUM(qty*price),0) FROM sales WHERE seller_id=?",arrayOf(s)); val sellerShare=total*(100.0-getShare())/100.0; val paid=one("SELECT COALESCE(SUM(amount),0) FROM payments WHERE seller_id=?",arrayOf(s)); return (sellerShare-paid).toLong() }
        fun dashboard():Dash { return Dash(one("SELECT COALESCE(SUM(qty),0) FROM deliveries"),one("SELECT COALESCE(SUM(qty),0) FROM sales"),one("SELECT COALESCE(SUM(qty),0) FROM returns"),one("SELECT COALESCE(SUM(qty*price),0) FROM sales"),one("SELECT COALESCE(SUM(qty),0) FROM deliveries")-one("SELECT COALESCE(SUM(qty),0) FROM sales")-one("SELECT COALESCE(SUM(qty),0) FROM returns")) }
        private fun one(sql:String,args:Array<Any?> = emptyArray()):Long { val a=args.map{it.toString()}.toTypedArray(); readableDatabase.rawQuery(sql,a).use{it.moveToFirst();return it.getLong(0)} }
        fun getShare():Double = readableDatabase.rawQuery("SELECT value FROM settings WHERE key='greenhouse_share'",null).use{if(it.moveToFirst()) it.getString(0).toDoubleOrNull()?:80.0 else 80.0}
        fun setShare(v:Double){writableDatabase.update("settings",cv("value" to v.toString()),"key='greenhouse_share'",null)}
    }
}
