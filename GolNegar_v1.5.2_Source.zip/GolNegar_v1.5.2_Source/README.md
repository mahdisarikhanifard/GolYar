

## Release 1.5.2

Build version: 1.5.2 (versionCode 82). This package preserves the draggable circular home wheel and includes regression checks for financial list contrast, back navigation, expense/sale ledgers, and seller-sync wiring. APK compilation is performed by the included GitHub Actions workflow.
