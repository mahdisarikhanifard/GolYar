

## Release 1.5.3

Build version: 1.5.3 (versionCode 83). This revision applies the requested visual changes in source: a transparent pale-rose launcher icon with the app label «گل نگار», smaller and more widely spaced draggable radial-menu circles without an outer frame, corrected status/navigation-bar insets so the title remains visible and the bottom navigation/back buttons sit above the system bar. The existing financial, navigation, and Firebase regression checks are retained. APK compilation must be confirmed by GitHub Actions.
